--
-- PostgreSQL database dump
--

\restrict lRuYNpkQDUpeGZEqsQHf2Fil7DwhSfw3yfecYV3QSRAIk5i6ON9FLABcdxELffk

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.bookings VALUES (1, 1, 'Lawn Care', 1, 1, 'Layton Martinez', 'completed', '2026-06-10', '9:00 AM', '123 Tamiami Trl', '33950', 45.00, 'Front and back yard', false, NULL, '2026-06-25 21:02:28.42883');
INSERT INTO public.bookings VALUES (2, 2, 'Pool Services', 1, 6, 'Janet Williams', 'confirmed', '2026-06-28', '7:00 AM', '123 Tamiami Trl', '33950', 99.00, NULL, true, 'monthly', '2026-06-25 21:02:28.42883');
INSERT INTO public.bookings VALUES (3, 5, 'HVAC Services', 1, 2, 'Mike Torres', 'pending', '2026-07-02', '11:00 AM', '123 Tamiami Trl', '33950', 250.00, NULL, false, NULL, '2026-06-25 21:02:28.42883');
INSERT INTO public.bookings VALUES (4, 8, 'Cleaning', 1, 3, 'Sarah Perkins', 'assigned', '2026-06-30', '9:00 AM', '123 Tamiami Trl', '33950', 120.00, NULL, false, NULL, '2026-06-25 21:02:28.42883');
INSERT INTO public.bookings VALUES (5, 1, 'Lawn Care', 1, 1, 'Layton Martinez', 'completed', '2026-05-20', '9:00 AM', '123 Tamiami Trl', '33950', 45.00, NULL, false, NULL, '2026-06-25 21:02:28.42883');


--
-- Data for Name: contractors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.contractors VALUES (1, 'Layton Martinez', 'Layton''s Lawn Care', '{"Lawn Care"}', 'Local teen entrepreneur delivering $45/visit lawn care. Serving Punta Gorda and Port Charlotte.', 4.90, 47, 312, true, '{"Punta Gorda","Port Charlotte"}', '941-555-0101', 'layton@laytonlawn.com', NULL, 14500.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');
INSERT INTO public.contractors VALUES (2, 'Mike Torres', 'Torres HVAC Solutions', '{HVAC,Electrical}', '15+ years HVAC experience. Licensed and insured. Same-day service available.', 4.80, 89, 521, true, '{"Port Charlotte","Deep Creek","North Port"}', '941-555-0102', 'mike@torreshvac.com', NULL, 67200.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');
INSERT INTO public.contractors VALUES (3, 'Sarah Perkins', 'Sparkling Clean FL', '{Cleaning,Handyman}', 'Residential and vacation rental cleaning specialist with 5-star reviews.', 5.00, 134, 789, true, '{"Punta Gorda","Charlotte Harbor","Burnt Store"}', '941-555-0103', 'sarah@sparklingclean.com', NULL, 42300.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');
INSERT INTO public.contractors VALUES (4, 'David Chen', 'Chen Plumbing & Electric', '{Plumbing,Electrical}', NULL, 4.70, 62, 283, true, '{"Port Charlotte","Punta Gorda","North Port"}', '941-555-0104', 'david@chenpe.com', NULL, 31800.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');
INSERT INTO public.contractors VALUES (5, 'Roberto Vega', 'Vega Construction', '{Construction,Roofing,Painting}', NULL, 4.90, 45, 198, true, '{"All Southwest Florida"}', '941-555-0105', 'roberto@vegaconstruction.com', NULL, 89400.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');
INSERT INTO public.contractors VALUES (6, 'Janet Williams', 'Williams Pool Care', '{"Pool Services"}', NULL, 4.80, 78, 456, true, '{"Punta Gorda","Burnt Store","Port Charlotte"}', '941-555-0106', 'janet@williamspool.com', NULL, 38900.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');
INSERT INTO public.contractors VALUES (7, 'Tom Hargrove', 'Hargrove Handyman', '{Handyman,Painting,Cleaning}', NULL, 4.60, 33, 156, false, '{"Deep Creek","North Port","Port Charlotte"}', '941-555-0107', 'tom@hargrovehandyman.com', NULL, 12400.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');
INSERT INTO public.contractors VALUES (8, 'Ana Rodriguez', 'Rodriguez Roofing', '{Roofing,Construction}', NULL, 4.90, 21, 88, true, '{"Charlotte Harbor","Port Charlotte","Punta Gorda"}', '941-555-0108', 'ana@rodriguezroofing.com', NULL, 45600.00, 'active', NULL, NULL, '2026-06-25 21:02:28.421239');


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.conversations VALUES (1, 1, 2, 'Layton Martinez', 'Contractor — Lawn Care', 'I''ll be there at 9am sharp. Gate code still 1234?', '2026-06-25 20:32:28.451', 1, NULL);
INSERT INTO public.conversations VALUES (2, 1, 3, 'Sarah Perkins', 'Contractor — Cleaning', 'Your home is all cleaned up! Left invoice in the app.', '2026-06-25 19:02:28.451', 0, NULL);
INSERT INTO public.conversations VALUES (3, 1, 6, 'BuyShare Support', 'Platform Support', 'Your issue has been resolved. Is there anything else?', '2026-06-24 21:02:28.451', 0, NULL);


--
-- Data for Name: earntree_earnings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: earntree_goals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: growth_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.growth_metrics VALUES (1, 'Jan', 42, 15800.00, 28, 156, '2026-06-25 21:02:28.447432');
INSERT INTO public.growth_metrics VALUES (2, 'Feb', 58, 21200.00, 31, 198, '2026-06-25 21:02:28.447432');
INSERT INTO public.growth_metrics VALUES (3, 'Mar', 87, 33400.00, 38, 267, '2026-06-25 21:02:28.447432');
INSERT INTO public.growth_metrics VALUES (4, 'Apr', 124, 47800.00, 45, 342, '2026-06-25 21:02:28.447432');
INSERT INTO public.growth_metrics VALUES (5, 'May', 178, 68900.00, 52, 431, '2026-06-25 21:02:28.447432');
INSERT INTO public.growth_metrics VALUES (6, 'Jun', 234, 91200.00, 61, 518, '2026-06-25 21:02:28.447432');


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.invoices VALUES (1, 1, 45.00, 'paid', '2026-06-15', NULL, 'Lawn Care Service — June 10', '2026-06-25 21:02:28.477277');
INSERT INTO public.invoices VALUES (2, 2, 99.00, 'paid', '2026-06-20', NULL, 'Monthly Pool Care — June', '2026-06-25 21:02:28.477277');
INSERT INTO public.invoices VALUES (3, 4, 120.00, 'sent', '2026-07-05', NULL, 'House Cleaning — June 30', '2026-06-25 21:02:28.477277');
INSERT INTO public.invoices VALUES (4, 3, 279.00, 'draft', '2026-07-10', NULL, 'HVAC Service — July 2', '2026-06-25 21:02:28.477277');


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.leads VALUES (1, 'Patricia Davidson', '941-555-2001', 'patricia@email.com', 'Pool Services', 'Need weekly pool maintenance for my 3BR home in Punta Gorda.', 'booked', 'phone', 'Interested in monthly pool care plan. Budget around $100/mo. Has existing pool equipment.', 1188.00, '33950', '2026-06-25 21:02:28.441972');
INSERT INTO public.leads VALUES (2, 'Carl Washington', '941-555-2002', 'carl@email.com', 'HVAC Services', 'AC isn''t cooling properly. Need someone ASAP.', 'contacted', 'sms', 'Emergency HVAC situation. Unit may need refrigerant recharge or capacitor replacement. Urgency: high.', 450.00, '33952', '2026-06-25 21:02:28.441972');
INSERT INTO public.leads VALUES (3, 'Maria Santos', '941-555-2003', NULL, 'Lawn Care', 'Looking for weekly lawn service for my property.', 'new', 'website', 'New lead for recurring lawn care service. Has 1/4 acre lot.', 2340.00, '33983', '2026-06-25 21:02:28.441972');
INSERT INTO public.leads VALUES (4, 'James Kowalski', '941-555-2004', 'jkowalski@email.com', 'Cleaning', 'Need house cleaning service for vacation rental turnover.', 'qualified', 'referral', 'Vacation rental turnover cleaning needed bi-weekly. High-value recurring client potential.', 5200.00, '33950', '2026-06-25 21:02:28.441972');
INSERT INTO public.leads VALUES (5, 'Betty Harmon', '941-555-2005', NULL, 'Handyman', 'Several small repairs needed around the house. Fence, deck, and gutters.', 'new', 'phone', 'Multiple handyman tasks. Fence repair, deck boards, gutter cleaning. Estimated 8 hours of work.', 600.00, '33980', '2026-06-25 21:02:28.441972');
INSERT INTO public.leads VALUES (6, 'Steve Nguyen', '941-555-2006', NULL, 'Pool Services', 'New homeowner. Need someone to set up my pool chemistry and maintenance plan.', 'new', 'website', 'New homeowner wanting pool setup and monthly maintenance. High conversion likelihood.', 1188.00, '33955', '2026-06-25 21:02:28.441972');


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.messages VALUES (1, 1, 2, 'Layton Martinez', 'Hi! Just confirming your lawn appointment for tomorrow.', '2026-06-25 21:02:28.465204', false);
INSERT INTO public.messages VALUES (2, 1, 1, 'You', 'Yes, please! Gate code is 1234.', '2026-06-25 21:02:28.465204', true);
INSERT INTO public.messages VALUES (3, 1, 2, 'Layton Martinez', 'I''ll be there at 9am sharp. Gate code still 1234?', '2026-06-25 21:02:28.465204', false);
INSERT INTO public.messages VALUES (4, 2, 3, 'Sarah Perkins', 'Just arrived and getting started!', '2026-06-25 21:02:28.465204', false);
INSERT INTO public.messages VALUES (5, 2, 1, 'You', 'Thanks, Sarah! Extra attention to the kitchen please.', '2026-06-25 21:02:28.465204', true);
INSERT INTO public.messages VALUES (6, 2, 3, 'Sarah Perkins', 'Your home is all cleaned up! Left invoice in the app.', '2026-06-25 21:02:28.465204', false);


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.payments VALUES (1, 45.00, 'Lawn Care — Layton''s Lawn Care', 'completed', 'charge', NULL, NULL, '2026-06-25 21:02:28.470398');
INSERT INTO public.payments VALUES (2, 99.00, 'Monthly Pool Care — Janet Williams', 'completed', 'charge', NULL, NULL, '2026-06-25 21:02:28.470398');
INSERT INTO public.payments VALUES (3, 120.00, 'House Cleaning — Sarah Perkins', 'completed', 'charge', NULL, NULL, '2026-06-25 21:02:28.470398');
INSERT INTO public.payments VALUES (4, 1200.00, 'Contractor Payout — Layton Martinez', 'completed', 'payout', NULL, NULL, '2026-06-25 21:02:28.470398');
INSERT INTO public.payments VALUES (5, 250.00, 'BuyShare Credits', 'completed', 'credit', NULL, NULL, '2026-06-25 21:02:28.470398');
INSERT INTO public.payments VALUES (6, 279.00, 'HVAC Services — Mike Torres (pending)', 'pending', 'charge', NULL, NULL, '2026-06-25 21:02:28.470398');


--
-- Data for Name: playdate_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: rideshare_trips; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.services VALUES (1, 'Lawn Care', 'Lawn Care', 'Professional lawn mowing, edging, and cleanup.', 45.00, 'visit', 'Leaf', 12);
INSERT INTO public.services VALUES (2, 'Pool Services', 'Pool Services', 'Full-service pool care — chemicals, cleaning, and maintenance.', 99.00, 'mo', 'Droplets', 8);
INSERT INTO public.services VALUES (3, 'Pool + Lawn Bundle', 'Pool Services', 'Pool and lawn care combo — best value.', 180.00, 'mo', 'Droplets', 5);
INSERT INTO public.services VALUES (4, 'Local Delivery', 'Delivery', 'Flat-rate hauling and delivery services.', 75.00, 'job', 'Truck', 4);
INSERT INTO public.services VALUES (5, 'HVAC Services', 'HVAC', 'Heating, ventilation, and air conditioning installation and repair.', 125.00, 'hr', 'Wind', 18);
INSERT INTO public.services VALUES (6, 'Plumbing', 'Plumbing', 'All plumbing repairs, installations, and emergencies.', 95.00, 'hr', 'Wrench', 14);
INSERT INTO public.services VALUES (7, 'Electrical', 'Electrical', 'Licensed electrical services for residential and commercial.', 110.00, 'hr', 'Zap', 11);
INSERT INTO public.services VALUES (8, 'Cleaning', 'Cleaning', 'Professional home and office cleaning services.', 85.00, 'visit', 'Sparkles', 22);
INSERT INTO public.services VALUES (9, 'Painting', 'Painting', 'Interior and exterior painting with premium finishes.', 350.00, 'room', 'Paintbrush', 9);
INSERT INTO public.services VALUES (10, 'Roofing', 'Roofing', 'Roof repair, replacement, and inspection services.', 450.00, 'job', 'Home', 7);
INSERT INTO public.services VALUES (11, 'Handyman', 'Handyman', 'General repairs, installations, and home improvements.', 75.00, 'hr', 'Hammer', 16);
INSERT INTO public.services VALUES (12, 'Construction', 'Construction', 'Full construction, renovation, and remodeling.', 85.00, 'hr', 'Hammer', 6);


--
-- Data for Name: share_listings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.share_listings VALUES (1, 'Luxury Pool & Lanai — Punta Gorda', 'pools', 'Crystal clear heated pool with sun shelf, full lanai, seating for 12. Perfect for family gatherings.', 150.00, 'day', 'Punta Gorda, FL', '33950', NULL, 'The Johnson Family', 4.90, 34, NULL, '{Heated,"Sun Shelf",Lanai,Parking,WiFi}', true, '2026-06-25 21:02:28.436436');
INSERT INTO public.share_listings VALUES (2, 'Waterfront Home — Charlotte Harbor', 'homes', '3BR/2BA waterfront home with private dock. Breathtaking views, fully furnished.', 285.00, 'night', 'Charlotte Harbor, FL', '33980', NULL, 'Harbor Stay LLC', 4.80, 22, NULL, '{Dock,Waterfront,"Fully Furnished",Kayaks,Parking}', true, '2026-06-25 21:02:28.436436');
INSERT INTO public.share_listings VALUES (3, '25ft Sea Ray Bowrider', 'boats', 'Stunning bowrider perfect for coastal cruising. Life jackets and basic gear included.', 320.00, 'day', 'Port Charlotte, FL', '33952', NULL, 'Dave''s Marine Rentals', 5.00, 18, NULL, '{"Life Jackets",Cooler,"Fuel Included","Safety Kit"}', true, '2026-06-25 21:02:28.436436');
INSERT INTO public.share_listings VALUES (4, 'Covered RV Parking — Deep Creek', 'parking', 'Secure covered parking space for RV, boat, or trailer. 24/7 access, gated community.', 85.00, 'month', 'Deep Creek, FL', '33983', NULL, 'Martinez Family', 4.70, 8, NULL, '{Covered,Gated,"24/7 Access","Security Camera"}', true, '2026-06-25 21:02:28.436436');
INSERT INTO public.share_listings VALUES (5, 'Private Backyard Oasis — North Port', 'yards', 'Large private yard with fire pit, outdoor kitchen, and string lights. Perfect for events.', 95.00, 'day', 'North Port, FL', '34286', NULL, 'The Reyes Family', 4.60, 11, NULL, '{"Fire Pit","Outdoor Kitchen","String Lights","Restroom Access"}', true, '2026-06-25 21:02:28.436436');
INSERT INTO public.share_listings VALUES (6, 'Class A Motorhome — Burnt Store', 'rvs', 'Fully equipped 38ft Class A motorhome. Full hookups, slides out, theater seating.', 195.00, 'night', 'Burnt Store, FL', '33955', NULL, 'Campbell Adventures', 4.80, 14, NULL, '{"Full Hookups",Slides,Generator,"Fully Stocked"}', true, '2026-06-25 21:02:28.436436');
INSERT INTO public.share_listings VALUES (7, 'Pool & Spa Combo — Port Charlotte', 'pools', 'Saltwater pool with heated spa. Grill and outdoor furniture included.', 175.00, 'day', 'Port Charlotte, FL', '33948', NULL, 'Garcia Family', 4.90, 28, NULL, '{Saltwater,"Heated Spa",Grill,"Outdoor Furniture"}', true, '2026-06-25 21:02:28.436436');
INSERT INTO public.share_listings VALUES (8, 'Gulf Access Pontoon Boat', 'boats', '22ft pontoon perfect for family fun on the water. Up to 10 passengers.', 250.00, 'day', 'Charlotte Harbor, FL', '33980', NULL, 'Sunshine Boat Club', 4.70, 31, NULL, '{"Gulf Access","10 Passengers","Bluetooth Speaker",Cooler}', true, '2026-06-25 21:02:28.436436');


--
-- Data for Name: thriftgirl_listings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users VALUES (1, 'Demo User', 'demo@buyshare.co', '941-555-0001', 'customer', NULL, NULL, 250.00, '2026-06-25 21:02:28.27921');


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bookings_id_seq', 5, true);


--
-- Name: contractors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contractors_id_seq', 8, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 3, true);


--
-- Name: earntree_earnings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.earntree_earnings_id_seq', 1, false);


--
-- Name: earntree_goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.earntree_goals_id_seq', 1, false);


--
-- Name: growth_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.growth_metrics_id_seq', 6, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 4, true);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leads_id_seq', 6, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 6, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 6, true);


--
-- Name: playdate_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.playdate_events_id_seq', 1, false);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- Name: rideshare_trips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rideshare_trips_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 12, true);


--
-- Name: share_listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.share_listings_id_seq', 8, true);


--
-- Name: thriftgirl_listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.thriftgirl_listings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- PostgreSQL database dump complete
--

\unrestrict lRuYNpkQDUpeGZEqsQHf2Fil7DwhSfw3yfecYV3QSRAIk5i6ON9FLABcdxELffk

