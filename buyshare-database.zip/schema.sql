--
-- PostgreSQL database dump
--

\restrict X1wI7wQfAPLPFm4XoZ747mEGiy20P3yEpkS30ALbR25sfF1RsjnnfefJjinG5qK

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: booking_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.booking_status AS ENUM (
    'pending',
    'confirmed',
    'assigned',
    'en_route',
    'in_progress',
    'completed',
    'cancelled'
);


--
-- Name: contractor_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.contractor_status AS ENUM (
    'active',
    'pending',
    'suspended'
);


--
-- Name: earntree_source; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.earntree_source AS ENUM (
    'share_rental',
    'referral',
    'contractor_bonus',
    'platform_credit',
    'thriftgirl_sale',
    'rideshare_payout',
    'playdate_hosting',
    'review_bonus',
    'signup_bonus'
);


--
-- Name: invoice_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invoice_status AS ENUM (
    'draft',
    'sent',
    'paid',
    'overdue'
);


--
-- Name: lead_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.lead_status AS ENUM (
    'new',
    'contacted',
    'qualified',
    'booked',
    'lost'
);


--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_status AS ENUM (
    'pending',
    'completed',
    'failed',
    'refunded'
);


--
-- Name: payment_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_type AS ENUM (
    'charge',
    'payout',
    'refund',
    'credit'
);


--
-- Name: playdate_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.playdate_type AS ENUM (
    'park_meetup',
    'indoor_play',
    'sports',
    'arts_crafts',
    'music',
    'swimming',
    'tutoring',
    'birthday_party',
    'nature_walk',
    'playgroup'
);


--
-- Name: rideshare_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.rideshare_status AS ENUM (
    'open',
    'matched',
    'en_route',
    'picked_up',
    'completed',
    'cancelled'
);


--
-- Name: thriftgirl_category; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.thriftgirl_category AS ENUM (
    'clothing',
    'shoes',
    'accessories',
    'home_decor',
    'electronics',
    'toys',
    'books',
    'vintage',
    'handmade',
    'other'
);


--
-- Name: thriftgirl_condition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.thriftgirl_condition AS ENUM (
    'new_with_tags',
    'like_new',
    'good',
    'fair',
    'poor'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'customer',
    'contractor',
    'dispatcher',
    'partner',
    'investor',
    'admin'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    admin_id integer,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id integer,
    details text,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    service_id integer NOT NULL,
    service_name text NOT NULL,
    customer_id integer NOT NULL,
    contractor_id integer,
    contractor_name text,
    status public.booking_status DEFAULT 'pending'::public.booking_status NOT NULL,
    scheduled_date text NOT NULL,
    scheduled_time text NOT NULL,
    address text NOT NULL,
    zip_code text NOT NULL,
    price numeric(10,2),
    notes text,
    is_recurring boolean DEFAULT false NOT NULL,
    recurring_frequency text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: contractors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contractors (
    id integer NOT NULL,
    name text NOT NULL,
    company text,
    categories text[] DEFAULT '{}'::text[] NOT NULL,
    bio text,
    rating numeric(3,2) DEFAULT 5.0 NOT NULL,
    review_count integer DEFAULT 0 NOT NULL,
    jobs_completed integer DEFAULT 0 NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    service_areas text[] DEFAULT '{}'::text[] NOT NULL,
    phone text,
    email text NOT NULL,
    avatar_url text,
    earnings numeric(12,2) DEFAULT '0'::numeric,
    status public.contractor_status DEFAULT 'pending'::public.contractor_status NOT NULL,
    license_number text,
    insurance_provider text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: contractors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contractors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contractors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contractors_id_seq OWNED BY public.contractors.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    participant1_id integer NOT NULL,
    participant2_id integer NOT NULL,
    participant_name text NOT NULL,
    participant_role text NOT NULL,
    last_message text DEFAULT ''::text NOT NULL,
    last_message_at timestamp without time zone DEFAULT now() NOT NULL,
    unread_count integer DEFAULT 0 NOT NULL,
    avatar_url text
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: earntree_earnings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.earntree_earnings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    source public.earntree_source NOT NULL,
    amount numeric(10,2) NOT NULL,
    description text NOT NULL,
    referral_code text,
    referred_user_id integer,
    status text DEFAULT 'pending'::text NOT NULL,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: earntree_earnings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.earntree_earnings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: earntree_earnings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.earntree_earnings_id_seq OWNED BY public.earntree_earnings.id;


--
-- Name: earntree_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.earntree_goals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    target_amount numeric(10,2) NOT NULL,
    current_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    deadline text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: earntree_goals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.earntree_goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: earntree_goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.earntree_goals_id_seq OWNED BY public.earntree_goals.id;


--
-- Name: growth_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.growth_metrics (
    id integer NOT NULL,
    month text NOT NULL,
    bookings integer DEFAULT 0 NOT NULL,
    revenue numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    contractors integer DEFAULT 0 NOT NULL,
    customers integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: growth_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.growth_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: growth_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.growth_metrics_id_seq OWNED BY public.growth_metrics.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    booking_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public.invoice_status DEFAULT 'draft'::public.invoice_status NOT NULL,
    due_date text NOT NULL,
    paid_at timestamp without time zone,
    description text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    name text NOT NULL,
    phone text,
    email text,
    service_type text NOT NULL,
    message text NOT NULL,
    status public.lead_status DEFAULT 'new'::public.lead_status NOT NULL,
    source text NOT NULL,
    ai_summary text,
    estimated_value numeric(10,2),
    zip_code text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    sender_name text NOT NULL,
    content text NOT NULL,
    sent_at timestamp without time zone DEFAULT now() NOT NULL,
    is_own boolean DEFAULT false NOT NULL
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    description text NOT NULL,
    status public.payment_status DEFAULT 'pending'::public.payment_status NOT NULL,
    type public.payment_type DEFAULT 'charge'::public.payment_type NOT NULL,
    invoice_id integer,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: playdate_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playdate_events (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    type public.playdate_type NOT NULL,
    host_id integer,
    host_name text NOT NULL,
    age_min integer DEFAULT 0 NOT NULL,
    age_max integer DEFAULT 18 NOT NULL,
    max_kids integer DEFAULT 10 NOT NULL,
    current_kids integer DEFAULT 0 NOT NULL,
    price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    is_free boolean DEFAULT true NOT NULL,
    location text NOT NULL,
    address text NOT NULL,
    zip_code text NOT NULL,
    event_date text NOT NULL,
    event_time text NOT NULL,
    duration_minutes integer DEFAULT 120 NOT NULL,
    image_url text,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: playdate_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.playdate_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: playdate_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.playdate_events_id_seq OWNED BY public.playdate_events.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    contractor_id integer NOT NULL,
    booking_id integer NOT NULL,
    reviewer_name text NOT NULL,
    rating integer NOT NULL,
    comment text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: rideshare_trips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rideshare_trips (
    id integer NOT NULL,
    rider_id integer,
    rider_name text NOT NULL,
    driver_id integer,
    driver_name text,
    driver_rating numeric(3,2),
    vehicle_info text,
    pickup_address text NOT NULL,
    dropoff_address text NOT NULL,
    pickup_zip text NOT NULL,
    dropoff_zip text NOT NULL,
    estimated_miles numeric(6,2),
    fare numeric(10,2),
    status public.rideshare_status DEFAULT 'open'::public.rideshare_status NOT NULL,
    scheduled_date text,
    scheduled_time text,
    is_shared boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: rideshare_trips_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rideshare_trips_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rideshare_trips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rideshare_trips_id_seq OWNED BY public.rideshare_trips.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    description text NOT NULL,
    base_price numeric(10,2),
    price_unit text,
    icon_name text DEFAULT 'Wrench'::text NOT NULL,
    contractor_count integer DEFAULT 0 NOT NULL
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: share_listings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.share_listings (
    id integer NOT NULL,
    title text NOT NULL,
    category text NOT NULL,
    description text NOT NULL,
    price numeric(10,2) NOT NULL,
    price_unit text NOT NULL,
    location text NOT NULL,
    zip_code text NOT NULL,
    host_id integer,
    host_name text NOT NULL,
    rating numeric(3,2) DEFAULT 5.0 NOT NULL,
    review_count integer DEFAULT 0 NOT NULL,
    image_url text,
    amenities text[] DEFAULT '{}'::text[] NOT NULL,
    available boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: share_listings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.share_listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: share_listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.share_listings_id_seq OWNED BY public.share_listings.id;


--
-- Name: thriftgirl_listings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thriftgirl_listings (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    category public.thriftgirl_category NOT NULL,
    condition public.thriftgirl_condition NOT NULL,
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    seller_id integer,
    seller_name text NOT NULL,
    seller_rating numeric(3,2) DEFAULT 5.0 NOT NULL,
    location text NOT NULL,
    zip_code text NOT NULL,
    image_url text,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    available boolean DEFAULT true NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: thriftgirl_listings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.thriftgirl_listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: thriftgirl_listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.thriftgirl_listings_id_seq OWNED BY public.thriftgirl_listings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    role public.user_role DEFAULT 'customer'::public.user_role NOT NULL,
    avatar_url text,
    zip_code text,
    credits numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: contractors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contractors ALTER COLUMN id SET DEFAULT nextval('public.contractors_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: earntree_earnings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earntree_earnings ALTER COLUMN id SET DEFAULT nextval('public.earntree_earnings_id_seq'::regclass);


--
-- Name: earntree_goals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earntree_goals ALTER COLUMN id SET DEFAULT nextval('public.earntree_goals_id_seq'::regclass);


--
-- Name: growth_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.growth_metrics ALTER COLUMN id SET DEFAULT nextval('public.growth_metrics_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: playdate_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playdate_events ALTER COLUMN id SET DEFAULT nextval('public.playdate_events_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: rideshare_trips id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rideshare_trips ALTER COLUMN id SET DEFAULT nextval('public.rideshare_trips_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: share_listings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.share_listings ALTER COLUMN id SET DEFAULT nextval('public.share_listings_id_seq'::regclass);


--
-- Name: thriftgirl_listings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thriftgirl_listings ALTER COLUMN id SET DEFAULT nextval('public.thriftgirl_listings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: contractors contractors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contractors
    ADD CONSTRAINT contractors_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: earntree_earnings earntree_earnings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earntree_earnings
    ADD CONSTRAINT earntree_earnings_pkey PRIMARY KEY (id);


--
-- Name: earntree_goals earntree_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earntree_goals
    ADD CONSTRAINT earntree_goals_pkey PRIMARY KEY (id);


--
-- Name: growth_metrics growth_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.growth_metrics
    ADD CONSTRAINT growth_metrics_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: playdate_events playdate_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playdate_events
    ADD CONSTRAINT playdate_events_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: rideshare_trips rideshare_trips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rideshare_trips
    ADD CONSTRAINT rideshare_trips_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: share_listings share_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.share_listings
    ADD CONSTRAINT share_listings_pkey PRIMARY KEY (id);


--
-- Name: thriftgirl_listings thriftgirl_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thriftgirl_listings
    ADD CONSTRAINT thriftgirl_listings_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict X1wI7wQfAPLPFm4XoZ747mEGiy20P3yEpkS30ALbR25sfF1RsjnnfefJjinG5qK

