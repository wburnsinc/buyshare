# Buyshare.co

Hyper-local peer-to-peer equipment rental marketplace for Southwest Florida (Charlotte County, Lee County, Punta Gorda). Neighbors rent tools, outdoor gear, trailers, and more to each other with Stripe Connect Express powering 90/10 commission splits.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port from env)
- `pnpm --filter @workspace/buyshare run dev` — run the frontend (port from env)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19 + Vite 7 + Tailwind CSS 4 + shadcn/ui + wouter
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Payments: Stripe Connect Express (Destination Charges, 10% platform commission)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- File uploads: multer (proof photos + listing photos)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/buyshare/` — React + Vite frontend (routes at `/`)
- `artifacts/api-server/` — Express 5 backend (routes at `/api`)
- `lib/api-spec/openapi.yaml` — Source of truth for all API contracts
- `lib/db/src/schema/` — Drizzle ORM schema (users, listings, bookings, requests, reviews)
- `lib/api-client-react/src/generated/` — Generated React Query hooks (DO NOT EDIT)
- `artifacts/api-server/src/lib/stripe.ts` — Stripe client + `calculateSplit()` math engine
- `public/uploads/` — File upload storage (listing photos + booking proof photos)

## Stripe Connect Architecture

- Platform uses **Destination Charges** with `application_fee_amount`
- 10% commission taken from rental price only (not deposit, not protection fee)
- Stripe fee (2.9% + $0.30) passed to renter when owner has `passFeesToRenter=true`
- Security deposit held in platform escrow, released via `/api/bookings/:id/release-deposit`
- Webhooks at `/api/webhooks/stripe` — requires raw body (mounted before express.json)
- Owner onboarding at `/api/connect/onboard` → `/connect/onboard` page

## Buyshare Math (calculateSplit)

```
rentalCents × 10% = platformFeeCents (application_fee_amount to Stripe)
rentalCents - platformFeeCents = ownerPayoutCents (auto-routed to owner's Stripe account)
(total + fees) × 2.9% + $0.30 = stripeFees (if passFeesToRenter=true)
addProtection ? +$3.99 = protectionFeeCents (goes to platform pool)
```

## Key API Routes

- `POST /api/connect/onboard` — Start Stripe Connect Express onboarding
- `GET  /api/connect/status/:userId` — Check onboarding completion
- `POST /api/bookings/calculate` — Real-time cost calculator
- `POST /api/bookings/checkout` — Create PaymentIntent with Destination Charge
- `POST /api/bookings/:id/proof/:type` — Upload check-in/checkout photos (multipart, min 3)
- `POST /api/bookings/:id/release-deposit` — Refund deposit to renter
- `POST /api/webhooks/stripe` — Stripe webhook handler

## Architecture Decisions

- Webhooks mounted before `express.json()` so raw body is preserved for Stripe signature verification
- All monetary values stored in cents (integers) to avoid floating-point errors
- Security deposit is NOT part of the `application_fee_amount` — it stays in platform until released
- `passFeesToRenter` toggle per owner controls whether Stripe fee is added to renter's total
- Photo uploads use multer disk storage at `public/uploads/` served statically

## Product Features

- **Stripe Connect Express** — Equipment owners connect their bank account to receive 90% of rental price
- **10% Platform Commission** — Automatically split at payment time via Stripe Destination Charges
- **Security Deposit Escrow** — Held by platform, 1-click release after return
- **Buyshare Protection** — Optional $3.99 per rental goes to platform insurance pool
- **Photo Proof Check-in/out** — Renters must upload 3+ photos to activate and complete rentals
- **Pass-Fee Toggle** — Owners choose whether to pass Stripe processing fees to renters
- **Tiered Pricing** — Daily, weekend (2-day), and weekly rates per listing
- **Community Request Board** — "Item Wanted" posts for equipment not currently listed
- **Delivery Toggle** — Owners can offer delivery with custom fee and radius
- **Verified Local Badges** — Identity-verified users shown with checkmark

## User Preferences

- Domain: buyshare.co
- Target market: Southwest Florida (Charlotte County, Lee County, Punta Gorda)
- Commission: 10% platform fee on rental price only
- No auth yet — currently uses demo user "user-demo-owner-1"

## Gotchas

- Always run codegen after changing `lib/api-spec/openapi.yaml`
- Schema names in OpenAPI must NOT match `<OperationIdPascal>Body` pattern (causes TS2308 collision)
- The zod index re-exports only `./generated/api` — do NOT add `./generated/types` back (causes duplicates)
- Stripe webhook route must use `express.raw()` middleware, not `express.json()`
- `multer` disk storage auto-creates the upload directory path must exist before upload
