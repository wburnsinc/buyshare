# Buyshare.co — Shared Libraries & Workspace

## Monorepo Structure
This is a pnpm workspace. All packages are in `lib/`:

- `lib/db/` — Shared PostgreSQL pool (exports `pool`)
- `lib/api-spec/` — Shared API type definitions
- `lib/api-zod/` — Zod schema validators
- `lib/api-client-react/` — React hooks for API calls
- `lib/integrations-openai-ai-server/` — OpenAI client (server-side)
- `lib/integrations-openai-ai-react/` — OpenAI client (React)

## Setup
```bash
pnpm install  # installs all workspace packages
```

## Database Pool
Import in any backend file:
```typescript
import { pool } from "@workspace/db";
const { rows } = await pool.query("SELECT * FROM users LIMIT 10");
```
