import { pgTable, text, boolean, timestamp, integer, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const bookingStatusEnum = pgEnum("booking_status", [
  "pending", "active", "completed", "disputed", "cancelled", "refunded"
]);

export const bookingsTable = pgTable("bookings", {
  id: text("id").primaryKey(),
  renterId: text("renter_id").notNull(),
  listingId: text("listing_id").notNull(),
  ownerId: text("owner_id").notNull(),
  status: bookingStatusEnum("status").notNull().default("pending"),

  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalDays: integer("total_days").notNull(),

  rentalAmountCents: integer("rental_amount_cents").notNull(),
  securityDepositCents: integer("security_deposit_cents").notNull().default(0),
  platformFeeCents: integer("platform_fee_cents").notNull(),
  stripeFeesCents: integer("stripe_fees_cents").notNull().default(0),
  protectionFeeCents: integer("protection_fee_cents").notNull().default(0),
  totalChargeCents: integer("total_charge_cents").notNull(),
  ownerPayoutCents: integer("owner_payout_cents").notNull(),
  addedProtection: boolean("added_protection").notNull().default(false),
  deliveryRequested: boolean("delivery_requested").notNull().default(false),
  deliveryFeeCents: integer("delivery_fee_cents").notNull().default(0),

  stripePaymentIntentId: text("stripe_payment_intent_id"),
  stripeTransferId: text("stripe_transfer_id"),
  depositRefundId: text("deposit_refund_id"),
  depositReleased: boolean("deposit_released").notNull().default(false),

  checkInPhotos: text("check_in_photos").array().notNull().default([]),
  checkInTimestamp: timestamp("check_in_timestamp"),
  checkOutPhotos: text("check_out_photos").array().notNull().default([]),
  checkOutTimestamp: timestamp("check_out_timestamp"),

  renterNotes: text("renter_notes"),
  ownerNotes: text("owner_notes"),
  disputeReason: text("dispute_reason"),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertBookingSchema = createInsertSchema(bookingsTable).omit({ createdAt: true, updatedAt: true });
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookingsTable.$inferSelect;
