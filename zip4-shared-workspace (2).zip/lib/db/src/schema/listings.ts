import { pgTable, text, boolean, timestamp, integer, real, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const listingStatusEnum = pgEnum("listing_status", ["available", "rented", "unavailable"]);
export const listingCategoryEnum = pgEnum("listing_category", [
  "tools", "outdoor", "vehicles", "sports", "electronics", "home", "lawn", "marine", "trailers", "other"
]);

export const listingsTable = pgTable("listings", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: listingCategoryEnum("category").notNull().default("other"),
  dailyRate: integer("daily_rate").notNull(),
  weekendRate: integer("weekend_rate"),
  weeklyRate: integer("weekly_rate"),
  securityDeposit: integer("security_deposit").notNull().default(0),
  status: listingStatusEnum("status").notNull().default("available"),
  photos: text("photos").array().notNull().default([]),
  location: text("location").notNull(),
  latitude: real("latitude"),
  longitude: real("longitude"),
  deliveryAvailable: boolean("delivery_available").notNull().default(false),
  deliveryFee: integer("delivery_fee"),
  deliveryRadiusMiles: integer("delivery_radius_miles"),
  requiresVerified: boolean("requires_verified").notNull().default(false),
  viewCount: integer("view_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertListingSchema = createInsertSchema(listingsTable).omit({ createdAt: true, updatedAt: true, viewCount: true });
export type InsertListing = z.infer<typeof insertListingSchema>;
export type Listing = typeof listingsTable.$inferSelect;
