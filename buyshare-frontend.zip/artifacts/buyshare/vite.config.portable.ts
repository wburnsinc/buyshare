/**
 * PORTABLE Vite config — use this when deploying OUTSIDE of Replit.
 * Rename this file to vite.config.ts to replace the Replit-specific version.
 *
 * Differences from vite.config.ts:
 *  - No @replit/vite-plugin-runtime-error-modal (unconditional Replit import removed)
 *  - No @replit/vite-plugin-cartographer
 *  - No @replit/vite-plugin-dev-banner
 *  - PORT defaults to 3000 if not set
 *  - BASE_PATH defaults to "/" if not set
 *  - Dev proxy to API server added (uncomment and set target)
 */
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

const port = Number(process.env.PORT) || 3000;
const basePath = process.env.BASE_PATH || "/";

export default defineConfig({
  base: basePath,
  plugins: [
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
      // Adjust this path if attached_assets moves relative to this file
      "@assets": path.resolve(import.meta.dirname, "..", "..", "attached_assets"),
    },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    port,
    strictPort: true,
    host: "0.0.0.0",
    allowedHosts: true,
    // Uncomment and set target to your API server URL for local dev:
    // proxy: {
    //   '/api': {
    //     target: 'http://localhost:8080',
    //     changeOrigin: true,
    //   }
    // },
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});
