import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Car, MapPin, Clock, DollarSign, Users, ArrowRight, Star, Navigation, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const STATUS_STYLES: Record<string, string> = {
  open: "bg-blue-100 text-blue-700",
  matched: "bg-purple-100 text-purple-700",
  en_route: "bg-yellow-100 text-yellow-700",
  picked_up: "bg-orange-100 text-orange-700",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

const STATUS_LABELS: Record<string, string> = {
  open: "Looking for Driver", matched: "Driver Matched", en_route: "Driver En Route",
  picked_up: "In Ride", completed: "Completed", cancelled: "Cancelled",
};

export default function RidesharePage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ riderName: "", pickupAddress: "", dropoffAddress: "", pickupZip: "", dropoffZip: "", scheduledDate: "", scheduledTime: "", isShared: false, notes: "" });

  const { data: stats } = useQuery({
    queryKey: ["rideshare-stats"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/rideshare/stats`); return res.json(); },
  });

  const { data: trips = [], isLoading } = useQuery({
    queryKey: ["rideshare-trips"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/rideshare/trips`); return res.json(); },
  });

  const bookMutation = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await fetch(`${BASE}/api/rideshare/trips`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return res.json();
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["rideshare-trips"] });
      toast({ title: "Ride Requested!", description: `Estimated fare: $${data.fare}. Finding your driver...` });
      setShowForm(false);
      setForm({ riderName: "", pickupAddress: "", dropoffAddress: "", pickupZip: "", dropoffZip: "", scheduledDate: "", scheduledTime: "", isShared: false, notes: "" });
    },
  });

  const activeTrips = (trips as any[]).filter(t => !["completed", "cancelled"].includes(t.status));
  const completedTrips = (trips as any[]).filter(t => t.status === "completed");

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1e40af 0%, #2563eb 50%, #0ea5e9 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 py-16 text-white">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Badge className="mb-4 bg-white/20 text-white border-0 text-sm">🚗 Local Rides, Community Drivers</Badge>
            <h1 className="text-5xl font-black mb-4">RideShare™</h1>
            <p className="text-xl text-white/80 mb-8 max-w-2xl">Affordable local ridesharing by community drivers in Punta Gorda, Port Charlotte, and Southwest Florida. No surge pricing.</p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-white text-blue-700 hover:bg-white/90 font-bold" onClick={() => setShowForm(true)} data-testid="btn-book-ride">
                <Car className="w-5 h-5 mr-2" /> Book a Ride
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <ArrowRight className="w-5 h-5 mr-2" /> Become a Driver
              </Button>
            </div>
          </motion.div>
          {/* Fare cards */}
          <div className="grid grid-cols-3 gap-4 mt-12 max-w-lg">
            {[{ label: "Under 5mi", price: "$8", icon: "🏘️" }, { label: "5–10 miles", price: "$14", icon: "🏙️" }, { label: "10+ miles", price: "$20", icon: "🛣️" }].map(f => (
              <div key={f.label} className="bg-white/10 rounded-xl p-3 text-center">
                <div className="text-2xl mb-1">{f.icon}</div>
                <div className="text-xl font-bold">{f.price}</div>
                <div className="text-xs text-white/70">{f.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="bg-card border-b border-border">
          <div className="max-w-7xl mx-auto px-4 py-5 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Total Trips", value: stats.totalTrips, icon: Car },
              { label: "Completed", value: stats.completedTrips, icon: Navigation },
              { label: "Revenue", value: `$${stats.revenue?.toFixed(0)}`, icon: DollarSign },
              { label: "Active Drivers", value: stats.activeDrivers, icon: Users },
            ].map(s => (
              <div key={s.label} className="text-center py-2">
                <s.icon className="w-5 h-5 mx-auto mb-1 text-blue-500" />
                <div className="text-2xl font-bold">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Booking Form */}
        {showForm && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8 p-6 rounded-2xl border border-border bg-card">
            <h2 className="text-xl font-bold mb-4">Book Your Ride</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input placeholder="Your name *" value={form.riderName} onChange={e => setForm(f => ({ ...f, riderName: e.target.value }))} data-testid="input-rider-name" />
              <Input placeholder="Pickup ZIP *" value={form.pickupZip} onChange={e => setForm(f => ({ ...f, pickupZip: e.target.value }))} />
              <Input placeholder="Pickup address *" value={form.pickupAddress} onChange={e => setForm(f => ({ ...f, pickupAddress: e.target.value }))} />
              <Input placeholder="Dropoff address *" value={form.dropoffAddress} onChange={e => setForm(f => ({ ...f, dropoffAddress: e.target.value }))} />
              <Input placeholder="Dropoff ZIP *" value={form.dropoffZip} onChange={e => setForm(f => ({ ...f, dropoffZip: e.target.value }))} />
              <Input type="date" value={form.scheduledDate} onChange={e => setForm(f => ({ ...f, scheduledDate: e.target.value }))} />
              <Input type="time" value={form.scheduledTime} onChange={e => setForm(f => ({ ...f, scheduledTime: e.target.value }))} />
              <Input placeholder="Notes (optional)" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
              <div className="md:col-span-2 flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.isShared} onChange={e => setForm(f => ({ ...f, isShared: e.target.checked }))} className="w-4 h-4" />
                  <span className="text-sm">Shared ride (save up to 40%)</span>
                </label>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white" onClick={() => bookMutation.mutate(form)} disabled={bookMutation.isPending || !form.riderName || !form.pickupAddress} data-testid="btn-confirm-ride">
                {bookMutation.isPending ? "Booking..." : "Book Ride"}
              </Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Active Rides */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-4">Active Rides</h2>
            {isLoading ? (
              <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-28 rounded-2xl border border-border animate-pulse" />)}</div>
            ) : activeTrips.length === 0 ? (
              <div className="text-center py-12 rounded-2xl border border-border bg-card">
                <Car className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-30" />
                <p className="text-muted-foreground">No active rides right now</p>
                <Button className="mt-3 bg-blue-600 hover:bg-blue-700 text-white" onClick={() => setShowForm(true)}>Book First Ride</Button>
              </div>
            ) : (
              <div className="space-y-3">
                {activeTrips.map((trip: any) => (
                  <motion.div key={trip.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    className="p-4 rounded-2xl border border-border bg-card">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <span className="font-bold">{trip.riderName}</span>
                        {trip.driverName && <span className="text-sm text-muted-foreground ml-2">→ {trip.driverName}</span>}
                      </div>
                      <Badge className={STATUS_STYLES[trip.status] || "bg-gray-100 text-gray-700"}>{STATUS_LABELS[trip.status]}</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-green-500" /> {trip.pickupAddress}</div>
                      <div className="flex items-center gap-1 ml-4"><ArrowRight className="w-3.5 h-3.5" /> {trip.dropoffAddress}</div>
                    </div>
                    <div className="flex items-center gap-4 mt-3 text-sm">
                      {trip.estimatedMiles && <span className="flex items-center gap-1"><Navigation className="w-3.5 h-3.5" /> {Number(trip.estimatedMiles).toFixed(1)} mi</span>}
                      {trip.fare && <span className="flex items-center gap-1 font-semibold text-blue-600"><DollarSign className="w-3.5 h-3.5" /> ${trip.fare}</span>}
                      {trip.isShared && <Badge className="bg-green-100 text-green-700 text-xs">Shared</Badge>}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-3">Become a Driver</h3>
              <p className="text-sm text-muted-foreground mb-3">Earn $15–$25/hr driving your community. Set your own hours.</p>
              <ul className="text-sm space-y-1 mb-4">
                {["Valid FL driver's license", "Clean background check", "Any 4-door vehicle", "Smartphone required"].map(r => (
                  <li key={r} className="flex items-center gap-2"><span className="text-green-500">✓</span>{r}</li>
                ))}
              </ul>
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Apply to Drive</Button>
            </div>
            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-3">Recent Completed</h3>
              {completedTrips.slice(0, 3).map((trip: any) => (
                <div key={trip.id} className="flex items-center justify-between py-2 border-b border-border last:border-0 text-sm">
                  <div>
                    <div className="font-medium">{trip.riderName}</div>
                    <div className="text-xs text-muted-foreground">{trip.pickupZip} → {trip.dropoffZip}</div>
                  </div>
                  <span className="font-semibold text-green-600">${trip.fare}</span>
                </div>
              ))}
              {completedTrips.length === 0 && <p className="text-sm text-muted-foreground">No completed rides yet</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
