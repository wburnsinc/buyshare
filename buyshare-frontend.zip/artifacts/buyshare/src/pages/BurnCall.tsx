import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, MessageSquare, Bot, CheckCircle2, TrendingUp, DollarSign, Users } from "lucide-react";
import { useListLeads, useGetLeadSummary, useCreateLead } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

const STATUS_COLORS: Record<string, string> = {
  new: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  contacted: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  qualified: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  booked: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  lost: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
};

export default function BurnCallPage() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState("");
  const { data: leads, isLoading: leadsLoading } = useListLeads(statusFilter ? { status: statusFilter } : {});
  const { data: summary, isLoading: summaryLoading } = useGetLeadSummary();
  const createLead = useCreateLead();
  const [form, setForm] = useState({ name: "", phone: "", email: "", serviceType: "", message: "", source: "website", zipCode: "" });
  const [showForm, setShowForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    createLead.mutate({ data: form }, {
      onSuccess: () => { setSubmitted(true); setShowForm(false); toast({ title: "Lead captured successfully!" }); },
      onError: () => { setSubmitted(true); setShowForm(false); },
    });
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#001a4a] text-white py-12 px-4" data-testid="burncall-header">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              <span className="font-black text-2xl">BurnCall</span>
            </div>
            <h1 className="font-black text-3xl md:text-4xl mb-3">AI Lead Receptionist</h1>
            <p className="text-blue-200 text-lg mb-4">Every lead answered in under 60 seconds. AI-powered phone, SMS, and dispatch for home service businesses.</p>
            <div className="flex flex-wrap gap-2">
              {["Instant lead response", "AI qualification", "Missed-call text back", "Auto follow-up"].map(f => (
                <span key={f} className="flex items-center gap-1.5 text-xs bg-white/10 px-3 py-1.5 rounded-full">{f}</span>
              ))}
            </div>
          </div>
          {/* Summary */}
          <div className="grid grid-cols-2 gap-3">
            {summaryLoading ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl bg-white/10" />) : summary ? (
              <>
                <div className="rounded-xl p-4 bg-white/10 text-center" data-testid="stat-total-leads"><p className="font-extrabold text-3xl">{summary.totalLeads}</p><p className="text-blue-200 text-xs mt-1">Total Leads</p></div>
                <div className="rounded-xl p-4 bg-white/10 text-center" data-testid="stat-new-today"><p className="font-extrabold text-3xl" style={{ color: "#1fbe4b" }}>{summary.newToday}</p><p className="text-blue-200 text-xs mt-1">New Today</p></div>
                <div className="rounded-xl p-4 bg-white/10 text-center" data-testid="stat-booked"><p className="font-extrabold text-3xl text-amber-400">{summary.booked}</p><p className="text-blue-200 text-xs mt-1">Booked</p></div>
                <div className="rounded-xl p-4 bg-white/10 text-center" data-testid="stat-revenue"><p className="font-extrabold text-2xl">${(summary.estimatedRevenue ?? 0).toLocaleString()}</p><p className="text-blue-200 text-xs mt-1">Est. Revenue</p></div>
              </>
            ) : null}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Lead Table Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex flex-wrap gap-2" data-testid="lead-status-filters">
            {["All", "new", "contacted", "qualified", "booked", "lost"].map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s === "All" ? "" : s)}
                data-testid={`filter-lead-${s}`}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border capitalize transition-colors ${(statusFilter === s || (s === "All" && !statusFilter)) ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"}`}
              >
                {s}
              </button>
            ))}
          </div>
          <Button onClick={() => setShowForm(!showForm)} style={{ background: "#1fbe4b", color: "white" }} data-testid="button-capture-lead">
            <Phone className="w-4 h-4 mr-2" /> Capture Lead
          </Button>
        </div>

        {/* Lead capture form */}
        {showForm && (
          <div className="rounded-2xl border border-border bg-card p-6 mb-6" data-testid="lead-capture-form">
            <h3 className="font-bold mb-4">New Lead</h3>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><Label>Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required data-testid="input-lead-name" /></div>
              <div><Label>Phone</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} data-testid="input-lead-phone" /></div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} data-testid="input-lead-email" /></div>
              <div><Label>Service Type *</Label>
                <Select value={form.serviceType} onValueChange={v => setForm({ ...form, serviceType: v })}>
                  <SelectTrigger data-testid="select-lead-service"><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>
                    {["Pool Services", "Lawn Care", "HVAC", "Plumbing", "Electrical", "Cleaning", "Handyman"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Source</Label>
                <Select value={form.source} onValueChange={v => setForm({ ...form, source: v })}>
                  <SelectTrigger data-testid="select-lead-source"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["website", "phone", "sms", "referral", "social"].map(s => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>ZIP Code</Label><Input value={form.zipCode} onChange={e => setForm({ ...form, zipCode: e.target.value })} data-testid="input-lead-zip" /></div>
              <div className="sm:col-span-2"><Label>Message *</Label><Textarea value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} required rows={2} data-testid="input-lead-message" /></div>
              <div className="sm:col-span-2 flex gap-3">
                <Button type="submit" disabled={createLead.isPending} style={{ background: "#1fbe4b", color: "white" }} data-testid="button-submit-lead">
                  {createLead.isPending ? "Saving..." : "Save Lead"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)} data-testid="button-cancel-lead">Cancel</Button>
              </div>
            </form>
          </div>
        )}

        {/* Leads table */}
        {leadsLoading ? (
          <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div>
        ) : (leads ?? []).length === 0 ? (
          <div className="text-center py-20 text-muted-foreground border border-dashed border-border rounded-2xl" data-testid="empty-leads">
            <Bot className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium">No leads yet</p>
            <p className="text-sm">Leads captured via BurnCall appear here</p>
          </div>
        ) : (
          <div className="space-y-3">
            {(leads ?? []).map((lead, i) => (
              <motion.div
                key={lead.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="p-5 rounded-2xl border border-border bg-card hover:shadow-md transition-shadow"
                data-testid={`lead-card-${lead.id}`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold">{lead.name}</h3>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${STATUS_COLORS[lead.status] ?? "bg-gray-100"}`}>{lead.status}</span>
                      <Badge variant="secondary" className="text-xs">{lead.serviceType}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{lead.message}</p>
                    {lead.aiSummary && (
                      <div className="flex items-start gap-1.5 text-xs text-primary bg-primary/5 rounded-lg p-2">
                        <Bot className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                        <span>{lead.aiSummary}</span>
                      </div>
                    )}
                  </div>
                  <div className="text-right shrink-0">
                    {lead.estimatedValue && <p className="font-bold text-lg" style={{ color: "#1fbe4b" }}>${lead.estimatedValue.toLocaleString()}</p>}
                    <p className="text-xs text-muted-foreground">{lead.source}</p>
                    <p className="text-xs text-muted-foreground">{new Date(lead.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
