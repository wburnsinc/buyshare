import { motion } from "framer-motion";
import { DollarSign, TrendingUp, Clock, CreditCard, FileText } from "lucide-react";
import { useListPayments, useGetPaymentSummary, useListInvoices } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300",
  completed: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  failed: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
  refunded: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  paid: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  sent: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  draft: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-300",
  overdue: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
};

export default function PaymentsPage() {
  const { data: payments, isLoading: paymentsLoading } = useListPayments();
  const { data: summary, isLoading: summaryLoading } = useGetPaymentSummary();
  const { data: invoices, isLoading: invoicesLoading } = useListInvoices();

  const SUMMARY_CARDS = [
    { label: "Total Spent", value: summary?.totalSpent, icon: DollarSign, color: "#002a6e" },
    { label: "Total Earned", value: summary?.totalEarned, icon: TrendingUp, color: "#1fbe4b" },
    { label: "Pending Payouts", value: summary?.pendingPayouts, icon: Clock, color: "#f59e0b" },
    { label: "BuyShare Credits", value: summary?.credits, icon: CreditCard, color: "#7c3aed" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#002a6e] text-white py-10 px-4" data-testid="payments-header">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-black text-2xl md:text-3xl mb-1">PocketCash</h1>
          <p className="text-blue-200">Payments, payouts, invoices, and credits — all in one place.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {SUMMARY_CARDS.map((card, i) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.label}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.07 }}
                className="rounded-xl border border-border bg-card p-5"
                data-testid={`summary-card-${card.label.toLowerCase().replace(/\s/g, "-")}`}
              >
                <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-3" style={{ background: `${card.color}15` }}>
                  <Icon className="w-4 h-4" style={{ color: card.color }} />
                </div>
                {summaryLoading ? (
                  <Skeleton className="h-7 w-24" />
                ) : (
                  <p className="font-extrabold text-xl">${(card.value ?? 0).toLocaleString()}</p>
                )}
                <p className="text-xs text-muted-foreground mt-0.5">{card.label}</p>
              </motion.div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Payment History */}
          <div>
            <h2 className="font-bold text-lg mb-4">Payment History</h2>
            {paymentsLoading ? (
              <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
            ) : (payments ?? []).length === 0 ? (
              <div className="text-center py-12 text-muted-foreground border border-dashed rounded-xl" data-testid="empty-payments">
                <DollarSign className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No payment history yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {(payments ?? []).map((payment, i) => (
                  <motion.div
                    key={payment.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card"
                    data-testid={`payment-row-${payment.id}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${payment.type === "payout" || payment.type === "credit" ? "bg-green-100 text-green-600" : "bg-blue-100 text-blue-600"}`}>
                      <DollarSign className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{payment.description}</p>
                      <p className="text-xs text-muted-foreground">{new Date(payment.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold text-sm ${payment.type === "payout" || payment.type === "credit" ? "text-green-600" : "text-foreground"}`}>
                        {payment.type === "payout" || payment.type === "credit" ? "+" : "-"}${payment.amount.toLocaleString()}
                      </p>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full ${STATUS_COLORS[payment.status] ?? "bg-gray-100 text-gray-700"}`}>{payment.status}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>

          {/* Invoices */}
          <div>
            <h2 className="font-bold text-lg mb-4 flex items-center gap-2"><FileText className="w-4 h-4" /> Invoices</h2>
            {invoicesLoading ? (
              <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
            ) : (invoices ?? []).length === 0 ? (
              <div className="text-center py-12 text-muted-foreground border border-dashed rounded-xl" data-testid="empty-invoices">
                <FileText className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No invoices yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {(invoices ?? []).map((invoice, i) => (
                  <motion.div
                    key={invoice.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card"
                    data-testid={`invoice-row-${invoice.id}`}
                  >
                    <div className="flex-1">
                      <p className="text-sm font-medium">{invoice.description}</p>
                      <p className="text-xs text-muted-foreground">Due: {invoice.dueDate}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${invoice.amount.toLocaleString()}</p>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full ${STATUS_COLORS[invoice.status] ?? "bg-gray-100 text-gray-700"}`}>{invoice.status}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
