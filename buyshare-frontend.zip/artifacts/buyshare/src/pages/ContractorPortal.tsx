import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  Briefcase, DollarSign, Star, MapPin, Calendar, CheckCircle2,
  Clock, ChevronRight, MessageSquare, FileText, TrendingUp, Zap,
  User, Settings, LogOut, AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300",
  confirmed: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  assigned: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  en_route: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
  in_progress: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300",
  completed: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  cancelled: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
};

const STATUS_NEXT: Record<string, string> = {
  assigned: "en_route", en_route: "in_progress", in_progress: "completed",
};

const STATUS_NEXT_LABEL: Record<string, string> = {
  assigned: "Mark En Route", en_route: "Mark In Progress", in_progress: "Mark Complete",
};

const MOCK_EARNINGS = [
  { month: "Jan", amount: 2400 }, { month: "Feb", amount: 1800 }, { month: "Mar", amount: 3200 },
  { month: "Apr", amount: 2900 }, { month: "May", amount: 3800 }, { month: "Jun", amount: 4200 },
];

export default function ContractorPortalPage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [tab, setTab] = useState<"jobs" | "earnings" | "profile" | "schedule">("jobs");

  const { data: bookings = [], isLoading } = useQuery({
    queryKey: ["contractor-bookings"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/bookings`); return res.json(); },
  });

  const { data: contractor } = useQuery({
    queryKey: ["contractor-profile"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/contractors`); const all = await res.json(); return all[0] || null; },
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["contractor-payments"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/payments`); return res.json(); },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await fetch(`${BASE}/api/bookings/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      return res.json();
    },
    onSuccess: (_, { status }) => {
      qc.invalidateQueries({ queryKey: ["contractor-bookings"] });
      toast({ title: "Status updated", description: `Job marked as ${status.replace(/_/g, " ")}.` });
    },
  });

  const myJobs = (bookings as any[]).filter(b => b.status !== "cancelled");
  const totalEarned = (payments as any[]).filter(p => p.status === "completed").reduce((s: number, p: any) => s + Number(p.amount), 0);
  const pendingPayout = (payments as any[]).filter(p => p.status === "pending").reduce((s: number, p: any) => s + Number(p.amount), 0);

  const TABS = [
    { id: "jobs", label: "Job Board", icon: Briefcase },
    { id: "earnings", label: "Earnings", icon: DollarSign },
    { id: "schedule", label: "Schedule", icon: Calendar },
    { id: "profile", label: "My Profile", icon: User },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #001a4a 0%, #002a6e 100%)" }} className="text-white">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <Badge className="mb-2 bg-green-500/20 text-green-300 border-green-500/30">Contractor Portal</Badge>
              <h1 className="text-3xl font-black">Welcome back, {contractor?.name?.split(" ")[0] || "Contractor"}</h1>
              <p className="text-white/60 mt-1">{contractor?.trades?.[0] || "Service Professional"} · {contractor?.location || "SW Florida"}</p>
            </div>
            <div className="hidden md:flex items-center gap-3">
              <div className="text-right">
                <div className="text-2xl font-bold text-green-400">${totalEarned.toFixed(0)}</div>
                <div className="text-xs text-white/60">Total Earned</div>
              </div>
              <div className="text-right ml-4">
                <div className="flex items-center gap-1"><Star className="w-4 h-4 text-yellow-400 fill-yellow-400" /><span className="text-xl font-bold">{contractor?.rating || "5.0"}</span></div>
                <div className="text-xs text-white/60">Rating</div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mt-6 border-b border-white/10">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id as any)}
                className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-t-lg transition-all ${tab === t.id ? "bg-white/10 text-white border-b-2 border-green-400" : "text-white/60 hover:text-white"}`}>
                <t.icon className="w-4 h-4" />{t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Job Board Tab */}
        {tab === "jobs" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {[
                { label: "Total Jobs", value: myJobs.length, icon: Briefcase, color: "text-blue-600" },
                { label: "Completed", value: myJobs.filter((b: any) => b.status === "completed").length, icon: CheckCircle2, color: "text-green-600" },
                { label: "In Progress", value: myJobs.filter((b: any) => ["assigned", "en_route", "in_progress"].includes(b.status)).length, icon: Zap, color: "text-orange-500" },
                { label: "Pending", value: myJobs.filter((b: any) => b.status === "pending").length, icon: Clock, color: "text-yellow-600" },
              ].map(s => (
                <div key={s.label} className="p-4 rounded-2xl border border-border bg-card text-center">
                  <s.icon className={`w-6 h-6 mx-auto mb-1 ${s.color}`} />
                  <div className="text-2xl font-bold">{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold mb-3">My Jobs</h2>
            {isLoading ? (
              <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-24 rounded-2xl border border-border animate-pulse" />)}</div>
            ) : myJobs.length === 0 ? (
              <div className="text-center py-12 rounded-2xl border border-border bg-card">
                <Briefcase className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-30" />
                <p className="text-muted-foreground">No jobs assigned yet. Make sure your profile is active.</p>
              </div>
            ) : (
              myJobs.map((job: any) => (
                <motion.div key={job.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="p-4 rounded-2xl border border-border bg-card hover:shadow-md transition-all">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold">{job.serviceName}</h3>
                        <Badge className={STATUS_STYLES[job.status] || ""}>{job.status.replace(/_/g, " ")}</Badge>
                      </div>
                      <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{job.address}</span>
                        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{job.scheduledDate} {job.scheduledTime}</span>
                        {job.price && <span className="flex items-center gap-1 font-semibold text-green-600"><DollarSign className="w-3.5 h-3.5" />${job.price}</span>}
                      </div>
                      {job.notes && <p className="text-sm text-muted-foreground mt-1 italic">{job.notes}</p>}
                    </div>
                    <div className="flex flex-col gap-2 shrink-0">
                      {STATUS_NEXT[job.status] && (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white text-xs"
                          onClick={() => updateStatus.mutate({ id: job.id, status: STATUS_NEXT[job.status] })}
                          disabled={updateStatus.isPending} data-testid={`btn-advance-${job.id}`}>
                          {STATUS_NEXT_LABEL[job.status]}
                        </Button>
                      )}
                      <Button size="sm" variant="outline" className="text-xs">
                        <MessageSquare className="w-3.5 h-3.5 mr-1" /> Message
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        )}

        {/* Earnings Tab */}
        {tab === "earnings" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { label: "Total Earned", value: `$${totalEarned.toFixed(0)}`, color: "text-green-600", icon: DollarSign },
                { label: "Pending Payout", value: `$${pendingPayout.toFixed(0)}`, color: "text-yellow-600", icon: Clock },
                { label: "This Month", value: `$${MOCK_EARNINGS[5].amount}`, color: "text-blue-600", icon: TrendingUp },
              ].map(s => (
                <div key={s.label} className="p-5 rounded-2xl border border-border bg-card">
                  <s.icon className={`w-6 h-6 mb-2 ${s.color}`} />
                  <div className={`text-3xl font-black ${s.color}`}>{s.value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-4">Monthly Earnings (6-Month View)</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={MOCK_EARNINGS}>
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip formatter={(v: number) => [`$${v}`, "Earned"]} />
                  <Bar dataKey="amount" fill="#1fbe4b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-4">Recent Payments</h3>
              {(payments as any[]).length === 0 ? <p className="text-muted-foreground text-sm">No payments yet</p> : (
                <div className="space-y-2">
                  {(payments as any[]).slice(0, 8).map((p: any) => (
                    <div key={p.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <div>
                        <div className="font-medium text-sm">{p.description}</div>
                        <div className="text-xs text-muted-foreground">{new Date(p.createdAt).toLocaleDateString()}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={p.status === "completed" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}>{p.status}</Badge>
                        <span className="font-bold">${Number(p.amount).toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Schedule Tab */}
        {tab === "schedule" && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-4 flex items-center gap-2"><Calendar className="w-5 h-5" /> Upcoming Schedule</h3>
              {myJobs.filter((b: any) => ["pending", "confirmed", "assigned", "en_route", "in_progress"].includes(b.status)).length === 0 ? (
                <p className="text-muted-foreground text-sm">No scheduled jobs. Stay ready!</p>
              ) : (
                <div className="space-y-3">
                  {myJobs.filter((b: any) => ["pending", "confirmed", "assigned", "en_route", "in_progress"].includes(b.status)).map((job: any) => (
                    <div key={job.id} className="flex gap-4 p-3 rounded-xl border border-border">
                      <div className="text-center min-w-[50px]">
                        <div className="text-lg font-black">{job.scheduledDate?.split("-")[2] || "—"}</div>
                        <div className="text-xs text-muted-foreground uppercase">{job.scheduledDate ? new Date(job.scheduledDate).toLocaleDateString("en", { month: "short" }) : ""}</div>
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold">{job.serviceName}</div>
                        <div className="text-sm text-muted-foreground">{job.address} · {job.scheduledTime}</div>
                        <Badge className={`mt-1 text-xs ${STATUS_STYLES[job.status]}`}>{job.status.replace(/_/g, " ")}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-3 flex items-center gap-2"><AlertCircle className="w-4 h-4 text-yellow-500" /> Availability Settings</h3>
              <p className="text-sm text-muted-foreground mb-4">Set your working hours to control when you receive job assignments.</p>
              <div className="grid grid-cols-2 gap-3">
                {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map(day => (
                  <label key={day} className="flex items-center gap-2 text-sm cursor-pointer p-2 rounded-lg border border-border hover:bg-accent/30">
                    <input type="checkbox" defaultChecked={!["Saturday", "Sunday"].includes(day)} className="w-4 h-4" />
                    {day}
                  </label>
                ))}
              </div>
              <Button className="mt-4 bg-green-600 hover:bg-green-700 text-white">Save Availability</Button>
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {tab === "profile" && contractor && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl border border-border bg-card">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-navy-800 to-green-500 flex items-center justify-center text-white text-2xl font-black" style={{ background: "linear-gradient(135deg, #002a6e, #1fbe4b)" }}>
                  {contractor.name?.charAt(0)}
                </div>
                <div>
                  <h2 className="text-xl font-bold">{contractor.name}</h2>
                  <p className="text-muted-foreground text-sm">{contractor.bio?.substring(0, 60) || "No bio yet"}...</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-muted-foreground" />{contractor.location}</div>
                <div className="flex items-center gap-2"><Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />{contractor.rating} rating · {contractor.jobsCompleted} jobs</div>
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" />{contractor.verified ? "Verified & Insured" : "Verification Pending"}</div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {(contractor.trades || []).map((t: string) => <Badge key={t} variant="secondary">{t}</Badge>)}
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-border bg-card space-y-3">
              <h3 className="font-bold flex items-center gap-2"><FileText className="w-4 h-4" /> Documents & Verification</h3>
              {[
                { label: "Driver's License", status: "verified" },
                { label: "Background Check", status: "verified" },
                { label: "Insurance Certificate", status: contractor.insured ? "verified" : "pending" },
                { label: "Business License", status: "verified" },
              ].map(d => (
                <div key={d.label} className="flex items-center justify-between p-3 rounded-xl border border-border">
                  <span className="text-sm font-medium">{d.label}</span>
                  <Badge className={d.status === "verified" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}>{d.status}</Badge>
                </div>
              ))}
              <Button className="w-full mt-2" variant="outline"><Settings className="w-4 h-4 mr-2" /> Edit Profile</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
