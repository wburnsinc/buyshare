import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Eye, EyeOff, ArrowRight, Mail, Lock, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import blueTruckLogo from "@assets/Blue_Truck_LOGO_1782419251695.PNG";
import shareLogo from "@assets/SHARE_LOGO_1782419307093.png";

const DEMO_ROLES = [
  { value: "customer", label: "Customer Demo", icon: "🏠", email: "customer@buyshare.co" },
  { value: "contractor", label: "Contractor Demo", icon: "🔨", email: "contractor@buyshare.co" },
  { value: "dispatcher", label: "Dispatcher Demo", icon: "📡", email: "dispatch@buyshare.co" },
  { value: "investor", label: "Investor Demo", icon: "💼", email: "investor@buyshare.co" },
  { value: "admin", label: "Admin Demo", icon: "🛡️", email: "admin@buyshare.co" },
];

export default function SignInPage() {
  const { toast } = useToast();
  const [showPass, setShowPass] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [loggedRole, setLoggedRole] = useState("");

  function handleSignIn() {
    if (!email || !password) { toast({ title: "Please fill in all fields", variant: "destructive" }); return; }
    const matched = DEMO_ROLES.find(r => r.email === email.toLowerCase());
    const role = matched?.value || "customer";
    localStorage.setItem("buyshare_role", role);
    localStorage.setItem("buyshare_user", JSON.stringify({ name: "Demo User", email, role }));
    setLoggedRole(matched?.label || "Customer");
    setLoggedIn(true);
    toast({ title: "Signed in! 👋", description: `Welcome back to BuyShare.co.` });
  }

  function loginAsDemo(r: typeof DEMO_ROLES[0]) {
    localStorage.setItem("buyshare_role", r.value);
    localStorage.setItem("buyshare_user", JSON.stringify({ name: `${r.label.replace(" Demo", "")}`, email: r.email, role: r.value }));
    setLoggedRole(r.label);
    setLoggedIn(true);
    toast({ title: `Signed in as ${r.label} 👋` });
  }

  if (loggedIn) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-sm">
          <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-14 h-14 text-green-500" />
          </div>
          <h2 className="text-3xl font-black mb-2">You're in!</h2>
          <Badge className="mb-6" style={{ background: "#1fbe4b22", color: "#1fbe4b" }}>{loggedRole}</Badge>
          <div className="space-y-3">
            <Link href="/dashboard"><Button className="w-full text-white" style={{ background: "#1fbe4b" }}>Go to Dashboard <ArrowRight className="w-4 h-4 ml-2" /></Button></Link>
            <Link href="/"><Button variant="outline" className="w-full">Browse BuyShare.co</Button></Link>
            {loggedRole.toLowerCase().includes("admin") && <Link href="/admin"><Button variant="outline" className="w-full">Admin Portal →</Button></Link>}
            {loggedRole.toLowerCase().includes("contractor") && <Link href="/contractor/portal"><Button variant="outline" className="w-full">Contractor Portal →</Button></Link>}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col lg:flex-row">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-5/12 flex-col justify-between p-12 text-white" style={{ background: "linear-gradient(135deg, #001a4a 0%, #002a6e 100%)" }}>
        <div className="flex items-center gap-3">
          <img src={blueTruckLogo} alt="Blue Truck" className="h-12 object-contain" />
          <img src={shareLogo} alt="SHARE" className="h-10 object-contain" />
        </div>
        <div>
          <h2 className="text-4xl font-black mb-4">Welcome back.</h2>
          <p className="text-white/70 text-lg mb-8">Sign in to manage bookings, access your contractor portal, view earnings, and more.</p>
          <div className="space-y-2">
            <p className="text-white/40 text-sm uppercase tracking-widest font-semibold">Quick Demo Access</p>
            <div className="space-y-2">
              {DEMO_ROLES.map(r => (
                <button key={r.value} onClick={() => loginAsDemo(r)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/15 transition-colors text-left">
                  <span className="text-xl">{r.icon}</span>
                  <div>
                    <div className="font-semibold text-sm">{r.label}</div>
                    <div className="text-white/40 text-xs">{r.email}</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-white/30 ml-auto" />
                </button>
              ))}
            </div>
          </div>
        </div>
        <p className="text-white/30 text-sm">BuyShare.co · SW Florida</p>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <h1 className="text-3xl font-black mb-1">Sign In</h1>
            <p className="text-muted-foreground">Enter your credentials or use a demo account</p>
          </div>

          <div className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input className="pl-10" type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} data-testid="input-signin-email" />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input className="pl-10 pr-10" type={showPass ? "text" : "password"} placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} data-testid="input-signin-password" />
              <button type="button" onClick={() => setShowPass(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="w-3.5 h-3.5" /> Remember me</label>
              <button className="text-blue-600 hover:underline">Forgot password?</button>
            </div>
            <Button className="w-full text-white font-bold" style={{ background: "#002a6e" }} onClick={handleSignIn} data-testid="btn-sign-in">
              Sign In <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>

          {/* Mobile demo buttons */}
          <div className="lg:hidden mt-6">
            <p className="text-sm text-muted-foreground mb-3 text-center">Quick Demo Access</p>
            <div className="grid grid-cols-2 gap-2">
              {DEMO_ROLES.map(r => (
                <button key={r.value} onClick={() => loginAsDemo(r)}
                  className="flex items-center gap-2 p-3 rounded-xl border border-border hover:bg-accent transition-colors text-sm">
                  <span>{r.icon}</span><span className="font-medium">{r.label}</span>
                </button>
              ))}
            </div>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-6">
            New to BuyShare?{" "}
            <Link href="/sign-up" className="font-semibold" style={{ color: "#002a6e" }}>Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
