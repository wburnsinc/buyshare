import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Star, MapPin, CheckCircle2, Wrench, ChevronRight, Search } from "lucide-react";
import { useListContractors } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

const CATEGORIES = ["All", "Lawn Care", "Pool Services", "HVAC", "Plumbing", "Electrical", "Construction", "Cleaning", "Painting", "Roofing", "Handyman", "Delivery"];

export default function ContractorsPage() {
  const [activeCategory, setActiveCategory] = useState("");
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const { data: contractors, isLoading } = useListContractors({
    category: activeCategory || undefined,
    verified: verifiedOnly || undefined,
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-[#002a6e] text-white py-12 px-4" data-testid="contractors-header">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-black text-3xl md:text-4xl mb-1">Find a Contractor</h1>
            <p className="text-blue-200">Browse verified professionals across every trade.</p>
          </div>
          <Link href="/contractors/join">
            <Button style={{ background: "#1fbe4b", color: "white" }} data-testid="button-join-contractor">
              Join as Contractor <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mb-8" data-testid="contractor-filters">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat === "All" ? "" : cat)}
              data-testid={`filter-${cat.toLowerCase().replace(/\s/g, "-")}`}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                (activeCategory === cat || (cat === "All" && !activeCategory))
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary"
              }`}
            >
              {cat}
            </button>
          ))}
          <button
            onClick={() => setVerifiedOnly(!verifiedOnly)}
            data-testid="filter-verified"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${verifiedOnly ? "bg-secondary text-secondary-foreground border-secondary" : "border-border text-muted-foreground hover:border-secondary"}`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" /> Verified Only
          </button>
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)}
          </div>
        ) : (contractors ?? []).length === 0 ? (
          <div className="text-center py-20 text-muted-foreground" data-testid="empty-contractors">
            <Wrench className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium">No contractors found</p>
            <p className="text-sm">Try a different category or remove filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {(contractors ?? []).map((contractor, i) => (
              <motion.div
                key={contractor.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-border bg-card p-5 hover:shadow-lg transition-shadow"
                data-testid={`card-contractor-${contractor.id}`}
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary text-lg shrink-0">
                    {contractor.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold truncate">{contractor.name}</h3>
                      {contractor.verified && <CheckCircle2 className="w-4 h-4 shrink-0" style={{ color: "#1fbe4b" }} />}
                    </div>
                    {contractor.company && <p className="text-xs text-muted-foreground">{contractor.company}</p>}
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span className="text-xs font-medium">{contractor.rating}</span>
                      <span className="text-xs text-muted-foreground">({contractor.reviewCount} reviews)</span>
                    </div>
                  </div>
                  <Badge variant={contractor.status === "active" ? "default" : "secondary"} className="text-xs shrink-0">
                    {contractor.status}
                  </Badge>
                </div>

                <div className="flex flex-wrap gap-1 mb-3">
                  {contractor.categories.slice(0, 3).map(cat => (
                    <Badge key={cat} variant="secondary" className="text-xs">{cat}</Badge>
                  ))}
                </div>

                <div className="flex flex-wrap gap-1 mb-4">
                  {contractor.serviceAreas.slice(0, 2).map(area => (
                    <span key={area} className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="w-3 h-3" />{area}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{contractor.jobsCompleted} jobs completed</span>
                  <Button size="sm" variant="outline" data-testid={`button-contact-${contractor.id}`}>Contact</Button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
