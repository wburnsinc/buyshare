import { motion } from "framer-motion";
import { Truck, Share2, Phone, DollarSign, CheckCircle2 } from "lucide-react";
import blueTruckLogo from "@assets/Blue_Truck_LOGO_1782419251695.PNG";
import shareLogo from "@assets/SHARE_LOGO_1782419307093.png";

const TIMELINE = [
  { year: "2020", event: "Blue Truck LLC founded in Punta Gorda, FL — pool care and lawn services for Southwest Florida." },
  { year: "2022", event: "Expanded contractor network to 50+ local service professionals across Charlotte County." },
  { year: "2023", event: "Launched SHARE™ — peer-to-peer marketplace for pools, homes, boats, and more." },
  { year: "2024", event: "BurnCall AI receptionist goes live — responding to 1,000+ leads per month automatically." },
  { year: "2025", event: "PocketCash integrated — unified payout and invoice platform for all contractors." },
  { year: "2026", event: "BuyShare.co launched — one unified platform connecting all brands under a single login." },
];

const BRANDS = [
  { icon: Truck, name: "Blue Truck LLC", desc: "The origin story. A local home services business that grew into a platform." },
  { icon: Share2, name: "SHARE™", desc: "The sharing marketplace. Rent anything, earn from everything you own." },
  { icon: Phone, name: "BurnCall", desc: "The lead capture engine. AI answering every call so you never miss a job." },
  { icon: DollarSign, name: "PocketCash", desc: "The money layer. Payouts, invoices, credits, and contractor earnings." },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#002a6e] text-white py-16 px-4" data-testid="about-header">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="font-black text-4xl md:text-5xl mb-4 leading-tight">
              Built in Florida.<br />
              <span style={{ color: "#1fbe4b" }}>Built for America.</span>
            </h1>
            <p className="text-blue-200 text-lg leading-relaxed">BuyShare.co started as a local pool care company in Punta Gorda and grew into a unified platform that brings contractors, homeowners, and investors together under one roof.</p>
          </div>
          <div className="flex items-center gap-6 justify-center">
            <img src={blueTruckLogo} alt="Blue Truck LLC" className="h-28 w-auto object-contain drop-shadow-2xl" />
            <img src={shareLogo} alt="SHARE™" className="h-24 w-auto object-contain drop-shadow-2xl" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
        {/* Mission */}
        <section className="text-center max-w-3xl mx-auto" data-testid="section-mission">
          <h2 className="font-black text-3xl mb-4">Our Mission</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            To create the most trusted home services and sharing economy marketplace in America — where every homeowner can find a reliable pro, every contractor can build a real business, and every investor can see exactly where their money is going.
          </p>
        </section>

        {/* Brand Stories */}
        <section data-testid="section-brands">
          <h2 className="font-bold text-2xl mb-8 text-center">The Four Pillars</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {BRANDS.map((b, i) => {
              const Icon = b.icon;
              return (
                <motion.div
                  key={b.name}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="flex gap-4 p-6 rounded-2xl border border-border hover:shadow-md transition-shadow"
                  data-testid={`card-brand-about-${b.name.toLowerCase().replace(/[^a-z]/g, "-")}`}
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-1">{b.name}</h3>
                    <p className="text-muted-foreground">{b.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Timeline */}
        <section data-testid="section-timeline">
          <h2 className="font-bold text-2xl mb-8 text-center">Our Journey</h2>
          <div className="space-y-4 max-w-2xl mx-auto">
            {TIMELINE.map((item, i) => (
              <motion.div
                key={item.year}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="flex gap-4 items-start"
                data-testid={`timeline-item-${item.year}`}
              >
                <div className="text-primary font-extrabold text-lg w-12 shrink-0 mt-0.5">{item.year}</div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 mt-0.5 shrink-0" style={{ color: "#1fbe4b" }} />
                  <p className="text-muted-foreground">{item.event}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Contact */}
        <section className="text-center" data-testid="section-about-contact">
          <h2 className="font-bold text-2xl mb-4">Get in Touch</h2>
          <p className="text-muted-foreground mb-2">Florida, USA</p>
          <p className="text-muted-foreground mb-1"><a href="tel:2232548299" className="text-primary font-semibold">223-254-8299</a></p>
          <p className="text-muted-foreground"><a href="mailto:BurnsInc@Outlook.com" className="text-primary font-semibold">BurnsInc@Outlook.com</a></p>
        </section>
      </div>
    </div>
  );
}
