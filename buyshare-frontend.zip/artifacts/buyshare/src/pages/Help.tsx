import { Phone, Mail, MapPin, ChevronDown } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FAQS = [
  { q: "How do I book a service?", a: "Browse our service categories, select the service you need, choose a date and time, and complete the booking form. We'll confirm within 24 hours and assign a verified contractor." },
  { q: "What areas does Blue Truck LLC serve?", a: "We currently serve Punta Gorda, Port Charlotte, Deep Creek, North Port, Burnt Store, and Charlotte Harbor in Southwest Florida." },
  { q: "How much does pool care cost?", a: "Monthly pool care starts at $99/month. Our pool + lawn bundle is $180/month. All pricing includes full-service chemical balancing, brushing, vacuuming, and filter cleaning." },
  { q: "How do I join as a contractor?", a: "Visit our Contractor Enrollment page and complete the application form. We verify licenses, insurance, and service areas before approving new contractors." },
  { q: "What is SHARE™?", a: "SHARE™ is our peer-to-peer marketplace where you can rent out or rent pools, homes, boats, parking spaces, yards, RVs, and more. List your assets and earn passive income." },
  { q: "What is BurnCall?", a: "BurnCall is our AI-powered phone and SMS receptionist. It automatically responds to incoming leads within 60 seconds, qualifies prospects, and can book appointments — even when you're unavailable." },
  { q: "What is PocketCash?", a: "PocketCash is our integrated payment and payout system. It handles contractor payouts, customer invoices, BuyShare credits, and referral rewards — all in one dashboard." },
  { q: "How do I request a refund?", a: "Refund requests must be submitted within 48 hours of service completion. Contact us at BurnsInc@Outlook.com or call 223-254-8299 with your booking ID." },
  { q: "Are contractors background-checked?", a: "Yes. All contractors on BuyShare.co must submit license documentation, proof of insurance, and pass our verification process before being listed." },
  { q: "How does delivery and hauling pricing work?", a: "Our flat-rate delivery: $75 for local transportation up to 15 miles, $90 for over 15 miles. Up to 20 minutes at the destination for loading/unloading is included." },
];

export default function HelpPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#002a6e] text-white py-12 px-4" data-testid="help-header">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="font-black text-3xl md:text-4xl mb-2">Help Center</h1>
          <p className="text-blue-200 text-lg">Find answers to common questions or reach us directly.</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
        {/* Contact */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-testid="contact-cards">
          {[
            { icon: Phone, label: "Call Us", value: "223-254-8299", href: "tel:2232548299" },
            { icon: Mail, label: "Email Us", value: "BurnsInc@Outlook.com", href: "mailto:BurnsInc@Outlook.com" },
            { icon: MapPin, label: "Service Area", value: "Punta Gorda, FL", href: undefined },
          ].map(item => {
            const Icon = item.icon;
            return (
              <div key={item.label} className="flex items-center gap-3 p-5 rounded-2xl border border-border bg-card" data-testid={`contact-card-${item.label.toLowerCase().replace(/\s/g, "-")}`}>
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  {item.href ? (
                    <a href={item.href} className="font-semibold text-sm hover:text-primary transition-colors">{item.value}</a>
                  ) : (
                    <p className="font-semibold text-sm">{item.value}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQs */}
        <div>
          <h2 className="font-bold text-2xl mb-6">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="space-y-3" data-testid="faq-accordion">
            {FAQS.map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`} className="border border-border rounded-xl px-4" data-testid={`faq-item-${i}`}>
                <AccordionTrigger className="font-semibold text-sm text-left py-4">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm pb-4">{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Service Hours */}
        <div className="rounded-2xl border border-border bg-card p-6" data-testid="service-hours">
          <h3 className="font-bold mb-4">Service Hours</h3>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><p className="text-muted-foreground text-xs uppercase tracking-wide mb-1">Monday – Saturday</p><p className="font-semibold">7:00 AM – 7:00 PM</p></div>
            <div><p className="text-muted-foreground text-xs uppercase tracking-wide mb-1">Sunday</p><p className="font-semibold">8:00 AM – 5:00 PM</p></div>
          </div>
          <p className="text-xs text-muted-foreground mt-3">Platform support available 24/7 via email. Emergency services available by phone.</p>
        </div>
      </div>
    </div>
  );
}
