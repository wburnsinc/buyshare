import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, Wrench, MapPin, Clock } from "lucide-react";
import { useListBookings, useUpdateBooking, getListBookingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const STATUS_OPTIONS = ["All", "pending", "confirmed", "assigned", "en_route", "in_progress", "completed", "cancelled"];
const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300",
  confirmed: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  assigned: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  en_route: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
  in_progress: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300",
  completed: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  cancelled: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
};

export default function BookingsPage() {
  const [statusFilter, setStatusFilter] = useState("");
  const { data: bookings, isLoading } = useListBookings(statusFilter ? { status: statusFilter } : {});
  const updateBooking = useUpdateBooking();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  function handleStatusChange(id: number, status: string) {
    updateBooking.mutate({ id, data: { status } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListBookingsQueryKey({}) });
        toast({ title: "Booking updated" });
      },
    });
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#002a6e] text-white py-10 px-4" data-testid="bookings-header">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-black text-2xl md:text-3xl mb-1">My Bookings</h1>
          <p className="text-blue-200">Track and manage all your service bookings.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filter */}
        <div className="flex flex-wrap gap-2 mb-6" data-testid="status-filters">
          {STATUS_OPTIONS.map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s === "All" ? "" : s)}
              data-testid={`filter-status-${s.toLowerCase()}`}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border capitalize transition-colors ${
                (statusFilter === s || (s === "All" && !statusFilter))
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary"
              }`}
            >
              {s.replace("_", " ")}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div>
        ) : (bookings ?? []).length === 0 ? (
          <div className="text-center py-20 text-muted-foreground" data-testid="empty-bookings">
            <Calendar className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium">No bookings found</p>
          </div>
        ) : (
          <div className="space-y-3">
            {(bookings ?? []).map((booking, i) => (
              <motion.div
                key={booking.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="flex flex-col sm:flex-row sm:items-center gap-4 p-5 rounded-2xl border border-border bg-card hover:shadow-md transition-shadow"
                data-testid={`booking-card-${booking.id}`}
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Wrench className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold truncate">{booking.serviceName}</h3>
                  <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {booking.scheduledDate} at {booking.scheduledTime}</span>
                    <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {booking.zipCode}</span>
                    {booking.price && <span className="font-semibold text-foreground">${booking.price}</span>}
                  </div>
                  {booking.contractorName && <p className="text-xs text-muted-foreground mt-1">Contractor: {booking.contractorName}</p>}
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full capitalize ${STATUS_COLORS[booking.status] ?? "bg-gray-100 text-gray-700"}`}>
                    {booking.status.replace("_", " ")}
                  </span>
                  <Select value={booking.status} onValueChange={v => handleStatusChange(booking.id, v)}>
                    <SelectTrigger className="w-32 text-xs h-8" data-testid={`select-status-${booking.id}`}><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STATUS_OPTIONS.filter(s => s !== "All").map(s => (
                        <SelectItem key={s} value={s} className="capitalize">{s.replace("_", " ")}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
