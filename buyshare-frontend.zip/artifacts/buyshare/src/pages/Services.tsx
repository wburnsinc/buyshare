import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Leaf, Hammer, Droplets, Sparkles, Wind, Wrench, Zap, Paintbrush, Home, Truck, Search as SearchIcon, MapPin, ChevronRight } from "lucide-react";
import { useListServices } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

const ICON_MAP: Record<string, React.ElementType> = {
  Leaf, Hammer, Droplets, Sparkles, Wind, Wrench, Zap, Paintbrush, Home, Truck,
};

const CATEGORIES = ["All", "Lawn Care", "Pool Services", "Construction", "HVAC", "Plumbing", "Electrical", "Cleaning", "Painting", "Roofing", "Handyman", "Delivery"];

export default function ServicesPage() {
  const [category, setCategory] = useState("");
  const [zip, setZip] = useState("");
  const [searchZip, setSearchZip] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const { data: services, isLoading } = useListServices(
    category && category !== "All" ? { category, zipCode: searchZip || undefined } : { zipCode: searchZip || undefined }
  );

  const filtered = (services ?? []).filter(s =>
    activeCategory === "All" || s.category === activeCategory
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-[#002a6e] text-white py-12 px-4" data-testid="services-header">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-black text-3xl md:text-4xl mb-2">Find a Service</h1>
          <p className="text-blue-200 mb-8">Browse local, verified professionals across every trade.</p>
          <div className="flex flex-col sm:flex-row gap-3 max-w-2xl">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
              <input
                className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder:text-white/50 text-sm focus:outline-none focus:border-white/50"
                placeholder="Service type..."
                data-testid="input-service-search"
              />
            </div>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
              <input
                className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder:text-white/50 text-sm focus:outline-none focus:border-white/50 w-40"
                placeholder="ZIP code"
                value={zip}
                onChange={e => setZip(e.target.value)}
                data-testid="input-zip-code"
              />
            </div>
            <Button
              style={{ background: "#1fbe4b", color: "white" }}
              onClick={() => setSearchZip(zip)}
              data-testid="button-search-services"
            >
              Search
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Category filter */}
        <div className="flex flex-wrap gap-2 mb-8" data-testid="category-filters">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => { setActiveCategory(cat); setCategory(cat === "All" ? "" : cat); }}
              data-testid={`filter-${cat.toLowerCase().replace(/\s/g, "-")}`}
              className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                activeCategory === cat
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background text-muted-foreground border-border hover:border-primary hover:text-primary"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Service Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-36 rounded-xl" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground" data-testid="empty-services">
            <Wrench className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium">No services found</p>
            <p className="text-sm">Try a different category or ZIP code</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filtered.map((service, i) => {
              const Icon = ICON_MAP[service.iconName] ?? Wrench;
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  data-testid={`card-service-${service.id}`}
                >
                  <Link href={`/contractors?category=${encodeURIComponent(service.name)}`}>
                    <div className="rounded-xl border border-border p-5 cursor-pointer hover:border-primary hover:shadow-md transition-all group">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <h3 className="font-semibold text-sm mb-1">{service.name}</h3>
                      {service.basePrice && (
                        <p className="text-xs text-muted-foreground mb-2">From ${service.basePrice}/{service.priceUnit}</p>
                      )}
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="text-xs">{service.contractorCount} pros</Badge>
                        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

