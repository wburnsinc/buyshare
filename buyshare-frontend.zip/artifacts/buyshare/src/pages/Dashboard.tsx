import { Link } from "wouter";
import { motion } from "framer-motion";
import { Calendar, MessageSquare, DollarSign, TrendingUp, CheckCircle2, Clock, Star, Wrench, Users, Phone } from "lucide-react";
import { useGetDashboardSummary, useGetRecentActivity, useGetMe, useGetPaymentSummary, useListBookings } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

const role = () => (localStorage.getItem("buyshare_role") || "customer") as "customer" | "contractor" | "dispatcher" | "investor" | "admin";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300",
  confirmed: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  assigned: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  en_route: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
  in_progress: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  completed: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  cancelled: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
};

export default function DashboardPage() {
  const { data: me, isLoading: meLoading } = useGetMe();
  const { data: summary, isLoading: summaryLoading } = useGetDashboardSummary();
  const { data: activity } = useGetRecentActivity();
  const { data: payments } = useGetPaymentSummary();
  const { data: bookings } = useListBookings({});

  const currentRole = role();

  const STAT_CARDS = [
    { label: "Total Bookings", value: summary?.totalBookings ?? 0, icon: Calendar, color: "#002a6e", href: "/dashboard/bookings" },
    { label: "Active Contractors", value: summary?.activeContractors ?? 0, icon: Users, color: "#1fbe4b", href: "/contractors" },
    { label: "Revenue", value: `$${(summary?.totalRevenue ?? 0).toLocaleString()}`, icon: DollarSign, color: "#001a4a", href: "/dashboard/payments" },
    { label: "Pending Jobs", value: summary?.pendingJobs ?? 0, icon: Clock, color: "#f59e0b", href: "/dashboard/bookings" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-[#002a6e] text-white py-10 px-4" data-testid="dashboard-header">
        <div className="max-w-7xl mx-auto">
          {meLoading ? (
            <Skeleton className="h-10 w-64 bg-white/20" />
          ) : (
            <div>
              <p className="text-blue-200 text-sm uppercase tracking-widest mb-1">Welcome back</p>
              <h1 className="font-black text-2xl md:text-3xl" data-testid="text-dashboard-greeting">
                {me?.name ?? "Demo User"}
              </h1>
              <div className="flex items-center gap-2 mt-2">
                <Badge className="capitalize text-xs" style={{ background: "rgba(255,255,255,0.15)", color: "white" }}>
                  {currentRole}
                </Badge>
                <span className="text-blue-200 text-sm">{me?.credits ?? 0} BuyShare Credits</span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stat Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {summaryLoading
            ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)
            : STAT_CARDS.map((stat, i) => {
                const Icon = stat.icon;
                return (
                  <Link key={stat.label} href={stat.href}>
                    <motion.div
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.07 }}
                      className="rounded-xl border border-border bg-card p-5 hover:shadow-md transition-shadow cursor-pointer"
                      data-testid={`stat-card-${stat.label.toLowerCase().replace(/\s/g, "-")}`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${stat.color}15` }}>
                          <Icon className="w-4 h-4" style={{ color: stat.color }} />
                        </div>
                      </div>
                      <p className="font-extrabold text-2xl">{stat.value}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
                    </motion.div>
                  </Link>
                );
              })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Bookings */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-lg">Recent Bookings</h2>
              <Link href="/dashboard/bookings"><Button variant="outline" size="sm" data-testid="button-view-all-bookings">View All</Button></Link>
            </div>
            {(bookings ?? []).slice(0, 5).map(booking => (
              <div key={booking.id} className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card" data-testid={`booking-row-${booking.id}`}>
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <Wrench className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{booking.serviceName}</p>
                  <p className="text-xs text-muted-foreground">{booking.scheduledDate} at {booking.scheduledTime}</p>
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${STATUS_COLORS[booking.status] ?? "bg-gray-100 text-gray-700"}`}>
                  {booking.status.replace("_", " ")}
                </span>
              </div>
            ))}
            {(bookings ?? []).length === 0 && (
              <div className="text-center py-10 text-muted-foreground border border-dashed border-border rounded-xl" data-testid="empty-dashboard-bookings">
                <Calendar className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No bookings yet</p>
                <Link href="/services"><Button size="sm" className="mt-3" style={{ background: "#1fbe4b", color: "white" }}>Book a Service</Button></Link>
              </div>
            )}
          </div>

          {/* Right sidebar */}
          <div className="space-y-4">
            {/* Payment Summary */}
            <div className="rounded-xl border border-border bg-card p-5" data-testid="card-payment-summary">
              <h3 className="font-bold mb-4 flex items-center gap-2"><DollarSign className="w-4 h-4" /> PocketCash</h3>
              {payments ? (
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Total Spent</span><span className="font-semibold">${payments.totalSpent.toLocaleString()}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Total Earned</span><span className="font-semibold text-green-600">${payments.totalEarned.toLocaleString()}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Credits</span><span className="font-semibold">${payments.credits}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Pending Payouts</span><span className="font-semibold text-amber-600">${payments.pendingPayouts.toLocaleString()}</span></div>
                </div>
              ) : <Skeleton className="h-24 w-full" />}
              <Link href="/dashboard/payments"><Button size="sm" variant="outline" className="w-full mt-4" data-testid="button-view-payments">View Payments</Button></Link>
            </div>

            {/* Quick Links */}
            <div className="rounded-xl border border-border bg-card p-5" data-testid="card-quick-links">
              <h3 className="font-bold mb-4">Quick Access</h3>
              <div className="space-y-2">
                <Link href="/services"><Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="quick-link-book"><Calendar className="w-4 h-4" /> Book a Service</Button></Link>
                <Link href="/dashboard/messages"><Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="quick-link-messages"><MessageSquare className="w-4 h-4" /> Messages</Button></Link>
                <Link href="/contractors"><Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="quick-link-contractors"><Users className="w-4 h-4" /> Find Contractors</Button></Link>
                <Link href="/burncall"><Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="quick-link-burncall"><Phone className="w-4 h-4" /> BurnCall Leads</Button></Link>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="rounded-xl border border-border bg-card p-5" data-testid="card-activity">
              <h3 className="font-bold mb-4">Activity</h3>
              <div className="space-y-3">
                {(activity ?? []).slice(0, 4).map(item => (
                  <div key={item.id} className="flex items-start gap-2" data-testid={`activity-${item.id}`}>
                    <div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                    <div>
                      <p className="text-xs text-foreground leading-tight">{item.description}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{item.actor}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
