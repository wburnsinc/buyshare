import { useState } from "react";
import { useGetMe, useUpdateMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { User, Bell, Shield, Trash2 } from "lucide-react";

export default function SettingsPage() {
  const { data: me, isLoading } = useGetMe();
  const updateMe = useUpdateMe();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", phone: "", zipCode: "" });
  const [initialized, setInitialized] = useState(false);

  if (me && !initialized) {
    setForm({ name: me.name, phone: me.phone ?? "", zipCode: me.zipCode ?? "" });
    setInitialized(true);
  }

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    updateMe.mutate({ data: { name: form.name, phone: form.phone || undefined, zipCode: form.zipCode || undefined } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        toast({ title: "Profile updated successfully" });
      },
    });
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#002a6e] text-white py-10 px-4" data-testid="settings-header">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-black text-2xl md:text-3xl">Account Settings</h1>
          <p className="text-blue-200">Manage your profile, notifications, and account preferences.</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
        {/* Profile */}
        <section className="rounded-2xl border border-border bg-card p-6" data-testid="section-profile">
          <div className="flex items-center gap-2 mb-5">
            <User className="w-4 h-4 text-primary" />
            <h2 className="font-bold">Profile Information</h2>
          </div>
          {isLoading ? (
            <div className="space-y-4"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
          ) : (
            <form onSubmit={handleSave} className="space-y-4" data-testid="form-profile">
              <div>
                <Label>Email</Label>
                <Input value={me?.email ?? ""} disabled className="text-muted-foreground" data-testid="input-settings-email" />
                <p className="text-xs text-muted-foreground mt-1">Email cannot be changed.</p>
              </div>
              <div>
                <Label>Full Name</Label>
                <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} data-testid="input-settings-name" />
              </div>
              <div>
                <Label>Phone</Label>
                <Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="(941) 555-0000" data-testid="input-settings-phone" />
              </div>
              <div>
                <Label>ZIP Code</Label>
                <Input value={form.zipCode} onChange={e => setForm({ ...form, zipCode: e.target.value })} placeholder="33950" data-testid="input-settings-zip" />
              </div>
              <div className="flex items-center gap-3">
                <Button type="submit" disabled={updateMe.isPending} style={{ background: "#1fbe4b", color: "white" }} data-testid="button-save-profile">
                  {updateMe.isPending ? "Saving..." : "Save Changes"}
                </Button>
                <div>
                  <span className="text-sm text-muted-foreground">Role: </span>
                  <Badge className="capitalize">{me?.role}</Badge>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Credits: </span>
                  <span className="font-semibold">${me?.credits}</span>
                </div>
              </div>
            </form>
          )}
        </section>

        {/* Notifications */}
        <section className="rounded-2xl border border-border bg-card p-6" data-testid="section-notifications">
          <div className="flex items-center gap-2 mb-5">
            <Bell className="w-4 h-4 text-primary" />
            <h2 className="font-bold">Notification Preferences</h2>
          </div>
          <div className="space-y-4 text-sm">
            {[
              "Email notifications for new bookings",
              "SMS alerts for contractor updates",
              "BurnCall lead notifications",
              "Weekly platform digest",
              "Investor report emails",
            ].map(pref => (
              <div key={pref} className="flex items-center justify-between py-2 border-b border-border last:border-0" data-testid={`pref-${pref.toLowerCase().replace(/\s/g, "-")}`}>
                <span className="text-muted-foreground">{pref}</span>
                <button className="w-10 h-5 rounded-full bg-primary relative transition-colors" aria-label={pref}>
                  <span className="absolute right-0.5 top-0.5 w-4 h-4 rounded-full bg-white shadow" />
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Security */}
        <section className="rounded-2xl border border-border bg-card p-6" data-testid="section-security">
          <div className="flex items-center gap-2 mb-5">
            <Shield className="w-4 h-4 text-primary" />
            <h2 className="font-bold">Security</h2>
          </div>
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start" data-testid="button-change-password">Change Password</Button>
            <Button variant="outline" className="w-full justify-start" data-testid="button-two-factor">Enable Two-Factor Authentication</Button>
          </div>
        </section>

        {/* Danger Zone */}
        <section className="rounded-2xl border border-red-200 dark:border-red-900/30 bg-red-50 dark:bg-red-900/10 p-6" data-testid="section-danger-zone">
          <div className="flex items-center gap-2 mb-3">
            <Trash2 className="w-4 h-4 text-destructive" />
            <h2 className="font-bold text-destructive">Danger Zone</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">Once you delete your account, there is no going back. All your bookings, payment history, and listings will be permanently removed.</p>
          <Button variant="destructive" size="sm" data-testid="button-delete-account">Delete My Account</Button>
        </section>
      </div>
    </div>
  );
}
