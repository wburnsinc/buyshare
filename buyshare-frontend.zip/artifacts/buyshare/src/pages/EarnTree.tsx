import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { TreePine, DollarSign, TrendingUp, Gift, Users, Star, Plus, Copy, CheckCircle2, Target, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const SOURCE_LABELS: Record<string, string> = {
  share_rental: "SHARE™ Rental", referral: "Referral Bonus", contractor_bonus: "Contractor Bonus",
  platform_credit: "Platform Credit", thriftgirl_sale: "ThriftGirl Sale", rideshare_payout: "Rideshare Payout",
  playdate_hosting: "Playdate Hosting", review_bonus: "Review Bonus", signup_bonus: "Signup Bonus",
};

const SOURCE_COLORS: Record<string, string> = {
  share_rental: "#0ea5e9", referral: "#1fbe4b", contractor_bonus: "#f59e0b",
  platform_credit: "#8b5cf6", thriftgirl_sale: "#ec4899", rideshare_payout: "#2563eb",
  playdate_hosting: "#f97316", review_bonus: "#14b8a6", signup_bonus: "#6366f1",
};

const PIE_COLORS = ["#0ea5e9", "#1fbe4b", "#f59e0b", "#8b5cf6", "#ec4899", "#f97316"];

const EARNING_SOURCES = [
  { icon: "🏠", title: "SHARE™ Rentals", desc: "List your pool, yard, RV, or home. Earn every time someone books.", avg: "$45–$120/day" },
  { icon: "🎽", title: "ThriftGirl Sales", desc: "Sell your pre-loved items. Keep 92% of every sale.", avg: "$10–$200/item" },
  { icon: "🚗", title: "Rideshare Driving", desc: "Drive locally, set your hours. No commitments.", avg: "$15–$25/hr" },
  { icon: "👨‍👧", title: "Playdate Hosting", desc: "Host kids events at your home or park. Earn per child.", avg: "$5–$20/kid" },
  { icon: "🔗", title: "Referral Program", desc: "Earn $25 for every friend who joins BuyShare.co.", avg: "$25/referral" },
  { icon: "⭐", title: "Review Rewards", desc: "Leave genuine reviews after every service.", avg: "$1–$5/review" },
  { icon: "🔨", title: "Contractor Work", desc: "Complete verified service jobs via Blue Truck or SHARE™.", avg: "$50–$200/job" },
  { icon: "🎯", title: "Signup Bonus", desc: "One-time bonus for completing your profile.", avg: "$10 one-time" },
];

export default function EarnTreePage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [copied, setCopied] = useState(false);
  const [showGoalForm, setShowGoalForm] = useState(false);
  const [goalForm, setGoalForm] = useState({ title: "", targetAmount: "", deadline: "" });

  const { data: summary } = useQuery({
    queryKey: ["earntree-summary"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/earntree/summary`); return res.json(); },
  });

  const { data: earnings = [] } = useQuery({
    queryKey: ["earntree-earnings"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/earntree/earnings`); return res.json(); },
  });

  const { data: referral } = useQuery({
    queryKey: ["earntree-referral"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/earntree/referral-code`); return res.json(); },
  });

  const createGoal = useMutation({
    mutationFn: async (data: typeof goalForm) => {
      const res = await fetch(`${BASE}/api/earntree/goals`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, targetAmount: Number(data.targetAmount) }),
      });
      return res.json();
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["earntree-summary"] }); toast({ title: "Goal set! 🎯", description: "Start earning to hit your target." }); setShowGoalForm(false); },
  });

  const pieData = summary?.bySource
    ? Object.entries(summary.bySource as Record<string, number>).map(([k, v]) => ({ name: SOURCE_LABELS[k] || k, value: v }))
    : [];

  const barData = (earnings as any[]).slice(-10).map((e: any) => ({
    name: SOURCE_LABELS[e.source]?.split(" ")[0] || e.source,
    amount: Number(e.amount),
  }));

  const handleCopy = () => {
    if (referral?.code) { navigator.clipboard.writeText(referral.code); setCopied(true); setTimeout(() => setCopied(false), 2000); toast({ title: "Copied! 🎉", description: "Share your code to earn $25 per referral." }); }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #14532d 0%, #16a34a 50%, #1fbe4b 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 py-16 text-white">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Badge className="mb-4 bg-white/20 text-white border-0 text-sm">🌱 Grow Your Income</Badge>
            <h1 className="text-5xl font-black mb-4">EarnTree™</h1>
            <p className="text-xl text-white/80 mb-8 max-w-2xl">
              Every listing, referral, review, and service grows your earning tree. Multiple income streams, one unified platform.
            </p>
            <div className="grid grid-cols-3 gap-4 max-w-sm">
              {summary ? [
                { label: "Total Earned", value: `$${Number(summary.total).toFixed(0)}` },
                { label: "Paid Out", value: `$${Number(summary.paid).toFixed(0)}` },
                { label: "Pending", value: `$${Number(summary.pending).toFixed(0)}` },
              ] : [
                { label: "Total Earned", value: "—" },
                { label: "Paid Out", value: "—" },
                { label: "Pending", value: "—" },
              ].map(s => (
                <div key={s.label} className="bg-white/10 rounded-xl p-3 text-center">
                  <div className="text-xl font-black">{s.value}</div>
                  <div className="text-xs text-white/70">{s.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
          {/* Animated tree */}
          <div className="absolute right-8 top-8 text-9xl opacity-20 select-none">🌳</div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Charts + Earnings */}
          <div className="lg:col-span-2 space-y-6">
            {/* Summary cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Total Earned", value: `$${Number(summary?.total || 0).toFixed(0)}`, icon: DollarSign, color: "text-green-600" },
                { label: "Referrals", value: summary?.referrals || 0, icon: Users, color: "text-blue-600" },
                { label: "Goals", value: summary?.goals?.length || 0, icon: Target, color: "text-purple-600" },
                { label: "Streams", value: Object.keys(summary?.bySource || {}).length || 0, icon: Zap, color: "text-orange-500" },
              ].map(s => (
                <div key={s.label} className="p-4 rounded-2xl border border-border bg-card text-center">
                  <s.icon className={`w-6 h-6 mx-auto mb-1 ${s.color}`} />
                  <div className="text-2xl font-bold">{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>

            {/* Bar chart */}
            {barData.length > 0 && (
              <div className="p-4 rounded-2xl border border-border bg-card">
                <h3 className="font-bold mb-4">Recent Earnings</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={barData}>
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip formatter={(v: number) => [`$${v}`, "Amount"]} />
                    <Bar dataKey="amount" fill="#1fbe4b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Pie chart */}
            {pieData.length > 0 && (
              <div className="p-4 rounded-2xl border border-border bg-card">
                <h3 className="font-bold mb-4">Earnings by Source</h3>
                <div className="flex flex-col sm:flex-row gap-4 items-center">
                  <ResponsiveContainer width={200} height={180}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} dataKey="value">
                        {pieData.map((_: any, i: number) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => [`$${v}`, ""]} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex flex-col gap-2">
                    {pieData.map((d: any, i: number) => (
                      <div key={d.name} className="flex items-center gap-2 text-sm">
                        <div className="w-3 h-3 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                        <span>{d.name}: <strong>${d.value}</strong></span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Goals */}
            <div className="p-4 rounded-2xl border border-border bg-card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">Income Goals</h3>
                <Button size="sm" variant="outline" onClick={() => setShowGoalForm(true)}><Plus className="w-3.5 h-3.5 mr-1" /> Add Goal</Button>
              </div>
              {showGoalForm && (
                <div className="mb-4 p-3 rounded-xl bg-accent/30 space-y-3">
                  <Input placeholder="Goal title (e.g., New iPhone)" value={goalForm.title} onChange={e => setGoalForm(f => ({ ...f, title: e.target.value }))} />
                  <Input type="number" placeholder="Target amount ($)" value={goalForm.targetAmount} onChange={e => setGoalForm(f => ({ ...f, targetAmount: e.target.value }))} />
                  <Input type="date" value={goalForm.deadline} onChange={e => setGoalForm(f => ({ ...f, deadline: e.target.value }))} />
                  <div className="flex gap-2">
                    <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => createGoal.mutate(goalForm)} disabled={!goalForm.title || !goalForm.targetAmount}>Set Goal</Button>
                    <Button size="sm" variant="ghost" onClick={() => setShowGoalForm(false)}>Cancel</Button>
                  </div>
                </div>
              )}
              {summary?.goals?.length > 0 ? summary.goals.map((g: any) => {
                const pct = Math.min((g.currentAmount / g.targetAmount) * 100, 100);
                return (
                  <div key={g.id} className="mb-3">
                    <div className="flex justify-between text-sm mb-1"><span className="font-medium">{g.title}</span><span>${g.currentAmount} / ${g.targetAmount}</span></div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full transition-all" style={{ width: `${pct}%` }} /></div>
                  </div>
                );
              }) : (
                <p className="text-sm text-muted-foreground">No goals yet. Set a savings or income target!</p>
              )}
            </div>
          </div>

          {/* Right: Referral + Ways to Earn */}
          <div className="space-y-4">
            {/* Referral card */}
            <div className="p-5 rounded-2xl border-2 border-green-400 bg-card">
              <h3 className="font-bold text-lg mb-1 flex items-center gap-2"><Gift className="w-5 h-5 text-green-500" /> Referral Code</h3>
              <p className="text-sm text-muted-foreground mb-3">Earn <strong className="text-green-600">$25</strong> for every friend who joins and completes their first booking.</p>
              {referral && (
                <>
                  <div className="flex gap-2 mb-3">
                    <Input readOnly value={referral.code} className="font-mono text-sm font-bold" />
                    <Button variant="outline" size="icon" onClick={handleCopy} data-testid="btn-copy-referral">
                      {copied ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div className="p-2 rounded-lg bg-accent/30">
                      <div className="font-bold text-lg">{referral.totalReferrals}</div>
                      <div className="text-xs text-muted-foreground">Referrals</div>
                    </div>
                    <div className="p-2 rounded-lg bg-accent/30">
                      <div className="font-bold text-lg text-green-600">${referral.totalEarned}</div>
                      <div className="text-xs text-muted-foreground">Earned</div>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Ways to earn */}
            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-3 flex items-center gap-2"><TreePine className="w-5 h-5 text-green-500" /> Ways to Earn</h3>
              <div className="space-y-3">
                {EARNING_SOURCES.map(s => (
                  <div key={s.title} className="flex gap-3 p-2 rounded-xl hover:bg-accent/30 transition-colors cursor-pointer">
                    <span className="text-2xl">{s.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm">{s.title}</div>
                      <div className="text-xs text-muted-foreground line-clamp-1">{s.desc}</div>
                    </div>
                    <Badge className="text-xs bg-green-100 text-green-700 border-0 shrink-0">{s.avg}</Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
