import { useState } from "react";
import { MessageSquare, Send } from "lucide-react";
import { useListConversations, useGetMessages, useSendMessage, getGetMessagesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function MessagesPage() {
  const { data: conversations, isLoading: convsLoading } = useListConversations();
  const [activeConv, setActiveConv] = useState<number | null>(null);
  const [newMsg, setNewMsg] = useState("");
  const { data: messages, isLoading: msgsLoading } = useGetMessages(activeConv ?? 0, {
    query: { enabled: !!activeConv, queryKey: getGetMessagesQueryKey(activeConv ?? 0) }
  });
  const sendMessage = useSendMessage();
  const queryClient = useQueryClient();

  function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!newMsg.trim() || !activeConv) return;
    sendMessage.mutate({ conversationId: activeConv, data: { content: newMsg } }, {
      onSuccess: () => {
        setNewMsg("");
        queryClient.invalidateQueries({ queryKey: getGetMessagesQueryKey(activeConv) });
      }
    });
  }

  return (
    <div className="min-h-screen bg-background" data-testid="messages-page">
      <div className="bg-[#002a6e] text-white py-10 px-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-black text-2xl md:text-3xl">Messages</h1>
          <p className="text-blue-200">Communicate with contractors and customers.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-5 h-[600px]">
          {/* Conversation list */}
          <div className="w-72 shrink-0 border border-border rounded-2xl overflow-hidden" data-testid="conversation-list">
            <div className="p-4 border-b border-border bg-muted/30">
              <h3 className="font-semibold text-sm">Conversations</h3>
            </div>
            <div className="overflow-y-auto h-full">
              {convsLoading ? (
                <div className="p-4 space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 rounded" />)}</div>
              ) : (conversations ?? []).length === 0 ? (
                <div className="p-6 text-center text-muted-foreground" data-testid="empty-conversations">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-xs">No conversations yet</p>
                </div>
              ) : (conversations ?? []).map(conv => (
                <button
                  key={conv.id}
                  onClick={() => setActiveConv(conv.id)}
                  data-testid={`conversation-${conv.id}`}
                  className={cn("w-full text-left p-4 border-b border-border hover:bg-muted/50 transition-colors", activeConv === conv.id ? "bg-primary/5 border-l-2 border-l-primary" : "")}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-sm">{conv.participantName}</span>
                    {conv.unreadCount > 0 && <Badge className="text-xs px-1.5 py-0.5">{conv.unreadCount}</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{conv.lastMessage}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">{conv.participantRole}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Message thread */}
          <div className="flex-1 border border-border rounded-2xl overflow-hidden flex flex-col" data-testid="message-thread">
            {!activeConv ? (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <div className="text-center">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>Select a conversation to start messaging</p>
                </div>
              </div>
            ) : (
              <>
                <div className="p-4 border-b border-border bg-muted/30">
                  <p className="font-semibold text-sm">{conversations?.find(c => c.id === activeConv)?.participantName}</p>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {msgsLoading ? (
                    <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 rounded-xl w-2/3" />)}</div>
                  ) : (messages ?? []).map(msg => (
                    <div key={msg.id} className={cn("flex", msg.isOwn ? "justify-end" : "justify-start")} data-testid={`message-${msg.id}`}>
                      <div className={cn("max-w-xs px-4 py-2.5 rounded-2xl text-sm", msg.isOwn ? "bg-primary text-primary-foreground rounded-br-none" : "bg-muted text-foreground rounded-bl-none")}>
                        <p>{msg.content}</p>
                        <p className="text-[10px] mt-1 opacity-70">{new Date(msg.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <form onSubmit={handleSend} className="p-4 border-t border-border flex gap-2" data-testid="message-input-form">
                  <Input value={newMsg} onChange={e => setNewMsg(e.target.value)} placeholder="Type a message..." className="flex-1" data-testid="input-message" />
                  <Button type="submit" disabled={sendMessage.isPending || !newMsg.trim()} data-testid="button-send-message">
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
