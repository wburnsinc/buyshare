import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ShoppingBag, Star, MapPin, Tag, Heart, Search, Filter, Plus, TrendingUp, Package, DollarSign, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const CATEGORIES = [
  { value: "all", label: "All Items" },
  { value: "clothing", label: "Clothing" },
  { value: "shoes", label: "Shoes" },
  { value: "accessories", label: "Accessories" },
  { value: "home_decor", label: "Home Décor" },
  { value: "electronics", label: "Electronics" },
  { value: "toys", label: "Toys & Kids" },
  { value: "books", label: "Books" },
  { value: "vintage", label: "Vintage" },
  { value: "handmade", label: "Handmade" },
];

const CONDITION_COLORS: Record<string, string> = {
  new_with_tags: "bg-green-100 text-green-700",
  like_new: "bg-emerald-100 text-emerald-700",
  good: "bg-blue-100 text-blue-700",
  fair: "bg-yellow-100 text-yellow-700",
  poor: "bg-red-100 text-red-700",
};

const CONDITION_LABELS: Record<string, string> = {
  new_with_tags: "New w/ Tags",
  like_new: "Like New",
  good: "Good",
  fair: "Fair",
  poor: "Poor",
};

const MOCK_IMAGES = [
  "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1484327973588-c31f829103fe?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1614251056798-0a63eda2bb25?w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=400&h=300&fit=crop",
];

export default function ThriftGirlPage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [category, setCategory] = useState("all");
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", category: "clothing", condition: "good", price: "", originalPrice: "", sellerName: "", location: "", zipCode: "" });

  const { data: listings = [], isLoading } = useQuery({
    queryKey: ["thriftgirl", category],
    queryFn: async () => {
      const url = category !== "all" ? `${BASE}/api/thriftgirl/listings?category=${category}` : `${BASE}/api/thriftgirl/listings`;
      const res = await fetch(url);
      return res.json();
    },
  });

  const { data: stats } = useQuery({
    queryKey: ["thriftgirl-stats"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/thriftgirl/stats`); return res.json(); },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await fetch(`${BASE}/api/thriftgirl/listings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, price: Number(data.price), originalPrice: data.originalPrice ? Number(data.originalPrice) : undefined, tags: [] }),
      });
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["thriftgirl"] });
      toast({ title: "Listed!", description: "Your item is now live on ThriftGirl." });
      setShowForm(false);
      setForm({ title: "", description: "", category: "clothing", condition: "good", price: "", originalPrice: "", sellerName: "", location: "", zipCode: "" });
    },
  });

  const filtered = listings.filter((l: any) =>
    search ? l.title.toLowerCase().includes(search.toLowerCase()) || l.description.toLowerCase().includes(search.toLowerCase()) : true
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #6d28d9 0%, #a855f7 50%, #ec4899 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 py-16 text-white">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Badge className="mb-4 bg-white/20 text-white border-0 text-sm">✨ Resell. Refresh. Rewear.</Badge>
            <h1 className="text-5xl font-black mb-4">ThriftGirl™</h1>
            <p className="text-xl text-white/80 mb-8 max-w-2xl">Your local marketplace to buy and sell pre-loved fashion, décor, and more. Earn while you clear your closet.</p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-white text-purple-700 hover:bg-white/90 font-bold" onClick={() => setShowForm(true)} data-testid="btn-list-item">
                <Plus className="w-5 h-5 mr-2" /> List an Item
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <ShoppingBag className="w-5 h-5 mr-2" /> Start Shopping
              </Button>
            </div>
          </motion.div>
        </div>
        {/* Decorative circles */}
        <div className="absolute -right-20 -top-20 w-96 h-96 rounded-full bg-white/5" />
        <div className="absolute -right-10 top-20 w-64 h-64 rounded-full bg-white/5" />
      </div>

      {/* Stats */}
      {stats && (
        <div className="bg-card border-b border-border">
          <div className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Active Listings", value: stats.activeListings?.toLocaleString(), icon: Package },
              { label: "Total Value", value: `$${stats.totalValue?.toFixed(0)}`, icon: DollarSign },
              { label: "Categories", value: stats.categories, icon: Tag },
              { label: "Sellers", value: "500+", icon: Users },
            ].map(s => (
              <div key={s.label} className="text-center">
                <s.icon className="w-5 h-5 mx-auto mb-1 text-purple-500" />
                <div className="text-2xl font-bold">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* List Item Form */}
        {showForm && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8 p-6 rounded-2xl border border-border bg-card">
            <h2 className="text-xl font-bold mb-4">List Your Item</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input placeholder="Item title *" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} data-testid="input-title" />
              <Input placeholder="Your name *" value={form.sellerName} onChange={e => setForm(f => ({ ...f, sellerName: e.target.value }))} />
              <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIES.slice(1).map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={form.condition} onValueChange={v => setForm(f => ({ ...f, condition: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(CONDITION_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
              </Select>
              <Input placeholder="Asking price ($) *" type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} data-testid="input-price" />
              <Input placeholder="Original retail price ($)" type="number" value={form.originalPrice} onChange={e => setForm(f => ({ ...f, originalPrice: e.target.value }))} />
              <Input placeholder="City / Location *" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} />
              <Input placeholder="ZIP Code *" value={form.zipCode} onChange={e => setForm(f => ({ ...f, zipCode: e.target.value }))} />
              <div className="md:col-span-2">
                <textarea className="w-full min-h-[80px] rounded-md border border-border bg-background p-3 text-sm" placeholder="Description — condition details, size, brand, etc. *" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white" onClick={() => createMutation.mutate(form)} disabled={createMutation.isPending || !form.title || !form.price} data-testid="btn-submit-listing">
                {createMutation.isPending ? "Listing..." : "Post Item"}
              </Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </motion.div>
        )}

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input className="pl-10" placeholder="Search listings..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-[180px]"><Filter className="w-4 h-4 mr-2" /><SelectValue /></SelectTrigger>
            <SelectContent>{CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="rounded-2xl border border-border bg-card animate-pulse h-72" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingBag className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-30" />
            <h3 className="text-xl font-semibold mb-2">No listings yet</h3>
            <p className="text-muted-foreground mb-4">Be the first to list something!</p>
            <Button onClick={() => setShowForm(true)} className="bg-purple-600 hover:bg-purple-700 text-white">List an Item</Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filtered.map((listing: any, i: number) => (
              <motion.div key={listing.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-lg transition-all cursor-pointer group">
                <div className="relative">
                  <img src={listing.imageUrl || MOCK_IMAGES[i % MOCK_IMAGES.length]} alt={listing.title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
                  <button className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center hover:bg-white transition-colors">
                    <Heart className="w-4 h-4 text-gray-600" />
                  </button>
                  {listing.featured && <Badge className="absolute top-2 left-2 bg-purple-500 text-white border-0 text-xs">Featured</Badge>}
                </div>
                <div className="p-3">
                  <div className="flex items-start justify-between gap-1 mb-1">
                    <h3 className="font-semibold text-sm line-clamp-1">{listing.title}</h3>
                  </div>
                  <Badge className={`text-xs mb-2 ${CONDITION_COLORS[listing.condition] || "bg-gray-100 text-gray-700"}`}>
                    {CONDITION_LABELS[listing.condition] || listing.condition}
                  </Badge>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-lg font-bold text-purple-600">${Number(listing.price).toFixed(2)}</span>
                      {listing.originalPrice && <span className="text-xs text-muted-foreground line-through ml-1">${Number(listing.originalPrice).toFixed(0)}</span>}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="w-3 h-3" />{listing.location?.split(",")[0]}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                    <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                    {listing.sellerRating} · {listing.sellerName}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
