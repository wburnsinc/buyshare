import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  ShieldCheck, Users, Briefcase, DollarSign, TrendingUp, AlertCircle,
  CheckCircle2, XCircle, Clock, Phone, BarChart2, Settings, Search,
  Calendar, Star, Zap, FileText, Globe
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700", confirmed: "bg-blue-100 text-blue-700",
  assigned: "bg-purple-100 text-purple-700", en_route: "bg-orange-100 text-orange-700",
  in_progress: "bg-cyan-100 text-cyan-700", completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

const REVENUE_DATA = [
  { month: "Jan", revenue: 12400, bookings: 48 }, { month: "Feb", revenue: 18200, bookings: 67 },
  { month: "Mar", revenue: 22100, bookings: 82 }, { month: "Apr", revenue: 19800, bookings: 74 },
  { month: "May", revenue: 28400, bookings: 105 }, { month: "Jun", revenue: 34200, bookings: 128 },
];

const USER_GROWTH = [
  { month: "Jan", users: 42 }, { month: "Feb", users: 78 }, { month: "Mar", users: 134 },
  { month: "Apr", users: 167 }, { month: "May", users: 215 }, { month: "Jun", users: 247 },
];

type AdminTab = "overview" | "bookings" | "contractors" | "payments" | "leads" | "analytics";

export default function AdminPortalPage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [tab, setTab] = useState<AdminTab>("overview");
  const [search, setSearch] = useState("");

  const { data: overview } = useQuery({
    queryKey: ["admin-overview"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/admin/overview`); return res.json(); },
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["admin-bookings"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/admin/bookings`); return res.json(); },
    enabled: tab === "bookings" || tab === "overview",
  });

  const { data: contractors = [] } = useQuery({
    queryKey: ["admin-contractors"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/admin/contractors`); return res.json(); },
    enabled: tab === "contractors",
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["admin-payments"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/admin/payments`); return res.json(); },
    enabled: tab === "payments",
  });

  const { data: leads = [] } = useQuery({
    queryKey: ["admin-leads"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/admin/leads`); return res.json(); },
    enabled: tab === "leads",
  });

  const approveContractor = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${BASE}/api/admin/contractors/${id}/approve`, { method: "PATCH" });
      return res.json();
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-contractors"] }); toast({ title: "Contractor approved ✓" }); },
  });

  const updateBookingStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await fetch(`${BASE}/api/admin/bookings/${id}/status`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      return res.json();
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-bookings"] }); toast({ title: "Booking updated" }); },
  });

  const TABS: { id: AdminTab; label: string; icon: any }[] = [
    { id: "overview", label: "Overview", icon: Globe },
    { id: "bookings", label: "Bookings", icon: Calendar },
    { id: "contractors", label: "Contractors", icon: Briefcase },
    { id: "payments", label: "Payments", icon: DollarSign },
    { id: "leads", label: "BurnCall Leads", icon: Phone },
    { id: "analytics", label: "Analytics", icon: BarChart2 },
  ];

  const filteredBookings = (bookings as any[]).filter(b =>
    !search || b.serviceName?.toLowerCase().includes(search.toLowerCase()) || b.address?.toLowerCase().includes(search.toLowerCase())
  );

  const filteredContractors = (contractors as any[]).filter(c =>
    !search || c.name?.toLowerCase().includes(search.toLowerCase()) || c.location?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Header */}
      <div style={{ background: "linear-gradient(135deg, #1a0030 0%, #001a4a 100%)" }} className="text-white">
        <div className="max-w-7xl mx-auto px-4 py-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <h1 className="text-2xl font-black">Master Admin Portal</h1>
                <p className="text-white/50 text-sm">BuyShare.co · Full Platform Control</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-green-500/20 text-green-300 border-green-500/30">System Online</Badge>
              <Badge className="bg-red-500/20 text-red-300 border-red-500/30">Admin Mode</Badge>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 overflow-x-auto scrollbar-hide">
            {TABS.map(t => (
              <button key={t.id} onClick={() => { setTab(t.id); setSearch(""); }}
                className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-t-lg whitespace-nowrap transition-all ${tab === t.id ? "bg-white/10 text-white border-b-2 border-red-400" : "text-white/50 hover:text-white"}`}>
                <t.icon className="w-3.5 h-3.5" />{t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Overview */}
        {tab === "overview" && (
          <div className="space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Total Bookings", value: overview?.totalBookings ?? "—", sub: `${overview?.pendingBookings ?? 0} pending`, icon: Calendar, color: "text-blue-600" },
                { label: "Active Contractors", value: overview?.activeContractors ?? "—", sub: `${overview?.totalContractors ?? 0} total`, icon: Users, color: "text-green-600" },
                { label: "Platform Revenue", value: overview?.totalRevenue ? `$${Number(overview.totalRevenue).toFixed(0)}` : "—", sub: "All time", icon: DollarSign, color: "text-emerald-600" },
                { label: "Open Leads", value: overview?.openLeads ?? "—", sub: "BurnCall inbox", icon: Phone, color: "text-orange-500" },
              ].map(s => (
                <motion.div key={s.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                  className="p-5 rounded-2xl border border-border bg-card">
                  <s.icon className={`w-6 h-6 mb-2 ${s.color}`} />
                  <div className="text-3xl font-black">{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-1">{s.sub}</div>
                  <div className="text-sm font-medium mt-1">{s.label}</div>
                </motion.div>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 rounded-2xl border border-border bg-card">
                <div className="text-2xl font-bold">{overview?.totalUsers ?? "—"}</div>
                <div className="text-sm text-muted-foreground">Total Users</div>
              </motion.div>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 rounded-2xl border border-border bg-card">
                <div className="text-2xl font-bold">{overview?.activeListings ?? "—"}</div>
                <div className="text-sm text-muted-foreground">Active SHARE™ Listings</div>
              </motion.div>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 rounded-2xl border border-border bg-card">
                <div className="text-2xl font-bold text-green-500">Online</div>
                <div className="text-sm text-muted-foreground">BurnCall AI Status</div>
              </motion.div>
            </div>

            {/* Recent Bookings Preview */}
            <div className="p-4 rounded-2xl border border-border bg-card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">Recent Bookings</h3>
                <Button size="sm" variant="outline" onClick={() => setTab("bookings")}>View All</Button>
              </div>
              <div className="space-y-2">
                {(bookings as any[]).slice(0, 5).map((b: any) => (
                  <div key={b.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div>
                      <span className="font-medium text-sm">{b.serviceName}</span>
                      <span className="text-xs text-muted-foreground ml-2">{b.address?.split(",")[0]}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`text-xs ${STATUS_STYLES[b.status] || ""}`}>{b.status}</Badge>
                      {b.price && <span className="text-sm font-semibold">${b.price}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Bookings */}
        {tab === "bookings" && (
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input className="pl-10" placeholder="Search by service or address..." value={search} onChange={e => setSearch(e.target.value)} />
              </div>
            </div>
            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              <div className="p-4 border-b border-border bg-muted/30">
                <h3 className="font-bold">All Bookings ({filteredBookings.length})</h3>
              </div>
              <div className="divide-y divide-border">
                {filteredBookings.map((b: any) => (
                  <div key={b.id} className="flex items-center gap-4 p-4 hover:bg-accent/30 transition-colors">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-bold">#{b.id}</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm">{b.serviceName}</div>
                      <div className="text-xs text-muted-foreground">{b.address} · {b.scheduledDate} {b.scheduledTime}</div>
                      {b.contractorName && <div className="text-xs text-blue-600">→ {b.contractorName}</div>}
                    </div>
                    <Badge className={`text-xs ${STATUS_STYLES[b.status] || ""}`}>{b.status.replace(/_/g, " ")}</Badge>
                    {b.price && <span className="text-sm font-bold">${b.price}</span>}
                    <div className="flex gap-1">
                      {b.status === "pending" && (
                        <Button size="sm" variant="outline" className="text-xs" onClick={() => updateBookingStatus.mutate({ id: b.id, status: "confirmed" })}>Confirm</Button>
                      )}
                      {b.status !== "completed" && b.status !== "cancelled" && (
                        <Button size="sm" variant="ghost" className="text-xs text-red-500" onClick={() => updateBookingStatus.mutate({ id: b.id, status: "cancelled" })}>Cancel</Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Contractors */}
        {tab === "contractors" && (
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input className="pl-10" placeholder="Search contractors..." value={search} onChange={e => setSearch(e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredContractors.map((c: any) => (
                <div key={c.id} className="p-4 rounded-2xl border border-border bg-card">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold">{c.name}</h3>
                      <p className="text-sm text-muted-foreground">{c.location}</p>
                    </div>
                    <div className="flex gap-1">
                      {c.verified ? <Badge className="bg-green-100 text-green-700 text-xs">Verified</Badge> : <Badge className="bg-yellow-100 text-yellow-700 text-xs">Pending</Badge>}
                      {c.isActive ? <Badge className="bg-blue-100 text-blue-700 text-xs">Active</Badge> : <Badge className="bg-gray-100 text-gray-700 text-xs">Inactive</Badge>}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {(c.trades || []).map((t: string) => <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>)}
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
                      <span>{c.rating}</span>
                      <span className="text-muted-foreground">· {c.jobsCompleted} jobs</span>
                    </div>
                    {!c.verified && (
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white text-xs"
                        onClick={() => approveContractor.mutate(c.id)} disabled={approveContractor.isPending} data-testid={`btn-approve-${c.id}`}>
                        <CheckCircle2 className="w-3 h-3 mr-1" /> Approve
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Payments */}
        {tab === "payments" && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              {[
                { label: "Total Revenue", value: `$${(payments as any[]).filter((p: any) => p.status === "completed").reduce((s: number, p: any) => s + Number(p.amount), 0).toFixed(0)}`, color: "text-green-600" },
                { label: "Pending", value: `$${(payments as any[]).filter((p: any) => p.status === "pending").reduce((s: number, p: any) => s + Number(p.amount), 0).toFixed(0)}`, color: "text-yellow-600" },
                { label: "Transactions", value: (payments as any[]).length, color: "text-blue-600" },
              ].map(s => (
                <div key={s.label} className="p-4 rounded-2xl border border-border bg-card">
                  <div className={`text-3xl font-black ${s.color}`}>{s.value}</div>
                  <div className="text-sm text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              <div className="p-4 border-b border-border bg-muted/30"><h3 className="font-bold">All Transactions</h3></div>
              <div className="divide-y divide-border">
                {(payments as any[]).map((p: any) => (
                  <div key={p.id} className="flex items-center gap-4 p-4">
                    <div className="flex-1">
                      <div className="font-medium text-sm">{p.description}</div>
                      <div className="text-xs text-muted-foreground">{p.method} · {new Date(p.createdAt).toLocaleDateString()}</div>
                    </div>
                    <Badge className={p.status === "completed" ? "bg-green-100 text-green-700 text-xs" : "bg-yellow-100 text-yellow-700 text-xs"}>{p.status}</Badge>
                    <span className="font-bold">${Number(p.amount).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* BurnCall Leads */}
        {tab === "leads" && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              <div className="p-4 border-b border-border bg-muted/30">
                <h3 className="font-bold">BurnCall AI Lead Inbox ({(leads as any[]).length})</h3>
              </div>
              <div className="divide-y divide-border">
                {(leads as any[]).map((l: any) => (
                  <div key={l.id} className="p-4 hover:bg-accent/30 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-semibold">{l.callerName}</h4>
                        <div className="text-sm text-muted-foreground">{l.phone} · {new Date(l.createdAt).toLocaleString()}</div>
                      </div>
                      <Badge className={l.status === "new" ? "bg-blue-100 text-blue-700" : l.status === "follow_up" ? "bg-yellow-100 text-yellow-700" : "bg-green-100 text-green-700"}>{l.status.replace(/_/g, " ")}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground italic">"{l.summary}"</p>
                    <div className="flex gap-2 mt-3">
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white text-xs">Call Back</Button>
                      <Button size="sm" variant="outline" className="text-xs">Assign to Contractor</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Analytics */}
        {tab === "analytics" && (
          <div className="space-y-6">
            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-4">Monthly Revenue & Bookings</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={REVENUE_DATA}>
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar yAxisId="left" dataKey="revenue" fill="#1fbe4b" radius={[4, 4, 0, 0]} name="Revenue ($)" />
                  <Bar yAxisId="right" dataKey="bookings" fill="#002a6e" radius={[4, 4, 0, 0]} name="Bookings" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="p-4 rounded-2xl border border-border bg-card">
              <h3 className="font-bold mb-4">User Growth</h3>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={USER_GROWTH}>
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="users" stroke="#1fbe4b" strokeWidth={2} dot={{ fill: "#1fbe4b" }} name="Users" />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Avg Booking Value", value: "$68", icon: DollarSign },
                { label: "Contractor Utilization", value: "73%", icon: Zap },
                { label: "Customer Retention", value: "81%", icon: TrendingUp },
                { label: "Lead Conversion", value: "34%", icon: Phone },
              ].map(s => (
                <div key={s.label} className="p-4 rounded-2xl border border-border bg-card text-center">
                  <s.icon className="w-5 h-5 mx-auto mb-1 text-muted-foreground" />
                  <div className="text-2xl font-bold">{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
