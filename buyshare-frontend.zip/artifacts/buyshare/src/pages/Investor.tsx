import { motion } from "framer-motion";
import { TrendingUp, DollarSign, Users, Home, MapPin, BarChart2 } from "lucide-react";
import { useGetInvestorStats, useGetGrowthMetrics } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from "recharts";
import sharePlatform from "@assets/ChatGPT_Image_Jun_19,_2026,_01_59_34_PM_1782419348109.png";

export default function InvestorPage() {
  const { data: stats, isLoading: statsLoading } = useGetInvestorStats();
  const { data: growth, isLoading: growthLoading } = useGetGrowthMetrics();

  const STAT_CARDS = stats ? [
    { label: "Market Opportunity", value: stats.totalMarketOpportunity, icon: DollarSign, color: "#002a6e" },
    { label: "Annual Growth Rate", value: stats.annualGrowthRate, icon: TrendingUp, color: "#1fbe4b" },
    { label: "Active Contractors", value: stats.activeContractors.toLocaleString(), icon: Users, color: "#001a4a" },
    { label: "Homes Served", value: stats.homesServed.toLocaleString(), icon: Home, color: "#7c3aed" },
  ] : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="bg-[#001a4a] text-white py-12 px-4" data-testid="investor-header">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div>
            <Badge className="mb-4 bg-white/10 text-white border-white/20">Investor Portal</Badge>
            <h1 className="font-black text-3xl md:text-4xl mb-3">Built for Long-Term Growth</h1>
            <p className="text-blue-200 text-lg mb-6">BuyShare.co is building the infrastructure layer for America's home services economy — one platform, every trade, every market.</p>
            <div className="flex flex-wrap gap-2">
              {(stats?.targetMarkets ?? ["Southwest Florida", "Tampa Bay", "Orlando"]).map(m => (
                <span key={m} className="flex items-center gap-1 text-xs bg-white/10 px-3 py-1.5 rounded-full"><MapPin className="w-3 h-3" />{m}</span>
              ))}
            </div>
          </div>
          <div>
            <img src={sharePlatform} alt="Platform Overview" className="w-full rounded-2xl shadow-2xl" data-testid="img-platform-overview" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
        {/* Stat Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {statsLoading
            ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
            : STAT_CARDS.map((card, i) => {
                const Icon = card.icon;
                return (
                  <motion.div
                    key={card.label}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.07 }}
                    className="rounded-xl border border-border bg-card p-5"
                    data-testid={`investor-stat-${card.label.toLowerCase().replace(/\s/g, "-")}`}
                  >
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-3" style={{ background: `${card.color}15` }}>
                      <Icon className="w-5 h-5" style={{ color: card.color }} />
                    </div>
                    <p className="font-extrabold text-2xl">{card.value}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{card.label}</p>
                  </motion.div>
                );
              })}
        </div>

        {/* Growth Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-border bg-card p-6" data-testid="chart-bookings-revenue">
            <h3 className="font-bold mb-5 flex items-center gap-2"><BarChart2 className="w-4 h-4" /> Monthly Bookings & Revenue</h3>
            {growthLoading ? (
              <Skeleton className="h-56 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={growth ?? []} barSize={12}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis yAxisId="left" tick={{ fontSize: 11 }} />
                  <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: "var(--color-card)", border: "1px solid var(--color-border)", borderRadius: "8px", fontSize: "12px" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "11px" }} />
                  <Bar yAxisId="left" dataKey="bookings" fill="#002a6e" name="Bookings" radius={[4, 4, 0, 0]} />
                  <Bar yAxisId="right" dataKey="revenue" fill="#1fbe4b" name="Revenue ($)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="rounded-2xl border border-border bg-card p-6" data-testid="chart-growth">
            <h3 className="font-bold mb-5 flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Contractors & Customers Growth</h3>
            {growthLoading ? (
              <Skeleton className="h-56 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={growth ?? []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: "var(--color-card)", border: "1px solid var(--color-border)", borderRadius: "8px", fontSize: "12px" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "11px" }} />
                  <Line type="monotone" dataKey="contractors" stroke="#002a6e" strokeWidth={2} dot={{ r: 3 }} name="Contractors" />
                  <Line type="monotone" dataKey="customers" stroke="#1fbe4b" strokeWidth={2} dot={{ r: 3 }} name="Customers" />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Market stats */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-testid="market-stats">
            <div className="rounded-2xl border border-border bg-card p-6">
              <h3 className="font-bold mb-2">Monthly Revenue</h3>
              <p className="text-3xl font-extrabold text-primary">${stats.monthlyRevenue.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground mt-1">Platform monthly revenue</p>
            </div>
            <div className="rounded-2xl border border-border bg-card p-6">
              <h3 className="font-bold mb-2">Total Bookings</h3>
              <p className="text-3xl font-extrabold" style={{ color: "#1fbe4b" }}>{stats.totalBookingsAllTime.toLocaleString()}+</p>
              <p className="text-sm text-muted-foreground mt-1">All-time platform bookings</p>
            </div>
            <div className="rounded-2xl border border-border bg-card p-6">
              <h3 className="font-bold mb-2">Platform NPS</h3>
              <p className="text-3xl font-extrabold text-amber-500">{stats.platformNpsScrore}</p>
              <p className="text-sm text-muted-foreground mt-1">Net Promoter Score</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
