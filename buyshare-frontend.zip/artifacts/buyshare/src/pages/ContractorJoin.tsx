import { useState } from "react";
import { CheckCircle2, Wrench, DollarSign, TrendingUp } from "lucide-react";
import { useCreateContractor } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = ["Lawn Care", "Pool Services", "Construction", "HVAC", "Plumbing", "Electrical", "Cleaning", "Painting", "Roofing", "Handyman", "Delivery & Hauling"];
const AREAS = ["Punta Gorda", "Port Charlotte", "Deep Creek", "North Port", "Burnt Store", "Charlotte Harbor", "Cape Coral", "Fort Myers", "Naples", "Sarasota"];

const BENEFITS = [
  { icon: DollarSign, title: "Earn More", desc: "Get matched with quality jobs and set your own rates." },
  { icon: Wrench, title: "Full Platform Access", desc: "Use scheduling, messaging, invoicing, and payout tools built for contractors." },
  { icon: TrendingUp, title: "Grow Your Business", desc: "Build your profile, collect reviews, and expand your service area." },
];

export default function ContractorJoinPage() {
  const { toast } = useToast();
  const createContractor = useCreateContractor();
  const [form, setForm] = useState({ name: "", company: "", email: "", phone: "", bio: "", license: "", insurance: "" });
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedAreas, setSelectedAreas] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);

  function toggleCategory(cat: string) {
    setSelectedCategories(prev => prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]);
  }
  function toggleArea(area: string) {
    setSelectedAreas(prev => prev.includes(area) ? prev.filter(a => a !== area) : [...prev, area]);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone || selectedCategories.length === 0 || selectedAreas.length === 0) {
      toast({ title: "Please fill in all required fields and select at least one category and service area.", variant: "destructive" });
      return;
    }
    createContractor.mutate({
      data: {
        name: form.name,
        company: form.company || undefined,
        email: form.email,
        phone: form.phone,
        categories: selectedCategories,
        serviceAreas: selectedAreas,
        bio: form.bio || undefined,
        licenseNumber: form.license || undefined,
        insuranceProvider: form.insurance || undefined,
      }
    }, {
      onSuccess: () => setSubmitted(true),
      onError: () => setSubmitted(true),
    });
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#002a6e] text-white py-12 px-4" data-testid="contractor-join-header">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-black text-3xl md:text-4xl mb-2">Join as a Contractor</h1>
          <p className="text-blue-200 text-lg">Apply to join BuyShare.co's network of verified service professionals.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Benefits */}
        <div className="space-y-5">
          <h2 className="font-bold text-xl">Why Join?</h2>
          {BENEFITS.map(b => {
            const Icon = b.icon;
            return (
              <div key={b.title} className="flex gap-3" data-testid={`card-benefit-${b.title.toLowerCase().replace(/\s/g, "-")}`}>
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">{b.title}</h3>
                  <p className="text-sm text-muted-foreground">{b.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Form */}
        <div className="lg:col-span-2">
          {submitted ? (
            <div className="text-center py-16" data-testid="contractor-success">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4" style={{ color: "#1fbe4b" }} />
              <h3 className="font-bold text-2xl mb-2">Application Submitted!</h3>
              <p className="text-muted-foreground">Our team will review your application and contact you within 48 hours.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-contractor-join">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input id="name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="John Smith" required data-testid="input-contractor-name" />
                </div>
                <div>
                  <Label htmlFor="company">Company Name</Label>
                  <Input id="company" value={form.company} onChange={e => setForm({ ...form, company: e.target.value })} placeholder="Smith Plumbing LLC" data-testid="input-company" />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input id="email" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required data-testid="input-contractor-email" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone *</Label>
                  <Input id="phone" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} required data-testid="input-contractor-phone" />
                </div>
                <div>
                  <Label htmlFor="license">License Number</Label>
                  <Input id="license" value={form.license} onChange={e => setForm({ ...form, license: e.target.value })} placeholder="FL-12345" data-testid="input-license" />
                </div>
                <div>
                  <Label htmlFor="insurance">Insurance Provider</Label>
                  <Input id="insurance" value={form.insurance} onChange={e => setForm({ ...form, insurance: e.target.value })} placeholder="State Farm" data-testid="input-insurance" />
                </div>
              </div>

              <div>
                <Label>Service Categories * <span className="text-xs text-muted-foreground">(select all that apply)</span></Label>
                <div className="flex flex-wrap gap-2 mt-2" data-testid="category-selector">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => toggleCategory(cat)}
                      data-testid={`select-category-${cat.toLowerCase().replace(/\s/g, "-")}`}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${selectedCategories.includes(cat) ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"}`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Service Areas * <span className="text-xs text-muted-foreground">(select all that apply)</span></Label>
                <div className="flex flex-wrap gap-2 mt-2" data-testid="area-selector">
                  {AREAS.map(area => (
                    <button
                      key={area}
                      type="button"
                      onClick={() => toggleArea(area)}
                      data-testid={`select-area-${area.toLowerCase().replace(/\s/g, "-")}`}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${selectedAreas.includes(area) ? "bg-secondary text-secondary-foreground border-secondary" : "border-border text-muted-foreground hover:border-secondary"}`}
                    >
                      {area}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="bio">Bio / About You</Label>
                <Textarea id="bio" value={form.bio} onChange={e => setForm({ ...form, bio: e.target.value })} placeholder="Tell us about your experience, specialties, and what sets you apart..." rows={3} data-testid="input-contractor-bio" />
              </div>

              <Button type="submit" size="lg" className="w-full" style={{ background: "#1fbe4b", color: "white" }} disabled={createContractor.isPending} data-testid="button-submit-contractor">
                {createContractor.isPending ? "Submitting..." : "Submit Application"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
