import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Waves, Star, MapPin, Calendar, Users, CheckCircle2, ChevronRight, Droplets } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const POOL_IMAGES = [
  "https://images.unsplash.com/photo-1575429198097-0414ec08e8cd?w=500&h=350&fit=crop",
  "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=500&h=350&fit=crop",
  "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=500&h=350&fit=crop",
  "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=500&h=350&fit=crop",
  "https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?w=500&h=350&fit=crop",
  "https://images.unsplash.com/photo-1519996529931-28324d5a630e?w=500&h=350&fit=crop",
];

export default function PoolSharePage() {
  const [zipFilter, setZipFilter] = useState("");

  const { data: listings = [], isLoading } = useQuery({
    queryKey: ["share-pools"],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/share/listings?category=pool`);
      return res.json();
    },
  });

  const filtered = (listings as any[]).filter(l =>
    !zipFilter || l.zipCode.includes(zipFilter) || l.location.toLowerCase().includes(zipFilter.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #0369a1 0%, #0ea5e9 50%, #38bdf8 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 py-16 text-white">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Badge className="mb-4 bg-white/20 text-white border-0 text-sm">🏊 Rent a Pool Near You</Badge>
            <h1 className="text-5xl font-black mb-2">PoolShare™</h1>
            <p className="text-sm font-semibold text-white/60 mb-4 tracking-widest uppercase">Powered by SHARE™</p>
            <p className="text-xl text-white/80 mb-8 max-w-2xl">Book private backyard pools by the hour in Punta Gorda, Port Charlotte, and Southwest Florida. No membership needed.</p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-white text-blue-700 hover:bg-white/90 font-bold">
                <Waves className="w-5 h-5 mr-2" /> Browse Pools
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <Droplets className="w-5 h-5 mr-2" /> List Your Pool
              </Button>
            </div>
          </motion.div>
        </div>
        <div className="absolute -right-10 -top-10 w-72 h-72 rounded-full bg-white/5" />
      </div>

      {/* How it works */}
      <div className="bg-card border-b border-border py-10">
        <div className="max-w-5xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-center mb-8">How PoolShare Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { step: "1", icon: "🔍", title: "Find a Pool", desc: "Browse verified backyard pools near you filtered by ZIP code, amenities, and price." },
              { step: "2", icon: "📅", title: "Book & Pay", desc: "Pick your date and time, pay securely. No cash needed. Instant confirmation." },
              { step: "3", icon: "🏊", title: "Swim & Enjoy", desc: "Show up, relax, and enjoy your private pool session. Host provides towels & info." },
              { step: "4", icon: "⭐", title: "Rate & Earn", desc: "Leave a review, earn BuyShare Credits. Hosts earn passive income from their pools." },
            ].map(s => (
              <div key={s.step} className="text-center">
                <div className="text-4xl mb-3">{s.icon}</div>
                <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center mx-auto mb-2">{s.step}</div>
                <h3 className="font-bold mb-1">{s.title}</h3>
                <p className="text-sm text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Filter */}
        <div className="flex gap-3 mb-6">
          <div className="relative flex-1 max-w-xs">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input className="pl-10" placeholder="Filter by ZIP or city..." value={zipFilter} onChange={e => setZipFilter(e.target.value)} />
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="rounded-2xl border border-border animate-pulse h-80" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <Waves className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-30" />
            <h3 className="text-xl font-semibold mb-2">No pools in this area yet</h3>
            <p className="text-muted-foreground mb-4">Be the first to list your pool and earn passive income!</p>
            <Link href="/share"><Button className="bg-blue-600 hover:bg-blue-700 text-white">List Your Pool on SHARE™</Button></Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((pool: any, i: number) => (
              <motion.div key={pool.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-lg transition-all group">
                <div className="relative">
                  <img src={POOL_IMAGES[i % POOL_IMAGES.length]} alt={pool.title} className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-300" />
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-white text-gray-800 border-0 text-xs font-bold">
                      ${pool.price}/{pool.priceUnit}
                    </Badge>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{pool.title}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span className="font-semibold text-sm">{pool.rating}</span>
                      <span className="text-xs text-muted-foreground">({pool.reviewCount} reviews)</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
                    <MapPin className="w-3.5 h-3.5" /> {pool.location} · {pool.zipCode}
                  </div>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{pool.description}</p>
                  {pool.amenities && pool.amenities.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {pool.amenities.slice(0, 3).map((a: string) => (
                        <Badge key={a} variant="secondary" className="text-xs">{a}</Badge>
                      ))}
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xl font-bold text-blue-600">${pool.price}</span>
                      <span className="text-sm text-muted-foreground">/{pool.priceUnit}</span>
                    </div>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white" data-testid={`btn-book-pool-${pool.id}`}>
                      Book Now <ChevronRight className="w-3.5 h-3.5 ml-1" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* List your pool CTA */}
        <div className="mt-12 p-8 rounded-2xl text-center" style={{ background: "linear-gradient(135deg, #0369a1 0%, #0ea5e9 100%)" }}>
          <Droplets className="w-12 h-12 mx-auto mb-4 text-white" />
          <h2 className="text-2xl font-bold text-white mb-2">Have a Pool? Start Earning.</h2>
          <p className="text-white/80 mb-6">Hosts earn $25–$75/hour. Set your schedule, your rules. We handle booking and payment.</p>
          <Link href="/share"><Button size="lg" className="bg-white text-blue-700 hover:bg-white/90 font-bold">List Your Pool on SHARE™</Button></Link>
        </div>
      </div>
    </div>
  );
}
