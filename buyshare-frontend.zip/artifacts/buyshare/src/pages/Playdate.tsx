import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Baby, MapPin, Clock, Users, Calendar, Plus, Star, Heart, Smile } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const EVENT_TYPES = [
  { value: "all", label: "All Events" },
  { value: "park_meetup", label: "Park Meetup" },
  { value: "indoor_play", label: "Indoor Play" },
  { value: "sports", label: "Sports" },
  { value: "arts_crafts", label: "Arts & Crafts" },
  { value: "music", label: "Music" },
  { value: "swimming", label: "Swimming" },
  { value: "tutoring", label: "Tutoring" },
  { value: "birthday_party", label: "Birthday Party" },
  { value: "nature_walk", label: "Nature Walk" },
  { value: "playgroup", label: "Playgroup" },
];

const TYPE_ICONS: Record<string, string> = {
  park_meetup: "🌳", indoor_play: "🧸", sports: "⚽", arts_crafts: "🎨", music: "🎵",
  swimming: "🏊", tutoring: "📚", birthday_party: "🎂", nature_walk: "🦋", playgroup: "👫",
};

const TYPE_COLORS: Record<string, string> = {
  park_meetup: "bg-green-100 text-green-700", indoor_play: "bg-yellow-100 text-yellow-700",
  sports: "bg-blue-100 text-blue-700", arts_crafts: "bg-pink-100 text-pink-700",
  music: "bg-purple-100 text-purple-700", swimming: "bg-cyan-100 text-cyan-700",
  tutoring: "bg-orange-100 text-orange-700", birthday_party: "bg-red-100 text-red-700",
  nature_walk: "bg-emerald-100 text-emerald-700", playgroup: "bg-indigo-100 text-indigo-700",
};

const IMAGES = [
  "https://images.unsplash.com/photo-1530731141654-5993c3016c77?w=400&h=250&fit=crop",
  "https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=400&h=250&fit=crop",
  "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=400&h=250&fit=crop",
  "https://images.unsplash.com/photo-1560785496-3c9d404c6f04?w=400&h=250&fit=crop",
  "https://images.unsplash.com/photo-1602030638412-bb8dcc0bc8b0?w=400&h=250&fit=crop",
];

export default function PlaydatePage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [typeFilter, setTypeFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", type: "park_meetup", hostName: "", ageMin: "2", ageMax: "10", maxKids: "8", price: "0", isFree: true, location: "", address: "", zipCode: "", eventDate: "", eventTime: "", durationMinutes: "120" });

  const { data: events = [], isLoading } = useQuery({
    queryKey: ["playdate-events", typeFilter],
    queryFn: async () => {
      const url = typeFilter !== "all" ? `${BASE}/api/playdate/events?type=${typeFilter}` : `${BASE}/api/playdate/events`;
      const res = await fetch(url);
      return res.json();
    },
  });

  const { data: stats } = useQuery({
    queryKey: ["playdate-stats"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/playdate/stats`); return res.json(); },
  });

  const rsvpMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${BASE}/api/playdate/events/${id}/rsvp`, { method: "POST" });
      return res.json();
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["playdate-events"] }); toast({ title: "RSVP Confirmed! 🎉", description: "You're signed up. The host will reach out with details." }); },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await fetch(`${BASE}/api/playdate/events`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, ageMin: Number(data.ageMin), ageMax: Number(data.ageMax), maxKids: Number(data.maxKids), price: Number(data.price), durationMinutes: Number(data.durationMinutes) }),
      });
      return res.json();
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["playdate-events"] }); toast({ title: "Event Created! 🌟", description: "Your playdate is live." }); setShowForm(false); },
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #f59e0b 0%, #f97316 50%, #ef4444 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 py-16 text-white">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Badge className="mb-4 bg-white/20 text-white border-0 text-sm">🧒 Where Kids Connect</Badge>
            <h1 className="text-5xl font-black mb-4">Playdate™</h1>
            <p className="text-xl text-white/80 mb-8 max-w-2xl">Find local kids' activities, park meetups, birthday parties, and more. Connect families in your neighborhood.</p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-white text-orange-600 hover:bg-white/90 font-bold" onClick={() => setShowForm(true)} data-testid="btn-host-event">
                <Plus className="w-5 h-5 mr-2" /> Host an Event
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <Calendar className="w-5 h-5 mr-2" /> Browse Events
              </Button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="bg-card border-b border-border">
          <div className="max-w-7xl mx-auto px-4 py-5 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Upcoming Events", value: stats.upcomingEvents, icon: "📅" },
              { label: "Kids Joining", value: stats.totalKids, icon: "🧒" },
              { label: "Host Families", value: stats.hosts, icon: "🏠" },
              { label: "Activities", value: "10+", icon: "🎯" },
            ].map(s => (
              <div key={s.label} className="text-center py-2">
                <div className="text-2xl mb-1">{s.icon}</div>
                <div className="text-2xl font-bold">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Host Form */}
        {showForm && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8 p-6 rounded-2xl border border-border bg-card">
            <h2 className="text-xl font-bold mb-4">Host a Playdate Event</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input placeholder="Event title *" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} data-testid="input-event-title" />
              <Input placeholder="Your name *" value={form.hostName} onChange={e => setForm(f => ({ ...f, hostName: e.target.value }))} />
              <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{EVENT_TYPES.slice(1).map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
              <Input placeholder="Location name *" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} />
              <Input placeholder="Full address *" value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
              <Input placeholder="ZIP Code *" value={form.zipCode} onChange={e => setForm(f => ({ ...f, zipCode: e.target.value }))} />
              <Input type="date" value={form.eventDate} onChange={e => setForm(f => ({ ...f, eventDate: e.target.value }))} />
              <Input type="time" value={form.eventTime} onChange={e => setForm(f => ({ ...f, eventTime: e.target.value }))} />
              <Input placeholder="Min age" type="number" value={form.ageMin} onChange={e => setForm(f => ({ ...f, ageMin: e.target.value }))} />
              <Input placeholder="Max age" type="number" value={form.ageMax} onChange={e => setForm(f => ({ ...f, ageMax: e.target.value }))} />
              <Input placeholder="Max kids" type="number" value={form.maxKids} onChange={e => setForm(f => ({ ...f, maxKids: e.target.value }))} />
              <Input placeholder="Cost per child ($0 = free)" type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value, isFree: Number(e.target.value) === 0 }))} />
              <div className="md:col-span-2">
                <textarea className="w-full min-h-[80px] rounded-md border border-border bg-background p-3 text-sm" placeholder="What to expect, what to bring, etc. *" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <Button className="bg-orange-500 hover:bg-orange-600 text-white" onClick={() => createMutation.mutate(form)} disabled={createMutation.isPending || !form.title || !form.hostName} data-testid="btn-create-event">
                {createMutation.isPending ? "Creating..." : "Create Event"}
              </Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </motion.div>
        )}

        {/* Type Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
          {EVENT_TYPES.map(t => (
            <button key={t.value} onClick={() => setTypeFilter(t.value)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${typeFilter === t.value ? "bg-orange-500 text-white" : "bg-card border border-border text-foreground hover:bg-accent"}`}>
              {t.value !== "all" && TYPE_ICONS[t.value]} {t.label}
            </button>
          ))}
        </div>

        {/* Events */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="rounded-2xl border border-border bg-card animate-pulse h-80" />)}
          </div>
        ) : events.length === 0 ? (
          <div className="text-center py-20">
            <Smile className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-30" />
            <h3 className="text-xl font-semibold mb-2">No events yet</h3>
            <p className="text-muted-foreground mb-4">Host the first playdate in your area!</p>
            <Button onClick={() => setShowForm(true)} className="bg-orange-500 hover:bg-orange-600 text-white">Host Event</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((ev: any, i: number) => (
              <motion.div key={ev.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-lg transition-all">
                <div className="relative">
                  <img src={IMAGES[i % IMAGES.length]} alt={ev.title} className="w-full h-48 object-cover" />
                  <div className="absolute top-3 left-3">
                    <Badge className={`${TYPE_COLORS[ev.type] || "bg-gray-100 text-gray-700"} border-0`}>
                      {TYPE_ICONS[ev.type]} {ev.type.replace(/_/g, " ")}
                    </Badge>
                  </div>
                  {ev.isFree && <Badge className="absolute top-3 right-3 bg-green-500 text-white border-0">FREE</Badge>}
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2">{ev.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{ev.description}</p>
                  <div className="space-y-1 text-sm text-muted-foreground mb-3">
                    <div className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {ev.location}</div>
                    <div className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {ev.eventDate} at {ev.eventTime}</div>
                    <div className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {ev.durationMinutes} min</div>
                    <div className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> Ages {ev.ageMin}–{ev.ageMax} · {ev.currentKids}/{ev.maxKids} kids</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-orange-500">{ev.isFree ? "Free" : `$${ev.price}`}</span>
                      <span className="text-xs text-muted-foreground ml-1">by {ev.hostName}</span>
                    </div>
                    <Button size="sm" className="bg-orange-500 hover:bg-orange-600 text-white" onClick={() => rsvpMutation.mutate(ev.id)} disabled={ev.currentKids >= ev.maxKids || rsvpMutation.isPending} data-testid={`btn-rsvp-${ev.id}`}>
                      {ev.currentKids >= ev.maxKids ? "Full" : "RSVP"}
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
