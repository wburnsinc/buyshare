import { useState } from "react";
import { motion } from "framer-motion";
import { Waves, Home, Anchor, ParkingCircle, Leaf, Truck, Star, MapPin, ChevronRight } from "lucide-react";
import { useListShareListings, useListShareCategories } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import shareLogo from "@assets/SHARE_LOGO_1782419307093.png";
import shareApp from "@assets/3d98f4f3-5c9d-47ee-b4fe-23bb0524299f_1782419316403.png";

const ICON_MAP: Record<string, React.ElementType> = {
  Waves, Home, Anchor, ParkingCircle, Leaf, Truck,
};

export default function SharePage() {
  const [activeCategory, setActiveCategory] = useState("");
  const { data: listings, isLoading: listingsLoading } = useListShareListings(activeCategory ? { category: activeCategory } : {});
  const { data: categories, isLoading: catsLoading } = useListShareCategories();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="bg-black text-white py-16 px-4 relative overflow-hidden" data-testid="share-hero">
        <div className="absolute inset-0 opacity-30 bg-[radial-gradient(ellipse_at_bottom_left,_#1fbe4b_0%,_transparent_50%)]" />
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative">
          <motion.div initial={{ opacity: 0, x: -24 }} animate={{ opacity: 1, x: 0 }}>
            <img src={shareLogo} alt="SHARE™" className="w-full max-w-sm mb-6 object-contain" data-testid="img-share-logo" />
            <p className="text-gray-300 text-lg mb-4">Rent out what you own or find what you need — locally, safely, easily.</p>
            <div className="flex flex-wrap gap-3 text-sm text-gray-400 mb-6">
              <span className="flex items-center gap-1.5"><Waves className="w-4 h-4 text-blue-400" /> Pools</span>
              <span className="flex items-center gap-1.5"><Home className="w-4 h-4 text-green-400" /> Homes</span>
              <span className="flex items-center gap-1.5"><ParkingCircle className="w-4 h-4 text-yellow-400" /> Parking</span>
              <span className="flex items-center gap-1.5"><Anchor className="w-4 h-4 text-cyan-400" /> Boats</span>
              <span className="flex items-center gap-1.5"><Leaf className="w-4 h-4 text-emerald-400" /> Yards</span>
              <span className="flex items-center gap-1.5"><Truck className="w-4 h-4 text-orange-400" /> RVs & More</span>
            </div>
            <p className="text-sm font-semibold tracking-widest text-gray-400 uppercase">Share Anything. Earn Anytime.</p>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
            <img src={shareApp} alt="SHARE App" className="w-full max-w-lg mx-auto rounded-2xl shadow-2xl object-cover" data-testid="img-share-app" />
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-10 px-4 border-b border-border bg-background" data-testid="section-categories">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setActiveCategory("")}
              data-testid="filter-all"
              className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors ${!activeCategory ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"}`}
            >
              All Categories
            </button>
            {(categories ?? []).map(cat => {
              const Icon = ICON_MAP[cat.iconName] ?? Waves;
              return (
                <button
                  key={cat.slug}
                  onClick={() => setActiveCategory(cat.name)}
                  data-testid={`filter-${cat.slug}`}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium border transition-colors ${activeCategory === cat.name ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"}`}
                >
                  <Icon className="w-3.5 h-3.5" /> {cat.name}
                  <span className="opacity-60 text-xs">({cat.listingCount})</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Listings */}
      <section className="py-10 px-4" data-testid="section-listings">
        <div className="max-w-7xl mx-auto">
          {listingsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-64 rounded-2xl" />)}
            </div>
          ) : (listings ?? []).length === 0 ? (
            <div className="text-center py-20 text-muted-foreground" data-testid="empty-listings">
              <Waves className="w-12 h-12 mx-auto mb-4 opacity-30" />
              <p className="text-lg font-medium">No listings found</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {(listings ?? []).map((listing, i) => (
                <motion.div
                  key={listing.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-lg transition-shadow group cursor-pointer"
                  data-testid={`card-listing-${listing.id}`}
                >
                  <div className="h-44 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center relative">
                    <Waves className="w-16 h-16 text-primary/30" />
                    {!listing.available && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <Badge variant="secondary">Unavailable</Badge>
                      </div>
                    )}
                    <div className="absolute top-2 left-2">
                      <Badge className="bg-black/60 text-white border-0 text-xs">{listing.category}</Badge>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-sm mb-1 group-hover:text-primary transition-colors">{listing.title}</h3>
                    <p className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
                      <MapPin className="w-3 h-3" /> {listing.location}
                    </p>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-extrabold text-lg">${listing.price}</span>
                        <span className="text-xs text-muted-foreground">/{listing.priceUnit}</span>
                      </div>
                      <div className="flex items-center gap-1 text-xs">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span className="font-medium">{listing.rating}</span>
                        <span className="text-muted-foreground">({listing.reviewCount})</span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {listing.amenities.slice(0, 3).map(a => (
                        <span key={a} className="text-[10px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground">{a}</span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
