import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Eye, EyeOff, CheckCircle2, ArrowRight, User, Mail, Phone, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import blueTruckLogo from "@assets/Blue_Truck_LOGO_1782419251695.PNG";
import shareLogo from "@assets/SHARE_LOGO_1782419307093.png";

const ROLES = [
  { value: "customer", label: "Customer / Homeowner", icon: "🏠", desc: "Book services, rent assets, earn rewards" },
  { value: "contractor", label: "Contractor / Pro", icon: "🔨", desc: "Accept jobs, earn money, build reputation" },
  { value: "investor", label: "Investor / Partner", icon: "💼", desc: "Track platform growth and opportunities" },
];

export default function SignUpPage() {
  const { toast } = useToast();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [showPass, setShowPass] = useState(false);
  const [form, setForm] = useState({
    firstName: "", lastName: "", email: "", phone: "", password: "", confirmPassword: "",
    role: "customer", agreeTerms: false, agreeMarketing: false,
  });

  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm(p => ({ ...p, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));

  function handleSubmit() {
    if (form.password !== form.confirmPassword) {
      toast({ title: "Passwords don't match", variant: "destructive" }); return;
    }
    if (!form.agreeTerms) {
      toast({ title: "Please agree to the Terms of Service", variant: "destructive" }); return;
    }
    localStorage.setItem("buyshare_role", form.role);
    localStorage.setItem("buyshare_user", JSON.stringify({ name: `${form.firstName} ${form.lastName}`, email: form.email, role: form.role }));
    toast({ title: "Account created! 🎉", description: `Welcome to BuyShare.co, ${form.firstName}!` });
    setStep(3);
  }

  return (
    <div className="min-h-screen bg-background flex flex-col lg:flex-row">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12 text-white" style={{ background: "linear-gradient(135deg, #001a4a 0%, #002a6e 100%)" }}>
        <div className="flex items-center gap-3">
          <img src={blueTruckLogo} alt="Blue Truck" className="h-12 object-contain" />
          <img src={shareLogo} alt="SHARE" className="h-10 object-contain" />
        </div>
        <div>
          <h2 className="text-4xl font-black mb-4">Join BuyShare.co</h2>
          <p className="text-white/70 text-lg mb-8">One account. Every platform. Unlimited earnings.</p>
          <div className="space-y-4">
            {[
              { icon: "🏠", text: "Book trusted home services in SW Florida" },
              { icon: "🏊", text: "Rent or list pools, yards, boats & more on SHARE™" },
              { icon: "🛍️", text: "Buy and sell on ThriftGirl marketplace" },
              { icon: "🌳", text: "Grow your passive income with EarnTree™" },
              { icon: "🚗", text: "Request local rides with RideShare™" },
            ].map(i => (
              <div key={i.text} className="flex items-center gap-3">
                <span className="text-2xl">{i.icon}</span>
                <span className="text-white/80">{i.text}</span>
              </div>
            ))}
          </div>
        </div>
        <p className="text-white/30 text-sm">Serving Punta Gorda, Port Charlotte & SW Florida</p>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {step === 3 ? (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center">
              <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-14 h-14 text-green-500" />
              </div>
              <h2 className="text-3xl font-black mb-2">Welcome to BuyShare!</h2>
              <p className="text-muted-foreground mb-2">Account created for <strong>{form.email}</strong></p>
              <Badge className="mb-8" style={{ background: "#1fbe4b22", color: "#1fbe4b" }}>{ROLES.find(r => r.value === form.role)?.label}</Badge>
              <div className="space-y-3">
                <Link href="/dashboard"><Button className="w-full text-white" style={{ background: "#1fbe4b" }}>Go to My Dashboard <ArrowRight className="w-4 h-4 ml-2" /></Button></Link>
                <Link href="/"><Button variant="outline" className="w-full">Explore BuyShare.co</Button></Link>
              </div>
            </motion.div>
          ) : (
            <>
              {/* Progress */}
              <div className="flex items-center gap-2 mb-8">
                {[1, 2].map(s => (
                  <div key={s} className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${step >= s ? "text-white" : "bg-muted text-muted-foreground"}`}
                      style={step >= s ? { background: "#002a6e" } : {}}>
                      {step > s ? <CheckCircle2 className="w-4 h-4" /> : s}
                    </div>
                    {s < 2 && <div className={`flex-1 h-0.5 w-8 ${step > s ? "bg-green-500" : "bg-muted"}`} />}
                  </div>
                ))}
                <span className="text-sm text-muted-foreground ml-2">Step {step} of 2</span>
              </div>

              <div className="mb-8">
                <h1 className="text-3xl font-black mb-1">{step === 1 ? "Create Account" : "Choose Your Role"}</h1>
                <p className="text-muted-foreground">{step === 1 ? "Fill in your details to get started" : "Pick how you'll use BuyShare.co"}</p>
              </div>

              {step === 1 && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input className="pl-10" placeholder="First name *" value={form.firstName} onChange={f("firstName")} data-testid="input-first-name" />
                    </div>
                    <Input placeholder="Last name *" value={form.lastName} onChange={f("lastName")} data-testid="input-last-name" />
                  </div>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-10" type="email" placeholder="Email address *" value={form.email} onChange={f("email")} data-testid="input-email" />
                  </div>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-10" type="tel" placeholder="Phone number" value={form.phone} onChange={f("phone")} />
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-10 pr-10" type={showPass ? "text" : "password"} placeholder="Password *" value={form.password} onChange={f("password")} data-testid="input-password" />
                    <button type="button" onClick={() => setShowPass(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-10" type="password" placeholder="Confirm password *" value={form.confirmPassword} onChange={f("confirmPassword")} />
                  </div>
                  <Button className="w-full text-white font-bold" style={{ background: "#002a6e" }}
                    onClick={() => setStep(2)} disabled={!form.firstName || !form.email || !form.password} data-testid="btn-next-step">
                    Continue <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
                  {ROLES.map(r => (
                    <button key={r.value} onClick={() => setForm(p => ({ ...p, role: r.value }))} data-testid={`role-${r.value}`}
                      className={`w-full p-4 rounded-2xl border-2 text-left transition-all ${form.role === r.value ? "border-green-500 bg-green-50 dark:bg-green-900/20" : "border-border hover:border-muted-foreground"}`}>
                      <div className="flex items-center gap-3">
                        <span className="text-3xl">{r.icon}</span>
                        <div>
                          <div className="font-bold">{r.label}</div>
                          <div className="text-sm text-muted-foreground">{r.desc}</div>
                        </div>
                        {form.role === r.value && <CheckCircle2 className="w-5 h-5 text-green-500 ml-auto" />}
                      </div>
                    </button>
                  ))}
                  <div className="space-y-2 pt-2">
                    <label className="flex items-start gap-2 cursor-pointer">
                      <input type="checkbox" checked={form.agreeTerms} onChange={f("agreeTerms")} className="mt-0.5 w-4 h-4" data-testid="checkbox-terms" />
                      <span className="text-sm">I agree to the <Link href="/legal/terms" className="underline">Terms of Service</Link> and <Link href="/legal/privacy" className="underline">Privacy Policy</Link> *</span>
                    </label>
                    <label className="flex items-start gap-2 cursor-pointer">
                      <input type="checkbox" checked={form.agreeMarketing} onChange={f("agreeMarketing")} className="mt-0.5 w-4 h-4" />
                      <span className="text-sm text-muted-foreground">Receive updates and promotions via email/SMS</span>
                    </label>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" className="flex-1" onClick={() => setStep(1)}>Back</Button>
                    <Button className="flex-1 text-white font-bold" style={{ background: "#1fbe4b" }}
                      onClick={handleSubmit} disabled={!form.agreeTerms} data-testid="btn-create-account">
                      Create Account
                    </Button>
                  </div>
                </motion.div>
              )}

              <p className="text-center text-sm text-muted-foreground mt-6">
                Already have an account?{" "}
                <Link href="/sign-in" className="font-semibold" style={{ color: "#002a6e" }}>Sign in</Link>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
