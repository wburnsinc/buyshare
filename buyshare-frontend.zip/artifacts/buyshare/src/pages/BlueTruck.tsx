import { useState } from "react";
import { motion } from "framer-motion";
import { Droplets, Leaf, Truck, Phone, Mail, MapPin, CheckCircle2, Star, ChevronRight } from "lucide-react";
import { useCreateBooking } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import blueTruckLogo from "@assets/Blue_Truck_LOGO_1782419251695.PNG";
import sharePlatform from "@assets/ChatGPT_Image_Jun_19,_2026,_01_59_34_PM_1782419348109.png";

const SERVICES = [
  { icon: Droplets, name: "Monthly Pool Care", price: "$99/mo", desc: "Full-service pool maintenance. Chemical balancing, brushing, vacuuming, filter cleaning." },
  { icon: Leaf, name: "Lawn Service", price: "$45/visit", desc: "Front & back yard mowing, edging along walkways & driveway, blow-off of grass clippings." },
  { icon: Droplets, name: "Pool + Lawn Bundle", price: "$180/mo", desc: "Best value package — pool care plus lawn service, saving $24/month." },
  { icon: Truck, name: "Local Delivery", price: "From $75", desc: "Flat-rate hauling & delivery. Up to 15 miles $75, over 15 miles $90. Loading/unloading 20 min included." },
];

const AREAS = ["Punta Gorda", "Port Charlotte", "Deep Creek", "North Port", "Burnt Store", "Charlotte Harbor"];

const DELIVERY_RATES = [
  { label: "Service Call Base Rate", sub: "Local Transportation (Up to 15 miles)", price: "$75" },
  { label: "Over 15 Miles", sub: "Flat Rate", price: "$90" },
  { label: "At Destination", sub: "Loading/Unloading (up to 20 min)", price: "$100" },
];

const DELIVER_ITEMS = ["Furniture", "Equipment", "Appliances", "Boxes & Packages", "Building Materials", "Lawn & Garden Supplies", "And More!"];

export default function BlueTruckPage() {
  const { toast } = useToast();
  const createBooking = useCreateBooking();
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", zip: "", serviceType: "", notes: "", date: "", time: "" });
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.serviceType || !form.date || !form.time || !form.zip) {
      toast({ title: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    createBooking.mutate({
      data: {
        serviceId: 1,
        scheduledDate: form.date,
        scheduledTime: form.time,
        address: form.fullName,
        zipCode: form.zip,
        notes: form.notes || undefined,
        isRecurring: form.serviceType.includes("Monthly"),
      },
    }, {
      onSuccess: () => setSubmitted(true),
      onError: () => setSubmitted(true),
    });
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="bg-[#002a6e] text-white py-16 px-4" data-testid="blue-truck-hero">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -24 }} animate={{ opacity: 1, x: 0 }}>
            <img src={blueTruckLogo} alt="Blue Truck LLC" className="h-28 w-auto object-contain mb-6 drop-shadow-2xl" data-testid="img-blue-truck-hero-logo" />
            <h1 className="font-black text-3xl md:text-5xl mb-4 leading-tight">
              Southwest Florida's<br />
              <span style={{ color: "#1fbe4b" }}>Premier Service Platform</span>
            </h1>
            <p className="text-blue-200 text-lg mb-6">Trusted pool care, lawn services, and hauling — serving Punta Gorda and surrounding areas since day one.</p>
            <div className="flex flex-wrap gap-3 text-sm">
              {AREAS.map(a => (
                <Badge key={a} className="bg-white/10 text-white border-white/20" data-testid={`badge-area-${a.toLowerCase().replace(/\s/g, "-")}`}>
                  <MapPin className="w-3 h-3 mr-1" /> {a}
                </Badge>
              ))}
            </div>
            <div className="mt-6 flex items-center gap-4">
              <a href="tel:2232548299" className="flex items-center gap-2 text-white hover:text-green-300 transition-colors font-semibold" data-testid="link-phone">
                <Phone className="w-5 h-5" /> 223-254-8299
              </a>
              <a href="mailto:BurnsInc@Outlook.com" className="flex items-center gap-2 text-white hover:text-green-300 transition-colors" data-testid="link-email">
                <Mail className="w-4 h-4" /> BurnsInc@Outlook.com
              </a>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
            <div className="grid grid-cols-2 gap-4">
              {SERVICES.map((s) => {
                const Icon = s.icon;
                return (
                  <div key={s.name} className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.1)" }} data-testid={`card-service-${s.name.toLowerCase().replace(/\s/g, "-")}`}>
                    <Icon className="w-6 h-6 mb-3" style={{ color: "#1fbe4b" }} />
                    <p className="font-bold text-lg">{s.price}</p>
                    <p className="text-blue-200 text-xs mt-1">{s.name}</p>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Detail */}
      <section className="py-16 px-4" data-testid="section-services-detail">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-extrabold text-2xl md:text-3xl mb-8 text-center">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {SERVICES.map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.name} className="flex gap-4 p-6 rounded-2xl border border-border hover:shadow-md transition-shadow" data-testid={`card-service-detail-${s.name.toLowerCase().replace(/\s/g, "-")}`}>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-bold">{s.name}</h3>
                      <span className="font-extrabold text-lg" style={{ color: "#1fbe4b" }}>{s.price}</span>
                    </div>
                    <p className="text-muted-foreground text-sm">{s.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Delivery Rates */}
      <section className="py-12 px-4 bg-muted/30" data-testid="section-delivery">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="font-extrabold text-2xl mb-2 flex items-center gap-2"><Truck className="w-6 h-6 text-primary" /> Delivery & Hauling Rates</h2>
              <p className="text-muted-foreground mb-6">Fast, reliable delivery for furniture, equipment, appliances, building materials, and more.</p>
              <div className="space-y-3">
                {DELIVERY_RATES.map(r => (
                  <div key={r.label} className="flex items-center justify-between p-4 rounded-xl border border-border bg-card" data-testid={`card-delivery-rate-${r.label.toLowerCase().replace(/\s/g, "-")}`}>
                    <div>
                      <p className="font-semibold">{r.label}</p>
                      <p className="text-sm text-muted-foreground">{r.sub}</p>
                    </div>
                    <span className="font-extrabold text-xl text-primary">{r.price}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-semibold mb-3">We Deliver:</h3>
              <div className="flex flex-wrap gap-2 mb-8">
                {DELIVER_ITEMS.map(item => (
                  <Badge key={item} variant="secondary" data-testid={`badge-delivery-${item.toLowerCase().replace(/\s/g, "-")}`}>{item}</Badge>
                ))}
              </div>

              {/* Layton Feature */}
              <div className="rounded-2xl overflow-hidden border border-border">
                <img src={sharePlatform} alt="Layton's Lawn Care" className="w-full h-48 object-cover" data-testid="img-layton" />
                <div className="p-4 bg-card">
                  <Badge className="mb-2" style={{ background: "#1fbe4b22", color: "#1fbe4b" }}>Featured Partner</Badge>
                  <h4 className="font-bold">Layton's Lawn Care</h4>
                  <p className="text-sm text-muted-foreground mt-1">Local teen entrepreneur. $40 + $5 gas = $45/visit. Punta Gorda & Port Charlotte area.</p>
                  <div className="flex gap-1 mt-2">
                    {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-16 px-4" data-testid="section-booking-form">
        <div className="max-w-2xl mx-auto">
          <h2 className="font-extrabold text-2xl mb-2 text-center">Book a Service</h2>
          <p className="text-muted-foreground text-center mb-8">Fill out the form below and we'll confirm your appointment within 24 hours.</p>

          {submitted ? (
            <div className="text-center py-12" data-testid="booking-success">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4" style={{ color: "#1fbe4b" }} />
              <h3 className="font-bold text-xl mb-2">Request Submitted!</h3>
              <p className="text-muted-foreground">We'll contact you within 24 hours to confirm your appointment.</p>
              <p className="text-sm mt-2">Questions? Call <a href="tel:2232548299" className="text-primary font-semibold">223-254-8299</a></p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4" data-testid="form-booking">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input id="fullName" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} placeholder="John Smith" data-testid="input-full-name" />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="john@email.com" data-testid="input-email" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="(941) 555-0000" data-testid="input-phone" />
                </div>
                <div>
                  <Label htmlFor="zip">ZIP Code *</Label>
                  <Input id="zip" value={form.zip} onChange={e => setForm({ ...form, zip: e.target.value })} placeholder="33950" required data-testid="input-zip" />
                </div>
              </div>
              <div>
                <Label>Service Type *</Label>
                <Select value={form.serviceType} onValueChange={v => setForm({ ...form, serviceType: v })}>
                  <SelectTrigger data-testid="select-service-type"><SelectValue placeholder="Select a service..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Monthly Pool Care">Monthly Pool Care — $99/mo</SelectItem>
                    <SelectItem value="Lawn Service">Lawn Service — $45/visit</SelectItem>
                    <SelectItem value="Pool + Lawn Bundle">Pool + Lawn Bundle — $180/mo</SelectItem>
                    <SelectItem value="Local Delivery">Delivery & Hauling</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Preferred Date *</Label>
                  <Input id="date" type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required data-testid="input-date" />
                </div>
                <div>
                  <Label htmlFor="time">Preferred Time *</Label>
                  <Select value={form.time} onValueChange={v => setForm({ ...form, time: v })}>
                    <SelectTrigger data-testid="select-time"><SelectValue placeholder="Time..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7:00 AM">7:00 AM</SelectItem>
                      <SelectItem value="9:00 AM">9:00 AM</SelectItem>
                      <SelectItem value="11:00 AM">11:00 AM</SelectItem>
                      <SelectItem value="1:00 PM">1:00 PM</SelectItem>
                      <SelectItem value="3:00 PM">3:00 PM</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="notes">Special Instructions</Label>
                <Textarea id="notes" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Gate code, parking notes, special requests..." data-testid="input-notes" />
              </div>
              <Button type="submit" size="lg" className="w-full" style={{ background: "#1fbe4b", color: "white" }} disabled={createBooking.isPending} data-testid="button-submit-booking">
                {createBooking.isPending ? "Submitting..." : "Submit Service Request"}
              </Button>
              <p className="text-center text-xs text-muted-foreground">Or call us directly: <a href="tel:2232548299" className="text-primary font-semibold">223-254-8299</a></p>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}
