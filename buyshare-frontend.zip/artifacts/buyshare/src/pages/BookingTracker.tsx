import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, Calendar, Clock, CheckCircle2, Truck, Wrench, Star, MessageSquare, Phone, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const STEPS = [
  { status: "pending", label: "Received", desc: "Your request is being reviewed", icon: Clock, color: "text-yellow-500" },
  { status: "confirmed", label: "Confirmed", desc: "Service confirmed and scheduled", icon: CheckCircle2, color: "text-blue-500" },
  { status: "assigned", label: "Assigned", desc: "Contractor has been assigned", icon: Wrench, color: "text-purple-500" },
  { status: "en_route", label: "En Route", desc: "Contractor is on the way", icon: Truck, color: "text-orange-500" },
  { status: "in_progress", label: "In Progress", desc: "Service is being performed", icon: Wrench, color: "text-cyan-500" },
  { status: "completed", label: "Completed", desc: "Service complete. Rate your experience", icon: CheckCircle2, color: "text-green-500" },
];

function getStepIndex(status: string) {
  return STEPS.findIndex(s => s.status === status);
}

interface TrackerProps {
  bookingId: number;
}

function BookingTrackerCard({ bookingId }: TrackerProps) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);

  const { data: booking, isLoading } = useQuery({
    queryKey: ["booking", bookingId],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/bookings/${bookingId}`);
      return res.json();
    },
    refetchInterval: 5000,
  });

  const advanceStatus = useMutation({
    mutationFn: async () => {
      const current = STEPS[getStepIndex(booking?.status)];
      const nextIdx = getStepIndex(booking?.status) + 1;
      if (nextIdx >= STEPS.length) return null;
      const next = STEPS[nextIdx];
      const res = await fetch(`${BASE}/api/bookings/${bookingId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next.status }),
      });
      return res.json();
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["booking", bookingId] }); toast({ title: "Status updated" }); },
  });

  if (isLoading) return <div className="animate-pulse h-64 rounded-2xl border border-border bg-card" />;
  if (!booking || booking.error) return <div className="p-4 rounded-2xl border border-border bg-card text-center text-muted-foreground">Booking not found</div>;

  const stepIdx = getStepIndex(booking.status);
  const isCompleted = booking.status === "completed";

  return (
    <div className="rounded-2xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="p-5 border-b border-border" style={{ background: "linear-gradient(135deg, #001a4a, #002a6e)" }}>
        <div className="flex items-start justify-between text-white">
          <div>
            <Badge className="mb-2 bg-white/10 text-white/80 border-0 text-xs">Booking #{bookingId}</Badge>
            <h3 className="text-xl font-bold">{booking.serviceName}</h3>
            <div className="flex items-center gap-1 text-white/70 text-sm mt-1"><MapPin className="w-3.5 h-3.5" /> {booking.address}</div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-green-400">{booking.price ? `$${Number(booking.price).toFixed(0)}` : "TBD"}</div>
            <div className="text-white/50 text-xs">Est. price</div>
          </div>
        </div>
        <div className="flex gap-4 mt-3 text-sm text-white/60">
          <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {booking.scheduledDate}</span>
          <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {booking.scheduledTime}</span>
        </div>
      </div>

      {/* Progress tracker */}
      <div className="p-5">
        <div className="relative">
          {/* Track line */}
          <div className="absolute left-4 top-4 bottom-4 w-0.5 bg-muted" />
          <div className="absolute left-4 top-4 w-0.5 bg-green-500 transition-all duration-1000"
            style={{ height: `${(stepIdx / (STEPS.length - 1)) * 100}%` }} />

          <div className="space-y-4">
            {STEPS.map((step, i) => {
              const done = i < stepIdx;
              const current = i === stepIdx;
              const upcoming = i > stepIdx;
              const Icon = step.icon;
              return (
                <div key={step.status} className={`flex items-center gap-4 ${upcoming ? "opacity-30" : ""}`}>
                  <div className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all ${done ? "bg-green-500" : current ? "bg-blue-500" : "bg-muted"}`}>
                    {done ? <CheckCircle2 className="w-4 h-4 text-white" /> : <Icon className={`w-4 h-4 ${current ? "text-white" : "text-muted-foreground"}`} />}
                  </div>
                  <div className="flex-1">
                    <div className={`font-semibold text-sm ${current ? "text-foreground" : "text-muted-foreground"}`}>
                      {step.label}
                      {current && <AnimatePresence><motion.span key="pulse" initial={{ opacity: 0 }} animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1.5 }} className="ml-2 text-xs text-blue-500 font-normal">● Live</motion.span></AnimatePresence>}
                    </div>
                    {(done || current) && <div className="text-xs text-muted-foreground">{step.desc}</div>}
                  </div>
                  {current && !isCompleted && stepIdx < STEPS.length - 1 && (
                    <Badge className="bg-blue-100 text-blue-700 text-xs animate-pulse">Current</Badge>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Contractor info */}
      {booking.contractorName && (
        <div className="px-5 pb-4 border-t border-border pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ background: "#002a6e" }}>
                {booking.contractorName.charAt(0)}
              </div>
              <div>
                <div className="font-semibold text-sm">{booking.contractorName}</div>
                <div className="text-xs text-muted-foreground">Your Service Pro</div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline"><Phone className="w-3.5 h-3.5" /></Button>
              <Button size="sm" variant="outline"><MessageSquare className="w-3.5 h-3.5" /></Button>
            </div>
          </div>
        </div>
      )}

      {/* Rating (if completed) */}
      {isCompleted && (
        <div className="px-5 pb-5 border-t border-border pt-4">
          <h4 className="font-semibold mb-3">Rate your experience</h4>
          <div className="flex gap-2 mb-3">
            {[1, 2, 3, 4, 5].map(s => (
              <button key={s} onMouseEnter={() => setHover(s)} onMouseLeave={() => setHover(0)} onClick={() => setRating(s)} data-testid={`star-${s}`}>
                <Star className={`w-8 h-8 transition-colors ${(hover || rating) >= s ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`} />
              </button>
            ))}
          </div>
          {rating > 0 && <Button className="text-white" style={{ background: "#1fbe4b" }} onClick={() => toast({ title: "Review submitted! Thank you ⭐" })}>Submit Review</Button>}
        </div>
      )}

      {/* Demo controls */}
      {!isCompleted && booking.status !== "cancelled" && (
        <div className="px-5 pb-5 border-t border-border pt-4">
          <p className="text-xs text-muted-foreground mb-2">Demo: Advance booking status</p>
          <Button size="sm" variant="outline" onClick={() => advanceStatus.mutate()} disabled={advanceStatus.isPending || stepIdx >= STEPS.length - 1} data-testid="btn-advance-status">
            Advance to next step <ChevronRight className="w-3.5 h-3.5 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}

export default function BookingTrackerPage() {
  const { data: bookings = [] } = useQuery({
    queryKey: ["all-bookings"],
    queryFn: async () => { const res = await fetch(`${BASE}/api/bookings`); return res.json(); },
  });

  const active = (bookings as any[]).filter(b => b.status !== "cancelled");

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <Badge className="mb-2" style={{ background: "#1fbe4b22", color: "#1fbe4b" }}>Real-Time Tracking</Badge>
          <h1 className="text-3xl font-black mb-2">Booking Tracker</h1>
          <p className="text-muted-foreground">Live status updates for all your service bookings. Updates every 5 seconds.</p>
        </div>

        {active.length === 0 ? (
          <div className="text-center py-20 rounded-2xl border border-border bg-card">
            <Truck className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-30" />
            <h3 className="text-xl font-semibold mb-2">No active bookings</h3>
            <p className="text-muted-foreground mb-4">Book a service to see real-time tracking.</p>
            <Link href="/services"><Button style={{ background: "#002a6e" }} className="text-white">Find Services</Button></Link>
          </div>
        ) : (
          <div className="space-y-6">
            {active.map((b: any) => <BookingTrackerCard key={b.id} bookingId={b.id} />)}
          </div>
        )}
      </div>
    </div>
  );
}
