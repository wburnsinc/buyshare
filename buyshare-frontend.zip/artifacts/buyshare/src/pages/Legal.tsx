import { useParams } from "wouter";

const PAGES: Record<string, { title: string; content: string[] }> = {
  privacy: {
    title: "Privacy Policy",
    content: [
      "Last updated: June 25, 2026",
      "BuyShare.co (operated by Blue Truck LLC) is committed to protecting your personal information. This policy describes how we collect, use, and share data when you use our platform.",
      "Information We Collect: We collect information you provide directly (name, email, phone, address), information from service bookings, payment information processed through Stripe, device and usage information.",
      "How We Use Your Information: To provide and improve our services, to connect customers with contractors, to process payments, to send service confirmations and updates, to comply with legal obligations.",
      "Data Sharing: We share your information with contractors you book, payment processors (Stripe), and service providers who help us operate the platform. We do not sell your personal information.",
      "Your Rights: You may request access to, correction of, or deletion of your personal data by contacting us at BurnsInc@Outlook.com.",
      "Contact: Blue Truck LLC · Florida, USA · BurnsInc@Outlook.com · 223-254-8299",
    ],
  },
  terms: {
    title: "Terms of Service",
    content: [
      "Last updated: June 25, 2026",
      "By using BuyShare.co, you agree to these Terms of Service. Please read them carefully.",
      "Eligibility: You must be at least 18 years old to use our services. By creating an account, you represent that you meet this requirement.",
      "Services: BuyShare.co provides a marketplace connecting homeowners with contractors, a peer-to-peer sharing marketplace (SHARE™), an AI lead management system (BurnCall), and contractor payment tools (PocketCash).",
      "Payments: All payments are processed securely through Stripe. Service prices are listed at time of booking and may include a platform service fee.",
      "Cancellations: Cancellations made more than 24 hours before a scheduled service receive a full refund. Cancellations within 24 hours may be subject to a cancellation fee.",
      "Disputes: In the event of a dispute between a customer and contractor, BuyShare.co will facilitate resolution. We reserve the right to make final decisions on platform-related disputes.",
      "Contact: BurnsInc@Outlook.com · 223-254-8299",
    ],
  },
  refund: {
    title: "Refund Policy",
    content: [
      "Last updated: June 25, 2026",
      "We stand behind the quality of services booked through BuyShare.co.",
      "Full Refunds: Available if a service is cancelled more than 24 hours before the scheduled time, or if a contractor fails to show up without notice.",
      "Partial Refunds: May be issued if a service was only partially completed. The amount is determined case-by-case.",
      "No Refund: Services completed as described are generally not eligible for refunds. Disputes must be raised within 48 hours of service completion.",
      "How to Request: Contact us at BurnsInc@Outlook.com with your booking ID and description of the issue. Refunds are processed within 5-7 business days.",
      "SHARE™ Listings: Cancellation policies for SHARE™ listings are set by the individual host and displayed before booking.",
    ],
  },
  "contractor-agreement": {
    title: "Contractor Agreement",
    content: [
      "Last updated: June 25, 2026",
      "This agreement governs contractors who list services on BuyShare.co (operated by Blue Truck LLC).",
      "Independent Contractor Status: Contractors are independent contractors, not employees of BuyShare.co or Blue Truck LLC. You are responsible for your own taxes, insurance, and equipment.",
      "Verification Requirements: All contractors must provide valid license information, proof of general liability insurance, and agree to a background check process.",
      "Service Quality: Contractors must complete services as described. Repeated complaints or cancellations may result in account suspension.",
      "Platform Fees: BuyShare.co charges a platform fee on completed bookings. Current fee structures are available in your contractor dashboard.",
      "Payouts: Payments are processed through PocketCash and released within 3-5 business days after service completion.",
      "Termination: Either party may terminate this agreement with 30 days written notice. BuyShare.co reserves the right to immediately suspend accounts that violate these terms.",
      "Contact: BurnsInc@Outlook.com · 223-254-8299",
    ],
  },
};

export default function LegalPage() {
  const { page } = useParams<{ page: string }>();
  const content = PAGES[page ?? ""] ?? PAGES["terms"];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#002a6e] text-white py-10 px-4" data-testid="legal-header">
        <div className="max-w-3xl mx-auto">
          <h1 className="font-black text-2xl md:text-3xl">{content.title}</h1>
        </div>
      </div>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-5" data-testid="legal-content">
        {content.content.map((para, i) => (
          <p key={i} className={`leading-relaxed ${i === 0 ? "text-xs text-muted-foreground" : "text-muted-foreground"}`}>{para}</p>
        ))}
        <div className="mt-8 pt-6 border-t border-border text-sm text-muted-foreground">
          <p>BuyShare.co is operated by Blue Truck LLC · Florida, USA</p>
          <p>Contact: <a href="mailto:BurnsInc@Outlook.com" className="text-primary">BurnsInc@Outlook.com</a> · <a href="tel:2232548299" className="text-primary">223-254-8299</a></p>
        </div>
      </div>
    </div>
  );
}
