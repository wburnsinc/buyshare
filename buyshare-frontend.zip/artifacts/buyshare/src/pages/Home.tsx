import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Leaf, Hammer, Droplets, Sparkles, Wind, Zap, Home, Paintbrush,
  Wrench, LayoutGrid, Users, TrendingUp, ShieldCheck, ChevronRight,
  ArrowRight, Truck, Share2, Phone, DollarSign, Star, CheckCircle2,
  Building2, Anchor, ParkingCircle, Waves, Search
} from "lucide-react";
import { useGetDashboardSummary, useGetRecentActivity } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import blueTruckLogo from "@assets/Blue_Truck_LOGO_1782419251695.PNG";
import shareLogo from "@assets/SHARE_LOGO_1782419307093.png";

const INDUSTRIES = [
  { label: "Lawn Care", icon: Leaf },
  { label: "Construction", icon: Hammer },
  { label: "Pool Services", icon: Droplets },
  { label: "Cleaning", icon: Sparkles },
  { label: "HVAC", icon: Wind },
  { label: "Plumbing", icon: Wrench },
  { label: "Electrical", icon: Zap },
  { label: "Painting", icon: Paintbrush },
  { label: "Roofing", icon: Home },
  { label: "Handyman", icon: Hammer },
  { label: "Delivery", icon: Truck },
  { label: "View All", icon: LayoutGrid },
];

const AUDIENCE = [
  {
    icon: Users,
    title: "For Homeowners & Businesses",
    color: "#002a6e",
    items: ["Find trusted local pros", "View reviews & ratings", "Get fast quotes & book online", "Manage jobs in one place"],
  },
  {
    icon: Wrench,
    title: "For Contractors & Service Pros",
    color: "#1fbe4b",
    items: ["Get matched with quality jobs", "Share work and find subcontractors", "Manage projects and clients", "Grow your business and reputation"],
  },
  {
    icon: TrendingUp,
    title: "For Investors & Partners",
    color: "#001a4a",
    items: ["Track investments and returns", "View company growth metrics", "Access investor documents", "Stay updated with company news"],
  },
];

const WHY = [
  "One platform. Every trade.",
  "Nationwide network of verified pros.",
  "Real-time job matching.",
  "Built for homeowners, pros & investors.",
  "AI-powered tools for faster results.",
  "Secure payments & instant quotes.",
  "24/7 support & resources.",
  "Unlimited potential. Real growth.",
];

const BRANDS = [
  { name: "Blue Truck LLC", desc: "Local home services — pool care, lawn care, delivery & hauling in Southwest Florida.", href: "/blue-truck", color: "#002a6e" },
  { name: "SHARE™", desc: "Peer-to-peer marketplace to rent pools, homes, boats, parking, yards & RVs.", href: "/share", color: "#1fbe4b" },
  { name: "BurnCall", desc: "AI phone & SMS receptionist — capture every lead, dispatch automatically.", href: "/burncall", color: "#001a4a" },
  { name: "PocketCash", desc: "Contractor payouts, invoices, credits & future wallet — all in one place.", href: "/dashboard/payments", color: "#0050CC" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, duration: 0.5, ease: "easeOut" } }),
};

export default function HomePage() {
  const { data: summary } = useGetDashboardSummary();
  const { data: activity } = useGetRecentActivity();

  const STATS = [
    { value: "3M+", label: "Homes Served" },
    { value: "500+", label: "Active Contractors" },
    { value: "10,000+", label: "Jobs Completed" },
    { value: "$25M+", label: "Market Opportunity" },
    { value: "24/7", label: "Platform Support" },
  ];

  return (
    <div className="overflow-x-hidden">
      {/* ── HERO ── */}
      <section className="relative bg-[#002a6e] text-white overflow-hidden" data-testid="hero-section">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_top_right,_#1fbe4b_0%,_transparent_60%)]" />
        <div className="hidden md:flex items-center justify-between px-6 py-2.5 text-xs font-semibold bg-[#001a4a]">
          <span className="uppercase tracking-widest text-blue-200">The Future of Workforce is Here.</span>
          <span className="font-extrabold text-base tracking-wide" style={{ color: "#1fbe4b" }}>CONNECT. HIRE. DELIVER. GROW.</span>
          <div className="flex items-center gap-6 text-blue-200">
            <span className="flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> LOCAL. RELIABLE.</span>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div initial="hidden" animate="visible" variants={fadeUp} custom={0}>
              <div className="flex items-center gap-4 mb-8">
                <Link href="/blue-truck">
                  <img src={blueTruckLogo} alt="Blue Truck LLC" className="h-24 lg:h-28 w-auto object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-200" data-testid="img-blue-truck-logo" />
                </Link>
                <div className="w-px h-20 bg-white/20" />
                <Link href="/share">
                  <img src={shareLogo} alt="SHARE™" className="h-20 lg:h-24 w-auto object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-200" data-testid="img-share-logo" />
                </Link>
              </div>

              <h1 className="font-black leading-tight mb-4 text-white" style={{ fontSize: "clamp(2.4rem,5vw,4rem)" }} data-testid="text-hero-headline">
                AMERICA GETS IT DONE<br />
                <span style={{ color: "#1fbe4b" }}>WITH BUYSHARE.</span>
              </h1>
              <p className="text-blue-200 text-lg leading-relaxed mb-8 max-w-lg">
                One platform connecting homeowners, businesses, and property owners with trusted service professionals across every industry.
              </p>

              <div className="flex flex-wrap gap-3">
                <Link href="/services">
                  <Button size="lg" className="gap-2" style={{ background: "#1fbe4b", color: "white" }} data-testid="button-find-services">
                    <Search className="w-4 h-4" /> Find Services
                  </Button>
                </Link>
                <Link href="/contractors/join">
                  <Button size="lg" variant="outline" className="gap-2 border-white/40 text-white hover:bg-white/10" data-testid="button-join-contractor">
                    Join as Contractor <ChevronRight className="w-4 h-4" />
                  </Button>
                </Link>
                <a href="tel:2232548299">
                  <Button size="lg" variant="ghost" className="gap-2 text-white hover:bg-white/10" data-testid="button-call-us">
                    <Phone className="w-4 h-4" /> 223-254-8299
                  </Button>
                </a>
              </div>
            </motion.div>

            {/* Brand cards */}
            <motion.div className="grid grid-cols-2 gap-4" initial="hidden" animate="visible">
              {BRANDS.map((brand, i) => (
                <motion.div key={brand.name} variants={fadeUp} custom={i + 1}>
                  <Link href={brand.href}>
                    <div
                      className="rounded-xl p-5 cursor-pointer hover:-translate-y-1 transition-transform duration-200 h-full"
                      style={{ background: brand.color === "#002a6e" ? "rgba(255,255,255,0.08)" : `${brand.color}22`, border: `1px solid ${brand.color}44` }}
                      data-testid={`card-brand-${brand.name.toLowerCase().replace(/[^a-z]/g, "-")}`}
                    >
                      <div className="font-extrabold text-white mb-2">{brand.name}</div>
                      <p className="text-blue-200 text-xs leading-relaxed">{brand.desc}</p>
                      <div className="mt-3 flex items-center gap-1 text-xs" style={{ color: "#1fbe4b" }}>
                        Learn more <ArrowRight className="w-3 h-3" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── INDUSTRIES ── */}
      <section className="py-14 px-4 bg-background" data-testid="section-industries">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-center font-extrabold text-xl uppercase tracking-widest mb-8 text-primary">Browse All Service Industries</h2>
          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-12 gap-3">
            {INDUSTRIES.map((ind, i) => {
              const Icon = ind.icon;
              return (
                <motion.div
                  key={ind.label}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.04 }}
                  whileHover={{ y: -4 }}
                  className="flex flex-col items-center gap-2 p-3 rounded-xl border border-border cursor-pointer hover:border-secondary hover:shadow-md transition-all text-center col-span-1"
                  data-testid={`card-industry-${ind.label.toLowerCase().replace(/\s/g, "-")}`}
                >
                  <Icon className="w-5 h-5 text-primary" />
                  <p className="text-[10px] font-semibold text-muted-foreground leading-tight">{ind.label}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <section className="py-12 px-4 bg-[#002a6e]" data-testid="section-stats">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-4">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              className="text-center py-6 px-4 rounded-xl"
              style={{ background: "rgba(255,255,255,0.08)" }}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              data-testid={`stat-${s.label.toLowerCase().replace(/\s/g, "-")}`}
            >
              <p className="font-extrabold text-3xl md:text-4xl mb-1" style={{ color: "#1fbe4b" }}>{s.value}</p>
              <p className="text-blue-200 text-xs font-semibold uppercase tracking-wide">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ── AUDIENCE ── */}
      <section className="py-16 px-4 bg-background" data-testid="section-audience">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-center font-extrabold text-2xl md:text-3xl mb-2 text-foreground">Built for Everyone.</h2>
          <p className="text-center text-muted-foreground mb-10">One platform. Every role.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {AUDIENCE.map((a, i) => {
              const Icon = a.icon;
              return (
                <motion.div
                  key={a.title}
                  className="rounded-2xl border border-border p-7 hover:shadow-lg transition-shadow"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  data-testid={`card-audience-${i}`}
                >
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ background: `${a.color}15` }}>
                    <Icon className="w-6 h-6" style={{ color: a.color }} />
                  </div>
                  <h3 className="font-bold text-lg mb-4">{a.title}</h3>
                  <ul className="space-y-2.5">
                    {a.items.map(item => (
                      <li key={item} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "#1fbe4b" }} />
                        {item}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── WHY BUYSHARE ── */}
      <section className="py-16 px-4 bg-muted/30" data-testid="section-why">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="mb-4" style={{ background: "#1fbe4b22", color: "#1fbe4b", border: "1px solid #1fbe4b44" }}>Why Choose BuyShare.co</Badge>
            <h2 className="font-extrabold text-3xl md:text-4xl mb-6 leading-tight">The platform that does it all.</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {WHY.map((w, i) => (
                <motion.div
                  key={w}
                  className="flex items-center gap-2.5 text-sm font-medium"
                  initial={{ opacity: 0, x: -12 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" style={{ color: "#1fbe4b" }} />
                  {w}
                </motion.div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/services"><Button style={{ background: "#002a6e", color: "white" }} data-testid="button-get-started">Get Started</Button></Link>
              <Link href="/about"><Button variant="outline" data-testid="button-learn-more">Learn More</Button></Link>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="space-y-3" data-testid="recent-activity">
            <h3 className="font-bold text-lg mb-4">Live Platform Activity</h3>
            {(activity ?? []).slice(0, 5).map((item) => (
              <motion.div
                key={item.id}
                className="flex items-start gap-3 p-3.5 rounded-xl border border-border bg-card"
                initial={{ opacity: 0, x: 12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                data-testid={`activity-item-${item.id}`}
              >
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{item.description}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{item.actor} · {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── BLUE TRUCK PRICING ── */}
      <section className="py-16 px-4 bg-[#002a6e] text-white" data-testid="section-blue-truck-pricing">
        <div className="max-w-7xl mx-auto text-center">
          <img src={blueTruckLogo} alt="Blue Truck LLC" className="h-20 w-auto object-contain mx-auto mb-6" />
          <h2 className="font-black text-3xl md:text-4xl mb-3">Southwest Florida's Premier Service Platform</h2>
          <p className="text-blue-200 mb-10">Serving Punta Gorda · Port Charlotte · Deep Creek · North Port · Burnt Store · Charlotte Harbor</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
            {[
              { label: "Monthly Pool Care", price: "$99/mo", sub: "Full-service pool maintenance" },
              { label: "Lawn Service", price: "$45/visit", sub: "Front, back & edging" },
              { label: "Pool + Lawn Bundle", price: "$180/mo", sub: "Best value — save $24/mo" },
            ].map(p => (
              <div key={p.label} className="rounded-2xl p-6 text-center" style={{ background: "rgba(255,255,255,0.1)" }} data-testid={`card-pricing-${p.label.toLowerCase().replace(/\s/g, "-")}`}>
                <p className="text-blue-200 text-sm mb-1">{p.label}</p>
                <p className="font-extrabold text-3xl mb-1">{p.price}</p>
                <p className="text-blue-300 text-xs">{p.sub}</p>
              </div>
            ))}
          </div>
          <Link href="/blue-truck"><Button size="lg" className="mt-8" style={{ background: "#1fbe4b", color: "white" }} data-testid="button-blue-truck-cta">Book a Service</Button></Link>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 px-4 bg-background" data-testid="section-cta">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-black text-3xl md:text-4xl mb-4">Ready to join the platform?</h2>
          <p className="text-muted-foreground text-lg mb-8">Whether you're a homeowner looking for trusted services, a contractor ready to grow, or an investor — there's a place for you on BuyShare.co.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/services"><Button size="lg" style={{ background: "#1fbe4b", color: "white" }} data-testid="button-cta-find-services">Find Services Now</Button></Link>
            <Link href="/contractors/join"><Button size="lg" variant="outline" data-testid="button-cta-join-contractor">Join as Contractor</Button></Link>
            <Link href="/investor"><Button size="lg" variant="ghost" data-testid="button-cta-investor">Investor Portal</Button></Link>
          </div>
        </div>
      </section>
    </div>
  );
}

