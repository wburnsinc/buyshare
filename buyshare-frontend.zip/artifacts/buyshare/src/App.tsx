import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import NotFound from "@/pages/not-found";
import Layout from "@/components/Layout";
import HomePage from "@/pages/Home";
import ServicesPage from "@/pages/Services";
import BlueTruckPage from "@/pages/BlueTruck";
import SharePage from "@/pages/Share";
import ContractorsPage from "@/pages/Contractors";
import ContractorJoinPage from "@/pages/ContractorJoin";
import DashboardPage from "@/pages/Dashboard";
import BookingsPage from "@/pages/Bookings";
import MessagesPage from "@/pages/Messages";
import PaymentsPage from "@/pages/Payments";
import BurnCallPage from "@/pages/BurnCall";
import InvestorPage from "@/pages/Investor";
import HelpPage from "@/pages/Help";
import AboutPage from "@/pages/About";
import SettingsPage from "@/pages/Settings";
import LegalPage from "@/pages/Legal";
import ThriftGirlPage from "@/pages/ThriftGirl";
import PlaydatePage from "@/pages/Playdate";
import RidesharePage from "@/pages/Rideshare";
import PoolSharePage from "@/pages/PoolShare";
import EarnTreePage from "@/pages/EarnTree";
import ContractorPortalPage from "@/pages/ContractorPortal";
import AdminPortalPage from "@/pages/AdminPortal";
import SignUpPage from "@/pages/SignUp";
import SignInPage from "@/pages/SignIn";
import BookingTrackerPage from "@/pages/BookingTracker";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30000,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/services" component={ServicesPage} />
        <Route path="/blue-truck" component={BlueTruckPage} />
        <Route path="/share" component={SharePage} />
        <Route path="/poolshare" component={PoolSharePage} />
        <Route path="/thriftgirl" component={ThriftGirlPage} />
        <Route path="/playdate" component={PlaydatePage} />
        <Route path="/rideshare" component={RidesharePage} />
        <Route path="/earntree" component={EarnTreePage} />
        <Route path="/contractors" component={ContractorsPage} />
        <Route path="/contractors/join" component={ContractorJoinPage} />
        <Route path="/contractor/portal" component={ContractorPortalPage} />
        <Route path="/dashboard" component={DashboardPage} />
        <Route path="/dashboard/bookings" component={BookingsPage} />
        <Route path="/dashboard/messages" component={MessagesPage} />
        <Route path="/dashboard/payments" component={PaymentsPage} />
        <Route path="/dashboard/tracker" component={BookingTrackerPage} />
        <Route path="/burncall" component={BurnCallPage} />
        <Route path="/investor" component={InvestorPage} />
        <Route path="/admin" component={AdminPortalPage} />
        <Route path="/sign-up" component={SignUpPage} />
        <Route path="/sign-in" component={SignInPage} />
        <Route path="/help" component={HelpPage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/settings" component={SettingsPage} />
        <Route path="/legal/:page" component={LegalPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
