import { Link, useLocation } from "wouter";
import { useState } from "react";
import { useTheme } from "next-themes";
import {
  Home, Search, Calendar, MessageSquare, User, Menu, X, Sun, Moon,
  ChevronDown, Phone, TrendingUp, HelpCircle, Info, Settings,
  Truck, Share2, DollarSign, ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Find Services", href: "/services" },
  { label: "Blue Truck", href: "/blue-truck" },
  { label: "SHARE™", href: "/share" },
  { label: "Contractors", href: "/contractors" },
  { label: "BurnCall", href: "/burncall" },
  { label: "Investors", href: "/investor" },
];

const MOBILE_NAV = [
  { label: "Home", href: "/", icon: Home },
  { label: "Search", href: "/services", icon: Search },
  { label: "Bookings", href: "/dashboard/bookings", icon: Calendar },
  { label: "Messages", href: "/dashboard/messages", icon: MessageSquare },
  { label: "Account", href: "/dashboard", icon: User },
];

const ROLES = ["customer", "contractor", "dispatcher", "investor", "admin"] as const;
type Role = typeof ROLES[number];

function getRoleLabel(role: Role) {
  const map: Record<Role, string> = {
    customer: "Customer",
    contractor: "Contractor",
    dispatcher: "Dispatcher",
    investor: "Investor",
    admin: "Admin",
  };
  return map[role];
}

function getRoleColor(role: Role) {
  const map: Record<Role, string> = {
    customer: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
    contractor: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
    dispatcher: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
    investor: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
    admin: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
  };
  return map[role];
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const storedRole = (localStorage.getItem("buyshare_role") as Role) || "customer";
  const [role, setRole] = useState<Role>(storedRole);

  function handleRoleChange(r: Role) {
    setRole(r);
    localStorage.setItem("buyshare_role", r);
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Top Nav */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border" data-testid="header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" data-testid="logo-link">
              <span className="flex items-center gap-1 font-black text-2xl tracking-tight select-none">
                <span className="text-primary">BUY</span>
                <span style={{ color: "#1fbe4b" }}>SHARE</span>
                <span className="text-muted-foreground text-lg font-semibold">.co</span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  data-testid={`nav-${link.label.toLowerCase().replace(/[^a-z]/g, "-")}`}
                  className={cn(
                    "px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    location === link.href
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Right side */}
            <div className="flex items-center gap-2">
              {/* Role switcher */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    data-testid="role-switcher"
                    className={cn("hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border border-current/20 transition-colors", getRoleColor(role))}
                  >
                    <ShieldCheck className="w-3 h-3" />
                    {getRoleLabel(role)}
                    <ChevronDown className="w-3 h-3" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {ROLES.map(r => (
                    <DropdownMenuItem key={r} onClick={() => handleRoleChange(r)} data-testid={`role-${r}`}>
                      {getRoleLabel(r)}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Theme toggle */}
              <button
                data-testid="theme-toggle"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              >
                <Sun className="w-4 h-4 dark:hidden" />
                <Moon className="w-4 h-4 hidden dark:block" />
              </button>

              {/* Auth buttons */}
              <Link href="/dashboard">
                <Button variant="ghost" size="sm" className="hidden sm:inline-flex" data-testid="btn-sign-in">Sign In</Button>
              </Link>
              <Link href="/dashboard">
                <Button size="sm" className="hidden sm:inline-flex" style={{ background: "#1fbe4b", color: "white" }} data-testid="btn-create-account">
                  Create Account
                </Button>
              </Link>

              {/* Mobile menu */}
              <button
                className="lg:hidden p-2 rounded-md text-muted-foreground hover:bg-muted"
                onClick={() => setMobileOpen(!mobileOpen)}
                data-testid="mobile-menu-toggle"
              >
                {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-border bg-background px-4 pb-4 pt-2" data-testid="mobile-menu">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                  location === link.href
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                {link.label}
              </Link>
            ))}
            <div className="mt-3 pt-3 border-t border-border flex flex-col gap-2">
              <div className="flex gap-2">
                {ROLES.map(r => (
                  <button
                    key={r}
                    onClick={() => handleRoleChange(r)}
                    className={cn("px-2 py-1 rounded text-xs font-semibold border transition-colors", role === r ? getRoleColor(r) : "text-muted-foreground border-muted")}
                  >
                    {getRoleLabel(r)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Page content */}
      <main className="flex-1 pb-16 lg:pb-0">
        {children}
      </main>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border" data-testid="mobile-bottom-nav">
        <div className="flex items-center justify-around h-16">
          {MOBILE_NAV.map((item) => {
            const Icon = item.icon;
            const active = location === item.href;
            return (
              <Link key={item.href} href={item.href} data-testid={`mobile-nav-${item.label.toLowerCase()}`}>
                <div className={cn("flex flex-col items-center gap-0.5 px-3 py-2 rounded-lg transition-colors", active ? "text-primary" : "text-muted-foreground")}>
                  <Icon className="w-5 h-5" />
                  <span className="text-[10px] font-medium">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <footer className="hidden lg:block border-t border-border bg-muted/30 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            <div className="col-span-2 md:col-span-1">
              <div className="font-black text-xl mb-3">
                <span className="text-primary">BUY</span>
                <span style={{ color: "#1fbe4b" }}>SHARE</span>
                <span className="text-muted-foreground text-base">.co</span>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">America's unified home services and sharing marketplace.</p>
              <div className="mt-3 text-sm text-muted-foreground space-y-1">
                <div className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" /> 223-254-8299</div>
                <div>BurnsInc@Outlook.com</div>
                <div>Florida, USA</div>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3">Services</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/blue-truck" className="hover:text-foreground">Blue Truck LLC</Link></li>
                <li><Link href="/share" className="hover:text-foreground">SHARE™</Link></li>
                <li><Link href="/services" className="hover:text-foreground">All Services</Link></li>
                <li><Link href="/contractors" className="hover:text-foreground">Find Contractors</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3">Platform</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/burncall" className="hover:text-foreground">BurnCall</Link></li>
                <li><Link href="/dashboard/payments" className="hover:text-foreground">PocketCash</Link></li>
                <li><Link href="/investor" className="hover:text-foreground">Investor Portal</Link></li>
                <li><Link href="/contractors/join" className="hover:text-foreground">Join as Contractor</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/about" className="hover:text-foreground">About Us</Link></li>
                <li><Link href="/help" className="hover:text-foreground">Help Center</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/legal/privacy" className="hover:text-foreground">Privacy Policy</Link></li>
                <li><Link href="/legal/terms" className="hover:text-foreground">Terms of Service</Link></li>
                <li><Link href="/legal/refund" className="hover:text-foreground">Refund Policy</Link></li>
                <li><Link href="/legal/contractor-agreement" className="hover:text-foreground">Contractor Agreement</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>© 2026 BuyShare.co — Blue Truck LLC. All rights reserved.</p>
            <p>Florida, USA · 223-254-8299</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
