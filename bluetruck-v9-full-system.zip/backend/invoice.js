function generateInvoice(customer){
return `Invoice for ${customer}`;
}
module.exports = generateInvoice;
