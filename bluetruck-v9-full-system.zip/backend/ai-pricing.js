function dynamicPrice(base, demand){
return base + (demand * 5);
}
module.exports = dynamicPrice;
