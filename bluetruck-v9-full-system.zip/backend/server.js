const express = require('express');
const app = express();
app.use(express.json());

// Booking
app.post('/book', (req,res)=>{
console.log(req.body);
res.send({status:"booked"});
});

// SMS (Twilio placeholder)
app.post('/sms', (req,res)=>{
console.log("SMS sent");
res.send({status:"sent"});
});

// Analytics
app.get('/analytics', (req,res)=>{
res.send({revenue:0, customers:0});
});

app.listen(3000, ()=>console.log("Running"));
