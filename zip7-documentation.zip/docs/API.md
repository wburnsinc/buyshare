# API Documentation

Base URL: `https://your-domain.replit.app` (or `http://localhost:8080` in development)

All authenticated endpoints require: `Authorization: Bearer <jwt_token>`

---

## Authentication

### POST /api/auth/register
Register a new user.
```json
Body: { "email": "...", "password": "...", "full_name": "..." }
Response: { "token": "...", "user": { "id", "email", "full_name", "is_admin" } }
```

### POST /api/auth/login
```json
Body: { "email": "...", "password": "..." }
Response: { "token": "...", "user": { ... } }
```

### GET /api/auth/me — 🔒 Auth required
Returns the current authenticated user.

### PATCH /api/auth/me — 🔒 Auth required
Update profile fields (full_name, phone, bio, avatar_url, etc.)

---

## BlueCertified (SWFL Contractor Network)

### GET /api/bluecertified/contractors
Query: `?category=&city=&zip=&q=&limit=&offset=`

### GET /api/bluecertified/contractors/me — 🔒
### GET /api/bluecertified/contractors/:id
### POST /api/bluecertified/contractors — 🔒
### PATCH /api/bluecertified/contractors/:id — 🔒 Owner only
### POST /api/bluecertified/contractors/:id/reviews — 🔒
### GET /api/bluecertified/jobs
### POST /api/bluecertified/jobs — 🔒
### PATCH /api/bluecertified/jobs/:id — 🔒 Owner
### DELETE /api/bluecertified/jobs/:id — 🔒 Owner
### POST /api/bluecertified/ai-match — 🔒
```json
Body: { "description": "I need a licensed roofer in Cape Coral..." }
Response: [{ "id", "name", "match_score", "reasoning" }]
```

---

## PropConnect (Real Estate & Lending Network)

### GET /api/propconnect/profiles
Query: `?role=&region=&city=&q=&limit=&offset=`

### GET /api/propconnect/profiles/me — 🔒
### GET /api/propconnect/profiles/:id
### POST /api/propconnect/profiles — 🔒
```json
Body: { "full_name", "role", "phone", "company", "license_number", "nmls_number",
        "email", "website", "bio", "years_experience", "photo_url",
        "business_card_url", "region", "city", "state", "zip", "address", "specialties" }
```
### PATCH /api/propconnect/profiles/:id — 🔒 Owner
### POST /api/propconnect/profiles/:id/reviews — 🔒
```json
Body: { "rating": 5, "comment": "...", "transaction_type": "Buyer" }
```

### GET /api/propconnect/pins
### POST /api/propconnect/pins — 🔒 (geocodes address via Google)
```json
Body: { "address": "123 Main St, Port Charlotte, FL", "label": "Main Office" }
```
### DELETE /api/propconnect/pins — 🔒

### GET /api/propconnect/listings
Query: `?listing_type=&region=&city=&min_price=&max_price=`

### GET /api/propconnect/listings/:id
### POST /api/propconnect/listings — 🔒 (requires profile)
### PATCH /api/propconnect/listings/:id — 🔒 Owner
### DELETE /api/propconnect/listings/:id — 🔒 Owner

### GET /api/propconnect/forum
Query: `?category=&region=&limit=&offset=`

### GET /api/propconnect/forum/:id (with comments)
### POST /api/propconnect/forum — 🔒
### POST /api/propconnect/forum/:id/vote — 🔒
### POST /api/propconnect/forum/:id/comments — 🔒

---

## Podcast Network

### GET /api/podcast/channels
Query: `?q=&category=&limit=&offset=`

### GET /api/podcast/channels/me — 🔒
### GET /api/podcast/channels/:id (with episodes)
### POST /api/podcast/channels — 🔒
```json
Body: { "name", "tagline", "description", "category", "photo_url", "banner_url",
        "youtube_url", "facebook_url", "tiktok_url", "instagram_url", "website_url", "email" }
```
### PATCH /api/podcast/channels/:id — 🔒 Owner

### GET /api/podcast/episodes
Query: `?video_type=&q=&limit=&offset=`

### GET /api/podcast/episodes/:id (increments view count, returns comments)
### POST /api/podcast/episodes — 🔒 (requires channel)
```json
Body: { "title", "description", "video_type", "youtube_url", "facebook_url",
        "tiktok_url", "video_url", "thumbnail_url", "tags", "duration_mins",
        "episode_number", "season_number" }
```
### DELETE /api/podcast/episodes/:id — 🔒 Owner
### POST /api/podcast/episodes/:id/like — 🔒 (toggle)
### POST /api/podcast/episodes/:id/comments — 🔒

---

## Admin Endpoints (🔒 Admin only)

### GET /api/admin/stats
### GET /api/admin/stats/extended
### GET /api/admin/dashboard-health
### GET /api/admin/users
### PATCH /api/admin/users/:id (ban, promote, update)
### DELETE /api/admin/users/:id
### GET /api/admin/listings
### GET /api/admin/contractors
### DELETE /api/admin/contractors/:id
### PATCH /api/admin/bluecertified/profiles/:id/status
### GET /api/admin/propconnect/profiles
### DELETE /api/admin/propconnect/profiles/:id
### GET /api/admin/propconnect/listings
### DELETE /api/admin/propconnect/listings/:id
### GET /api/admin/propconnect/forum
### DELETE /api/admin/propconnect/forum/:id
### GET /api/admin/podcast/channels
### DELETE /api/admin/podcast/channels/:id
### PATCH /api/admin/podcast/channels/:id/status
### GET /api/admin/podcast/episodes
### DELETE /api/admin/podcast/episodes/:id
