# Changelog

All notable changes to Buyshare.co are documented here.

---

## v3.0.0 — June 2026

### Added
- **Podcast Network** (`/podcast`) — Community video and podcast hub
  - Channels with YouTube, Facebook, TikTok, and direct video URL support
  - Episode posting with auto-thumbnail for YouTube, embedded player
  - Browse episodes by platform filter, search by title/tags
  - Like and comment system on episodes
  - Admin: `/admin/podcast` — manage channels and episodes

- **PropConnect** (`/propconnect`) — Real Estate & Lending Professional Network
  - Profiles for Realtors, Loan Officers, Mortgage Lenders, Investors, and more
  - SWFL and Central Pennsylvania (Harrisburg/York) service regions
  - Home listings with photo gallery (SFH, Condo, Fix & Flip, Multi-Family, Land)
  - Reddit-style community forum (Fix & Flip, Market Updates, Testimonials, etc.)
  - Interactive Leaflet office map — one pin per professional, geocoded via Google
  - Business card image display, client reviews 1–5 stars
  - Admin: `/admin/propconnect` — manage profiles, listings, forum posts

- **BlueCertified** (`/bluecertified`) — SWFL Contractor Network Exchange
  - Contractor profiles with 29 service categories
  - AI-powered matching (OpenAI GPT-4o-mini)
  - Who's Hiring subcontract job board
  - Client reviews and ratings
  - Admin: `/admin/bluecertified` — manage contractors and job postings

- **Admin Portal Extensions** section in sidebar
  - BlueCertified, PropConnect, and Podcast Network now have dedicated admin pages

### Changed
- Tools dropdown in navigation updated with BlueCertified, PropConnect, and Podcast links
- AdminLayout nav reorganized with new "Extensions" section

---

## v2.x — Earlier 2026

- BurnCall AI module — business call automation
- EarnTree — community earning and referral network
- PocketCash — P2P micro-lending
- PLAYDATE — family meetup coordination
- Stripe subscription billing
- Dark mode
- THRIFTgirl marketplace
- Investor community portal
- Layton's Home Services booking
- Business directory with map
- Vetted Pros certification program

---

## v1.0.0 — 2025

- Initial Buyshare.co P2P marketplace launch
- User authentication
- Buy/sell listings
- Home-sharing and bookings
- Basic admin portal
