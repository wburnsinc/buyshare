# Module Documentation

---

## BuyShare (Core Marketplace)

**Purpose:** Peer-to-peer buy/sell listings and home-sharing platform.

**Routes:** `/` (home), `/listings`, `/share`

**Database tables:** `listings`, `share_listings`, `bookings`, `reviews`

**Key features:**
- Post and browse buy/sell listings
- Home-sharing with booking/reservation system
- User ratings and reviews

---

## BurnCall AI

**Purpose:** AI-powered business call automation and campaign management.

**Route:** `/burncall`

**Database tables:** `burncall_campaigns`, `burncall_logs`

**AI:** GPT-4o-mini for call script generation and analysis

**Admin:** `/admin/burncall`

---

## EarnTree

**Purpose:** Community earnings, referrals, and network rewards.

**Route:** `/earntree`

**Database tables:** `earntree_nodes`, `earntree_earnings`

**Admin:** `/admin/earntree`

---

## PocketCash

**Purpose:** P2P micro-lending between community members.

**Route:** `/pocketcash`

**Database tables:** `pocketcash_loans`, `pocketcash_repayments`

**Payments:** Stripe for loan disbursements and repayments

**Admin:** `/admin/pocketcash`

---

## PLAYDATE

**Purpose:** Family meetup and event coordination for SWFL families.

**Route:** `/playdate`

**Database tables:** `playdate_meetups`, `playdate_rsvps`, `playdate_comments`

**Features:**
- Post meetup events with location and max attendees
- RSVP system with access codes
- Leaflet map of all meetup locations
- Comment threads per event

**Admin:** `/admin/playdate-rsvps`

---

## BlueCertified

**Purpose:** SWFL contractor network — homeowners find verified contractors.

**Route:** `/bluecertified`

**Database tables:** `blc_contractor_profiles`, `blc_contractor_categories`, `blc_contractor_reviews`, `blc_job_postings`

**API routes:** `/api/bluecertified/*`

**Features:**
- 29 service categories
- AI matching (GPT-4o-mini reads all profiles, returns ranked matches)
- Who's Hiring subcontract job board
- Star ratings and reviews

**Admin:** `/admin/bluecertified`

---

## PropConnect

**Purpose:** Real estate and lending professional network for SWFL and Central PA.

**Route:** `/propconnect`

**Database tables:** `re_profiles`, `re_map_pins`, `re_listings`, `re_forum_posts`, `re_forum_comments`, `re_forum_votes`, `re_reviews`

**API routes:** `/api/propconnect/*`

**Features:**
- 8 professional role types (Realtor, Loan Officer, Lender, etc.)
- Two service regions: SWFL and Central Pennsylvania
- Property listings with photos (7 listing types)
- Reddit-style community forum (7 categories)
- Office map with Google-geocoded pins
- Business card image display
- Client reviews 1–5 stars

**Admin:** `/admin/propconnect`

---

## Podcast Network

**Purpose:** Community video and podcast channel hub.

**Route:** `/podcast`

**Database tables:** `podcast_channels`, `podcast_episodes`, `podcast_likes`, `podcast_comments`

**API routes:** `/api/podcast/*`

**Features:**
- Channel creation with profile photo, banner, social links (YouTube, Facebook, TikTok, Instagram)
- Episode posting with platform selector
- YouTube auto-embed (extracts video ID from URL)
- Facebook video embed via plugins/video.php
- TikTok embed via TikTok oEmbed
- View count tracking
- Like/unlike toggle
- Comment threads
- 14 content categories

**Admin:** `/admin/podcast`

---

## Directory

**Purpose:** Local business directory with map pins.

**Route:** `/directory`

**Database tables:** `businesses`, `map_pins`

---

## Admin Portal

**Purpose:** Full platform administration.

**Route:** `/admin` (and subroutes)

**Access:** Admin-only (guarded by `AdminGuard` component)

**Features:**
- Dashboard with stats, MRR, revenue charts
- User management (search, ban, promote)
- All payments and subscriptions
- Broadcast notifications
- Audit log
- Feature flags
- Extension module management (BlueCertified, PropConnect, Podcast)
