# Deployment Guide

## Option 1: Replit (Current hosting)

The app is already configured for Replit hosting.

1. Click **Deploy** in the Replit UI
2. The platform builds and hosts both the API server and the web frontend
3. Production URL: `https://buyshare.replit.app` (or your custom domain)

---

## Option 2: Docker (Self-hosted / VPS / Cloud)

### Dockerfile — API Server

```dockerfile
FROM node:20-alpine

WORKDIR /app

# Install pnpm
RUN npm install -g pnpm

# Copy workspace files
COPY package.json pnpm-workspace.yaml pnpm-lock.yaml ./
COPY packages/ ./packages/
COPY artifacts/api-server/ ./artifacts/api-server/

# Install dependencies
RUN pnpm install --frozen-lockfile

# Build
RUN pnpm --filter @workspace/api-server run build

EXPOSE 8080

CMD ["node", "--enable-source-maps", "./artifacts/api-server/dist/index.mjs"]
```

### Dockerfile — Web Frontend

```dockerfile
FROM node:20-alpine AS build

WORKDIR /app

RUN npm install -g pnpm

COPY package.json pnpm-workspace.yaml pnpm-lock.yaml ./
COPY packages/ ./packages/
COPY artifacts/buyshare/ ./artifacts/buyshare/

RUN pnpm install --frozen-lockfile
RUN pnpm --filter @workspace/buyshare run build

# Serve with nginx
FROM nginx:alpine
COPY --from=build /app/artifacts/buyshare/dist /usr/share/nginx/html
COPY release/deployment/nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80
```

### docker-compose.yml

```yaml
version: '3.9'

services:
  api:
    build:
      context: .
      dockerfile: release/deployment/Dockerfile.api
    ports:
      - "8080:8080"
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - JWT_SECRET=${JWT_SECRET}
      - STRIPE_SECRET_KEY=${STRIPE_SECRET_KEY}
      - STRIPE_WEBHOOK_SECRET=${STRIPE_WEBHOOK_SECRET}
      - GOOGLE_API_KEY=${GOOGLE_API_KEY}
      - AI_INTEGRATIONS_OPENAI_BASE_URL=${AI_INTEGRATIONS_OPENAI_BASE_URL}
      - AI_INTEGRATIONS_OPENAI_API_KEY=${AI_INTEGRATIONS_OPENAI_API_KEY}
      - RESEND_API_KEY=${RESEND_API_KEY}
      - PORT=8080
      - NODE_ENV=production
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  web:
    build:
      context: .
      dockerfile: release/deployment/Dockerfile.web
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      - api
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=buyshare
      - POSTGRES_USER=buyshare
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

volumes:
  postgres_data:
```

---

## Option 3: Railway / Render

1. Connect your GitHub repository
2. Create two services: **API** and **Web**
3. Set the build/start commands:
   - API: `pnpm --filter @workspace/api-server run build && pnpm --filter @workspace/api-server run start`
   - Web: `pnpm --filter @workspace/buyshare run build` (output: `artifacts/buyshare/dist`)
4. Add all environment variables from `.env.example`

---

## Option 4: DigitalOcean App Platform

1. Create a new App from GitHub
2. Add two components:
   - **API component** (Node.js): source `artifacts/api-server`
   - **Static site**: source `artifacts/buyshare`, build `pnpm run build`, output `dist`
3. Set environment variables in the App Settings panel

---

## Nginx Config (for self-hosted)

```nginx
server {
    listen 80;
    server_name buyshare.co www.buyshare.co;

    # Redirect HTTP to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name buyshare.co;

    ssl_certificate /etc/letsencrypt/live/buyshare.co/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/buyshare.co/privkey.pem;

    # API proxy
    location /api {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Stripe webhooks
    location /webhook {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
    }

    # Frontend (SPA — all routes to index.html)
    root /var/www/buyshare;
    index index.html;
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## SSL (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d buyshare.co -d www.buyshare.co
sudo systemctl enable certbot.timer
```

---

## Health Check

```
GET /health
→ 200 OK  { "status": "ok", "db": "connected" }
```
