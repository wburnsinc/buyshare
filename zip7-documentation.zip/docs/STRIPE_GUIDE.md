# Stripe Integration Guide

## Dashboard Setup

1. Create account at https://stripe.com
2. Enable **Subscription** billing in the Dashboard
3. Create your Products and Prices (see below)
4. Create a Webhook endpoint

---

## Required Stripe Configuration

### Products to Create

| Product | Description | Billing |
|---------|-------------|---------|
| Buyshare Pro | Platform subscription | Monthly / Annual |
| BurnCall Starter | AI call automation | Monthly |
| BurnCall Pro | AI call automation pro | Monthly |
| PocketCash Access | Micro-lending feature | Monthly |

### Webhook Endpoint

Create a webhook pointing to: `https://yourdomain.com/webhook`

**Events to listen for:**
- `checkout.session.completed`
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`
- `invoice.payment_succeeded`
- `invoice.payment_failed`

---

## Environment Variables

```env
STRIPE_SECRET_KEY=sk_live_...       # From Dashboard → API Keys
STRIPE_PUBLISHABLE_KEY=pk_live_...  # From Dashboard → API Keys
STRIPE_WEBHOOK_SECRET=whsec_...     # From Dashboard → Webhooks
```

---

## Code Integration Points

### Creating a Checkout Session
```typescript
// artifacts/api-server/src/routes/...
const session = await stripe.checkout.sessions.create({
  customer: user.stripe_customer_id,
  mode: 'subscription',
  line_items: [{ price: priceId, quantity: 1 }],
  success_url: `${FRONTEND_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
  cancel_url: `${FRONTEND_URL}/pricing`,
});
```

### Webhook Verification
```typescript
const event = stripe.webhooks.constructEvent(
  req.body, req.headers['stripe-signature'], STRIPE_WEBHOOK_SECRET
);
```

### Customer Portal
```typescript
const session = await stripe.billingPortal.sessions.create({
  customer: user.stripe_customer_id,
  return_url: `${FRONTEND_URL}/account`,
});
```

---

## Testing

Use Stripe test mode keys (`sk_test_...`) in development.

Test card numbers:
- Success: `4242 4242 4242 4242`
- Declined: `4000 0000 0000 0002`
- 3D Secure: `4000 0025 0000 3155`
