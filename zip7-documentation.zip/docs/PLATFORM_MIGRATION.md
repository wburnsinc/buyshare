# Platform Migration Guide

## Moving from Replit to Any Other Host

This document covers the exact code changes required when deploying outside of Replit. There are **3 things** that use Replit-internal infrastructure and must be swapped.

---

## Change 1 — Object Storage → AWS S3 (or R2)

**File:** `artifacts/api-server/src/lib/objectStorage.ts`

The existing file uses Replit's sidecar at `http://127.0.0.1:1106` and will crash on any other platform.

**Replace the entire file** with this S3-compatible version:

```typescript
// objectStorage.ts — AWS S3 / Cloudflare R2 version
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { randomUUID } from "crypto";

const s3 = new S3Client({
  region: process.env.AWS_REGION || "us-east-1",
  // For Cloudflare R2, add: endpoint: process.env.AWS_ENDPOINT_URL
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.AWS_BUCKET_NAME!;

export class ObjectStorageService {
  /** Generate a pre-signed PUT URL for direct browser upload */
  async getObjectEntityUploadURL(): Promise<string> {
    const key = `uploads/${randomUUID()}`;
    const cmd = new PutObjectCommand({ Bucket: BUCKET, Key: key });
    return getSignedUrl(s3, cmd, { expiresIn: 900 });
  }

  /** Generate a pre-signed GET URL for a private object */
  async getSignedDownloadURL(key: string, ttlSec = 3600): Promise<string> {
    const cmd = new GetObjectCommand({ Bucket: BUCKET, Key: key });
    return getSignedUrl(s3, cmd, { expiresIn: ttlSec });
  }

  /** Delete an object */
  async deleteObject(key: string): Promise<void> {
    await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
  }
}

export const objectStorageService = new ObjectStorageService();

// Keep this export for compatibility with existing imports
export const objectStorageClient = s3;
export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
  }
}
```

**Install the required packages:**
```bash
pnpm --filter @workspace/api-server add @aws-sdk/client-s3 @aws-sdk/s3-request-presigner
```

**Required environment variables:**
```env
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_BUCKET_NAME=buyshare-uploads
AWS_REGION=us-east-1
# For Cloudflare R2 only:
# AWS_ENDPOINT_URL=https://<account_id>.r2.cloudflarestorage.com
```

---

## Change 2 — OpenAI → Direct API

**Files to update:**
- `artifacts/api-server/src/routes/bluecertified.ts` (AI contractor matching)
- `artifacts/api-server/src/routes/modules/burncall.ts` (BurnCall AI)
- Any other route using `AI_INTEGRATIONS_OPENAI_BASE_URL`

**Current code (Replit proxy):**
```typescript
const openaiBase = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
const openaiKey  = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;

const aiRes = await fetch(`${openaiBase}/chat/completions`, {
  method: "POST",
  headers: { Authorization: `Bearer ${openaiKey}`, "Content-Type": "application/json" },
  body: JSON.stringify({ model: "gpt-4o-mini", messages: [...] }),
});
```

**Replace with (standard OpenAI):**
```typescript
// Option A — use the openai npm package (recommended)
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const completion = await openai.chat.completions.create({
  model: "gpt-4o-mini",
  messages: [...],
  max_tokens: 2000,
});
const text = completion.choices[0]?.message?.content ?? "";
```

**Or Option B — keep the fetch approach, just change the URL:**
```typescript
const aiRes = await fetch("https://api.openai.com/v1/chat/completions", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ model: "gpt-4o-mini", messages: [...] }),
});
```

**Install (if using the npm package):**
```bash
pnpm --filter @workspace/api-server add openai
```

**Required environment variable:**
```env
OPENAI_API_KEY=sk-...
```

**Remove these Replit-specific vars from your `.env`:**
```
# DELETE THESE — not needed outside Replit:
# AI_INTEGRATIONS_OPENAI_BASE_URL=
# AI_INTEGRATIONS_OPENAI_API_KEY=
```

---

## Change 3 — CORS Origins

**File:** `artifacts/api-server/src/app.ts`

Find the CORS configuration and add your production domain:

```typescript
// Current (may be permissive for Replit proxy)
app.use(cors());

// Replace with:
app.use(cors({
  origin: [
    "https://buyshare.co",
    "https://www.buyshare.co",
    // add staging domain if needed:
    // "https://staging.buyshare.co",
  ],
  credentials: true,
}));
```

---

## Change 4 — Remove Replit-Only lib packages (optional cleanup)

These packages in `lib/` are Replit-specific wrappers and can be removed if unused:

| Package | Status |
|---------|--------|
| `lib/integrations-openai-ai-server` | Remove — replaced by `openai` npm package |
| `lib/integrations-openai-ai-react` | Remove — frontend doesn't call AI directly |
| `lib/object-storage-web` | Remove — replaced by S3 SDK |
| `lib/api-client-react` | Keep if used by frontend |
| `lib/db` | **Keep** — this is the shared PostgreSQL pool |
| `lib/api-spec` | Keep if used |
| `lib/api-zod` | Keep if used |

To remove unused lib packages, delete their directories and remove the workspace references from `pnpm-workspace.yaml`.

---

## Managed Hosting — Quick Reference

### Railway
1. Connect GitHub repo
2. Create **two services**: API (Node) and Web (static)
3. API build: `pnpm --filter @workspace/api-server run build`
4. API start: `node --enable-source-maps artifacts/api-server/dist/index.mjs`
5. Web build: `pnpm --filter @workspace/buyshare run build`
6. Web publish dir: `artifacts/buyshare/dist`
7. Add all env vars in Railway's Variables panel
8. Railway provides PostgreSQL as an add-on — copy the `DATABASE_URL`

### Render
Same as Railway — two services (web service + static site).
Render also provides managed PostgreSQL.

### DigitalOcean App Platform
1. Create App from GitHub
2. Add API component (Node.js) + Static Site component
3. Set env vars in App Settings
4. DigitalOcean provides managed PostgreSQL via "Add-ons"

### VPS (Ubuntu/Debian)
```bash
# 1. Install Node 20 + pnpm
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install nodejs
npm install -g pnpm

# 2. Install PostgreSQL
sudo apt install postgresql
sudo -u postgres createdb buyshare

# 3. Clone + install
git clone <your-repo> /var/www/buyshare
cd /var/www/buyshare
pnpm install --frozen-lockfile

# 4. Run migrations
psql "$DATABASE_URL" < database/migrations/001_full_schema.sql

# 5. Build
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/buyshare run build

# 6. Serve API with PM2
npm install -g pm2
pm2 start "node --enable-source-maps artifacts/api-server/dist/index.mjs" \
  --name buyshare-api --env production
pm2 save
pm2 startup

# 7. Serve frontend with nginx
sudo cp -r artifacts/buyshare/dist/* /var/www/html/
sudo cp deployment/nginx.conf /etc/nginx/sites-available/buyshare
sudo ln -s /etc/nginx/sites-available/buyshare /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# 8. SSL
sudo certbot --nginx -d buyshare.co -d www.buyshare.co
```

---

## What Stays the Same (No Changes Needed)

| Item | Status |
|------|--------|
| PostgreSQL queries (`pool.query`) | ✓ Works everywhere |
| Stripe integration | ✓ Works everywhere |
| Resend email | ✓ Works everywhere |
| Google Geocoding API | ✓ Works everywhere |
| JWT authentication | ✓ Works everywhere |
| Leaflet maps | ✓ Client-side, no server change |
| All React frontend code | ✓ Works everywhere |
| pnpm monorepo structure | ✓ Works everywhere |
| Admin portal | ✓ Works everywhere |
