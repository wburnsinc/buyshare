# Architecture Overview

## System Architecture

```
Browser
  │
  ▼
Vite (React SPA) — artifacts/buyshare
  │  POST/GET/PATCH/DELETE via fetch()
  │  Bearer JWT token in Authorization header
  ▼
Express API — artifacts/api-server
  │  requireAuth middleware validates JWT
  │  Pool queries via @workspace/db (pg)
  ▼
PostgreSQL Database (Replit managed)
```

## Monorepo Structure

This is a **pnpm workspace** monorepo. Each artifact is an independent package:

```
packages/
  db/                    # Shared: exports pool (pg.Pool)

artifacts/
  api-server/            # @workspace/api-server
    src/
      index.ts           # Express app bootstrap, ensureAllTables()
      routes/
        index.ts         # Master router (mounts all sub-routers)
        auth.ts          # /api/auth/* — register, login, me, update
        admin/           # /api/admin/* — all admin endpoints
        bluecertified.ts # /api/bluecertified/*
        propconnect.ts   # /api/propconnect/*
        podcast.ts       # /api/podcast/*  (also /api/admin/podcast/*)
        modules/         # BurnCall, EarnTree, PocketCash
        ...
      middleware/
        auth.ts          # requireAuth (JWT verify)
        rateLimit.ts     # express-rate-limit

  buyshare/              # @workspace/buyshare (React + Vite)
    src/
      App.tsx            # SPA router, Navbar, AdminGuard
      pages/
        admin/           # Admin portal pages (AdminLayout wrapper)
        modules/         # BurnCall, EarnTree, PocketCash UIs
        bluecertified.tsx
        propconnect.tsx
        podcast.tsx
        ...
      components/
        admin/
          AdminLayout.tsx  # Sidebar navigation for /admin/*
        ui/              # shadcn/ui components
      context/
        AuthContext.tsx  # useAuth() hook — JWT stored in localStorage
        DarkModeContext.tsx
```

## Authentication Flow

1. User submits email + password to `POST /api/auth/login`
2. Server verifies bcrypt hash, issues JWT (signed with `JWT_SECRET`)
3. Frontend stores token as `bs_token` in `localStorage`
4. Every authenticated request sends `Authorization: Bearer <token>`
5. `requireAuth` middleware verifies the JWT and attaches `req.user`

## Database Initialization

All tables are created (idempotently) at server startup via `ensureAllTables()` in `artifacts/api-server/src/index.ts`. Each feature module also calls its own `ensure*Tables()` function on import.

## API Convention

- All routes prefixed `/api/`
- Admin routes prefixed `/api/admin/`
- Authentication via `requireAuth` middleware
- Responses: JSON `{ data }` on success, `{ error: string }` on failure

## Frontend State

- Auth state: `useAuth()` context (reads `bs_token` from localStorage)
- No global state library — component-local `useState` + `useEffect`
- API base: `import.meta.env.BASE_URL.replace(/\/$/, "")` (supports Replit path routing)

## File Upload / Media

- Images stored as URLs (users paste Imgur, Cloudinary, etc.)
- Replit Object Storage available for server-side uploads via `@replit/object-storage`

## Map Integration

- Leaflet + OpenStreetMap (dynamic import, no SSR issues)
- Google Geocoding API (`GOOGLE_API_KEY`) for address → lat/lng conversion
- CSS injected dynamically to avoid Vite bundling issues
