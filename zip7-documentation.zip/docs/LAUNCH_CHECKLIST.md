# Launch Checklist — Zero to Live

Follow these steps in order. Each item must be complete before moving to the next section.

---

## PHASE 1 — Infrastructure Setup

### 1.1 PostgreSQL Database
- [ ] Provision a PostgreSQL 14+ database (Neon, Supabase, Railway, RDS, or self-hosted)
- [ ] Copy the connection string — format: `postgresql://user:pass@host:5432/dbname`
- [ ] Set `DATABASE_URL` environment variable on your host
- [ ] Run the migration: `psql "$DATABASE_URL" < database/migrations/001_full_schema.sql`
- [ ] Run the seed: `psql "$DATABASE_URL" < database/migrations/002_seed_data.sql`
- [ ] Verify: `psql "$DATABASE_URL" -c "SELECT count(*) FROM users"` → should return `0`

### 1.2 File Storage (choose one)
> ⚠️ The included `objectStorage.ts` uses Replit's internal sidecar and WILL NOT work outside Replit.
> You MUST replace it before deploying. See `PLATFORM_MIGRATION.md` for exact code changes.

**Option A — AWS S3 (recommended)**
- [ ] Create an S3 bucket (e.g. `buyshare-uploads`)
- [ ] Create an IAM user with `s3:PutObject`, `s3:GetObject`, `s3:DeleteObject` on that bucket
- [ ] Set `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_BUCKET_NAME`, `AWS_REGION`

**Option B — Cloudflare R2 (no egress fees)**
- [ ] Create R2 bucket in Cloudflare dashboard
- [ ] Generate R2 API token
- [ ] R2 is S3-compatible — use same AWS env vars with `AWS_ENDPOINT_URL` set to your R2 endpoint

**Option C — Cloudinary (simplest)**
- [ ] Create free Cloudinary account
- [ ] Set `CLOUDINARY_URL=cloudinary://api_key:api_secret@cloud_name`

### 1.3 Stripe
- [ ] Create Stripe account at https://stripe.com
- [ ] Get Live API keys from Dashboard → Developers → API Keys
- [ ] Set `STRIPE_SECRET_KEY=sk_live_...`
- [ ] Set `STRIPE_PUBLISHABLE_KEY=pk_live_...`
- [ ] Create Webhook endpoint in Dashboard → Developers → Webhooks
  - URL: `https://yourdomain.com/webhook`
  - Events: `checkout.session.completed`, `customer.subscription.created`,
    `customer.subscription.updated`, `customer.subscription.deleted`,
    `invoice.payment_succeeded`, `invoice.payment_failed`
- [ ] Set `STRIPE_WEBHOOK_SECRET=whsec_...`
- [ ] **Stripe prices are auto-created** on first checkout — no manual product setup needed

### 1.4 Email (Resend)
- [ ] Create account at https://resend.com
- [ ] Verify your sending domain (buyshare.co) in Resend dashboard
- [ ] Create API key → set `RESEND_API_KEY=re_...`
- [ ] Set `FROM_EMAIL=noreply@buyshare.co`

### 1.5 OpenAI (for BlueCertified AI matching & BurnCall)
> ⚠️ See `PLATFORM_MIGRATION.md` — the OpenAI client must be updated for non-Replit.

- [ ] Create account at https://platform.openai.com
- [ ] Generate API key → set `OPENAI_API_KEY=sk-...`
- [ ] After migration, remove `AI_INTEGRATIONS_OPENAI_BASE_URL` and `AI_INTEGRATIONS_OPENAI_API_KEY`

### 1.6 Google Geocoding (for maps)
- [ ] Go to https://console.cloud.google.com
- [ ] Enable: **Geocoding API** and **Places API**
- [ ] Create API key → restrict to your server IP or domain
- [ ] Set `GOOGLE_API_KEY=AIza...`

### 1.7 JWT Secret
- [ ] Generate a strong random secret: `openssl rand -hex 64`
- [ ] Set `JWT_SECRET=<the output>`
- [ ] Set `JWT_EXPIRES_IN=7d`

### 1.8 Admin Password
- [ ] Choose a strong admin password
- [ ] Set `MASTER_ADMIN_PASSWORD=<your password>`
- [ ] This password will be set for both `burnsinc@outlook.com` and `admin@buyshare.co` on startup

---

## PHASE 2 — Build & Deploy

### 2.1 Install Dependencies
```bash
pnpm install --frozen-lockfile
```

### 2.2 Apply the Platform Migration
> ⚠️ Do this BEFORE building. See `PLATFORM_MIGRATION.md` for exact file changes.
- [ ] Replace `src/lib/objectStorage.ts` with the S3 version
- [ ] Update OpenAI client in `src/routes/bluecertified.ts` and any BurnCall routes

### 2.3 Build API Server
```bash
pnpm --filter @workspace/api-server run build
# Output: artifacts/api-server/dist/index.mjs
```

### 2.4 Build Frontend
```bash
pnpm --filter @workspace/buyshare run build
# Output: artifacts/buyshare/dist/
```

### 2.5 Option A — Docker Deploy
```bash
# Build and start all services
docker-compose up --build -d

# Check logs
docker-compose logs -f api
```

### 2.5 Option B — Manual Deploy
```bash
# Start API (background)
NODE_ENV=production PORT=8080 node --enable-source-maps \
  artifacts/api-server/dist/index.mjs &

# Serve frontend with nginx (copy dist/ to nginx html dir)
# See deployment/nginx.conf
```

### 2.6 Verify Health Check
```bash
curl https://yourdomain.com/api/health
# Expected: { "status": "ok", "db": "connected" }
```

---

## PHASE 3 — First-Run Verification

### 3.1 Admin Account
- [ ] Visit `https://yourdomain.com/auth`
- [ ] Sign in with `burnsinc@outlook.com` + your `MASTER_ADMIN_PASSWORD`
- [ ] Confirm redirect to dashboard
- [ ] Visit `https://yourdomain.com/admin` — confirm admin portal loads
- [ ] Check sidebar has: Overview, Business Tools, Marketplace, Community, Extensions, Platform

### 3.2 Feature Flags (all off by default)
- [ ] Go to `/admin/feature-flags`
- [ ] Enable **BurnCall**, **EarnTree**, **PocketCash** if you want them live
- [ ] Leave disabled if you want to launch with core marketplace only

### 3.3 Core Flow Tests
- [ ] Register a new user account
- [ ] Post a listing
- [ ] Browse listings
- [ ] Test map at `/map` — pins should appear
- [ ] Test `/bluecertified` — AI match requires at least one contractor profile
- [ ] Test `/propconnect` — create a profile, confirm map pin geocodes
- [ ] Test `/podcast` — create a channel, post a YouTube episode

### 3.4 Stripe Test
- [ ] Go to `/pricing` or `/invest`
- [ ] Click a paid tier → confirm Stripe checkout loads
- [ ] Use test card `4242 4242 4242 4242` (exp 12/34, CVC 123)
- [ ] Confirm subscription shows in `/admin/subscriptions`

### 3.5 Email Test
- [ ] Trigger a booking or registration that sends an email
- [ ] Confirm email arrives from `noreply@buyshare.co`

---

## PHASE 4 — DNS & SSL

### 4.1 DNS
- [ ] Point `buyshare.co` A record to your server IP
- [ ] Point `www.buyshare.co` A record or CNAME to same
- [ ] Wait for propagation (up to 48h, usually <1h)

### 4.2 SSL (Let's Encrypt — if self-hosting)
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d buyshare.co -d www.buyshare.co
# Auto-renews via systemd timer
```

### 4.3 If using managed hosting (Railway, Render, DigitalOcean App Platform)
- [ ] SSL is handled automatically ✓
- [ ] Set custom domain in the hosting dashboard

---

## PHASE 5 — Go Live Checklist

- [ ] `NODE_ENV=production` is set
- [ ] No `.env` file committed to git
- [ ] Stripe is in **Live mode** (not Test mode)
- [ ] Resend domain is verified
- [ ] Google API key is restricted to your production domain/IP
- [ ] `MASTER_ADMIN_PASSWORD` is a strong unique password (not the default)
- [ ] Database backups are scheduled (see `backups/BACKUP_GUIDE.md`)
- [ ] Health check endpoint returns 200: `GET /api/health`
- [ ] Run `pnpm audit` — resolve any critical vulnerabilities

---

## Emergency Contacts / Access

| Resource | Where |
|----------|-------|
| Admin portal | `https://yourdomain.com/admin` |
| API health | `https://yourdomain.com/api/health` |
| Admin bootstrap reset | `GET /api/auth/admin-bootstrap?token=buyshare-admin-2026` |
| Stripe dashboard | https://dashboard.stripe.com |
| Resend dashboard | https://resend.com/emails |
| Google Cloud Console | https://console.cloud.google.com |
