# Buyshare.co Launch Checklist

## 1. Infrastructure
- [ ] PostgreSQL 15+ database provisioned
- [ ] DATABASE_URL set and tested
- [ ] Run schema.sql against empty DB: `psql $DATABASE_URL < database/schema.sql`
- [ ] Verify all tables created: `psql $DATABASE_URL -c "\dt"`

## 2. Environment Secrets
- [ ] JWT_SECRET generated (64+ random chars)
- [ ] STRIPE_SECRET_KEY from Stripe Dashboard
- [ ] STRIPE_WEBHOOK_SECRET from Stripe Webhooks page
- [ ] GOOGLE_API_KEY with Geocoding API enabled
- [ ] OPENAI_API_KEY from platform.openai.com
- [ ] RESEND_API_KEY from resend.com

## 3. Stripe Setup
- [ ] Create Stripe account at stripe.com
- [ ] Create products and prices in Stripe Dashboard
- [ ] Set up webhook endpoint: https://your-domain.com/webhook/stripe
- [ ] Subscribe to events: payment_intent.*, customer.subscription.*
- [ ] Copy STRIPE_WEBHOOK_SECRET

## 4. Email Setup (Resend)
- [ ] Create account at resend.com
- [ ] Verify sending domain (buyshare.co)
- [ ] Add RESEND_API_KEY to environment
- [ ] Test: POST /api/auth/register with new account and confirm email flow

## 5. Domain & SSL
- [ ] Point buyshare.co DNS A record to server IP
- [ ] Install Let's Encrypt: certbot --nginx -d buyshare.co -d www.buyshare.co
- [ ] Verify HTTPS works: https://buyshare.co

## 6. Build & Deploy
- [ ] Install dependencies: pnpm install
- [ ] Build API: pnpm --filter @workspace/api-server run build
- [ ] Build Web: pnpm --filter @workspace/buyshare run build
- [ ] Start API: node artifacts/api-server/dist/index.mjs
- [ ] Serve Web: nginx or serve artifacts/buyshare/dist

## 7. Admin Setup
- [ ] Register account with burnsinc@outlook.com or admin@buyshare.co
- [ ] Navigate to /admin — confirm admin access works
- [ ] Set up Feature Flags in /admin/feature-flags
- [ ] Seed initial data if needed

## 8. BurnCall AI Setup
- [ ] Confirm OpenAI API key works (/api/burncall/ai/qualify-lead)
- [ ] Confirm Resend email works (auto-respond test)
- [ ] Set pricing in Stripe: $50/$100/$150 Starter/Growth/Pro

## 9. Final Checks
- [ ] Health endpoint: GET /health → {"status":"ok","db":"connected"}
- [ ] Auth flow: register, login, get /api/auth/me
- [ ] BurnCall public booking page: /bc/:key/book
- [ ] Map loads (Google API key working)
- [ ] Stripe checkout works end-to-end
- [ ] Mobile app (Expo) connects to production API URL
