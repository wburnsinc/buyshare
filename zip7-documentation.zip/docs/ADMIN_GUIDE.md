# Admin Portal Guide

## Access

Navigate to `/admin` after signing in with an admin account.

**Admin emails (auto-promoted on startup):**
- `burnsinc@outlook.com`
- `admin@buyshare.co`

---

## Admin Sections

### Overview
| Page | URL | Purpose |
|------|-----|---------|
| Dashboard | `/admin` | Platform stats, revenue, user growth charts |
| All Payments | `/admin/payments` | Every Stripe payment in the system |
| Subscriptions | `/admin/subscriptions` | Active/cancelled subscriptions |
| Users | `/admin/users` | Search, ban, promote users |

### Business Tools
| Page | URL | Purpose |
|------|-----|---------|
| BurnCall AI | `/admin/burncall` | BurnCall usage and campaign management |
| EarnTree | `/admin/earntree` | EarnTree network and earnings |
| PocketCash | `/admin/pocketcash` | P2P micro-lending transactions |
| Feature Flags | `/admin/feature-flags` | Enable/disable platform features |

### Marketplace
| Page | URL | Purpose |
|------|-----|---------|
| Listings | `/admin/listings` | All buy/sell listings; approve/delete |
| Share Listings | `/admin/share-listings` | Home-share listings |
| Bookings | `/admin/bookings` | All booking reservations |
| THRIFTgirl | `/admin/thrift` | Thrift marketplace items |

### Community
| Page | URL | Purpose |
|------|-----|---------|
| Supported Businesses | `/admin/supported-businesses` | Featured business sponsors |
| Business Directory | `/admin/businesses` | Local business directory |
| Pro Requests | `/admin/pro-requests` | Applications to become a vetted pro |
| Vetted Pros | `/admin/vetted-pros` | Approved professional profiles |
| Contractors | `/admin/contractors` | Contractor profiles |
| Investors | `/admin/investors` | Investment community members |
| PLAYDATE RSVPs | `/admin/playdate-rsvps` | Family meetup RSVPs |

### Extensions
| Page | URL | Purpose |
|------|-----|---------|
| BlueCertified | `/admin/bluecertified` | Contractor profiles, job postings — approve/suspend/delete |
| PropConnect | `/admin/propconnect` | RE profiles, listings, forum posts — manage/delete |
| Podcast Network | `/admin/podcast` | Channels and episodes — suspend/delete |

### Platform
| Page | URL | Purpose |
|------|-----|---------|
| Services & Pricing | `/admin/services` | Service tiers and pricing |
| Partner Checkouts | `/admin/partner-checkouts` | White-label checkout sessions |
| Reviews | `/admin/reviews` | All platform reviews |
| Broadcast | `/admin/notifications` | Send push notifications to all users |
| Map Pins | `/admin/map-pins` | User-placed map pins |
| Layton's Bookings | `/admin/laytons` | Layton's service bookings |
| Platform Settings | `/admin/platform-settings` | Global configuration |
| Audit Log | `/admin/audit-log` | All admin actions logged |

---

## Common Admin Tasks

### Ban a user
1. Go to **Users** → search for the user
2. Click **Ban** — user is immediately locked out
3. Action is logged in the Audit Log

### Suspend a BlueCertified contractor
1. Go to **Extensions → BlueCertified**
2. Find the profile
3. Change status dropdown to **suspended**

### Delete a PropConnect listing
1. Go to **Extensions → PropConnect → Listings tab**
2. Find the listing
3. Click the 🗑️ icon (confirms before deleting)

### Suspend a Podcast channel
1. Go to **Extensions → Podcast Network**
2. Find the channel
3. Change status to **suspended** — all episodes hidden

### Send a broadcast notification
1. Go to **Platform → Broadcast**
2. Compose message with title, body, optional CTA URL
3. Click **Send to All Users**

---

## Audit Log

Every admin action (create/update/delete/ban) is recorded in the audit log with:
- Admin email who performed the action
- Action type
- Target entity
- Timestamp

Access at `/admin/audit-log`
