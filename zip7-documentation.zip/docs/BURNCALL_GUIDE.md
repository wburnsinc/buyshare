# BurnCall AI — Technical Reference

## Overview
BurnCall AI is a full-stack automated lead management system for home service contractors.
Contractors sign up, configure their business profile, and share a booking link with customers.

## Pricing (current)
| Plan | Price | Leads/mo | Key Features |
|------|-------|----------|-------------|
| Starter | $50/mo | 100 | AI response, 0-100 scoring, email notifications |
| Growth | $100/mo | 500 | SMS + email, missed-call text back, calendar booking |
| Pro | $150/mo | 2,000 | Multiple locations, CRM integrations, API access |

## How It Works (Automated Flow)

1. **Lead captured** — via: a) dashboard manual entry, b) webhook POST from website form, c) public booking page /bc/:key/book
2. **AI qualifies** — GPT scores lead 0-100 (Hot/Warm/Cold), detects spam + emergencies, generates draft response
3. **Auto-respond** — if enabled in Setup, AI emails the customer within 60s with personalized reply + booking link
4. **Appointment created** — if customer selects a date on the booking page, appointment is auto-created in calendar
5. **Contractor alerted** — contractor gets email with full lead details, AI score, and recommended next step

## Database Tables
- `bc_contacts` — all leads/contacts (with ai_qualification JSONB)
- `bc_appointments` — scheduled appointments
- `bc_business_profile` — contractor's business setup
- `bc_services` — services offered (used by AI for context)
- `bc_faqs` — knowledge base FAQs (used by AI)
- `bc_automations` — automation rules (with run counts)
- `bc_lead_webhooks` — shareable webhook keys
- `bc_campaigns` — email/SMS campaigns
- `bc_revenue_entries` — closed jobs and revenue

## Key API Endpoints

### Public (no auth)
- `GET  /api/burncall/public/:webhookKey` — business info + services
- `POST /api/burncall/public/:webhookKey/book` — customer submits booking

### Authenticated
- `GET  /api/burncall/contacts` — all contacts
- `POST /api/burncall/contacts` — create + auto-qualify contact
- `POST /api/burncall/contacts/:id/qualify` — re-run AI qualification
- `GET  /api/burncall/appointments` — calendar appointments
- `POST /api/burncall/appointments` — create appointment
- `GET  /api/burncall/setup` — business profile
- `POST /api/burncall/setup` — save business profile (seeds 5 automations on first save)
- `GET  /api/burncall/services` — knowledge base services
- `GET  /api/burncall/faqs` — knowledge base FAQs
- `GET  /api/burncall/automations` — automation list
- `GET  /api/burncall/stats` — dashboard stats
- `POST /api/burncall/ai/chat` — AI assistant (streaming SSE)
- `POST /api/burncall/ai/qualify-lead` — qualify a lead description

## Lead Capture Webhook
Contractors embed a form on their website and POST to:
```
POST /api/burncall/capture/:webhookKey
Body: { name, email, phone, company, service_type, message }
```

## AI Scoring
- Uses GPT model with business context injected into system prompt
- Returns JSON: { score: 0-100, tier: hot|warm|cold, isSpam: bool, isEmergency: bool, draftResponse: string }
- Emergency triggers 🚨 badge + "Call immediately" alert
- Spam triggers 🛡️ badge and skips auto-respond

## Frontend Routes
- `/burncall` — main dashboard (requires login)
- `/bc/:webhookKey/book` — public customer booking page (no login)
