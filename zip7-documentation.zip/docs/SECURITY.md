# Security Guide

## Authentication

- Passwords hashed with **bcrypt** (cost factor 10)
- JWT tokens signed with `JWT_SECRET` (HS256)
- Tokens stored in `localStorage` (`bs_token`)
- No refresh tokens — tokens expire per `JWT_EXPIRES_IN`
- Admin access verified on every request via `req.user.is_admin`

## Authorization

- All mutating endpoints require authentication (`requireAuth` middleware)
- Owner checks: `WHERE id=$1 AND user_id=$2` before updates/deletes
- Admin endpoints: `if (!req.user?.is_admin) return 403`
- No role-based access control library — explicit checks in each route

## SQL Injection Prevention

- All queries use **parameterized queries** (`pool.query("SELECT ... WHERE id=$1", [id])`)
- No string interpolation in SQL
- Input passed directly to `$N` placeholders

## XSS Protection

- React escapes all rendered content by default
- No `dangerouslySetInnerHTML` in production code
- User-supplied URLs rendered as `href` attributes — not executed

## CSRF

- API is stateless (JWT Bearer tokens)
- No cookies used for auth — CSRF not applicable
- CORS configured to allow Replit proxy origins

## Rate Limiting

- `express-rate-limit` applied to auth endpoints
- `POST /api/auth/login`: 10 requests / 15 minutes per IP
- `POST /api/auth/register`: 5 requests / 15 minutes per IP

## Environment Variables

- Secrets stored in Replit Secrets (environment variables)
- `.env.example` provided — never commit real `.env`
- No hardcoded API keys in source code

## Security Checklist for Deployment

- [ ] Change `JWT_SECRET` to a strong random value (32+ chars)
- [ ] Enable HTTPS (TLS) via Let's Encrypt or cloud provider
- [ ] Set `STRIPE_WEBHOOK_SECRET` and verify webhook signatures
- [ ] Restrict `DATABASE_URL` to localhost or VPC only
- [ ] Review CORS origins for production domain
- [ ] Enable PostgreSQL connection SSL (`?sslmode=require`)
- [ ] Set `NODE_ENV=production` (disables stack traces in errors)
- [ ] Run `pnpm audit` to check for vulnerable dependencies
- [ ] Configure firewall to block direct access to port 8080 (proxy via Nginx)

## Known Limitations

- No email verification on registration
- No two-factor authentication
- No session invalidation (JWT-only, no blocklist)
- Image URLs not validated (users paste external URLs)
