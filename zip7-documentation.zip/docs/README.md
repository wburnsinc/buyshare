# Buyshare.co — Platform README

**Version:** 3.0.0
**Release Date:** June 2026
**Platform:** Buyshare.co — Southwest Florida & Central Pennsylvania Community Platform

---

## Overview

Buyshare.co is a full-stack peer-to-peer community and services marketplace built for Southwest Florida (SWFL) and Central Pennsylvania. It includes tools for sharing, lending, real estate networking, podcast broadcasting, and community coordination.

## Platform Modules

| Module | Route | Purpose |
|--------|-------|---------|
| Marketplace | `/` | P2P buy/sell listings and home-sharing |
| BurnCall | `/burncall` | AI-powered business call automation |
| EarnTree | `/earntree` | Community earnings and referral network |
| PocketCash | `/pocketcash` | P2P micro-lending between members |
| PLAYDATE | `/playdate` | Family meetup and event coordination |
| BlueCertified | `/bluecertified` | SWFL contractor network exchange |
| PropConnect | `/propconnect` | Realtor, Loan Officer & Lender network |
| Podcast Network | `/podcast` | Community video & podcast channel hub |
| Directory | `/directory` | Local business directory with map |
| QuickEarn | `/quick-earn` | Fast earning opportunities |
| THRIFTgirl | `/thrift` | Thrift and resale marketplace |
| Admin Portal | `/admin` | Full platform administration |

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, TypeScript, Tailwind CSS, Framer Motion |
| Backend | Node.js, Express, TypeScript |
| Database | PostgreSQL (Replit managed) |
| Auth | JWT (custom) + bcrypt |
| Payments | Stripe (subscriptions + one-time) |
| Email | Resend |
| AI | OpenAI GPT-4o-mini via Replit AI Integrations |
| Maps | Leaflet + OpenStreetMap + Google Geocoding API |
| Storage | Replit Object Storage |
| Package Manager | pnpm (monorepo workspace) |

## Repository Structure

```
/
├── artifacts/
│   ├── api-server/          # Express backend
│   │   └── src/
│   │       ├── routes/      # All API route handlers
│   │       ├── middleware/  # Auth, rate limiting
│   │       └── index.ts     # App bootstrap + DB init
│   └── buyshare/            # React frontend
│       └── src/
│           ├── pages/       # All page components
│           ├── components/  # Shared UI components
│           ├── context/     # Auth, DarkMode context
│           └── App.tsx      # Routes + Navbar
├── packages/
│   └── db/                  # Shared DB pool (pg)
├── release/                 # This handoff package
└── package.json             # pnpm workspace root
```

## Quick Start (Development)

```bash
# Install dependencies
pnpm install

# Start API server (port from $PORT env var, defaults 8080)
pnpm --filter @workspace/api-server run dev

# Start web frontend (Vite dev server)
pnpm --filter @workspace/buyshare run dev
```

## Admin Access

Admin emails: `burnsinc@outlook.com`, `admin@buyshare.co`

Navigate to `/admin` after signing in with an admin account.
