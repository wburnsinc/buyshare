-- ============================================================
  -- BUYSHARE.CO — COMPLETE DATABASE SCHEMA
  -- Generated: 2026-06-27T09:17:44.563Z
  -- Platform: PostgreSQL 15+
  -- ============================================================
  -- Run this against a fresh PostgreSQL database to initialize
  -- the full Buyshare.co schema for all modules.
  -- ============================================================

  -- Extensions
  CREATE EXTENSION IF NOT EXISTS "pgcrypto";

  -- ─── ENUMS ────────────────────────────────────────────────────────────────────

  DO $$ BEGIN
    CREATE TYPE listing_status AS ENUM ('active','inactive','pending','rented');
  EXCEPTION WHEN duplicate_object THEN NULL; END $$;

  DO $$ BEGIN
    CREATE TYPE listing_category AS ENUM (
      'pool','boat','kayak','vehicle','equipment','storage',
      'yard','room','garage','tools','sports','other'
    );
  EXCEPTION WHEN duplicate_object THEN NULL; END $$;

  DO $$ BEGIN
    CREATE TYPE booking_status AS ENUM (
      'pending','approved','active','completed','cancelled','disputed'
    );
  EXCEPTION WHEN duplicate_object THEN NULL; END $$;

  -- ─── CORE USERS ───────────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS users (
    id                TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    email             TEXT NOT NULL UNIQUE,
    password_hash     TEXT NOT NULL,
    full_name         TEXT NOT NULL,
    phone             TEXT,
    bio               TEXT,
    avatar_url        TEXT,
    is_admin          BOOLEAN NOT NULL DEFAULT FALSE,
    is_verified       BOOLEAN NOT NULL DEFAULT FALSE,
    stripe_customer_id TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS users_email_idx ON users (email);

  -- ─── PLATFORM SETTINGS ────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS feature_flags (
    key         TEXT PRIMARY KEY,
    enabled     BOOLEAN NOT NULL DEFAULT TRUE,
    label       TEXT,
    description TEXT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS platform_settings (
    key        TEXT PRIMARY KEY,
    value      TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id           TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    admin_email  TEXT NOT NULL,
    action       TEXT NOT NULL,
    target_type  TEXT,
    target_id    TEXT,
    details      TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── MARKETPLACE LISTINGS ─────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS listings (
    id                    TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    owner_id              TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title                 TEXT NOT NULL,
    description           TEXT NOT NULL,
    category              listing_category NOT NULL,
    daily_rate            INTEGER NOT NULL,
    weekend_rate          INTEGER,
    weekly_rate           INTEGER,
    security_deposit      INTEGER NOT NULL DEFAULT 0,
    status                listing_status NOT NULL DEFAULT 'active',
    photos                TEXT[] NOT NULL DEFAULT '{}',
    location              TEXT NOT NULL,
    latitude              REAL,
    longitude             REAL,
    delivery_available    BOOLEAN NOT NULL DEFAULT FALSE,
    delivery_fee          INTEGER,
    delivery_radius_miles INTEGER,
    requires_verified     BOOLEAN NOT NULL DEFAULT FALSE,
    view_count            INTEGER NOT NULL DEFAULT 0,
    pinned                BOOLEAN NOT NULL DEFAULT FALSE,
    featured              BOOLEAN NOT NULL DEFAULT FALSE,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS listings_owner_idx ON listings (owner_id);
  CREATE INDEX IF NOT EXISTS listings_status_idx ON listings (status);
  CREATE INDEX IF NOT EXISTS listings_category_idx ON listings (category);

  -- ─── BOOKINGS ─────────────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS bookings (
    id                       TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    renter_id                TEXT NOT NULL REFERENCES users(id),
    listing_id               TEXT NOT NULL REFERENCES listings(id),
    owner_id                 TEXT NOT NULL REFERENCES users(id),
    status                   booking_status NOT NULL DEFAULT 'pending',
    start_date               TIMESTAMPTZ NOT NULL,
    end_date                 TIMESTAMPTZ NOT NULL,
    total_days               INTEGER NOT NULL,
    rental_amount_cents      INTEGER NOT NULL,
    security_deposit_cents   INTEGER NOT NULL DEFAULT 0,
    platform_fee_cents       INTEGER NOT NULL DEFAULT 0,
    stripe_fees_cents        INTEGER NOT NULL DEFAULT 0,
    protection_fee_cents     INTEGER NOT NULL DEFAULT 0,
    total_charge_cents       INTEGER NOT NULL,
    owner_payout_cents       INTEGER NOT NULL,
    added_protection         BOOLEAN NOT NULL DEFAULT FALSE,
    delivery_requested       BOOLEAN NOT NULL DEFAULT FALSE,
    delivery_fee_cents       INTEGER NOT NULL DEFAULT 0,
    stripe_payment_intent_id TEXT,
    stripe_transfer_id       TEXT,
    deposit_refund_id        TEXT,
    deposit_released         BOOLEAN NOT NULL DEFAULT FALSE,
    check_in_photos          TEXT[] NOT NULL DEFAULT '{}',
    check_in_timestamp       TIMESTAMPTZ,
    check_out_photos         TEXT[] NOT NULL DEFAULT '{}',
    check_out_timestamp      TIMESTAMPTZ,
    renter_notes             TEXT,
    owner_notes              TEXT,
    dispute_reason           TEXT,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS bookings_renter_idx ON bookings (renter_id);
  CREATE INDEX IF NOT EXISTS bookings_owner_idx ON bookings (owner_id);
  CREATE INDEX IF NOT EXISTS bookings_listing_idx ON bookings (listing_id);
  CREATE INDEX IF NOT EXISTS bookings_status_idx ON bookings (status);

  -- ─── REVIEWS ──────────────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS reviews (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    booking_id  TEXT REFERENCES bookings(id) ON DELETE SET NULL,
    reviewer_id TEXT NOT NULL REFERENCES users(id),
    reviewed_id TEXT NOT NULL REFERENCES users(id),
    rating      INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment     TEXT,
    type        TEXT NOT NULL DEFAULT 'renter', -- 'renter' | 'owner'
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── SHARE LISTINGS (Home Sharing) ────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS share_listings (
    id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    owner_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title           TEXT NOT NULL,
    description     TEXT,
    type            TEXT NOT NULL,
    nightly_rate    INTEGER,
    monthly_rate    INTEGER,
    photos          TEXT[] DEFAULT '{}',
    location        TEXT,
    latitude        REAL,
    longitude       REAL,
    amenities       TEXT[] DEFAULT '{}',
    rules           TEXT,
    available_from  DATE,
    available_to    DATE,
    status          TEXT NOT NULL DEFAULT 'active',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS share_bookings (
    id                       TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    renter_id                TEXT REFERENCES users(id),
    listing_id               TEXT REFERENCES share_listings(id),
    check_in                 DATE NOT NULL,
    check_out                DATE NOT NULL,
    guests                   INTEGER DEFAULT 1,
    total_cents              INTEGER NOT NULL,
    stripe_payment_intent_id TEXT,
    status                   TEXT NOT NULL DEFAULT 'pending',
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── NOTIFICATIONS ────────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS notifications (
    id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type       TEXT NOT NULL,
    title      TEXT NOT NULL,
    message    TEXT,
    read       BOOLEAN NOT NULL DEFAULT FALSE,
    link       TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS notifications_user_idx ON notifications (user_id);
  CREATE INDEX IF NOT EXISTS notifications_read_idx ON notifications (user_id, read);

  -- ─── MAP PINS ─────────────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS map_pins (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    label       TEXT NOT NULL,
    lat         DOUBLE PRECISION NOT NULL,
    lng         DOUBLE PRECISION NOT NULL,
    category    TEXT NOT NULL,
    phone       TEXT,
    description TEXT,
    icon_color  TEXT NOT NULL DEFAULT '#3b82f6',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── INVESTORS ────────────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS investors (
    id                   TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name                 TEXT NOT NULL,
    email                TEXT NOT NULL,
    phone                TEXT,
    amount               INTEGER NOT NULL,
    tier                 TEXT NOT NULL,
    annual_return_pct    NUMERIC(5,2) NOT NULL,
    stripe_session_id    TEXT,
    stripe_payment_status TEXT,
    status               TEXT DEFAULT 'pending',
    notes                TEXT,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── BURNCALL AI MODULE ───────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS bc_contacts (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id          TEXT REFERENCES users(id) ON DELETE SET NULL,
    name             TEXT NOT NULL,
    email            TEXT,
    phone            TEXT,
    company          TEXT,
    service_type     TEXT,
    status           TEXT NOT NULL DEFAULT 'new',
    tags             TEXT[] DEFAULT '{}',
    notes            TEXT,
    source           TEXT DEFAULT 'manual',
    ai_qualification JSONB,
    ai_response_draft TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS bc_contacts_user_idx ON bc_contacts (user_id);
  CREATE INDEX IF NOT EXISTS bc_contacts_status_idx ON bc_contacts (status);

  CREATE TABLE IF NOT EXISTS bc_conversations (
    id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    contact_id TEXT REFERENCES bc_contacts(id) ON DELETE CASCADE,
    user_id    TEXT REFERENCES users(id) ON DELETE SET NULL,
    title      TEXT,
    messages   JSONB NOT NULL DEFAULT '[]',
    status     TEXT NOT NULL DEFAULT 'open',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bc_appointments (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    contact_id       TEXT REFERENCES bc_contacts(id) ON DELETE SET NULL,
    user_id          TEXT REFERENCES users(id) ON DELETE SET NULL,
    title            TEXT NOT NULL,
    description      TEXT,
    scheduled_at     TIMESTAMPTZ NOT NULL,
    duration_minutes INTEGER DEFAULT 60,
    status           TEXT NOT NULL DEFAULT 'scheduled',
    location         TEXT,
    notes            TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS bc_appointments_user_idx ON bc_appointments (user_id);
  CREATE INDEX IF NOT EXISTS bc_appointments_scheduled_idx ON bc_appointments (scheduled_at);

  CREATE TABLE IF NOT EXISTS bc_campaigns (
    id           TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id      TEXT REFERENCES users(id) ON DELETE SET NULL,
    name         TEXT NOT NULL,
    type         TEXT NOT NULL DEFAULT 'email',
    status       TEXT NOT NULL DEFAULT 'draft',
    subject      TEXT,
    body         TEXT,
    target_count INTEGER DEFAULT 0,
    sent_count   INTEGER DEFAULT 0,
    open_count   INTEGER DEFAULT 0,
    reply_count  INTEGER DEFAULT 0,
    scheduled_at TIMESTAMPTZ,
    sent_at      TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bc_notes (
    id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    contact_id TEXT NOT NULL REFERENCES bc_contacts(id) ON DELETE CASCADE,
    user_id    TEXT REFERENCES users(id) ON DELETE SET NULL,
    content    TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bc_revenue_entries (
    id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id        TEXT REFERENCES users(id) ON DELETE SET NULL,
    contact_id     TEXT REFERENCES bc_contacts(id) ON DELETE SET NULL,
    job_title      TEXT NOT NULL,
    revenue_amount NUMERIC(10,2) NOT NULL,
    service_type   TEXT,
    source         TEXT DEFAULT 'manual',
    notes          TEXT,
    closed_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS bc_revenue_user_idx ON bc_revenue_entries (user_id);

  CREATE TABLE IF NOT EXISTS bc_lead_webhooks (
    id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name           TEXT NOT NULL,
    webhook_key    TEXT NOT NULL UNIQUE DEFAULT gen_random_uuid()::text,
    source_label   TEXT DEFAULT 'Website Form',
    leads_captured INTEGER NOT NULL DEFAULT 0,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS bc_webhooks_user_idx ON bc_lead_webhooks (user_id);
  CREATE INDEX IF NOT EXISTS bc_webhooks_key_idx ON bc_lead_webhooks (webhook_key);

  CREATE TABLE IF NOT EXISTS bc_reminders (
    id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id    TEXT REFERENCES users(id) ON DELETE SET NULL,
    contact_id TEXT REFERENCES bc_contacts(id) ON DELETE CASCADE,
    title      TEXT NOT NULL,
    due_at     TIMESTAMPTZ NOT NULL,
    status     TEXT NOT NULL DEFAULT 'pending',
    notes      TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bc_business_profile (
    id                   TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id              TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    business_name        TEXT,
    trade                TEXT,
    service_area         TEXT DEFAULT 'Southwest Florida',
    business_hours       TEXT DEFAULT 'Mon–Fri 8am–5pm',
    response_tone        TEXT DEFAULT 'professional',
    qualifying_questions TEXT[] DEFAULT '{}',
    custom_context       TEXT,
    auto_respond_enabled BOOLEAN DEFAULT FALSE,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bc_services (
    id                TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name              TEXT NOT NULL,
    description       TEXT,
    price_range       TEXT,
    duration_estimate TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bc_faqs (
    id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    question   TEXT NOT NULL,
    answer     TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bc_automations (
    id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    description   TEXT,
    trigger_event TEXT NOT NULL,
    action_type   TEXT NOT NULL,
    action_config JSONB DEFAULT '{}',
    is_enabled    BOOLEAN DEFAULT TRUE,
    runs          INTEGER DEFAULT 0,
    last_run_at   TIMESTAMPTZ,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── EARNTREE MODULE ──────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS et_referral_codes (
    id                TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code              TEXT NOT NULL UNIQUE,
    clicks            INTEGER NOT NULL DEFAULT 0,
    conversions       INTEGER NOT NULL DEFAULT 0,
    total_earned_cents INTEGER NOT NULL DEFAULT 0,
    is_active         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS et_referrals (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    referrer_user_id TEXT NOT NULL REFERENCES users(id),
    referred_user_id TEXT REFERENCES users(id),
    referred_email   TEXT,
    code             TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending',
    reward_type      TEXT NOT NULL DEFAULT 'signup',
    business_campaign_id TEXT,
    converted_at     TIMESTAMPTZ,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS et_commissions (
    id                  TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id             TEXT NOT NULL REFERENCES users(id),
    referral_id         TEXT REFERENCES et_referrals(id),
    share_submission_id TEXT,
    amount_cents        INTEGER NOT NULL,
    status              TEXT NOT NULL DEFAULT 'pending',
    description         TEXT,
    payout_method       TEXT,
    paid_at             TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS et_affiliate_tiers (
    id                 TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id            TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    tier               TEXT NOT NULL DEFAULT 'Seed',
    total_referrals    INTEGER NOT NULL DEFAULT 0,
    total_earned_cents INTEGER NOT NULL DEFAULT 0,
    total_shares       INTEGER NOT NULL DEFAULT 0,
    network_activated  BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS et_payout_requests (
    id           TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id      TEXT NOT NULL REFERENCES users(id),
    amount_cents INTEGER NOT NULL,
    method       TEXT NOT NULL,
    paypal_email TEXT,
    status       TEXT NOT NULL DEFAULT 'pending',
    admin_notes  TEXT,
    processed_at TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS et_business_campaigns (
    id                      TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id                 TEXT NOT NULL REFERENCES users(id),
    business_name           TEXT NOT NULL,
    category                TEXT NOT NULL,
    description             TEXT,
    website                 TEXT,
    phone                   TEXT,
    city                    TEXT,
    state                   TEXT,
    radius_miles            INTEGER DEFAULT 25,
    reward_per_signup_cents  INTEGER NOT NULL DEFAULT 0,
    reward_per_booking_cents INTEGER NOT NULL DEFAULT 0,
    reward_per_share_cents   INTEGER NOT NULL DEFAULT 0,
    weekly_budget_cents      INTEGER NOT NULL DEFAULT 0,
    spend_this_week_cents    INTEGER NOT NULL DEFAULT 0,
    total_referrals          INTEGER NOT NULL DEFAULT 0,
    total_shares             INTEGER NOT NULL DEFAULT 0,
    total_paid_cents         INTEGER NOT NULL DEFAULT 0,
    is_active                BOOLEAN NOT NULL DEFAULT TRUE,
    subscription_active      BOOLEAN NOT NULL DEFAULT FALSE,
    subscription_expires_at  TIMESTAMPTZ,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS et_share_submissions (
    id                   TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id              TEXT NOT NULL REFERENCES users(id),
    business_campaign_id TEXT REFERENCES et_business_campaigns(id),
    platform             TEXT NOT NULL,
    proof_url            TEXT,
    caption              TEXT,
    reward_cents         INTEGER NOT NULL DEFAULT 0,
    status               TEXT NOT NULL DEFAULT 'pending',
    reviewer_notes       TEXT,
    reviewed_at          TIMESTAMPTZ,
    reviewed_by          TEXT,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS et_network_activations (
    id           TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id      TEXT NOT NULL REFERENCES users(id),
    platform     TEXT NOT NULL,
    proof_url    TEXT,
    activated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── POCKETCASH MODULE ────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS pc_loans (
    id                       TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    borrower_id              TEXT NOT NULL REFERENCES users(id),
    lender_id                TEXT REFERENCES users(id),
    amount_cents             INTEGER NOT NULL,
    interest_rate_pct        NUMERIC(5,2) NOT NULL DEFAULT 0,
    term_days                INTEGER NOT NULL,
    purpose                  TEXT,
    status                   TEXT NOT NULL DEFAULT 'requested',
    stripe_payment_intent_id TEXT,
    funded_at                TIMESTAMPTZ,
    due_at                   TIMESTAMPTZ,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS pc_repayments (
    id                       TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    loan_id                  TEXT NOT NULL REFERENCES pc_loans(id),
    amount_cents             INTEGER NOT NULL,
    stripe_payment_intent_id TEXT,
    status                   TEXT NOT NULL DEFAULT 'pending',
    paid_at                  TIMESTAMPTZ,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── PLAYDATE MODULE ──────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS meetups (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    title       TEXT NOT NULL,
    description TEXT,
    location    TEXT NOT NULL,
    date        DATE NOT NULL,
    time        TEXT,
    age_range   TEXT,
    host_name   TEXT,
    host_email  TEXT,
    status      TEXT NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS meetup_rsvps (
    id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    meetup_id     TEXT NOT NULL REFERENCES meetups(id) ON DELETE CASCADE,
    first_name    TEXT NOT NULL,
    last_initial  TEXT NOT NULL,
    contact       TEXT NOT NULL,
    num_children  INTEGER NOT NULL DEFAULT 1,
    reminded_at   TIMESTAMPTZ,
    emailed_at    TIMESTAMPTZ,
    emailed_type  TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS meetup_comments (
    id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    meetup_id     TEXT NOT NULL REFERENCES meetups(id) ON DELETE CASCADE,
    user_id       TEXT NOT NULL REFERENCES users(id),
    user_name     TEXT NOT NULL,
    user_initials TEXT NOT NULL,
    body          TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── BLUECERTIFIED MODULE ─────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS blc_contractor_profiles (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id          TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    full_name        TEXT NOT NULL,
    company_name     TEXT,
    address          TEXT,
    city             TEXT NOT NULL,
    state            TEXT NOT NULL,
    zip              TEXT NOT NULL,
    phone            TEXT NOT NULL,
    email            TEXT,
    website          TEXT,
    bio              TEXT,
    years_experience INTEGER,
    license_number   TEXT,
    insured          BOOLEAN NOT NULL DEFAULT FALSE,
    photo_url        TEXT,
    status           TEXT NOT NULL DEFAULT 'pending',
    is_featured      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ
  );

  CREATE TABLE IF NOT EXISTS blc_contractor_categories (
    id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    profile_id TEXT NOT NULL REFERENCES blc_contractor_profiles(id) ON DELETE CASCADE,
    category   TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS blc_contractor_reviews (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    profile_id       TEXT NOT NULL REFERENCES blc_contractor_profiles(id) ON DELETE CASCADE,
    reviewer_user_id TEXT NOT NULL REFERENCES users(id),
    reviewer_name    TEXT NOT NULL,
    rating           INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment          TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS blc_job_postings (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    posted_by_user_id TEXT NOT NULL REFERENCES users(id),
    poster_name      TEXT NOT NULL,
    title            TEXT NOT NULL,
    description      TEXT,
    category         TEXT NOT NULL,
    city             TEXT NOT NULL,
    zip              TEXT,
    budget_min       INTEGER,
    budget_max       INTEGER,
    contact_email    TEXT,
    contact_phone    TEXT,
    job_type         TEXT NOT NULL DEFAULT 'one_time',
    status           TEXT NOT NULL DEFAULT 'open',
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── PROPCONNECT MODULE ───────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS pc_profiles (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id          TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    full_name        TEXT NOT NULL,
    role             TEXT NOT NULL,
    phone            TEXT,
    company          TEXT,
    license_number   TEXT,
    nmls_number      TEXT,
    email            TEXT,
    website          TEXT,
    bio              TEXT,
    years_experience INTEGER,
    photo_url        TEXT,
    business_card_url TEXT,
    region           TEXT,
    city             TEXT,
    state            TEXT,
    zip              TEXT,
    address          TEXT,
    specialties      TEXT[] DEFAULT '{}',
    is_featured      BOOLEAN NOT NULL DEFAULT FALSE,
    status           TEXT NOT NULL DEFAULT 'active',
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── DIRECTORY MODULE ─────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS businesses (
    id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    business_name  TEXT NOT NULL,
    slug           TEXT NOT NULL UNIQUE,
    category       TEXT NOT NULL,
    address        TEXT,
    city           TEXT,
    state          TEXT,
    zip            TEXT,
    phone          TEXT,
    website        TEXT,
    email          TEXT,
    latitude       NUMERIC,
    longitude      NUMERIC,
    description    TEXT,
    logo_url       TEXT,
    photos         TEXT[] DEFAULT '{}',
    hours          TEXT,
    social_links   TEXT,
    claim_status   TEXT NOT NULL DEFAULT 'unclaimed',
    verified_status TEXT NOT NULL DEFAULT 'unverified',
    owner_user_id  TEXT REFERENCES users(id),
    featured       BOOLEAN NOT NULL DEFAULT FALSE,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE,
    views          INTEGER DEFAULT 0,
    rating         NUMERIC(3,2),
    review_count   INTEGER DEFAULT 0,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS business_claims (
    id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    business_id    TEXT NOT NULL REFERENCES businesses(id),
    user_id        TEXT NOT NULL REFERENCES users(id),
    user_email     TEXT NOT NULL,
    user_name      TEXT,
    business_email TEXT,
    notes          TEXT,
    status         TEXT NOT NULL DEFAULT 'pending',
    admin_notes    TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS business_saves (
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, business_id)
  );

  -- ─── LAYTON'S PEST CONTROL (Partner) ─────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS laytons_bookings (
    id                   TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name                 TEXT NOT NULL,
    email                TEXT NOT NULL,
    phone                TEXT NOT NULL,
    service              TEXT NOT NULL,
    address              TEXT NOT NULL,
    preferred_date       TEXT NOT NULL,
    notes                TEXT,
    status               TEXT NOT NULL DEFAULT 'pending',
    admin_notes          TEXT,
    stripe_session_id    TEXT,
    stripe_payment_status TEXT,
    amount_cents         INTEGER,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── CONTRACTORS (Legacy BlueTruck) ───────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS contractors (
    id                  TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name                TEXT NOT NULL,
    email               TEXT NOT NULL UNIQUE,
    phone               TEXT NOT NULL,
    business_name       TEXT,
    services            TEXT,
    zip_code            TEXT,
    bio                 TEXT,
    license_number      TEXT,
    years_experience    INTEGER,
    status              TEXT DEFAULT 'pending',
    photo_url           TEXT,
    hourly_rate         NUMERIC(10,2),
    subscription_status TEXT DEFAULT 'free',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ
  );

  CREATE TABLE IF NOT EXISTS contractor_jobs (
    id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    title          TEXT NOT NULL,
    category       TEXT NOT NULL,
    location       TEXT NOT NULL,
    address        TEXT,
    pay            TEXT NOT NULL,
    pay_amount     NUMERIC(10,2),
    description    TEXT,
    client_name    TEXT,
    client_phone   TEXT,
    scheduled_date TEXT,
    scheduled_time TEXT,
    tags           TEXT,
    status         TEXT DEFAULT 'open',
    posted_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS contractor_claims (
    id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    job_id         TEXT NOT NULL REFERENCES contractor_jobs(id),
    contractor_email TEXT NOT NULL,
    status         TEXT DEFAULT 'pending',
    notes          TEXT,
    claimed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at   TIMESTAMPTZ
  );

  CREATE TABLE IF NOT EXISTS contractor_ratings (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    job_id           TEXT NOT NULL REFERENCES contractor_jobs(id),
    contractor_email TEXT NOT NULL,
    client_name      TEXT,
    rating           INTEGER CHECK (rating BETWEEN 1 AND 5),
    review           TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS bluetruck_service_requests (
    id                   SERIAL PRIMARY KEY,
    full_name            TEXT,
    email                TEXT,
    phone                TEXT,
    zip                  TEXT,
    service_type         TEXT,
    address              TEXT,
    special_instructions TEXT,
    status               TEXT DEFAULT 'new',
    created_at           TIMESTAMPTZ DEFAULT NOW()
  );

  -- ─── THRIFT MARKETPLACE ───────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS thrift_items (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    seller_id   TEXT REFERENCES users(id) ON DELETE SET NULL,
    title       TEXT NOT NULL,
    description TEXT,
    price_cents INTEGER NOT NULL,
    category    TEXT,
    condition   TEXT,
    photos      TEXT[] DEFAULT '{}',
    location    TEXT,
    status      TEXT NOT NULL DEFAULT 'available',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── PODCAST MODULE ───────────────────────────────────────────────────────────

  CREATE TABLE IF NOT EXISTS podcast_channels (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    slug        TEXT NOT NULL UNIQUE,
    description TEXT,
    cover_url   TEXT,
    category    TEXT,
    status      TEXT NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS podcast_episodes (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    channel_id  TEXT NOT NULL REFERENCES podcast_channels(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    description TEXT,
    video_url   TEXT,
    thumbnail   TEXT,
    duration    INTEGER,
    status      TEXT NOT NULL DEFAULT 'published',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- ─── SEED: DEFAULT FEATURE FLAGS ─────────────────────────────────────────────

  INSERT INTO feature_flags (key, enabled, label, description) VALUES
    ('marketplace',     TRUE,  'Marketplace',       'Buy/sell listing marketplace'),
    ('share_listings',  TRUE,  'Home Sharing',      'Home sharing and rental listings'),
    ('burncall',        TRUE,  'BurnCall AI',       'AI-powered business call automation'),
    ('earntree',        TRUE,  'EarnTree',          'Community earnings and referral network'),
    ('pocketcash',      TRUE,  'PocketCash',        'P2P micro-lending platform'),
    ('playdate',        TRUE,  'PLAYDATE',          'Family meetup coordination'),
    ('bluecertified',   TRUE,  'BlueCertified',     'SWFL contractor network'),
    ('propconnect',     TRUE,  'PropConnect',       'Real estate professional network'),
    ('directory',       TRUE,  'Directory',         'Local business directory'),
    ('thrift',          TRUE,  'THRIFTgirl',        'Thrift marketplace'),
    ('podcast',         TRUE,  'Podcast Network',   'Community podcast channel')
  ON CONFLICT (key) DO NOTHING;

  -- ─── END OF SCHEMA ────────────────────────────────────────────────────────────
  -- Total tables: ~65+
  -- Run: psql $DATABASE_URL < schema.sql
  