# Migrating Database FROM Replit

## Step 1: Export from Replit
In Replit's shell or via their database panel:
```bash
# Schema only
pg_dump $DATABASE_URL --schema-only -f replit-schema.sql

# Full backup (schema + data)
pg_dump $DATABASE_URL -f replit-full-backup.sql

# Data only (no schema)
pg_dump $DATABASE_URL --data-only -f replit-data.sql
```

## Step 2: Import to New Host
```bash
# Create target database
createdb buyshare_new

# Import schema first (or use schema.sql from this package)
psql $NEW_DATABASE_URL < replit-schema.sql

# Import data
psql $NEW_DATABASE_URL < replit-data.sql
```

## Step 3: Verify
```bash
psql $NEW_DATABASE_URL -c "SELECT COUNT(*) FROM users;"
psql $NEW_DATABASE_URL -c "SELECT COUNT(*) FROM listings;"
```

## Step 4: Update Environment
Update DATABASE_URL in your new deployment to point to the new database.
