# Buyshare.co — Database Package

## How to Initialize a Fresh Database

1. Create a PostgreSQL 15+ database:
```bash
createdb buyshare
# or on managed hosting, create via dashboard
```

2. Run the schema:
```bash
psql $DATABASE_URL < schema.sql
```

3. Verify all tables:
```bash
psql $DATABASE_URL -c "\dt"
# Should show 65+ tables
```

## Table Groups

| Prefix | Module | Tables |
|--------|--------|--------|
| (none) | Core | users, listings, bookings, reviews, notifications, map_pins, investors |
| bc_    | BurnCall AI | bc_contacts, bc_appointments, bc_campaigns, bc_automations, bc_business_profile, bc_services, bc_faqs, bc_lead_webhooks, bc_notes, bc_revenue_entries, bc_reminders, bc_conversations |
| et_    | EarnTree | et_referral_codes, et_referrals, et_commissions, et_affiliate_tiers, et_payout_requests, et_business_campaigns, et_share_submissions, et_network_activations |
| pc_    | PocketCash/PropConnect | pc_loans, pc_repayments, pc_profiles |
| blc_   | BlueCertified | blc_contractor_profiles, blc_contractor_categories, blc_contractor_reviews, blc_job_postings |

## Important Notes

- All IDs use `gen_random_uuid()::text` (requires pgcrypto extension)
- Enum types created with DO $$ blocks (idempotent)
- All tables use `CREATE TABLE IF NOT EXISTS` (safe to re-run)
- Feature flags seeded with INSERT ... ON CONFLICT DO NOTHING

## Backup Command
```bash
pg_dump $DATABASE_URL --schema-only -f schema-backup.sql
pg_dump $DATABASE_URL -f full-backup.sql  # includes data
```

## Connection String Format
```
postgresql://USERNAME:PASSWORD@HOST:5432/DBNAME
postgresql://USERNAME:PASSWORD@HOST:5432/DBNAME?sslmode=require  # for cloud DB
```

## Hosted Options
- **Neon** (neon.tech) — free tier, serverless PostgreSQL
- **Supabase** (supabase.com) — free tier, includes auth + storage
- **Railway** (railway.app) — $5/mo PostgreSQL
- **DigitalOcean Managed DB** — $15/mo
- **AWS RDS** — production scale
