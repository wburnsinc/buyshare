import { pgTable, serial, text, integer, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const growthMetricsTable = pgTable("growth_metrics", {
  id: serial("id").primaryKey(),
  month: text("month").notNull(),
  bookings: integer("bookings").notNull().default(0),
  revenue: numeric("revenue", { precision: 12, scale: 2 }).notNull().default("0"),
  contractors: integer("contractors").notNull().default(0),
  customers: integer("customers").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertGrowthMetricSchema = createInsertSchema(growthMetricsTable).omit({ id: true, createdAt: true });
export type InsertGrowthMetric = z.infer<typeof insertGrowthMetricSchema>;
export type GrowthMetric = typeof growthMetricsTable.$inferSelect;
