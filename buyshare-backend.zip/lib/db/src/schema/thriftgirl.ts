import { pgTable, serial, text, integer, numeric, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const thriftgirlCategoryEnum = pgEnum("thriftgirl_category", [
  "clothing", "shoes", "accessories", "home_decor", "electronics", "toys", "books", "vintage", "handmade", "other"
]);

export const thriftgirlConditionEnum = pgEnum("thriftgirl_condition", [
  "new_with_tags", "like_new", "good", "fair", "poor"
]);

export const thriftgirlListingsTable = pgTable("thriftgirl_listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: thriftgirlCategoryEnum("category").notNull(),
  condition: thriftgirlConditionEnum("condition").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  originalPrice: numeric("original_price", { precision: 10, scale: 2 }),
  sellerId: integer("seller_id"),
  sellerName: text("seller_name").notNull(),
  sellerRating: numeric("seller_rating", { precision: 3, scale: 2 }).notNull().default("5.0"),
  location: text("location").notNull(),
  zipCode: text("zip_code").notNull(),
  imageUrl: text("image_url"),
  tags: text("tags").array().notNull().default([]),
  available: boolean("available").notNull().default(true),
  featured: boolean("featured").notNull().default(false),
  views: integer("views").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertThriftgirlListingSchema = createInsertSchema(thriftgirlListingsTable).omit({ id: true, createdAt: true });
export type InsertThriftgirlListing = z.infer<typeof insertThriftgirlListingSchema>;
export type ThriftgirlListing = typeof thriftgirlListingsTable.$inferSelect;
