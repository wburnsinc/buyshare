import { pgTable, serial, text, boolean, integer, numeric, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const contractorStatusEnum = pgEnum("contractor_status", ["active", "pending", "suspended"]);

export const contractorsTable = pgTable("contractors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  company: text("company"),
  categories: text("categories").array().notNull().default([]),
  bio: text("bio"),
  rating: numeric("rating", { precision: 3, scale: 2 }).notNull().default("5.0"),
  reviewCount: integer("review_count").notNull().default(0),
  jobsCompleted: integer("jobs_completed").notNull().default(0),
  verified: boolean("verified").notNull().default(false),
  serviceAreas: text("service_areas").array().notNull().default([]),
  phone: text("phone"),
  email: text("email").notNull(),
  avatarUrl: text("avatar_url"),
  earnings: numeric("earnings", { precision: 12, scale: 2 }).default("0"),
  status: contractorStatusEnum("status").notNull().default("pending"),
  licenseNumber: text("license_number"),
  insuranceProvider: text("insurance_provider"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertContractorSchema = createInsertSchema(contractorsTable).omit({ id: true, createdAt: true });
export type InsertContractor = z.infer<typeof insertContractorSchema>;
export type Contractor = typeof contractorsTable.$inferSelect;
