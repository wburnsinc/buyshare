import { pgTable, serial, text, integer, numeric, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const playdateTypeEnum = pgEnum("playdate_type", [
  "park_meetup", "indoor_play", "sports", "arts_crafts", "music", "swimming", "tutoring", "birthday_party", "nature_walk", "playgroup"
]);

export const playdateEventsTable = pgTable("playdate_events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: playdateTypeEnum("type").notNull(),
  hostId: integer("host_id"),
  hostName: text("host_name").notNull(),
  ageMin: integer("age_min").notNull().default(0),
  ageMax: integer("age_max").notNull().default(18),
  maxKids: integer("max_kids").notNull().default(10),
  currentKids: integer("current_kids").notNull().default(0),
  price: numeric("price", { precision: 10, scale: 2 }).notNull().default("0"),
  isFree: boolean("is_free").notNull().default(true),
  location: text("location").notNull(),
  address: text("address").notNull(),
  zipCode: text("zip_code").notNull(),
  eventDate: text("event_date").notNull(),
  eventTime: text("event_time").notNull(),
  durationMinutes: integer("duration_minutes").notNull().default(120),
  imageUrl: text("image_url"),
  tags: text("tags").array().notNull().default([]),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPlaydateEventSchema = createInsertSchema(playdateEventsTable).omit({ id: true, createdAt: true });
export type InsertPlaydateEvent = z.infer<typeof insertPlaydateEventSchema>;
export type PlaydateEvent = typeof playdateEventsTable.$inferSelect;
