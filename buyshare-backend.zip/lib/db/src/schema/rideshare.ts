import { pgTable, serial, text, integer, numeric, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const rideshareStatusEnum = pgEnum("rideshare_status", [
  "open", "matched", "en_route", "picked_up", "completed", "cancelled"
]);

export const rideshareTripsTable = pgTable("rideshare_trips", {
  id: serial("id").primaryKey(),
  riderId: integer("rider_id"),
  riderName: text("rider_name").notNull(),
  driverId: integer("driver_id"),
  driverName: text("driver_name"),
  driverRating: numeric("driver_rating", { precision: 3, scale: 2 }),
  vehicleInfo: text("vehicle_info"),
  pickupAddress: text("pickup_address").notNull(),
  dropoffAddress: text("dropoff_address").notNull(),
  pickupZip: text("pickup_zip").notNull(),
  dropoffZip: text("dropoff_zip").notNull(),
  estimatedMiles: numeric("estimated_miles", { precision: 6, scale: 2 }),
  fare: numeric("fare", { precision: 10, scale: 2 }),
  status: rideshareStatusEnum("status").notNull().default("open"),
  scheduledDate: text("scheduled_date"),
  scheduledTime: text("scheduled_time"),
  isShared: boolean("is_shared").notNull().default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRideshareSchema = createInsertSchema(rideshareTripsTable).omit({ id: true, createdAt: true });
export type InsertRideshare = z.infer<typeof insertRideshareSchema>;
export type RideshareTrip = typeof rideshareTripsTable.$inferSelect;
