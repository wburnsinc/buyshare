import { pgTable, serial, text, integer, numeric, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const shareListingsTable = pgTable("share_listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  priceUnit: text("price_unit").notNull(),
  location: text("location").notNull(),
  zipCode: text("zip_code").notNull(),
  hostId: integer("host_id"),
  hostName: text("host_name").notNull(),
  rating: numeric("rating", { precision: 3, scale: 2 }).notNull().default("5.0"),
  reviewCount: integer("review_count").notNull().default(0),
  imageUrl: text("image_url"),
  amenities: text("amenities").array().notNull().default([]),
  available: boolean("available").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertShareListingSchema = createInsertSchema(shareListingsTable).omit({ id: true, createdAt: true });
export type InsertShareListing = z.infer<typeof insertShareListingSchema>;
export type ShareListing = typeof shareListingsTable.$inferSelect;
