import { pgTable, serial, text, integer, numeric, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const earntreeSourceEnum = pgEnum("earntree_source", [
  "share_rental", "referral", "contractor_bonus", "platform_credit", "thriftgirl_sale", "rideshare_payout", "playdate_hosting", "review_bonus", "signup_bonus"
]);

export const earntreeEarningsTable = pgTable("earntree_earnings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  source: earntreeSourceEnum("source").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  referralCode: text("referral_code"),
  referredUserId: integer("referred_user_id"),
  status: text("status").notNull().default("pending"),
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const earntreeGoalsTable = pgTable("earntree_goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  targetAmount: numeric("target_amount", { precision: 10, scale: 2 }).notNull(),
  currentAmount: numeric("current_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  deadline: text("deadline"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertEarntreeEarningSchema = createInsertSchema(earntreeEarningsTable).omit({ id: true, createdAt: true });
export type InsertEarntreeEarning = z.infer<typeof insertEarntreeEarningSchema>;
export type EarntreeEarning = typeof earntreeEarningsTable.$inferSelect;
