import { pgTable, serial, text, numeric, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const leadStatusEnum = pgEnum("lead_status", ["new", "contacted", "qualified", "booked", "lost"]);

export const leadsTable = pgTable("leads", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  serviceType: text("service_type").notNull(),
  message: text("message").notNull(),
  status: leadStatusEnum("status").notNull().default("new"),
  source: text("source").notNull(),
  aiSummary: text("ai_summary"),
  estimatedValue: numeric("estimated_value", { precision: 10, scale: 2 }),
  zipCode: text("zip_code"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLeadSchema = createInsertSchema(leadsTable).omit({ id: true, createdAt: true });
export type InsertLead = z.infer<typeof insertLeadSchema>;
export type Lead = typeof leadsTable.$inferSelect;
