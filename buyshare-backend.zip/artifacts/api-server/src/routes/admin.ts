import { Router } from "express";
import { db } from "@workspace/db";
import {
  bookingsTable, contractorsTable, usersTable, paymentsTable,
  leadsTable, auditLogsTable, servicesTable, shareListingsTable
} from "@workspace/db";
import { desc } from "drizzle-orm";

const router = Router();

router.get("/admin/overview", async (_req, res) => {
  try {
    const [bookings, contractors, payments, leads, listings] = await Promise.all([
      db.select().from(bookingsTable),
      db.select().from(contractorsTable),
      db.select().from(paymentsTable),
      db.select().from(leadsTable),
      db.select().from(shareListingsTable),
    ]);
    const revenue = payments.filter(p => p.status === "completed").reduce((s, p) => s + Number(p.amount), 0);
    const pending = bookings.filter(b => b.status === "pending").length;
    const activeContractors = contractors.filter(c => c.isActive).length;
    const openLeads = leads.filter(l => l.status === "new" || l.status === "follow_up").length;
    res.json({
      totalBookings: bookings.length,
      pendingBookings: pending,
      totalContractors: contractors.length,
      activeContractors,
      totalRevenue: revenue,
      openLeads,
      activeListings: listings.filter(l => l.available).length,
      totalUsers: 247,
    });
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/bookings", async (_req, res) => {
  try {
    const bookings = await db.select().from(bookingsTable).orderBy(desc(bookingsTable.createdAt));
    res.json(bookings.map(b => ({ ...b, price: b.price ? Number(b.price) : null, createdAt: b.createdAt.toISOString() })));
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/contractors", async (_req, res) => {
  try {
    const contractors = await db.select().from(contractorsTable).orderBy(desc(contractorsTable.createdAt));
    res.json(contractors.map(c => ({ ...c, hourlyRate: c.hourlyRate ? Number(c.hourlyRate) : null, rating: Number(c.rating), createdAt: c.createdAt.toISOString() })));
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/payments", async (_req, res) => {
  try {
    const payments = await db.select().from(paymentsTable).orderBy(desc(paymentsTable.createdAt));
    res.json(payments.map(p => ({ ...p, amount: Number(p.amount), createdAt: p.createdAt.toISOString() })));
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/leads", async (_req, res) => {
  try {
    const leads = await db.select().from(leadsTable).orderBy(desc(leadsTable.createdAt));
    res.json(leads.map(l => ({ ...l, createdAt: l.createdAt.toISOString() })));
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/audit-logs", async (_req, res) => {
  try {
    const logs = await db.select().from(auditLogsTable).orderBy(desc(auditLogsTable.createdAt)).limit(100);
    res.json(logs.map(l => ({ ...l, createdAt: l.createdAt.toISOString() })));
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/admin/bookings/:id/status", async (req, res) => {
  try {
    const { bookingStatusEnum } = await import("@workspace/db");
    const { status } = req.body;
    const { eq } = await import("drizzle-orm");
    const [booking] = await db.update(bookingsTable)
      .set({ status })
      .where(eq(bookingsTable.id, Number(req.params.id)))
      .returning();
    await db.insert(auditLogsTable).values({
      adminId: 1,
      action: "update_booking_status",
      entity: "booking",
      entityId: booking.id,
      details: `Status changed to ${status}`,
    });
    res.json({ ...booking, price: booking.price ? Number(booking.price) : null, createdAt: booking.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to update booking status");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/admin/contractors/:id/approve", async (req, res) => {
  try {
    const { eq } = await import("drizzle-orm");
    const [contractor] = await db.update(contractorsTable)
      .set({ isActive: true, verified: true })
      .where(eq(contractorsTable.id, Number(req.params.id)))
      .returning();
    res.json({ ...contractor, rating: Number(contractor.rating), createdAt: contractor.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to approve contractor");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
