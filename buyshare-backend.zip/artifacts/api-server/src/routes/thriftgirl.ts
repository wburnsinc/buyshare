import { Router } from "express";
import { db } from "@workspace/db";
import { thriftgirlListingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/thriftgirl/listings", async (req, res) => {
  try {
    const listings = await db.select().from(thriftgirlListingsTable).orderBy(thriftgirlListingsTable.createdAt);
    const filtered = req.query.category
      ? listings.filter(l => l.category === req.query.category)
      : listings;
    res.json(filtered.map(l => ({ ...l, price: Number(l.price), originalPrice: l.originalPrice ? Number(l.originalPrice) : null, sellerRating: Number(l.sellerRating) })));
  } catch (err) {
    req.log.error({ err }, "Failed to list thriftgirl listings");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/thriftgirl/listings/:id", async (req, res) => {
  try {
    const [listing] = await db.select().from(thriftgirlListingsTable).where(eq(thriftgirlListingsTable.id, Number(req.params.id)));
    if (!listing) return res.status(404).json({ error: "Not found" });
    res.json({ ...listing, price: Number(listing.price), originalPrice: listing.originalPrice ? Number(listing.originalPrice) : null });
  } catch (err) {
    req.log.error({ err }, "Failed to get listing");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/thriftgirl/listings", async (req, res) => {
  try {
    const { title, description, category, condition, price, originalPrice, sellerName, location, zipCode, imageUrl, tags } = req.body;
    const [listing] = await db.insert(thriftgirlListingsTable).values({
      title, description, category, condition,
      price: String(price),
      originalPrice: originalPrice ? String(originalPrice) : null,
      sellerName, location, zipCode, imageUrl,
      tags: tags || [],
    }).returning();
    res.status(201).json({ ...listing, price: Number(listing.price) });
  } catch (err) {
    req.log.error({ err }, "Failed to create listing");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/thriftgirl/stats", async (_req, res) => {
  try {
    const all = await db.select().from(thriftgirlListingsTable);
    const active = all.filter(l => l.available).length;
    const totalValue = all.reduce((s, l) => s + Number(l.price), 0);
    res.json({ totalListings: all.length, activeListings: active, totalValue, categories: 10 });
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
