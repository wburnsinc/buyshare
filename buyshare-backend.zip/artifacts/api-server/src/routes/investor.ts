import { Router } from "express";
import { db } from "@workspace/db";
import { growthMetricsTable } from "@workspace/db";

const router = Router();

router.get("/investor/stats", async (_req, res) => {
  res.json({
    totalMarketOpportunity: "$25M+",
    annualGrowthRate: "38%",
    activeContractors: 500,
    homesServed: 3000000,
    monthlyRevenue: 284500,
    totalBookingsAllTime: 10000,
    platformNpsScrore: 72,
    targetMarkets: ["Southwest Florida", "Tampa Bay", "Orlando", "Miami", "Jacksonville"],
  });
});

router.get("/investor/growth", async (_req, res) => {
  try {
    const metrics = await db.select().from(growthMetricsTable).orderBy(growthMetricsTable.month);
    res.json(metrics.map(m => ({
      ...m,
      revenue: Number(m.revenue),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to get growth metrics");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
