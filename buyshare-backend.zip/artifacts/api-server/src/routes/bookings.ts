import { Router } from "express";
import { db } from "@workspace/db";
import { bookingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/bookings", async (req, res) => {
  try {
    const bookings = await db.select().from(bookingsTable).orderBy(bookingsTable.createdAt);
    const filtered = req.query.status
      ? bookings.filter(b => b.status === req.query.status)
      : bookings;
    res.json(filtered.map(b => ({
      ...b,
      price: b.price ? Number(b.price) : null,
      createdAt: b.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list bookings");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/bookings", async (req, res) => {
  try {
    const { serviceId, scheduledDate, scheduledTime, address, zipCode, notes, isRecurring, recurringFrequency } = req.body;
    const services = await db.query?.services?.findFirst?.() ?? null;
    const [booking] = await db.insert(bookingsTable).values({
      serviceId,
      serviceName: req.body.serviceName || "Service",
      customerId: 1,
      status: "pending",
      scheduledDate,
      scheduledTime,
      address,
      zipCode,
      notes,
      isRecurring: isRecurring ?? false,
      recurringFrequency,
    }).returning();
    res.status(201).json({ ...booking, price: null, createdAt: booking.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create booking");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/bookings/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, id));
    if (!booking) return res.status(404).json({ error: "Not found" });
    res.json({ ...booking, price: booking.price ? Number(booking.price) : null, createdAt: booking.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get booking");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/bookings/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const updates: Record<string, unknown> = {};
    if (req.body.status) updates.status = req.body.status;
    if (req.body.contractorId) updates.contractorId = req.body.contractorId;
    if (req.body.price) updates.price = req.body.price;
    if (req.body.notes) updates.notes = req.body.notes;
    const [updated] = await db.update(bookingsTable).set(updates).where(eq(bookingsTable.id, id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json({ ...updated, price: updated.price ? Number(updated.price) : null, createdAt: updated.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to update booking");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
