import { Router } from "express";
import { db } from "@workspace/db";
import { earntreeEarningsTable, earntreeGoalsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/earntree/earnings", async (req, res) => {
  try {
    const userId = Number(req.query.userId) || 1;
    const earnings = await db.select().from(earntreeEarningsTable).where(eq(earntreeEarningsTable.userId, userId));
    res.json(earnings.map(e => ({ ...e, amount: Number(e.amount) })));
  } catch (err) {
    req.log.error({ err }, "Failed to list earnings");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/earntree/summary", async (req, res) => {
  try {
    const userId = Number(req.query.userId) || 1;
    const earnings = await db.select().from(earntreeEarningsTable).where(eq(earntreeEarningsTable.userId, userId));
    const goals = await db.select().from(earntreeGoalsTable).where(eq(earntreeGoalsTable.userId, userId));
    const total = earnings.reduce((s, e) => s + Number(e.amount), 0);
    const paid = earnings.filter(e => e.status === "paid").reduce((s, e) => s + Number(e.amount), 0);
    const pending = earnings.filter(e => e.status === "pending").reduce((s, e) => s + Number(e.amount), 0);
    const bySource = earnings.reduce((acc, e) => {
      acc[e.source] = (acc[e.source] || 0) + Number(e.amount);
      return acc;
    }, {} as Record<string, number>);
    res.json({ total, paid, pending, bySource, referrals: earnings.filter(e => e.source === "referral").length, goals: goals.map(g => ({ ...g, targetAmount: Number(g.targetAmount), currentAmount: Number(g.currentAmount) })) });
  } catch (err) {
    req.log.error({ err }, "Failed to get earntree summary");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/earntree/goals", async (req, res) => {
  try {
    const { title, targetAmount, deadline } = req.body;
    const [goal] = await db.insert(earntreeGoalsTable).values({
      userId: 1,
      title,
      targetAmount: String(targetAmount),
      deadline,
    }).returning();
    res.status(201).json({ ...goal, targetAmount: Number(goal.targetAmount), currentAmount: Number(goal.currentAmount) });
  } catch (err) {
    req.log.error({ err }, "Failed to create goal");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/earntree/referral-code", async (_req, res) => {
  res.json({ code: "EARN-DEMO-2024", totalReferrals: 7, totalEarned: 175, nextPayout: "2024-07-01" });
});

export default router;
