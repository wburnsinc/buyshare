import { Router } from "express";
import { db } from "@workspace/db";
import { playdateEventsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/playdate/events", async (req, res) => {
  try {
    const events = await db.select().from(playdateEventsTable).orderBy(playdateEventsTable.eventDate);
    const filtered = req.query.type
      ? events.filter(e => e.type === req.query.type)
      : events;
    res.json(filtered.map(e => ({ ...e, price: Number(e.price) })));
  } catch (err) {
    req.log.error({ err }, "Failed to list playdate events");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/playdate/events/:id", async (req, res) => {
  try {
    const [event] = await db.select().from(playdateEventsTable).where(eq(playdateEventsTable.id, Number(req.params.id)));
    if (!event) return res.status(404).json({ error: "Not found" });
    res.json({ ...event, price: Number(event.price) });
  } catch (err) {
    req.log.error({ err }, "Failed to get event");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/playdate/events", async (req, res) => {
  try {
    const { title, description, type, hostName, ageMin, ageMax, maxKids, price, isFree, location, address, zipCode, eventDate, eventTime, durationMinutes } = req.body;
    const [event] = await db.insert(playdateEventsTable).values({
      title, description, type, hostName,
      ageMin: ageMin ?? 0, ageMax: ageMax ?? 18,
      maxKids: maxKids ?? 10,
      price: String(price || 0),
      isFree: isFree ?? true,
      location, address, zipCode, eventDate, eventTime,
      durationMinutes: durationMinutes ?? 120,
    }).returning();
    res.status(201).json({ ...event, price: Number(event.price) });
  } catch (err) {
    req.log.error({ err }, "Failed to create event");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/playdate/events/:id/rsvp", async (req, res) => {
  try {
    const [event] = await db.select().from(playdateEventsTable).where(eq(playdateEventsTable.id, Number(req.params.id)));
    if (!event) return res.status(404).json({ error: "Not found" });
    if (event.currentKids >= event.maxKids) return res.status(400).json({ error: "Event is full" });
    const [updated] = await db.update(playdateEventsTable)
      .set({ currentKids: event.currentKids + 1 })
      .where(eq(playdateEventsTable.id, Number(req.params.id)))
      .returning();
    res.json({ ...updated, price: Number(updated.price) });
  } catch (err) {
    req.log.error({ err }, "Failed to RSVP");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/playdate/stats", async (_req, res) => {
  try {
    const events = await db.select().from(playdateEventsTable);
    const upcoming = events.filter(e => e.active).length;
    const totalKids = events.reduce((s, e) => s + e.currentKids, 0);
    res.json({ totalEvents: events.length, upcomingEvents: upcoming, totalKids, hosts: new Set(events.map(e => e.hostName)).size });
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
