import { Router } from "express";
import { db } from "@workspace/db";
import { reviewsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/reviews", async (req, res) => {
  try {
    const reviews = await db.select().from(reviewsTable).orderBy(reviewsTable.createdAt);
    const filtered = req.query.contractorId
      ? reviews.filter(r => r.contractorId === parseInt(req.query.contractorId as string))
      : reviews;
    res.json(filtered.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error({ err }, "Failed to list reviews");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/reviews", async (req, res) => {
  try {
    const [review] = await db.insert(reviewsTable).values({
      contractorId: req.body.contractorId,
      bookingId: req.body.bookingId,
      reviewerName: "Customer",
      rating: req.body.rating,
      comment: req.body.comment,
    }).returning();
    res.status(201).json({ ...review, createdAt: review.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create review");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
