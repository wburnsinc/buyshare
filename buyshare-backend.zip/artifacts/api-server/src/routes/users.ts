import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/users/me", async (_req, res) => {
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, 1));
    if (!user) {
      const [created] = await db.insert(usersTable).values({
        name: "Demo User",
        email: "demo@buyshare.co",
        role: "customer",
        credits: "250",
      }).returning();
      return res.json({ ...created, credits: Number(created.credits), createdAt: created.createdAt.toISOString() });
    }
    res.json({ ...user, credits: Number(user.credits), createdAt: user.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get user");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/users/me", async (req, res) => {
  try {
    const updates: Record<string, unknown> = {};
    if (req.body.name) updates.name = req.body.name;
    if (req.body.phone !== undefined) updates.phone = req.body.phone;
    if (req.body.zipCode !== undefined) updates.zipCode = req.body.zipCode;
    if (req.body.avatarUrl !== undefined) updates.avatarUrl = req.body.avatarUrl;
    const [updated] = await db.update(usersTable).set(updates).where(eq(usersTable.id, 1)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json({ ...updated, credits: Number(updated.credits), createdAt: updated.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to update user");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
