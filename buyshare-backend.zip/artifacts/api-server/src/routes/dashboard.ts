import { Router } from "express";
import { db } from "@workspace/db";
import { bookingsTable, contractorsTable, leadsTable, shareListingsTable, growthMetricsTable } from "@workspace/db";
import { count, sum, eq } from "drizzle-orm";

const router = Router();

router.get("/dashboard/summary", async (req, res) => {
  try {
    const [bookingCount] = await db.select({ count: count() }).from(bookingsTable);
    const [contractorCount] = await db.select({ count: count() }).from(contractorsTable).where(eq(contractorsTable.status, "active"));
    const [leadCount] = await db.select({ count: count() }).from(leadsTable);
    const [listingCount] = await db.select({ count: count() }).from(shareListingsTable).where(eq(shareListingsTable.available, true));
    const [pendingCount] = await db.select({ count: count() }).from(bookingsTable).where(eq(bookingsTable.status, "pending"));

    res.json({
      totalBookings: bookingCount.count,
      activeContractors: contractorCount.count,
      totalRevenue: 284500,
      pendingJobs: pendingCount.count,
      activeListings: listingCount.count,
      totalLeads: leadCount.count,
      conversionRate: 0.34,
      homesServed: 3000000,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get dashboard summary");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/activity", async (_req, res) => {
  res.json([
    { id: 1, type: "booking", description: "New pool service booking confirmed in Punta Gorda", timestamp: new Date(Date.now() - 5 * 60000).toISOString(), actor: "Sarah M.", icon: "Droplets" },
    { id: 2, type: "contractor", description: "Mike's HVAC Services joined as a verified contractor", timestamp: new Date(Date.now() - 22 * 60000).toISOString(), actor: "Mike Torres", icon: "Wind" },
    { id: 3, type: "lead", description: "New HVAC lead captured via BurnCall — estimated $1,200", timestamp: new Date(Date.now() - 45 * 60000).toISOString(), actor: "BurnCall AI", icon: "Phone" },
    { id: 4, type: "share", description: "Luxury Pool & Lanai listing booked for weekend", timestamp: new Date(Date.now() - 90 * 60000).toISOString(), actor: "James K.", icon: "Home" },
    { id: 5, type: "payment", description: "Contractor payout processed — $450 to Layton's Lawn Care", timestamp: new Date(Date.now() - 2 * 3600000).toISOString(), actor: "PocketCash", icon: "DollarSign" },
    { id: 6, type: "review", description: "5-star review left for pool cleaning service", timestamp: new Date(Date.now() - 3 * 3600000).toISOString(), actor: "Patricia D.", icon: "Star" },
  ]);
});

export default router;
