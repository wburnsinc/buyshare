import { Router } from "express";
import { db } from "@workspace/db";
import { contractorsTable, bookingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/contractors", async (req, res) => {
  try {
    const contractors = await db.select().from(contractorsTable);
    const filtered = req.query.verified === "true"
      ? contractors.filter(c => c.verified)
      : contractors;
    res.json(filtered.map(c => ({
      ...c,
      rating: Number(c.rating),
      earnings: c.earnings ? Number(c.earnings) : null,
      createdAt: c.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list contractors");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/contractors", async (req, res) => {
  try {
    const [contractor] = await db.insert(contractorsTable).values({
      name: req.body.name,
      company: req.body.company,
      email: req.body.email,
      phone: req.body.phone,
      categories: req.body.categories ?? [],
      serviceAreas: req.body.serviceAreas ?? [],
      bio: req.body.bio,
      licenseNumber: req.body.licenseNumber,
      insuranceProvider: req.body.insuranceProvider,
      status: "pending",
      verified: false,
    }).returning();
    res.status(201).json({ ...contractor, rating: Number(contractor.rating), earnings: null, createdAt: contractor.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create contractor");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/contractors/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [contractor] = await db.select().from(contractorsTable).where(eq(contractorsTable.id, id));
    if (!contractor) return res.status(404).json({ error: "Not found" });
    res.json({ ...contractor, rating: Number(contractor.rating), earnings: contractor.earnings ? Number(contractor.earnings) : null, createdAt: contractor.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get contractor");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/contractors/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const updates: Record<string, unknown> = {};
    if (req.body.bio !== undefined) updates.bio = req.body.bio;
    if (req.body.categories) updates.categories = req.body.categories;
    if (req.body.serviceAreas) updates.serviceAreas = req.body.serviceAreas;
    if (req.body.phone) updates.phone = req.body.phone;
    if (req.body.status) updates.status = req.body.status;
    const [updated] = await db.update(contractorsTable).set(updates).where(eq(contractorsTable.id, id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json({ ...updated, rating: Number(updated.rating), earnings: updated.earnings ? Number(updated.earnings) : null, createdAt: updated.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to update contractor");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/contractors/:id/jobs", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const jobs = await db.select().from(bookingsTable).where(eq(bookingsTable.contractorId, id));
    res.json(jobs.map(j => ({
      id: j.id,
      bookingId: j.id,
      title: j.serviceName,
      category: j.serviceName,
      address: j.address,
      zipCode: j.zipCode,
      scheduledDate: j.scheduledDate,
      price: j.price ? Number(j.price) : null,
      status: j.status,
      customerName: "Customer",
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to get contractor jobs");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
