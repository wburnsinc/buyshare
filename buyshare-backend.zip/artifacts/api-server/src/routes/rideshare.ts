import { Router } from "express";
import { db } from "@workspace/db";
import { rideshareTripsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/rideshare/trips", async (req, res) => {
  try {
    const trips = await db.select().from(rideshareTripsTable).orderBy(rideshareTripsTable.createdAt);
    const filtered = req.query.status
      ? trips.filter(t => t.status === req.query.status)
      : trips;
    res.json(filtered.map(t => ({ ...t, fare: t.fare ? Number(t.fare) : null, estimatedMiles: t.estimatedMiles ? Number(t.estimatedMiles) : null })));
  } catch (err) {
    req.log.error({ err }, "Failed to list trips");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/rideshare/trips", async (req, res) => {
  try {
    const { riderName, pickupAddress, dropoffAddress, pickupZip, dropoffZip, scheduledDate, scheduledTime, isShared, notes } = req.body;
    const miles = Math.random() * 15 + 2;
    const fare = miles < 5 ? 8 : miles < 10 ? 14 : 20;
    const [trip] = await db.insert(rideshareTripsTable).values({
      riderName, pickupAddress, dropoffAddress, pickupZip, dropoffZip,
      scheduledDate, scheduledTime,
      isShared: isShared ?? false,
      notes,
      estimatedMiles: String(miles.toFixed(2)),
      fare: String(fare),
      status: "open",
    }).returning();
    res.status(201).json({ ...trip, fare: Number(trip.fare), estimatedMiles: Number(trip.estimatedMiles) });
  } catch (err) {
    req.log.error({ err }, "Failed to create trip");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/rideshare/trips/:id/status", async (req, res) => {
  try {
    const { status } = req.body;
    const [trip] = await db.update(rideshareTripsTable)
      .set({ status })
      .where(eq(rideshareTripsTable.id, Number(req.params.id)))
      .returning();
    res.json({ ...trip, fare: trip.fare ? Number(trip.fare) : null });
  } catch (err) {
    req.log.error({ err }, "Failed to update trip status");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/rideshare/stats", async (_req, res) => {
  try {
    const trips = await db.select().from(rideshareTripsTable);
    const completed = trips.filter(t => t.status === "completed").length;
    const revenue = trips.filter(t => t.status === "completed").reduce((s, t) => s + Number(t.fare || 0), 0);
    res.json({ totalTrips: trips.length, completedTrips: completed, revenue, activeDrivers: 12 });
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
