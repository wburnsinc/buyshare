import { Router } from "express";
import { db } from "@workspace/db";
import { paymentsTable, invoicesTable } from "@workspace/db";

const router = Router();

router.get("/payments", async (_req, res) => {
  try {
    const payments = await db.select().from(paymentsTable).orderBy(paymentsTable.createdAt);
    res.json(payments.map(p => ({
      ...p,
      amount: Number(p.amount),
      createdAt: p.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list payments");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/payments/summary", async (_req, res) => {
  try {
    res.json({
      totalSpent: 1245.00,
      totalEarned: 28450.00,
      pendingPayouts: 1200.00,
      credits: 250.00,
      thisMonthSpent: 279.00,
      thisMonthEarned: 4500.00,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get payment summary");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/invoices", async (_req, res) => {
  try {
    const invoices = await db.select().from(invoicesTable).orderBy(invoicesTable.createdAt);
    res.json(invoices.map(i => ({
      ...i,
      amount: Number(i.amount),
      createdAt: i.createdAt.toISOString(),
      paidAt: i.paidAt ? i.paidAt.toISOString() : null,
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list invoices");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
