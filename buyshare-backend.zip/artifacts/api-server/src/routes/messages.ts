import { Router } from "express";
import { db } from "@workspace/db";
import { conversationsTable, messagesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/messages", async (_req, res) => {
  try {
    const convos = await db.select().from(conversationsTable).orderBy(conversationsTable.lastMessageAt);
    res.json(convos.map(c => ({
      ...c,
      lastMessageAt: c.lastMessageAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list conversations");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/messages/:conversationId", async (req, res) => {
  try {
    const id = parseInt(req.params.conversationId);
    const msgs = await db.select().from(messagesTable).where(eq(messagesTable.conversationId, id)).orderBy(messagesTable.sentAt);
    res.json(msgs.map(m => ({ ...m, sentAt: m.sentAt.toISOString() })));
  } catch (err) {
    req.log.error({ err }, "Failed to get messages");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/messages/:conversationId", async (req, res) => {
  try {
    const conversationId = parseInt(req.params.conversationId);
    const [msg] = await db.insert(messagesTable).values({
      conversationId,
      senderId: 1,
      senderName: "You",
      content: req.body.content,
      isOwn: true,
    }).returning();
    // Update conversation last message
    await db.update(conversationsTable).set({
      lastMessage: req.body.content,
      lastMessageAt: new Date(),
    }).where(eq(conversationsTable.id, conversationId));
    res.status(201).json({ ...msg, sentAt: msg.sentAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to send message");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
