import { Router } from "express";
import { db } from "@workspace/db";
import { shareListingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/share/listings", async (req, res) => {
  try {
    const listings = await db.select().from(shareListingsTable).orderBy(shareListingsTable.createdAt);
    const filtered = req.query.category
      ? listings.filter(l => l.category === req.query.category)
      : listings;
    res.json(filtered.map(l => ({
      ...l,
      price: Number(l.price),
      rating: Number(l.rating),
      createdAt: l.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list share listings");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/share/listings", async (req, res) => {
  try {
    const [listing] = await db.insert(shareListingsTable).values({
      title: req.body.title,
      category: req.body.category,
      description: req.body.description,
      price: req.body.price,
      priceUnit: req.body.priceUnit,
      location: req.body.location,
      zipCode: req.body.zipCode,
      hostName: "Host",
      amenities: req.body.amenities ?? [],
      available: true,
    }).returning();
    res.status(201).json({ ...listing, price: Number(listing.price), rating: Number(listing.rating), createdAt: listing.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create share listing");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/share/listings/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [listing] = await db.select().from(shareListingsTable).where(eq(shareListingsTable.id, id));
    if (!listing) return res.status(404).json({ error: "Not found" });
    res.json({ ...listing, price: Number(listing.price), rating: Number(listing.rating), createdAt: listing.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get share listing");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/share/categories", async (_req, res) => {
  res.json([
    { name: "Pools", slug: "pools", listingCount: 24, iconName: "Waves", description: "Private pools and pool access" },
    { name: "Homes", slug: "homes", listingCount: 31, iconName: "Home", description: "Vacation homes and rental properties" },
    { name: "Boats", slug: "boats", listingCount: 18, iconName: "Anchor", description: "Boats and watercraft rentals" },
    { name: "Parking", slug: "parking", listingCount: 42, iconName: "ParkingCircle", description: "Parking spots and garages" },
    { name: "Yards", slug: "yards", listingCount: 15, iconName: "Leaf", description: "Yards and outdoor spaces" },
    { name: "RVs", slug: "rvs", listingCount: 9, iconName: "Truck", description: "RVs and campers" },
  ]);
});

export default router;
