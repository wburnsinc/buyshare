import { Router } from "express";
import { db } from "@workspace/db";
import { leadsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { count } from "drizzle-orm";

const router = Router();

router.get("/burncall/leads", async (req, res) => {
  try {
    const leads = await db.select().from(leadsTable).orderBy(leadsTable.createdAt);
    const filtered = req.query.status
      ? leads.filter(l => l.status === req.query.status)
      : leads;
    res.json(filtered.map(l => ({
      ...l,
      estimatedValue: l.estimatedValue ? Number(l.estimatedValue) : null,
      createdAt: l.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to list leads");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/burncall/leads", async (req, res) => {
  try {
    const [lead] = await db.insert(leadsTable).values({
      name: req.body.name,
      phone: req.body.phone,
      email: req.body.email,
      serviceType: req.body.serviceType,
      message: req.body.message,
      source: req.body.source,
      zipCode: req.body.zipCode,
      status: "new",
      aiSummary: `New ${req.body.serviceType} inquiry from ${req.body.name}. Follow up within 1 hour.`,
      estimatedValue: "850",
    }).returning();
    res.status(201).json({ ...lead, estimatedValue: Number(lead.estimatedValue), createdAt: lead.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create lead");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/burncall/leads/summary", async (_req, res) => {
  try {
    const leads = await db.select().from(leadsTable);
    const newLeads = leads.filter(l => l.status === "new");
    const qualified = leads.filter(l => l.status === "qualified");
    const booked = leads.filter(l => l.status === "booked");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const newToday = leads.filter(l => l.createdAt >= today).length;
    res.json({
      totalLeads: leads.length,
      newToday,
      qualified: qualified.length,
      booked: booked.length,
      conversionRate: leads.length > 0 ? booked.length / leads.length : 0,
      estimatedRevenue: booked.length * 850,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get lead summary");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
