import { db } from "@workspace/db";
import {
  servicesTable, contractorsTable, bookingsTable, shareListingsTable,
  leadsTable, growthMetricsTable, conversationsTable, messagesTable,
  paymentsTable, invoicesTable, usersTable,
} from "@workspace/db";

async function seed() {
  console.log("Seeding database...");

  // Users
  await db.insert(usersTable).values([
    { name: "Demo User", email: "demo@buyshare.co", role: "customer", credits: "250", phone: "941-555-0001" },
  ]).onConflictDoNothing();

  // Services
  await db.insert(servicesTable).values([
    { name: "Lawn Care", category: "Lawn Care", description: "Professional lawn mowing, edging, and cleanup.", basePrice: "45", priceUnit: "visit", iconName: "Leaf", contractorCount: 12 },
    { name: "Pool Services", category: "Pool Services", description: "Full-service pool care — chemicals, cleaning, and maintenance.", basePrice: "99", priceUnit: "mo", iconName: "Droplets", contractorCount: 8 },
    { name: "Pool + Lawn Bundle", category: "Pool Services", description: "Pool and lawn care combo — best value.", basePrice: "180", priceUnit: "mo", iconName: "Droplets", contractorCount: 5 },
    { name: "Local Delivery", category: "Delivery", description: "Flat-rate hauling and delivery services.", basePrice: "75", priceUnit: "job", iconName: "Truck", contractorCount: 4 },
    { name: "HVAC Services", category: "HVAC", description: "Heating, ventilation, and air conditioning installation and repair.", basePrice: "125", priceUnit: "hr", iconName: "Wind", contractorCount: 18 },
    { name: "Plumbing", category: "Plumbing", description: "All plumbing repairs, installations, and emergencies.", basePrice: "95", priceUnit: "hr", iconName: "Wrench", contractorCount: 14 },
    { name: "Electrical", category: "Electrical", description: "Licensed electrical services for residential and commercial.", basePrice: "110", priceUnit: "hr", iconName: "Zap", contractorCount: 11 },
    { name: "Cleaning", category: "Cleaning", description: "Professional home and office cleaning services.", basePrice: "85", priceUnit: "visit", iconName: "Sparkles", contractorCount: 22 },
    { name: "Painting", category: "Painting", description: "Interior and exterior painting with premium finishes.", basePrice: "350", priceUnit: "room", iconName: "Paintbrush", contractorCount: 9 },
    { name: "Roofing", category: "Roofing", description: "Roof repair, replacement, and inspection services.", basePrice: "450", priceUnit: "job", iconName: "Home", contractorCount: 7 },
    { name: "Handyman", category: "Handyman", description: "General repairs, installations, and home improvements.", basePrice: "75", priceUnit: "hr", iconName: "Hammer", contractorCount: 16 },
    { name: "Construction", category: "Construction", description: "Full construction, renovation, and remodeling.", basePrice: "85", priceUnit: "hr", iconName: "Hammer", contractorCount: 6 },
  ]).onConflictDoNothing();

  // Contractors
  await db.insert(contractorsTable).values([
    { name: "Layton Martinez", company: "Layton's Lawn Care", email: "layton@laytonlawn.com", phone: "941-555-0101", categories: ["Lawn Care"], serviceAreas: ["Punta Gorda", "Port Charlotte"], rating: "4.9", reviewCount: 47, jobsCompleted: 312, verified: true, status: "active", earnings: "14500", bio: "Local teen entrepreneur delivering $45/visit lawn care. Serving Punta Gorda and Port Charlotte." },
    { name: "Mike Torres", company: "Torres HVAC Solutions", email: "mike@torreshvac.com", phone: "941-555-0102", categories: ["HVAC", "Electrical"], serviceAreas: ["Port Charlotte", "Deep Creek", "North Port"], rating: "4.8", reviewCount: 89, jobsCompleted: 521, verified: true, status: "active", earnings: "67200", bio: "15+ years HVAC experience. Licensed and insured. Same-day service available." },
    { name: "Sarah Perkins", company: "Sparkling Clean FL", email: "sarah@sparklingclean.com", phone: "941-555-0103", categories: ["Cleaning", "Handyman"], serviceAreas: ["Punta Gorda", "Charlotte Harbor", "Burnt Store"], rating: "5.0", reviewCount: 134, jobsCompleted: 789, verified: true, status: "active", earnings: "42300", bio: "Residential and vacation rental cleaning specialist with 5-star reviews." },
    { name: "David Chen", company: "Chen Plumbing & Electric", email: "david@chenpe.com", phone: "941-555-0104", categories: ["Plumbing", "Electrical"], serviceAreas: ["Port Charlotte", "Punta Gorda", "North Port"], rating: "4.7", reviewCount: 62, jobsCompleted: 283, verified: true, status: "active", earnings: "31800" },
    { name: "Roberto Vega", company: "Vega Construction", email: "roberto@vegaconstruction.com", phone: "941-555-0105", categories: ["Construction", "Roofing", "Painting"], serviceAreas: ["All Southwest Florida"], rating: "4.9", reviewCount: 45, jobsCompleted: 198, verified: true, status: "active", earnings: "89400" },
    { name: "Janet Williams", company: "Williams Pool Care", email: "janet@williamspool.com", phone: "941-555-0106", categories: ["Pool Services"], serviceAreas: ["Punta Gorda", "Burnt Store", "Port Charlotte"], rating: "4.8", reviewCount: 78, jobsCompleted: 456, verified: true, status: "active", earnings: "38900" },
    { name: "Tom Hargrove", company: "Hargrove Handyman", email: "tom@hargrovehandyman.com", phone: "941-555-0107", categories: ["Handyman", "Painting", "Cleaning"], serviceAreas: ["Deep Creek", "North Port", "Port Charlotte"], rating: "4.6", reviewCount: 33, jobsCompleted: 156, verified: false, status: "active", earnings: "12400" },
    { name: "Ana Rodriguez", company: "Rodriguez Roofing", email: "ana@rodriguezroofing.com", phone: "941-555-0108", categories: ["Roofing", "Construction"], serviceAreas: ["Charlotte Harbor", "Port Charlotte", "Punta Gorda"], rating: "4.9", reviewCount: 21, jobsCompleted: 88, verified: true, status: "active", earnings: "45600" },
  ]).onConflictDoNothing();

  // Bookings
  await db.insert(bookingsTable).values([
    { serviceId: 1, serviceName: "Lawn Care", customerId: 1, contractorId: 1, contractorName: "Layton Martinez", status: "completed", scheduledDate: "2026-06-10", scheduledTime: "9:00 AM", address: "123 Tamiami Trl", zipCode: "33950", price: "45", notes: "Front and back yard" },
    { serviceId: 2, serviceName: "Pool Services", customerId: 1, contractorId: 6, contractorName: "Janet Williams", status: "confirmed", scheduledDate: "2026-06-28", scheduledTime: "7:00 AM", address: "123 Tamiami Trl", zipCode: "33950", price: "99", isRecurring: true, recurringFrequency: "monthly" },
    { serviceId: 5, serviceName: "HVAC Services", customerId: 1, contractorId: 2, contractorName: "Mike Torres", status: "pending", scheduledDate: "2026-07-02", scheduledTime: "11:00 AM", address: "123 Tamiami Trl", zipCode: "33950", price: "250" },
    { serviceId: 8, serviceName: "Cleaning", customerId: 1, contractorId: 3, contractorName: "Sarah Perkins", status: "assigned", scheduledDate: "2026-06-30", scheduledTime: "9:00 AM", address: "123 Tamiami Trl", zipCode: "33950", price: "120" },
    { serviceId: 1, serviceName: "Lawn Care", customerId: 1, contractorId: 1, contractorName: "Layton Martinez", status: "completed", scheduledDate: "2026-05-20", scheduledTime: "9:00 AM", address: "123 Tamiami Trl", zipCode: "33950", price: "45" },
  ]).onConflictDoNothing();

  // SHARE Listings
  await db.insert(shareListingsTable).values([
    { title: "Luxury Pool & Lanai — Punta Gorda", category: "pools", description: "Crystal clear heated pool with sun shelf, full lanai, seating for 12. Perfect for family gatherings.", price: "150", priceUnit: "day", location: "Punta Gorda, FL", zipCode: "33950", hostName: "The Johnson Family", rating: "4.9", reviewCount: 34, amenities: ["Heated", "Sun Shelf", "Lanai", "Parking", "WiFi"] },
    { title: "Waterfront Home — Charlotte Harbor", category: "homes", description: "3BR/2BA waterfront home with private dock. Breathtaking views, fully furnished.", price: "285", priceUnit: "night", location: "Charlotte Harbor, FL", zipCode: "33980", hostName: "Harbor Stay LLC", rating: "4.8", reviewCount: 22, amenities: ["Dock", "Waterfront", "Fully Furnished", "Kayaks", "Parking"] },
    { title: "25ft Sea Ray Bowrider", category: "boats", description: "Stunning bowrider perfect for coastal cruising. Life jackets and basic gear included.", price: "320", priceUnit: "day", location: "Port Charlotte, FL", zipCode: "33952", hostName: "Dave's Marine Rentals", rating: "5.0", reviewCount: 18, amenities: ["Life Jackets", "Cooler", "Fuel Included", "Safety Kit"] },
    { title: "Covered RV Parking — Deep Creek", category: "parking", description: "Secure covered parking space for RV, boat, or trailer. 24/7 access, gated community.", price: "85", priceUnit: "month", location: "Deep Creek, FL", zipCode: "33983", hostName: "Martinez Family", rating: "4.7", reviewCount: 8, amenities: ["Covered", "Gated", "24/7 Access", "Security Camera"] },
    { title: "Private Backyard Oasis — North Port", category: "yards", description: "Large private yard with fire pit, outdoor kitchen, and string lights. Perfect for events.", price: "95", priceUnit: "day", location: "North Port, FL", zipCode: "34286", hostName: "The Reyes Family", rating: "4.6", reviewCount: 11, amenities: ["Fire Pit", "Outdoor Kitchen", "String Lights", "Restroom Access"] },
    { title: "Class A Motorhome — Burnt Store", category: "rvs", description: "Fully equipped 38ft Class A motorhome. Full hookups, slides out, theater seating.", price: "195", priceUnit: "night", location: "Burnt Store, FL", zipCode: "33955", hostName: "Campbell Adventures", rating: "4.8", reviewCount: 14, amenities: ["Full Hookups", "Slides", "Generator", "Fully Stocked"] },
    { title: "Pool & Spa Combo — Port Charlotte", category: "pools", description: "Saltwater pool with heated spa. Grill and outdoor furniture included.", price: "175", priceUnit: "day", location: "Port Charlotte, FL", zipCode: "33948", hostName: "Garcia Family", rating: "4.9", reviewCount: 28, amenities: ["Saltwater", "Heated Spa", "Grill", "Outdoor Furniture"] },
    { title: "Gulf Access Pontoon Boat", category: "boats", description: "22ft pontoon perfect for family fun on the water. Up to 10 passengers.", price: "250", priceUnit: "day", location: "Charlotte Harbor, FL", zipCode: "33980", hostName: "Sunshine Boat Club", rating: "4.7", reviewCount: 31, amenities: ["Gulf Access", "10 Passengers", "Bluetooth Speaker", "Cooler"] },
  ]).onConflictDoNothing();

  // Leads
  await db.insert(leadsTable).values([
    { name: "Patricia Davidson", phone: "941-555-2001", email: "patricia@email.com", serviceType: "Pool Services", message: "Need weekly pool maintenance for my 3BR home in Punta Gorda.", status: "booked", source: "phone", aiSummary: "Interested in monthly pool care plan. Budget around $100/mo. Has existing pool equipment.", estimatedValue: "1188", zipCode: "33950" },
    { name: "Carl Washington", phone: "941-555-2002", email: "carl@email.com", serviceType: "HVAC Services", message: "AC isn't cooling properly. Need someone ASAP.", status: "contacted", source: "sms", aiSummary: "Emergency HVAC situation. Unit may need refrigerant recharge or capacitor replacement. Urgency: high.", estimatedValue: "450", zipCode: "33952" },
    { name: "Maria Santos", phone: "941-555-2003", serviceType: "Lawn Care", message: "Looking for weekly lawn service for my property.", status: "new", source: "website", aiSummary: "New lead for recurring lawn care service. Has 1/4 acre lot.", estimatedValue: "2340", zipCode: "33983" },
    { name: "James Kowalski", phone: "941-555-2004", email: "jkowalski@email.com", serviceType: "Cleaning", message: "Need house cleaning service for vacation rental turnover.", status: "qualified", source: "referral", aiSummary: "Vacation rental turnover cleaning needed bi-weekly. High-value recurring client potential.", estimatedValue: "5200", zipCode: "33950" },
    { name: "Betty Harmon", phone: "941-555-2005", serviceType: "Handyman", message: "Several small repairs needed around the house. Fence, deck, and gutters.", status: "new", source: "phone", aiSummary: "Multiple handyman tasks. Fence repair, deck boards, gutter cleaning. Estimated 8 hours of work.", estimatedValue: "600", zipCode: "33980" },
    { name: "Steve Nguyen", phone: "941-555-2006", serviceType: "Pool Services", message: "New homeowner. Need someone to set up my pool chemistry and maintenance plan.", status: "new", source: "website", aiSummary: "New homeowner wanting pool setup and monthly maintenance. High conversion likelihood.", estimatedValue: "1188", zipCode: "33955" },
  ]).onConflictDoNothing();

  // Growth Metrics (investor data)
  await db.insert(growthMetricsTable).values([
    { month: "Jan", bookings: 42, revenue: "15800", contractors: 28, customers: 156 },
    { month: "Feb", bookings: 58, revenue: "21200", contractors: 31, customers: 198 },
    { month: "Mar", bookings: 87, revenue: "33400", contractors: 38, customers: 267 },
    { month: "Apr", bookings: 124, revenue: "47800", contractors: 45, customers: 342 },
    { month: "May", bookings: 178, revenue: "68900", contractors: 52, customers: 431 },
    { month: "Jun", bookings: 234, revenue: "91200", contractors: 61, customers: 518 },
  ]).onConflictDoNothing();

  // Conversations
  await db.insert(conversationsTable).values([
    { participant1Id: 1, participant2Id: 2, participantName: "Layton Martinez", participantRole: "Contractor — Lawn Care", lastMessage: "I'll be there at 9am sharp. Gate code still 1234?", lastMessageAt: new Date(Date.now() - 30 * 60000), unreadCount: 1 },
    { participant1Id: 1, participant2Id: 3, participantName: "Sarah Perkins", participantRole: "Contractor — Cleaning", lastMessage: "Your home is all cleaned up! Left invoice in the app.", lastMessageAt: new Date(Date.now() - 2 * 3600000), unreadCount: 0 },
    { participant1Id: 1, participant2Id: 6, participantName: "BuyShare Support", participantRole: "Platform Support", lastMessage: "Your issue has been resolved. Is there anything else?", lastMessageAt: new Date(Date.now() - 24 * 3600000), unreadCount: 0 },
  ]).onConflictDoNothing();

  // Messages
  await db.insert(messagesTable).values([
    { conversationId: 1, senderId: 2, senderName: "Layton Martinez", content: "Hi! Just confirming your lawn appointment for tomorrow.", isOwn: false },
    { conversationId: 1, senderId: 1, senderName: "You", content: "Yes, please! Gate code is 1234.", isOwn: true },
    { conversationId: 1, senderId: 2, senderName: "Layton Martinez", content: "I'll be there at 9am sharp. Gate code still 1234?", isOwn: false },
    { conversationId: 2, senderId: 3, senderName: "Sarah Perkins", content: "Just arrived and getting started!", isOwn: false },
    { conversationId: 2, senderId: 1, senderName: "You", content: "Thanks, Sarah! Extra attention to the kitchen please.", isOwn: true },
    { conversationId: 2, senderId: 3, senderName: "Sarah Perkins", content: "Your home is all cleaned up! Left invoice in the app.", isOwn: false },
  ]).onConflictDoNothing();

  // Payments
  await db.insert(paymentsTable).values([
    { amount: "45.00", description: "Lawn Care — Layton's Lawn Care", status: "completed", type: "charge" },
    { amount: "99.00", description: "Monthly Pool Care — Janet Williams", status: "completed", type: "charge" },
    { amount: "120.00", description: "House Cleaning — Sarah Perkins", status: "completed", type: "charge" },
    { amount: "1200.00", description: "Contractor Payout — Layton Martinez", status: "completed", type: "payout" },
    { amount: "250.00", description: "BuyShare Credits", status: "completed", type: "credit" },
    { amount: "279.00", description: "HVAC Services — Mike Torres (pending)", status: "pending", type: "charge" },
  ]).onConflictDoNothing();

  // Invoices
  await db.insert(invoicesTable).values([
    { bookingId: 1, amount: "45.00", status: "paid", dueDate: "2026-06-15", description: "Lawn Care Service — June 10" },
    { bookingId: 2, amount: "99.00", status: "paid", dueDate: "2026-06-20", description: "Monthly Pool Care — June" },
    { bookingId: 4, amount: "120.00", status: "sent", dueDate: "2026-07-05", description: "House Cleaning — June 30" },
    { bookingId: 3, amount: "279.00", status: "draft", dueDate: "2026-07-10", description: "HVAC Service — July 2" },
  ]).onConflictDoNothing();

  console.log("Seed complete!");
  process.exit(0);
}

seed().catch(err => {
  console.error("Seed failed:", err);
  process.exit(1);
});
