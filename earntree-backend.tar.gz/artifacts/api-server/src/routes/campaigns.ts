import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, campaignsTable, businessesTable, shareEventsTable, trackingLinksTable } from "@workspace/db";
import { eq, and, desc, count, sql } from "drizzle-orm";
import { nanoid } from "nanoid";

const router = Router();

// GET /campaigns - user feed with matching scores
router.get("/campaigns", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);

  let userId: number | null = null;
  if (clerkId) {
    const [u] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
    if (u) userId = u.id;
  }

  const limit = Math.min(Number(req.query.limit) || 20, 50);
  const offset = Number(req.query.offset) || 0;
  const category = req.query.category as string | undefined;
  const userState = req.query.state as string | undefined;

  let query = db.select({
    campaign: campaignsTable,
    businessName: businessesTable.name,
    businessLogoUrl: businessesTable.logoUrl,
  }).from(campaignsTable)
    .leftJoin(businessesTable, eq(campaignsTable.businessId, businessesTable.id))
    .where(eq(campaignsTable.status, "active"))
    .$dynamic();

  const campaigns = await query.orderBy(desc(campaignsTable.createdAt)).limit(limit).offset(offset);

  // Check which campaigns user has already shared
  const sharedCampaignIds = new Set<number>();
  if (userId) {
    const shared = await db.select({ campaignId: shareEventsTable.campaignId })
      .from(shareEventsTable)
      .where(eq(shareEventsTable.userId, userId));
    shared.forEach(s => { if (s.campaignId) sharedCampaignIds.add(s.campaignId); });
  }

  const result = campaigns.map(({ campaign: c, businessName, businessLogoUrl }) => {
    // Simple matching score
    let matchScore = 0.5;
    let reason = "Popular campaign in your region";
    if (userState && c.state === userState) {
      matchScore += 0.3;
      reason = `Recommended because it serves ${c.city} and nearby areas.`;
    }

    return {
      id: c.id,
      businessId: c.businessId,
      businessName: businessName ?? "Local Business",
      businessLogoUrl: businessLogoUrl ?? null,
      title: c.title,
      description: c.description,
      status: c.status,
      rewardAmount: Number(c.rewardAmount),
      category: c.category,
      city: c.city,
      state: c.state,
      zip: c.zip ?? null,
      serviceRadius: c.serviceRadius ? Number(c.serviceRadius) : null,
      landingPageUrl: c.landingPageUrl ?? null,
      ctaText: c.ctaText ?? null,
      imageUrl: c.imageUrl ?? null,
      weeklyBudget: Number(c.weeklyBudget),
      budgetRemaining: Math.max(0, Number(c.weeklyBudget) - Number(c.budgetSpent)),
      estimatedVerificationHours: c.estimatedVerificationHours,
      startDate: c.startDate,
      endDate: c.endDate,
      createdAt: c.createdAt.toISOString(),
      recommendationReason: reason,
      matchScore,
      shareCount: c.shareCount,
      clickCount: c.clickCount,
      userHasShared: userId ? sharedCampaignIds.has(c.id) : false,
    };
  });

  res.json({ campaigns: result, total: result.length });
});

// GET /campaigns/:id
router.get("/campaigns/:id", async (req, res): Promise<void> => {
  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const [row] = await db.select({
    campaign: campaignsTable,
    businessName: businessesTable.name,
    businessLogoUrl: businessesTable.logoUrl,
  }).from(campaignsTable)
    .leftJoin(businessesTable, eq(campaignsTable.businessId, businessesTable.id))
    .where(eq(campaignsTable.id, id));

  if (!row) { res.status(404).json({ error: "Campaign not found" }); return; }

  const c = row.campaign;
  res.json({
    id: c.id,
    businessId: c.businessId,
    businessName: row.businessName ?? "Local Business",
    businessLogoUrl: row.businessLogoUrl ?? null,
    title: c.title,
    description: c.description,
    status: c.status,
    rewardAmount: Number(c.rewardAmount),
    category: c.category,
    city: c.city,
    state: c.state,
    zip: c.zip ?? null,
    serviceRadius: c.serviceRadius ? Number(c.serviceRadius) : null,
    landingPageUrl: c.landingPageUrl ?? null,
    ctaText: c.ctaText ?? null,
    imageUrl: c.imageUrl ?? null,
    weeklyBudget: Number(c.weeklyBudget),
    budgetRemaining: Math.max(0, Number(c.weeklyBudget) - Number(c.budgetSpent)),
    estimatedVerificationHours: c.estimatedVerificationHours,
    startDate: c.startDate,
    endDate: c.endDate,
    createdAt: c.createdAt.toISOString(),
    recommendationReason: null,
    matchScore: null,
    shareCount: c.shareCount,
    clickCount: c.clickCount,
    userHasShared: false,
  });
});

// POST /campaigns/:id/share
router.post("/campaigns/:id/share", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const campaignId = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const { shareChannel } = req.body;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [campaign] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, campaignId));
  if (!campaign) { res.status(404).json({ error: "Campaign not found" }); return; }

  const code = nanoid(12);

  const [link] = await db.insert(trackingLinksTable).values({
    userId: user.id,
    campaignId,
    code,
    destinationUrl: campaign.landingPageUrl ?? `https://earntree.co`,
  }).returning();

  const [event] = await db.insert(shareEventsTable).values({
    userId: user.id,
    campaignId,
    trackingLinkId: link.id,
    shareChannel,
    status: "recorded",
    rewardStatus: "pending",
  }).returning();

  // Increment campaign share count
  await db.update(campaignsTable).set({ shareCount: sql`${campaignsTable.shareCount} + 1` }).where(eq(campaignsTable.id, campaignId));

  const trackingUrl = `${process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}` : "http://localhost"}/api/t/${code}`;

  res.status(201).json({
    id: event.id,
    campaignId: event.campaignId ?? campaignId,
    shareChannel: event.shareChannel,
    trackingCode: code,
    trackingUrl,
    status: event.status,
    rewardStatus: event.rewardStatus ?? null,
    createdAt: event.createdAt.toISOString(),
  });
});

// GET /t/:code — tracked link redirect
router.get("/t/:code", async (req, res): Promise<void> => {
  const code = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
  const [link] = await db.select().from(trackingLinksTable).where(eq(trackingLinksTable.code, code));

  if (!link) {
    res.redirect("https://earntree.co");
    return;
  }

  await db.update(trackingLinksTable).set({ clickCount: sql`${trackingLinksTable.clickCount} + 1` }).where(eq(trackingLinksTable.id, link.id));
  if (link.campaignId) {
    await db.update(campaignsTable).set({ clickCount: sql`${campaignsTable.clickCount} + 1` }).where(eq(campaignsTable.id, link.campaignId));
  }

  res.redirect(link.destinationUrl);
});

// GET /share-history
router.get("/share-history", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const offset = Number(req.query.offset) || 0;

  const events = await db.select().from(shareEventsTable)
    .where(eq(shareEventsTable.userId, user.id))
    .orderBy(desc(shareEventsTable.createdAt))
    .limit(limit).offset(offset);

  const [{ total }] = await db.select({ total: count() }).from(shareEventsTable).where(eq(shareEventsTable.userId, user.id));

  const baseUrl = process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}` : "http://localhost";

  const result = await Promise.all(events.map(async (e) => {
    let trackingCode = "";
    let trackingUrl = "";
    if (e.trackingLinkId) {
      const [link] = await db.select().from(trackingLinksTable).where(eq(trackingLinksTable.id, e.trackingLinkId));
      if (link) {
        trackingCode = link.code;
        trackingUrl = `${baseUrl}/api/t/${link.code}`;
      }
    }
    return {
      id: e.id,
      campaignId: e.campaignId ?? null,
      shareChannel: e.shareChannel,
      trackingCode,
      trackingUrl,
      status: e.status,
      rewardStatus: e.rewardStatus ?? null,
      createdAt: e.createdAt.toISOString(),
    };
  }));

  res.json({ events: result, total });
});

// GET /business/campaigns
router.get("/business/campaigns", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const campaigns = await db.select().from(campaignsTable)
    .where(eq(campaignsTable.businessId, biz.id))
    .orderBy(desc(campaignsTable.createdAt));

  const result = campaigns.map(c => ({
    id: c.id,
    businessId: c.businessId,
    businessName: biz.name,
    businessLogoUrl: biz.logoUrl ?? null,
    title: c.title,
    description: c.description,
    status: c.status,
    rewardAmount: Number(c.rewardAmount),
    category: c.category,
    city: c.city,
    state: c.state,
    zip: c.zip ?? null,
    serviceRadius: c.serviceRadius ? Number(c.serviceRadius) : null,
    landingPageUrl: c.landingPageUrl ?? null,
    ctaText: c.ctaText ?? null,
    imageUrl: c.imageUrl ?? null,
    weeklyBudget: Number(c.weeklyBudget),
    budgetRemaining: Math.max(0, Number(c.weeklyBudget) - Number(c.budgetSpent)),
    estimatedVerificationHours: c.estimatedVerificationHours,
    startDate: c.startDate,
    endDate: c.endDate,
    createdAt: c.createdAt.toISOString(),
    recommendationReason: null,
    matchScore: null,
    shareCount: c.shareCount,
    clickCount: c.clickCount,
    userHasShared: false,
  }));

  res.json({ campaigns: result, total: result.length });
});

// POST /business/campaigns
router.post("/business/campaigns", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const { title, description, category, city, state, zip, serviceRadius, landingPageUrl, ctaText, imageUrl, rewardAmount, weeklyBudget, startDate, endDate, targetAudience } = req.body;

  const [campaign] = await db.insert(campaignsTable).values({
    businessId: biz.id,
    title,
    description,
    category,
    city,
    state,
    zip,
    serviceRadius,
    landingPageUrl,
    ctaText,
    imageUrl,
    rewardAmount: String(rewardAmount ?? "0.25"),
    weeklyBudget: String(weeklyBudget ?? "50"),
    startDate,
    endDate,
    targetAudience,
    status: "pending",
  }).returning();

  res.status(201).json({
    id: campaign.id,
    businessId: campaign.businessId,
    businessName: biz.name,
    businessLogoUrl: biz.logoUrl ?? null,
    title: campaign.title,
    description: campaign.description,
    status: campaign.status,
    rewardAmount: Number(campaign.rewardAmount),
    category: campaign.category,
    city: campaign.city,
    state: campaign.state,
    zip: campaign.zip ?? null,
    serviceRadius: campaign.serviceRadius ? Number(campaign.serviceRadius) : null,
    landingPageUrl: campaign.landingPageUrl ?? null,
    ctaText: campaign.ctaText ?? null,
    imageUrl: campaign.imageUrl ?? null,
    weeklyBudget: Number(campaign.weeklyBudget),
    budgetRemaining: Number(campaign.weeklyBudget),
    estimatedVerificationHours: campaign.estimatedVerificationHours,
    startDate: campaign.startDate,
    endDate: campaign.endDate,
    createdAt: campaign.createdAt.toISOString(),
  });
});

// GET /business/campaigns/:id
router.get("/business/campaigns/:id", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);

  const [campaign] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!campaign) { res.status(404).json({ error: "Not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.id, campaign.businessId));

  res.json({
    id: campaign.id,
    businessId: campaign.businessId,
    businessName: biz?.name ?? "Business",
    businessLogoUrl: biz?.logoUrl ?? null,
    title: campaign.title,
    description: campaign.description,
    status: campaign.status,
    rewardAmount: Number(campaign.rewardAmount),
    category: campaign.category,
    city: campaign.city,
    state: campaign.state,
    zip: campaign.zip ?? null,
    serviceRadius: campaign.serviceRadius ? Number(campaign.serviceRadius) : null,
    landingPageUrl: campaign.landingPageUrl ?? null,
    ctaText: campaign.ctaText ?? null,
    imageUrl: campaign.imageUrl ?? null,
    weeklyBudget: Number(campaign.weeklyBudget),
    budgetRemaining: Math.max(0, Number(campaign.weeklyBudget) - Number(campaign.budgetSpent)),
    estimatedVerificationHours: campaign.estimatedVerificationHours,
    startDate: campaign.startDate,
    endDate: campaign.endDate,
    createdAt: campaign.createdAt.toISOString(),
    shareCount: campaign.shareCount,
    clickCount: campaign.clickCount,
    recommendationReason: null,
    matchScore: null,
    userHasShared: false,
  });
});

// PUT /business/campaigns/:id
router.put("/business/campaigns/:id", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const { title, description, category, city, state, zip, serviceRadius, landingPageUrl, ctaText, imageUrl, rewardAmount, weeklyBudget, startDate, endDate } = req.body;

  const [updated] = await db.update(campaignsTable).set({
    title, description, category, city, state, zip, serviceRadius,
    landingPageUrl, ctaText, imageUrl,
    rewardAmount: String(rewardAmount),
    weeklyBudget: String(weeklyBudget),
    startDate, endDate,
  }).where(and(eq(campaignsTable.id, id), eq(campaignsTable.businessId, biz.id))).returning();

  if (!updated) { res.status(404).json({ error: "Campaign not found" }); return; }

  res.json({
    id: updated.id, businessId: updated.businessId, businessName: biz.name,
    businessLogoUrl: biz.logoUrl ?? null, title: updated.title, description: updated.description,
    status: updated.status, rewardAmount: Number(updated.rewardAmount), category: updated.category,
    city: updated.city, state: updated.state, zip: updated.zip ?? null,
    serviceRadius: updated.serviceRadius ? Number(updated.serviceRadius) : null,
    landingPageUrl: updated.landingPageUrl ?? null, ctaText: updated.ctaText ?? null,
    imageUrl: updated.imageUrl ?? null, weeklyBudget: Number(updated.weeklyBudget),
    budgetRemaining: Math.max(0, Number(updated.weeklyBudget) - Number(updated.budgetSpent)),
    estimatedVerificationHours: updated.estimatedVerificationHours,
    startDate: updated.startDate, endDate: updated.endDate, createdAt: updated.createdAt.toISOString(),
  });
});

// PATCH /business/campaigns/:id/status
router.patch("/business/campaigns/:id/status", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const { status } = req.body;
  const [updated] = await db.update(campaignsTable).set({ status })
    .where(and(eq(campaignsTable.id, id), eq(campaignsTable.businessId, biz.id))).returning();

  if (!updated) { res.status(404).json({ error: "Campaign not found" }); return; }

  res.json({ id: updated.id, status: updated.status, title: updated.title, businessId: updated.businessId,
    businessName: biz.name, businessLogoUrl: biz.logoUrl ?? null, description: updated.description,
    rewardAmount: Number(updated.rewardAmount), category: updated.category, city: updated.city, state: updated.state,
    zip: updated.zip ?? null, serviceRadius: updated.serviceRadius ? Number(updated.serviceRadius) : null,
    landingPageUrl: updated.landingPageUrl ?? null, ctaText: updated.ctaText ?? null, imageUrl: updated.imageUrl ?? null,
    weeklyBudget: Number(updated.weeklyBudget), budgetRemaining: Number(updated.weeklyBudget),
    estimatedVerificationHours: updated.estimatedVerificationHours, startDate: updated.startDate, endDate: updated.endDate,
    createdAt: updated.createdAt.toISOString(),
  });
});

// GET /business/campaigns/:id/analytics
router.get("/business/campaigns/:id/analytics", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);

  const [campaign] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!campaign) { res.status(404).json({ error: "Not found" }); return; }

  const shares = await db.select({ channel: shareEventsTable.shareChannel }).from(shareEventsTable)
    .where(eq(shareEventsTable.campaignId, id));

  const channelMap = new Map<string, number>();
  shares.forEach(s => { channelMap.set(s.channel, (channelMap.get(s.channel) ?? 0) + 1); });

  const sharesByChannel = Array.from(channelMap.entries()).map(([channel, count]) => ({ channel, count }));
  const totalSpend = Number(campaign.budgetSpent);
  const totalShares = campaign.shareCount;
  const totalClicks = campaign.clickCount;

  res.json({
    campaignId: id,
    totalShares,
    totalClicks,
    totalConversions: campaign.conversionCount,
    totalSpend,
    costPerShare: totalShares > 0 ? totalSpend / totalShares : 0,
    costPerClick: totalClicks > 0 ? totalSpend / totalClicks : 0,
    sharesByChannel,
    sharesByDay: [],
    topLocations: [],
  });
});

export default router;
