import { Router } from "express";
import { getAuth, clerkClient } from "@clerk/express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import { logger } from "../lib/logger";

const router = Router();

router.get("/auth/me", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  let [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));

  if (!user) {
    // Auto-create user from Clerk
    try {
      const clerkUser = await clerkClient.users.getUser(clerkId);
      const email = clerkUser.emailAddresses[0]?.emailAddress ?? "";
      const name = `${clerkUser.firstName ?? ""} ${clerkUser.lastName ?? ""}`.trim() || email;
      const avatarUrl = clerkUser.imageUrl;
      const referralCode = nanoid(8).toUpperCase();

      const [created] = await db.insert(usersTable).values({
        clerkId,
        email,
        name,
        avatarUrl,
        referralCode,
        role: "user",
      }).returning();
      user = created;
    } catch (err) {
      req.log.error({ err }, "Failed to create user from Clerk");
      res.status(500).json({ error: "Failed to create user" });
      return;
    }
  }

  res.json({
    id: user.id,
    clerkId: user.clerkId,
    email: user.email,
    name: user.name,
    avatarUrl: user.avatarUrl,
    referralCode: user.referralCode,
    role: user.role,
    city: user.city,
    state: user.state,
    zip: user.zip,
    lat: user.lat ? Number(user.lat) : null,
    lng: user.lng ? Number(user.lng) : null,
    networkActivated: user.networkActivated,
    isFrozen: user.isFrozen,
    createdAt: user.createdAt.toISOString(),
  });
});

router.put("/auth/profile", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { name, city, state, zip, lat, lng } = req.body;

  const [user] = await db.update(usersTable)
    .set({ name, city, state, zip, lat, lng })
    .where(eq(usersTable.clerkId, clerkId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json({
    id: user.id,
    clerkId: user.clerkId,
    email: user.email,
    name: user.name,
    avatarUrl: user.avatarUrl,
    referralCode: user.referralCode,
    role: user.role,
    city: user.city,
    state: user.state,
    zip: user.zip,
    lat: user.lat ? Number(user.lat) : null,
    lng: user.lng ? Number(user.lng) : null,
    networkActivated: user.networkActivated,
    isFrozen: user.isFrozen,
    createdAt: user.createdAt.toISOString(),
  });
});

export default router;
