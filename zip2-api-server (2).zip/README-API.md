# Buyshare.co — API Server

## Stack
- Node.js 20 + TypeScript (compiled to ESM)
- Express 4
- PostgreSQL (pg driver)
- JWT auth (jsonwebtoken + bcryptjs)
- Stripe payments
- Resend email
- OpenAI GPT

## Install & Run
```bash
pnpm install
pnpm --filter @workspace/api-server run dev  # dev (auto-restart)
pnpm --filter @workspace/api-server run build && node dist/index.mjs  # production
```

## Route Structure
- `src/routes/auth.ts` — /api/auth/* (register, login, me)
- `src/routes/modules/burncall.ts` — /api/burncall/* + /api/burncall/public/*
- `src/routes/modules/earntree.ts` — /api/earntree/*
- `src/routes/modules/pocketcash.ts` — /api/pocketcash/*
- `src/routes/bluecertified.ts` — /api/bluecertified/*
- `src/routes/propconnect.ts` — /api/propconnect/*
- `src/routes/podcast.ts` — /api/podcast/*
- `src/routes/admin/` — /api/admin/* (requireMasterAdmin)

## Environment Variables Required
See .env.example in ZIP 6 (Deployment Package)

## Health Check
GET /health → 200 {"status":"ok","db":"connected"}
