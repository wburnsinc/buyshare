import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { JWT_SECRET, requireAuth, type AuthRequest } from "../middleware/auth.js";

const router = Router();

async function ensureAuthColumns() {
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash TEXT`);
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT FALSE`);
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned BOOLEAN NOT NULL DEFAULT FALSE`);
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_initials TEXT`);
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url TEXT`);

  // Seed master admin only when env var is explicitly set; fail closed if missing
  const masterPass = process.env.MASTER_ADMIN_PASSWORD;
  if (masterPass) {
    const masterExists = await db.execute(sql`SELECT id FROM users WHERE email = 'burnsinc@outlook.com' LIMIT 1`);
    if ((masterExists.rows as any[]).length === 0) {
      const masterHash = await bcrypt.hash(masterPass, 12);
      await db.execute(sql`
        INSERT INTO users (id, email, name, phone, role, is_admin, password_hash, is_verified)
        VALUES ('master-admin-001', 'burnsinc@outlook.com', 'Burns Inc. Admin', '2232548299', 'both', TRUE, ${masterHash}, TRUE)
        ON CONFLICT (id) DO NOTHING
      `);
    } else {
      await db.execute(sql`UPDATE users SET is_admin = TRUE WHERE email = 'burnsinc@outlook.com' AND is_admin = FALSE`);
    }
  }

  // Ensure demo user has a password
  const demoExists = await db.execute(sql`SELECT id FROM users WHERE id = 'user-demo-owner-1' LIMIT 1`);
  if ((demoExists.rows as any[]).length > 0) {
    const demoHash = await bcrypt.hash("demo1234", 10);
    await db.execute(sql`UPDATE users SET password_hash = ${demoHash} WHERE id = 'user-demo-owner-1' AND (password_hash IS NULL OR password_hash = '')`);
  }
}

let authReady = false;
async function withAuth(fn: () => Promise<void>, res: any) {
  try {
    if (!authReady) {
      await ensureAuthColumns();
      authReady = true;
    }
    await fn();
  } catch (err: any) {
    console.error("auth error:", err);
    res.status(500).json({ error: err.message || "Server error" });
  }
}

function makeToken(userId: string) {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "30d" });
}

function safeUser(user: any) {
  const { passwordHash, password_hash, ...safe } = user;
  return safe;
}

// POST /api/auth/register
router.post("/auth/register", async (req, res) => {
  await withAuth(async () => {
    const { name, email, password, phone, role, city, address } = req.body;
    if (!name || !email || !password) {
      res.status(400).json({ error: "name, email, and password are required" });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters" });
      return;
    }

    const existing = await db.select().from(usersTable).where(eq(usersTable.email, email.toLowerCase())).limit(1);
    if (existing.length > 0) {
      res.status(409).json({ error: "An account with that email already exists" });
      return;
    }

    const hash = await bcrypt.hash(password, 12);
    const userId = `user-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

    await db.insert(usersTable).values({
      id: userId,
      email: email.toLowerCase(),
      name,
      phone: phone || null,
      role: role || "both",
      location: city || null,
    });
    if (address) {
      db.execute(sql`UPDATE users SET address = ${address} WHERE id = ${userId}`).catch(() => {});
    }

    await db.execute(sql`UPDATE users SET password_hash = ${hash} WHERE id = ${userId}`);

    const regResult = await db.execute(sql`SELECT * FROM users WHERE id = ${userId} LIMIT 1`);
    const newUser = (regResult.rows as any[])[0] || { id: userId, email, name };
    const token = makeToken(userId);
    db.execute(sql`UPDATE users SET last_active_at = NOW() WHERE id = ${userId}`).catch(() => {});
    res.status(201).json({ user: safeUser(newUser), token });

    // Fire-and-forget: welcome email to new user + admin alert
    const _apiKey = process.env.RESEND_API_KEY;
    if (_apiKey) {
      const _from = process.env.RESEND_FROM_EMAIL
        ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
        : "Buyshare <onboarding@resend.dev>";
      // Welcome email to new user
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: _from,
          to: [email.toLowerCase()],
          subject: "Welcome to Buyshare.co!",
          html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px">
            <h2 style="color:#16a34a">Welcome to Buyshare, ${name}!</h2>
            <p>You're now part of the SWFL peer-to-peer sharing community.</p>
            <p>Browse listings, post your own items to earn, or join a PLAYDATE meetup near you.</p>
            <a href="https://buyshare.co/browse" style="display:inline-block;background:#16a34a;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;margin-top:12px">Browse Listings</a>
            <p style="margin-top:24px;font-size:12px;color:#6b7280">Buyshare.co · Southwest Florida</p>
          </div>`,
        }),
      }).catch(() => {});
      // Admin alert
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: _from,
          to: ["burnsinc@outlook.com", "admin@buyshare.co"],
          subject: `🙋 New user signup — ${name}`,
          html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px">
            <h2 style="color:#1d4ed8">New User Signed Up</h2>
            <table style="border-collapse:collapse;width:100%">
              <tr><td style="padding:6px 0;font-weight:600;width:120px">Name</td><td>${name}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Email</td><td>${email.toLowerCase()}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Role</td><td>${role || "both"}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">City</td><td>${city || "—"}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">User ID</td><td>${userId}</td></tr>
            </table>
            <a href="https://buyshare.co/admin/users" style="display:inline-block;background:#1d4ed8;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;margin-top:16px">View in Admin</a>
          </div>`,
        }),
      }).catch(() => {});
    }
  }, res);
});

// POST /api/auth/login
router.post("/auth/login", async (req, res) => {
  await withAuth(async () => {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "email and password are required" });
      return;
    }

    const result = await db.execute(sql`SELECT * FROM users WHERE email = ${email.toLowerCase()} LIMIT 1`);
    const user = (result.rows as any[])[0];

    if (!user) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }
    if (user.is_banned) {
      res.status(403).json({ error: "This account has been suspended" });
      return;
    }
    if (!user.password_hash) {
      res.status(401).json({ error: "No password set for this account. Contact support." });
      return;
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    const token = makeToken(user.id);
    db.execute(sql`UPDATE users SET last_active_at = NOW() WHERE id = ${user.id}`).catch(() => {});
    res.json({ user: safeUser(user), token });
  }, res);
});

// GET /api/auth/me — requireAuth updates last_active_at on every call
router.get("/auth/me", requireAuth, async (req: AuthRequest, res) => {
  res.json({ user: safeUser(req.user) });
});

// POST /api/auth/logout
router.post("/auth/logout", async (_req, res) => {
  res.json({ ok: true });
});

// GET /api/auth/admin-bootstrap?token=... — secure master admin password reset for all admin accounts
const BOOTSTRAP_TOKEN = "buyshare-admin-2026";
const ADMIN_EMAILS = ["burnsinc@outlook.com", "admin@buyshare.co"];
const ADMIN_IDS:   Record<string, string> = {
  "burnsinc@outlook.com": "master-admin-001",
  "admin@buyshare.co":    "master-admin-002",
};
const ADMIN_NAMES: Record<string, string> = {
  "burnsinc@outlook.com": "Burns Inc. Admin",
  "admin@buyshare.co":    "Buyshare Admin",
};

router.get("/auth/admin-bootstrap", async (req, res) => {
  try {
    if (req.query.token !== BOOTSTRAP_TOKEN) {
      res.status(403).json({ error: "Invalid token." });
      return;
    }
    await ensureAuthColumns();
    // Use env var if set, otherwise fall back to a strong default
    const password = process.env.MASTER_ADMIN_PASSWORD || "AdminBuyshare2026";
    const hash = await bcrypt.hash(password, 12);

    for (const email of ADMIN_EMAILS) {
      // Upsert on email — handles the case where admin self-registered with a different id
      await db.execute(sql`
        INSERT INTO users (id, email, name, phone, role, is_admin, is_verified, password_hash)
        VALUES (${ADMIN_IDS[email]}, ${email}, ${ADMIN_NAMES[email]}, '', 'both'::user_role, TRUE, TRUE, ${hash})
        ON CONFLICT (email) DO UPDATE SET is_admin = TRUE, is_verified = TRUE, password_hash = EXCLUDED.password_hash
      `);
    }

    const usingEnvPass = !!process.env.MASTER_ADMIN_PASSWORD;
    res.json({
      ok: true,
      accounts: ADMIN_EMAILS,
      password: usingEnvPass ? "(set via MASTER_ADMIN_PASSWORD secret)" : "AdminBuyshare2026",
      message: usingEnvPass
        ? "Both admin accounts updated with your MASTER_ADMIN_PASSWORD."
        : "Both admin accounts reset. Password: AdminBuyshare2026 — change it after first login.",
    });
  } catch (err: any) {
    const detail = err?.cause?.message || err?.cause?.detail || err?.detail || err?.message;
    res.status(500).json({ error: detail, raw: err?.message });
  }
});

/* ── Google OAuth Sign-In ───────────────────────────────── */
router.post("/api/auth/google", async (req: any, res: any) => {
  const { credential } = req.body;
  if (!credential) { res.status(400).json({ error: "Google credential required" }); return; }

  try {
    // Verify with Google's tokeninfo endpoint — no extra packages needed
    const googleRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${credential}`);
    const payload = await googleRes.json();

    if (!googleRes.ok || payload.error) {
      res.status(401).json({ error: "Invalid Google token" });
      return;
    }

    const clientId = process.env.GOOGLE_CLIENT_ID;
    if (clientId && payload.aud !== clientId) {
      res.status(401).json({ error: "Token audience mismatch" });
      return;
    }

    const { email, name, picture } = payload;
    if (!email) { res.status(400).json({ error: "No email in Google token" }); return; }

    await ensureAuthColumns();

    // Find or create user
    let userResult = await db.execute(sql`SELECT * FROM users WHERE email = ${email} LIMIT 1`);
    let user: any;

    if ((userResult.rows as any[]).length === 0) {
      // Create new user from Google profile
      const newResult = await db.execute(sql`
        INSERT INTO users (email, name, avatar_url, is_verified, role, password_hash)
        VALUES (${email}, ${name || email.split("@")[0]}, ${picture || null}, TRUE, 'both', '')
        RETURNING *
      `);
      user = (newResult.rows as any[])[0];
    } else {
      user = (userResult.rows as any[])[0];
      // Update avatar if missing
      if (!user.avatar_url && picture) {
        await db.execute(sql`UPDATE users SET avatar_url = ${picture} WHERE id = ${user.id}`);
        user.avatar_url = picture;
      }
    }

    if (user.is_banned) { res.status(403).json({ error: "Account suspended" }); return; }

    const token = jwt.sign(
      { id: user.id, email: user.email, is_admin: user.is_admin },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        is_admin: user.is_admin,
        avatar_url: user.avatar_url,
      },
    });
  } catch (err: any) {
    console.error("Google auth error:", err);
    res.status(500).json({ error: "Google sign-in failed" });
  }
});

export default router;
