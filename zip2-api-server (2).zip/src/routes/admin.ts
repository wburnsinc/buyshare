import { Router } from "express";
import { db, pool } from "@workspace/db";
import { usersTable, listingsTable, bookingsTable, reviewsTable } from "@workspace/db";
import { eq, sql, desc, count } from "drizzle-orm";
import { requireMasterAdmin, AuthRequest } from "../middleware/auth.js";
import { stripe } from "../lib/stripe.js";

const router = Router();

// ── AUDIT LOG HELPER ───────────────────────────────────
async function initAuditLog() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS audit_log (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      admin_email TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

export async function logAudit(adminEmail: string, action: string, targetType: string, targetId: string, details: string) {
  try {
    await initAuditLog();
    await db.execute(sql`
      INSERT INTO audit_log (admin_email, action, target_type, target_id, details)
      VALUES (${adminEmail}, ${action}, ${targetType}, ${targetId}, ${details})
    `);
  } catch {}
}

// ── STATS ──────────────────────────────────────────────
router.get("/admin/stats", requireMasterAdmin, async (_req, res) => {
  try {
    const [users] = await db.select({ count: count() }).from(usersTable);
    const [listings] = await db.select({ count: count() }).from(listingsTable);
    const [bookings] = await db.select({ count: count() }).from(bookingsTable);

    const revenueResult = await db.execute(sql`
      SELECT COALESCE(SUM(platform_fee_cents), 0) as total_revenue FROM bookings WHERE status IN ('completed', 'active')
    `);

    const shareListingsResult = await db.execute(sql`SELECT COUNT(*) as count FROM share_listings`).catch(() => ({ rows: [{ count: 0 }] }));
    const shareBookingsResult = await db.execute(sql`SELECT COUNT(*) as count FROM share_bookings`).catch(() => ({ rows: [{ count: 0 }] }));
    const recentUsersResult = await db.execute(sql`
      SELECT id, name, email, role, is_verified, is_admin, created_at FROM users ORDER BY created_at DESC LIMIT 5
    `);
    const recentBookingsResult = await db.execute(sql`
      SELECT b.id, b.status, b.total_charge_cents, b.start_date, b.end_date,
             l.title as listing_title, b.renter_id, b.owner_id
      FROM bookings b LEFT JOIN listings l ON b.listing_id = l.id
      ORDER BY b.created_at DESC LIMIT 5
    `).catch(() => ({ rows: [] }));

    res.json({
      users: Number(users.count),
      listings: Number(listings.count),
      bookings: Number(bookings.count),
      revenue: Number((revenueResult.rows as any[])[0]?.total_revenue || 0),
      shareListings: Number((shareListingsResult.rows as any[])[0]?.count || 0),
      shareBookings: Number((shareBookingsResult.rows as any[])[0]?.count || 0),
      recentUsers: recentUsersResult.rows,
      recentBookings: recentBookingsResult.rows,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── USERS ──────────────────────────────────────────────
async function ensureLastActiveColumn() {
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMPTZ`).catch(() => {});
}

router.get("/admin/users", requireMasterAdmin, async (req, res) => {
  try {
    await ensureSubCancelColumn();
    await ensureLastActiveColumn();
    const { search, role, verified, sortBy, inactiveDays, neverActive } = req.query as any;
    const searchTerm = search ? `%${search}%` : null;
    const inactiveDaysNum = inactiveDays ? parseInt(inactiveDays, 10) : null;
    const orderClause = sortBy === "last_active"
      ? sql`ORDER BY u.last_active_at DESC NULLS LAST`
      : sql`ORDER BY u.created_at DESC`;
    const result = await db.execute(sql`
      SELECT u.*,
        (SELECT COUNT(*) FROM listings WHERE owner_id = u.id) as listing_count,
        (SELECT COUNT(*) FROM bookings WHERE renter_id = u.id OR owner_id = u.id) as booking_count,
        s.tier as sub_tier,
        s.status as sub_status,
        s.cancel_at_period_end as sub_canceling,
        s.current_period_end as sub_period_end
      FROM users u
      LEFT JOIN LATERAL (
        SELECT tier, status, cancel_at_period_end, current_period_end
        FROM subscriptions
        WHERE email = u.email AND status IN ('active','trialing')
        ORDER BY created_at DESC LIMIT 1
      ) s ON TRUE
      WHERE 1=1
      ${searchTerm ? sql`AND (u.name ILIKE ${searchTerm} OR u.email ILIKE ${searchTerm})` : sql``}
      ${role ? sql`AND u.role = ${role}` : sql``}
      ${verified === "true" ? sql`AND u.is_verified = TRUE` : sql``}
      ${verified === "false" ? sql`AND u.is_verified = FALSE` : sql``}
      ${neverActive === "true" ? sql`AND u.last_active_at IS NULL` : sql``}
      ${inactiveDaysNum && neverActive !== "true" ? sql`AND (u.last_active_at IS NULL OR u.last_active_at < NOW() - (${inactiveDaysNum} || ' days')::INTERVAL)` : sql``}
      ${orderClause}
      LIMIT 200
    `);
    res.json({ users: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/users/export", requireMasterAdmin, async (_req, res) => {
  try {
    await ensureLastActiveColumn();
    const result = await db.execute(sql`
      SELECT u.name, u.email, u.role, u.created_at, u.last_active_at
      FROM users u
      ORDER BY u.created_at DESC
    `);
    const rows = result.rows as any[];
    const escape = (v: any) => {
      if (v === null || v === undefined) return "";
      const s = String(v);
      if (s.includes(",") || s.includes('"') || s.includes("\n")) return `"${s.replace(/"/g, '""')}"`;
      return s;
    };
    const header = "Name,Email,Role,Joined Date,Last Active";
    const lines = rows.map(u => [
      escape(u.name),
      escape(u.email),
      escape(u.role),
      escape(u.created_at ? new Date(u.created_at).toISOString().split("T")[0] : ""),
      escape(u.last_active_at ? new Date(u.last_active_at).toISOString().split("T")[0] : "Never"),
    ].join(","));
    const csv = [header, ...lines].join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", 'attachment; filename="users.csv"');
    res.send(csv);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/users/:id/bookings", requireMasterAdmin, async (req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT b.*, l.title as listing_title
      FROM bookings b
      LEFT JOIN listings l ON b.listing_id = l.id
      WHERE b.renter_id = ${req.params.id} OR b.owner_id = ${req.params.id}
      ORDER BY b.created_at DESC LIMIT 50
    `);
    res.json({ bookings: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function ensureUserExtColumns() {
  await db.execute(sql`
    ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT FALSE;
  `).catch(() => {});
  await db.execute(sql`
    ALTER TABLE users ADD COLUMN IF NOT EXISTS is_verified BOOLEAN NOT NULL DEFAULT FALSE;
  `).catch(() => {});
  await db.execute(sql`
    ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned BOOLEAN NOT NULL DEFAULT FALSE;
  `).catch(() => {});
  await db.execute(sql`
    ALTER TABLE users ADD COLUMN IF NOT EXISTS subscription_tier TEXT NOT NULL DEFAULT 'free';
  `).catch(() => {});
  await db.execute(sql`
    ALTER TABLE users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();
  `).catch(() => {});
}

let userExtReady = false;
async function withUserExt(fn: () => Promise<void>) {
  if (!userExtReady) { await ensureUserExtColumns(); userExtReady = true; }
  return fn();
}

router.patch("/admin/users/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await withUserExt(async () => {});
    const { isAdmin, isVerified, isBanned, role, name, email, phone, bio, avatarUrl, subscriptionTier } = req.body;
    const sets: string[] = [];
    const params: any[] = [req.params.id];
    if (isAdmin !== undefined) { params.push(isAdmin); sets.push(`is_admin = $${params.length}`); }
    if (isVerified !== undefined) { params.push(isVerified); sets.push(`is_verified = $${params.length}`); }
    if (isBanned !== undefined) { params.push(isBanned); sets.push(`is_banned = $${params.length}`); }
    if (role !== undefined) { params.push(role); sets.push(`role = $${params.length}`); }
    if (name !== undefined) { params.push(name); sets.push(`name = $${params.length}`); }
    if (email !== undefined) { params.push(email); sets.push(`email = $${params.length}`); }
    if (phone !== undefined) { params.push(phone); sets.push(`phone = $${params.length}`); }
    if (bio !== undefined) { params.push(bio); sets.push(`bio = $${params.length}`); }
    if (avatarUrl !== undefined) { params.push(avatarUrl); sets.push(`avatar_url = $${params.length}`); }
    if (subscriptionTier !== undefined) { params.push(subscriptionTier); sets.push(`subscription_tier = $${params.length}`); }
    if (sets.length === 0) { res.json({ ok: true }); return; }
    const q = `UPDATE users SET ${sets.join(", ")} WHERE id = $1 RETURNING *`;
    const result = await pool.query(q, params);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "user", req.params.id, `Updated fields: ${Object.keys(req.body).join(", ")}`);
    res.json({ user: (result.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/users/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const adminEmail = (req as any).user?.email || "admin";
    await db.execute(sql`DELETE FROM users WHERE id = ${req.params.id}`);
    await logAudit(adminEmail, "delete", "user", req.params.id, "User account deleted");
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── LISTINGS ───────────────────────────────────────────
router.get("/admin/listings", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT l.*, u.name as owner_name, u.email as owner_email
      FROM listings l LEFT JOIN users u ON l.owner_id = u.id
      ORDER BY l.created_at DESC LIMIT 200
    `);
    res.json({ listings: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function ensureListingsPinned() {
  await db.execute(sql`ALTER TABLE listings ADD COLUMN IF NOT EXISTS pinned BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE listings ADD COLUMN IF NOT EXISTS featured BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
}

router.patch("/admin/listings/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureListingsPinned();
    const { status, title, description, category, dailyRate, weekendRate, weeklyRate, location, ownerId, featured, pinned } = req.body;
    const sets: string[] = ["updated_at = NOW()"];
    const params: any[] = [req.params.id];
    const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
    add(status, "status");
    add(title, "title");
    add(description, "description");
    add(category, "category");
    add(dailyRate, "daily_rate");
    add(weekendRate, "weekend_rate");
    add(weeklyRate, "weekly_rate");
    add(location, "location");
    add(ownerId, "owner_id");
    add(featured, "featured");
    add(pinned, "pinned");
    const q = `UPDATE listings SET ${sets.join(", ")} WHERE id = $1 RETURNING *`;
    const result = await pool.query(q, params);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "listing", req.params.id, `Updated: ${Object.keys(req.body).join(", ")}`);
    res.json({ listing: (result.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/listings/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const adminEmail = (req as any).user?.email || "admin";
    await db.execute(sql`DELETE FROM listings WHERE id = ${req.params.id}`);
    await logAudit(adminEmail, "delete", "listing", req.params.id, "Listing deleted by admin");
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── SHARE LISTINGS ─────────────────────────────────────
router.get("/admin/share-listings", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`SELECT * FROM share_listings ORDER BY created_at DESC LIMIT 200`);
    res.json({ listings: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function ensureShareListingsFeatured() {
  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS featured BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
}

router.patch("/admin/share-listings/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureShareListingsFeatured();
    const { status, title, description, share_type, price_per_hour, price_per_day, city, address, host_name, featured } = req.body;
    const sets: string[] = [];
    const params: any[] = [req.params.id];
    const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
    add(status, "status");
    add(title, "title");
    add(description, "description");
    add(share_type, "share_type");
    const ph = price_per_hour === "" ? null : price_per_hour !== undefined ? Number(price_per_hour) : undefined;
    const pd = price_per_day === "" ? null : price_per_day !== undefined ? Number(price_per_day) : undefined;
    if (ph !== undefined && ph !== null && isNaN(ph)) { res.status(400).json({ error: "Invalid price_per_hour" }); return; }
    if (pd !== undefined && pd !== null && isNaN(pd)) { res.status(400).json({ error: "Invalid price_per_day" }); return; }
    add(ph, "price_per_hour");
    add(pd, "price_per_day");
    add(city, "city");
    add(address, "address");
    add(host_name, "host_name");
    add(featured, "featured");
    if (sets.length === 0) { res.json({ ok: true }); return; }
    const q = `UPDATE share_listings SET ${sets.join(", ")} WHERE id = $1 RETURNING *`;
    const result = await pool.query(q, params);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "share_listing", String(req.params.id), `Updated: ${Object.keys(req.body).join(", ")}`);
    res.json({ listing: (result.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/share-listings/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const adminEmail = (req as any).user?.email || "admin";
    await db.execute(sql`DELETE FROM share_listings WHERE id = ${req.params.id}`);
    await logAudit(adminEmail, "delete", "share_listing", String(req.params.id), "Share listing deleted by admin");
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── BOOKINGS ───────────────────────────────────────────
router.get("/admin/bookings", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT b.*, l.title as listing_title,
        r.name as renter_name, r.email as renter_email,
        o.name as owner_name, o.email as owner_email
      FROM bookings b
      LEFT JOIN listings l ON b.listing_id = l.id
      LEFT JOIN users r ON b.renter_id = r.id
      LEFT JOIN users o ON b.owner_id = o.id
      ORDER BY b.created_at DESC LIMIT 200
    `);
    res.json({ bookings: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/bookings/:id/status", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { status } = req.body;
    await db.execute(sql`UPDATE bookings SET status = ${status} WHERE id = ${req.params.id}`);
    const adminEmail = req.user?.email || "admin";
    await logAudit(adminEmail, "update", "booking", req.params.id, `Status → ${status}`);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/share-bookings", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT sb.*, sl.title as listing_title, sl.share_type
      FROM share_bookings sb
      LEFT JOIN share_listings sl ON sb.listing_id = sl.id
      ORDER BY sb.created_at DESC LIMIT 200
    `);
    res.json({ bookings: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/share-bookings/:id/status", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { status } = req.body;
    await db.execute(sql`UPDATE share_bookings SET status = ${status} WHERE id = ${req.params.id}`);
    const adminEmail = req.user?.email || "admin";
    await logAudit(adminEmail, "update", "share_booking", req.params.id, `Status → ${status}`);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── CONTRACTORS ─────────────────────────────────────────
async function ensureContractorsTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractors (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      business_name TEXT,
      services TEXT,
      zip_code TEXT,
      bio TEXT,
      license_number TEXT,
      years_experience INTEGER,
      hourly_rate INTEGER,
      subscription_status TEXT DEFAULT 'none',
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS hourly_rate INTEGER`).catch(() => {});
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT 'none'`).catch(() => {});
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()`).catch(() => {});
}

router.get("/admin/contractors", requireMasterAdmin, async (_req, res) => {
  try {
    await ensureContractorsTable();
    const result = await db.execute(sql`SELECT * FROM contractors ORDER BY created_at DESC LIMIT 500`);
    res.json({ contractors: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/contractors/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureContractorsTable();
    const { status, name, email, phone, business_name, services, zip_code, bio, license_number, years_experience, hourly_rate, subscription_status } = req.body;
    const sets: string[] = ["updated_at = NOW()"];
    const params: any[] = [req.params.id];
    const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
    add(status, "status");
    add(name, "name");
    add(email, "email");
    add(phone, "phone");
    add(business_name, "business_name");
    add(services !== undefined ? (typeof services === "string" ? services : JSON.stringify(services)) : undefined, "services");
    add(zip_code, "zip_code");
    add(bio, "bio");
    add(license_number, "license_number");
    add(years_experience, "years_experience");
    add(hourly_rate, "hourly_rate");
    add(subscription_status, "subscription_status");
    const q = `UPDATE contractors SET ${sets.join(", ")} WHERE id = $1 RETURNING *`;
    const result = await pool.query(q, params);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "contractor", req.params.id, `Updated: ${Object.keys(req.body).join(", ")}`);
    res.json({ contractor: (result.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/contractors/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureContractorsTable();
    const adminEmail = (req as any).user?.email || "admin";
    await db.execute(sql`DELETE FROM contractors WHERE id = ${req.params.id}`);
    await logAudit(adminEmail, "delete", "contractor", req.params.id, "Contractor deleted by admin");
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── BULK ACTIONS ────────────────────────────────────────

router.post("/admin/users/bulk", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { action, ids } = req.body as { action: string; ids: string[] };
    if (!Array.isArray(ids) || ids.length === 0) { res.status(400).json({ error: "No ids provided" }); return; }
    await withUserExt(async () => {});
    const adminEmail = (req as any).user?.email || "admin";
    if (action === "ban") {
      await db.execute(sql`UPDATE users SET is_banned = TRUE WHERE id = ANY(${ids}::text[])`);
    } else if (action === "unban") {
      await db.execute(sql`UPDATE users SET is_banned = FALSE WHERE id = ANY(${ids}::text[])`);
    } else if (action === "delete") {
      await db.execute(sql`DELETE FROM users WHERE id = ANY(${ids}::text[])`);
    } else {
      res.status(400).json({ error: "Unknown action" }); return;
    }
    await logAudit(adminEmail, `bulk_${action}`, "user", ids.join(","), `Bulk ${action} on ${ids.length} users: [${ids.join(", ")}]`);
    res.json({ ok: true, count: ids.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/listings/bulk", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { action, ids } = req.body as { action: string; ids: string[] };
    if (!Array.isArray(ids) || ids.length === 0) { res.status(400).json({ error: "No ids provided" }); return; }
    const adminEmail = (req as any).user?.email || "admin";
    if (action === "approve") {
      await db.execute(sql`UPDATE listings SET status = 'available', updated_at = NOW() WHERE id = ANY(${ids}::text[])`);
    } else if (action === "remove") {
      await db.execute(sql`UPDATE listings SET status = 'unavailable', updated_at = NOW() WHERE id = ANY(${ids}::text[])`);
    } else if (action === "delete") {
      await db.execute(sql`DELETE FROM listings WHERE id = ANY(${ids}::text[])`);
    } else {
      res.status(400).json({ error: "Unknown action" }); return;
    }
    await logAudit(adminEmail, `bulk_${action}`, "listing", ids.join(","), `Bulk ${action} on ${ids.length} listings: [${ids.join(", ")}]`);
    res.json({ ok: true, count: ids.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/share-listings/bulk", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { action, ids } = req.body as { action: string; ids: string[] };
    if (!Array.isArray(ids) || ids.length === 0) { res.status(400).json({ error: "No ids provided" }); return; }
    const adminEmail = (req as any).user?.email || "admin";
    if (action === "approve") {
      await db.execute(sql`UPDATE share_listings SET status = 'active' WHERE id = ANY(${ids}::int[])`);
    } else if (action === "remove") {
      await db.execute(sql`UPDATE share_listings SET status = 'inactive' WHERE id = ANY(${ids}::int[])`);
    } else if (action === "delete") {
      await db.execute(sql`DELETE FROM share_listings WHERE id = ANY(${ids}::int[])`);
    } else {
      res.status(400).json({ error: "Unknown action" }); return;
    }
    await logAudit(adminEmail, `bulk_${action}`, "share_listing", ids.join(","), `Bulk ${action} on ${ids.length} share listings: [${ids.join(", ")}]`);
    res.json({ ok: true, count: ids.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/contractors/bulk", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureContractorsTable();
    const { action, ids } = req.body as { action: string; ids: string[] };
    if (!Array.isArray(ids) || ids.length === 0) { res.status(400).json({ error: "No ids provided" }); return; }
    const adminEmail = (req as any).user?.email || "admin";
    if (action === "approve") {
      await db.execute(sql`UPDATE contractors SET status = 'approved', updated_at = NOW() WHERE id = ANY(${ids}::text[])`);
    } else if (action === "reject") {
      await db.execute(sql`UPDATE contractors SET status = 'rejected', updated_at = NOW() WHERE id = ANY(${ids}::text[])`);
    } else if (action === "delete") {
      await db.execute(sql`DELETE FROM contractors WHERE id = ANY(${ids}::text[])`);
    } else {
      res.status(400).json({ error: "Unknown action" }); return;
    }
    await logAudit(adminEmail, `bulk_${action}`, "contractor", ids.join(","), `Bulk ${action} on ${ids.length} contractors: [${ids.join(", ")}]`);
    res.json({ ok: true, count: ids.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── THRIFT LISTINGS BULK ────────────────────────────────
router.post("/admin/thrift-listings/bulk", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { action, ids } = req.body as { action: string; ids: string[] };
    if (!Array.isArray(ids) || ids.length === 0) { res.status(400).json({ error: "No ids provided" }); return; }
    const adminEmail = (req as any).user?.email || "admin";
    if (action === "approve") {
      await db.execute(sql`UPDATE thrift_listings SET status = 'available' WHERE id = ANY(${ids}::text[])`);
    } else if (action === "remove") {
      await db.execute(sql`UPDATE thrift_listings SET status = 'removed' WHERE id = ANY(${ids}::text[])`);
    } else if (action === "delete") {
      await db.execute(sql`DELETE FROM thrift_listings WHERE id = ANY(${ids}::text[])`);
    } else {
      res.status(400).json({ error: "Unknown action" }); return;
    }
    await logAudit(adminEmail, `bulk_${action}`, "thrift_listing", ids.join(","), `Bulk ${action} on ${ids.length} thrift listings: [${ids.join(", ")}]`);
    res.json({ ok: true, count: ids.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── SERVICES ───────────────────────────────────────────
const DEFAULT_SERVICES = [
  { id: "pool_cleaning", name: "Monthly Pool Care", provider: "BlueTruck LLC", description: "Weekly pool maintenance — chemicals, filter cleaning, equipment checks.", price: 9900, unit: "/mo", active: true },
  { id: "lawn_care", name: "Lawn Care", provider: "Layton's Lawncare / BlueTruck LLC", description: "Mow, edge, trim, and cleanup. Per visit service.", price: 4500, unit: "/visit", active: true },
  { id: "pool_lawn_bundle", name: "Pool + Lawn Bundle", provider: "BlueTruck LLC", description: "Weekly pool care + weekly lawn maintenance. Save 15%.", price: 18000, unit: "/mo", active: true },
  { id: "handyman", name: "Handyman Services", provider: "BlueTruck LLC", description: "Licensed & insured handyman. First hour includes assessment.", price: 7500, unit: "/hr", active: true },
];

async function ensureServicesTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS services (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      provider TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      price INTEGER NOT NULL DEFAULT 0,
      unit TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    )
  `);
  const existing = await db.execute(sql`SELECT id FROM services LIMIT 1`);
  if ((existing.rows as any[]).length === 0) {
    for (const svc of DEFAULT_SERVICES) {
      await db.execute(sql`
        INSERT INTO services (id, name, provider, description, price, unit, active)
        VALUES (${svc.id}, ${svc.name}, ${svc.provider}, ${svc.description}, ${svc.price}, ${svc.unit}, ${svc.active ? 1 : 0})
      `);
    }
  }
}

router.get("/admin/services", requireMasterAdmin, async (_req, res) => {
  try {
    await ensureServicesTable();
    const result = await db.execute(sql`SELECT * FROM services ORDER BY id`);
    const services = (result.rows as any[]).map(r => ({ ...r, active: Boolean(r.active) }));
    res.json({ services });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/services/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureServicesTable();
    const existing = await db.execute(sql`SELECT * FROM services WHERE id = ${req.params.id}`);
    if ((existing.rows as any[]).length === 0) { res.status(404).json({ error: "Service not found" }); return; }
    const { name, description, price, unit, active, provider } = req.body;
    const row: any = { ...(existing.rows as any[])[0] };
    if (name !== undefined) row.name = name;
    if (description !== undefined) row.description = description;
    if (price !== undefined) row.price = Number(price);
    if (unit !== undefined) row.unit = unit;
    if (active !== undefined) row.active = active ? 1 : 0;
    if (provider !== undefined) row.provider = provider;
    await db.execute(sql`
      UPDATE services SET name = ${row.name}, provider = ${row.provider}, description = ${row.description},
        price = ${row.price}, unit = ${row.unit}, active = ${row.active}
      WHERE id = ${req.params.id}
    `);
    const adminEmail = req.user?.email || "admin";
    await logAudit(adminEmail, "update", "service", req.params.id, `Updated: ${Object.keys(req.body).join(", ")}`);
    res.json({ service: { ...row, active: Boolean(row.active) } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── REVIEWS ────────────────────────────────────────────
router.get("/admin/reviews", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT r.*, u.name as reviewer_name, l.title as listing_title
      FROM reviews r
      LEFT JOIN users u ON r.reviewer_id = u.id
      LEFT JOIN listings l ON r.listing_id = l.id
      ORDER BY r.created_at DESC LIMIT 200
    `);
    res.json({ reviews: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/reviews/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await db.execute(sql`DELETE FROM reviews WHERE id = ${req.params.id}`);
    const adminEmail = req.user?.email || "admin";
    await logAudit(adminEmail, "delete", "review", req.params.id, "Review deleted by admin");
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── PARTNER CHECKOUTS ─────────────────────────────────
router.get("/admin/partner-checkouts", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT * FROM partner_checkout_log ORDER BY created_at DESC LIMIT 200
    `).catch(() => ({ rows: [] }));
    res.json({ checkouts: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── NOTIFICATIONS BROADCAST ────────────────────────────
router.post("/admin/notifications/broadcast", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { message, type, userId, link } = req.body;
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY,
        user_id TEXT,
        type TEXT NOT NULL DEFAULT 'info',
        message TEXT NOT NULL,
        read BOOLEAN NOT NULL DEFAULT FALSE,
        link TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    let recipientEmails: { id: string; email: string }[] = [];
    if (userId) {
      await db.execute(sql`INSERT INTO notifications (user_id, type, message, link) VALUES (${userId}, ${type || "info"}, ${message}, ${link || null})`);
      const uRow = await db.execute(sql`SELECT id, email FROM users WHERE id = ${userId} LIMIT 1`);
      recipientEmails = uRow.rows as any[];
    } else {
      const users = await db.execute(sql`SELECT id, email FROM users WHERE email IS NOT NULL AND email != ''`);
      for (const u of users.rows as any[]) {
        await db.execute(sql`INSERT INTO notifications (user_id, type, message, link) VALUES (${u.id}, ${type || "info"}, ${message}, ${link || null})`);
      }
      recipientEmails = users.rows as any[];
    }
    const adminEmail = req.user?.email || "admin";
    const target = userId ? `user:${userId}` : "all-users";
    await logAudit(adminEmail, "create", "notification", target, `Broadcast: "${message}"`);
    res.json({ ok: true, sent: userId ? 1 : "all" });

    // Fire-and-forget: email each recipient their notification
    const _apiKey = process.env.RESEND_API_KEY;
    if (_apiKey && recipientEmails.length > 0) {
      const _from = process.env.RESEND_FROM_EMAIL
        ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
        : "Buyshare <onboarding@resend.dev>";
      const linkHtml = link ? `<p style="margin-top:12px"><a href="https://buyshare.co${link}" style="color:#16a34a;font-weight:600">View on Buyshare.co →</a></p>` : "";
      for (const u of recipientEmails) {
        if (!u.email || u.email.includes("@placeholder")) continue;
        fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            from: _from,
            to: [u.email],
            subject: `Buyshare notification`,
            html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px">
              <h2 style="color:#111827;font-size:18px">You have a new notification</h2>
              <p style="font-size:15px;color:#374151;line-height:1.6">${message}</p>
              ${linkHtml}
              <p style="margin-top:24px;font-size:12px;color:#6b7280">Buyshare.co · Southwest Florida</p>
            </div>`,
          }),
        }).catch(() => {});
      }
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── MAP PINS ───────────────────────────────────────────
async function initMapPins() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS map_pins (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      label TEXT NOT NULL,
      lat DOUBLE PRECISION NOT NULL,
      lng DOUBLE PRECISION NOT NULL,
      category TEXT NOT NULL DEFAULT 'Other',
      phone TEXT,
      description TEXT,
      icon_color TEXT NOT NULL DEFAULT 'blue',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

router.get("/admin/map-pins", requireMasterAdmin, async (_req, res) => {
  try {
    await initMapPins();
    const result = await db.execute(sql`SELECT * FROM map_pins ORDER BY created_at DESC`);
    res.json({ pins: result.rows });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post("/admin/map-pins", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await initMapPins();
    const { label, lat, lng, category, phone, description, icon_color } = req.body;
    if (!label || lat == null || lng == null) { res.status(400).json({ error: "label, lat, lng required" }); return; }
    const result = await db.execute(sql`
      INSERT INTO map_pins (label, lat, lng, category, phone, description, icon_color)
      VALUES (${label}, ${lat}, ${lng}, ${category || "Other"}, ${phone || null}, ${description || null}, ${icon_color || "blue"})
      RETURNING *
    `);
    const pin = (result.rows as any[])[0];
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "create", "map_pin", pin?.id || "", `Created pin: ${label}`);
    res.json({ pin });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.patch("/admin/map-pins/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { label, lat, lng, category, phone, description, icon_color } = req.body;
    const sets: string[] = ["updated_at = NOW()"];
    const p: any[] = [req.params.id];
    const add = (v: any, col: string) => { if (v !== undefined) { p.push(v); sets.push(`${col} = $${p.length}`); } };
    add(label, "label"); add(lat, "lat"); add(lng, "lng"); add(category, "category");
    add(phone, "phone"); add(description, "description"); add(icon_color, "icon_color");
    const q = `UPDATE map_pins SET ${sets.join(", ")} WHERE id = $1 RETURNING *`;
    const result = await pool.query(q, p);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "map_pin", req.params.id, `Updated pin: ${label || req.params.id}`);
    res.json({ pin: (result.rows as any[])[0] });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete("/admin/map-pins/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const adminEmail = (req as any).user?.email || "admin";
    await db.execute(sql`DELETE FROM map_pins WHERE id = ${req.params.id}`);
    await logAudit(adminEmail, "delete", "map_pin", req.params.id, "Map pin deleted");
    res.json({ ok: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ── PLATFORM SETTINGS ──────────────────────────────────
async function initPlatformSettings() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS platform_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT '',
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

router.get("/admin/platform-settings", requireMasterAdmin, async (_req, res) => {
  try {
    await initPlatformSettings();
    const result = await db.execute(sql`SELECT key, value FROM platform_settings`);
    const settings: Record<string, string> = {};
    for (const row of result.rows as any[]) settings[row.key] = row.value;
    res.json({ settings });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.patch("/admin/platform-settings", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await initPlatformSettings();
    const { settings } = req.body as { settings: Record<string, string> };
    for (const [key, value] of Object.entries(settings || {})) {
      await db.execute(sql`
        INSERT INTO platform_settings (key, value) VALUES (${key}, ${value})
        ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
      `);
    }
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "platform_settings", "global", `Updated: ${Object.keys(settings || {}).join(", ")}`);
    res.json({ ok: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Public endpoint for featured listings
router.get("/platform/featured-listings", async (_req, res) => {
  try {
    await initPlatformSettings();
    const result = await db.execute(sql`SELECT key, value FROM platform_settings WHERE key IN ('featured_listing_ids','featured_section_title','featured_max_count')`);
    const s: Record<string, string> = {};
    for (const row of result.rows as any[]) s[(row as any).key] = (row as any).value;
    const ids = (s.featured_listing_ids || "").split(",").map((id: string) => id.trim()).filter(Boolean);
    const maxCount = parseInt(s.featured_max_count || "6", 10) || 6;
    const title = s.featured_section_title || "Featured Listings";
    if (!ids.length) { res.json({ listings: [], title, maxCount }); return; }
    const placeholders = ids.map((_: string, i: number) => `$${i + 1}`).join(", ");
    const listings = await pool.query(`SELECT * FROM listings WHERE id IN (${placeholders}) AND status = 'available' LIMIT ${maxCount}`, ids);
    res.json({ listings: listings.rows, title, maxCount });
  } catch { res.json({ listings: [], title: "Featured Listings", maxCount: 6 }); }
});

// Public endpoint for announcement banner
router.get("/platform/announcement", async (_req, res) => {
  try {
    await initPlatformSettings();
    const result = await db.execute(sql`SELECT key, value FROM platform_settings WHERE key IN ('announcement_banner','announcement_color')`);
    const s: Record<string, string> = {};
    for (const row of result.rows as any[]) s[(row as any).key] = (row as any).value;
    res.json({ banner: s.announcement_banner || "", color: s.announcement_color || "" });
  } catch { res.json({ banner: "", color: "" }); }
});

// ── AUDIT LOG ──────────────────────────────────────────
router.get("/admin/audit-log", requireMasterAdmin, async (_req, res) => {
  try {
    await initAuditLog();
    const result = await db.execute(sql`SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 500`);
    res.json({ entries: result.rows });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ── DASHBOARD HEALTH ───────────────────────────────────
router.get("/admin/dashboard-health", requireMasterAdmin, async (_req, res) => {
  try {
    await initAuditLog();
    await initPlatformSettings();

    // Check DB connectivity
    let dbOk = true;
    try { await db.execute(sql`SELECT 1`); } catch { dbOk = false; }

    // Last 5 audit entries
    const auditResult = await db.execute(sql`SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 5`);

    // Platform settings flags
    const settingsResult = await db.execute(sql`
      SELECT key, value FROM platform_settings
      WHERE key IN ('maintenance_mode', 'announcement_banner', 'announcement_color')
    `);
    const settings: Record<string, string> = {};
    for (const row of settingsResult.rows as any[]) settings[(row as any).key] = (row as any).value;

    res.json({
      dbOk,
      maintenanceMode: settings.maintenance_mode === "true",
      announcement: settings.announcement_banner || "",
      announcementColor: settings.announcement_color || "",
      recentAudit: auditResult.rows,
    });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ── USER NOTIFICATIONS ─────────────────────────────────
router.get("/notifications/:userId", async (req, res) => {
  try {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY, user_id TEXT, type TEXT NOT NULL DEFAULT 'info',
        message TEXT NOT NULL, read BOOLEAN NOT NULL DEFAULT FALSE,
        link TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    const result = await db.execute(sql`
      SELECT * FROM notifications WHERE user_id = ${req.params.userId} ORDER BY created_at DESC LIMIT 50
    `);
    res.json({ notifications: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/notifications/:id/read", async (req, res) => {
  try {
    await db.execute(sql`UPDATE notifications SET read = TRUE WHERE id = ${req.params.id}`);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/notifications/read-all/:userId", async (req, res) => {
  try {
    await db.execute(sql`UPDATE notifications SET read = TRUE WHERE user_id = ${req.params.userId}`);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/* ─── THRIFT REPORTS ─────────────────────────────────────────────────────── */

router.get("/admin/thrift-reports", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT r.*, l.title as listing_title
      FROM thrift_reports r
      LEFT JOIN thrift_listings l ON l.id = r.listing_id
      ORDER BY r.created_at DESC LIMIT 200
    `);
    res.json({ reports: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/thrift-reports/:id/status", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { status } = req.body;
    if (!["pending", "reviewed", "dismissed"].includes(status)) {
      return res.status(400).json({ error: "status must be pending | reviewed | dismissed" });
    }
    await db.execute(sql`UPDATE thrift_reports SET status = ${status} WHERE id = ${req.params.id}`);
    const adminEmail = req.user?.email || "admin";
    await logAudit(adminEmail, "update", "thrift_report", req.params.id, `Status → ${status}`);
    return res.json({ ok: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ── CHURN ALERT ────────────────────────────────────────

async function getMasterAdminEmail(): Promise<string | null> {
  try {
    const result = await db.execute(sql`
      SELECT email FROM users WHERE is_admin = TRUE ORDER BY created_at ASC LIMIT 1
    `);
    const email = (result.rows as any[])[0]?.email as string | undefined;
    if (email) return email.toLowerCase();
  } catch (err) {
    console.error("[churn-alert] Failed to look up master admin email:", err);
  }
  return process.env.MASTER_ADMIN_EMAIL || null;
}

async function sendChurnAlertEmail(churnRate: number, cancellations: number, activeAtStart: number, domain: string): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.log(`[churn-alert] Email skipped (no RESEND_API_KEY). Churn: ${churnRate}%, cancellations: ${cancellations}`);
    return false;
  }
  const to = await getMasterAdminEmail();
  if (!to) {
    console.error("[churn-alert] No master admin email found — skipping alert");
    return false;
  }
  const from = process.env.RESEND_FROM_EMAIL
    ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
    : "Buyshare <onboarding@resend.dev>";
  const lastMonth = new Date();
  lastMonth.setMonth(lastMonth.getMonth() - 1);
  const monthLabel = lastMonth.toLocaleString("en-US", { month: "long", year: "numeric" });
  const subsLink = `https://${domain}/admin/subscriptions`;
  const html = `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;">
      <div style="background:#dc2626;padding:24px 32px;">
        <h1 style="color:#ffffff;margin:0;font-size:22px;">⚠️ Churn Alert</h1>
        <p style="color:#fca5a5;margin:6px 0 0;">Monthly churn has exceeded your configured threshold</p>
      </div>
      <div style="padding:32px;">
        <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
          <tr>
            <td style="padding:12px 16px;background:#fef2f2;border-radius:8px;text-align:center;width:33%;">
              <div style="font-size:28px;font-weight:bold;color:#dc2626;">${churnRate}%</div>
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">Churn Rate</div>
            </td>
            <td style="padding:12px;width:2%;"></td>
            <td style="padding:12px 16px;background:#f8fafc;border-radius:8px;text-align:center;width:33%;">
              <div style="font-size:28px;font-weight:bold;color:#1e293b;">${cancellations}</div>
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">Cancellations</div>
            </td>
            <td style="padding:12px;width:2%;"></td>
            <td style="padding:12px 16px;background:#f8fafc;border-radius:8px;text-align:center;width:33%;">
              <div style="font-size:28px;font-weight:bold;color:#1e293b;">${activeAtStart}</div>
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">Active at Start</div>
            </td>
          </tr>
        </table>
        <p style="color:#374151;line-height:1.6;margin:0 0 24px;">
          <strong>${monthLabel}</strong> saw <strong>${cancellations} subscription cancellation${cancellations !== 1 ? "s" : ""}</strong> out of
          ${activeAtStart} active subscribers — a churn rate of <strong>${churnRate}%</strong>.
          This has crossed your configured alert threshold. Review your subscriptions to identify retention opportunities.
        </p>
        <a href="${subsLink}"
           style="display:inline-block;background:#2563eb;color:#ffffff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;">
          View Subscriptions →
        </a>
        <p style="color:#9ca3af;font-size:12px;margin-top:24px;">
          You can adjust or disable this alert threshold in Platform Settings → Alerts.
        </p>
      </div>
    </div>
  `;
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to, subject: `🚨 Churn Alert: ${churnRate}% last month — ${monthLabel}`, html }),
    });
    if (!response.ok) {
      const body = await response.text();
      console.error(`[churn-alert] Resend error ${response.status}: ${body}`);
      return false;
    }
    console.log(`[churn-alert] Churn alert email sent to ${to}. Churn: ${churnRate}%, cancellations: ${cancellations}`);
    return true;
  } catch (err) {
    console.error("[churn-alert] Failed to send churn alert email:", err);
    return false;
  }
}

export async function checkAndAlertChurn() {
  try {
    await initPlatformSettings();

    const settingsResult = await db.execute(sql`
      SELECT key, value FROM platform_settings
      WHERE key IN ('churn_alert_threshold', 'churn_alert_last_notified_month')
    `);
    const settings: Record<string, string> = {};
    for (const row of settingsResult.rows as any[]) settings[(row as any).key] = (row as any).value;

    const threshold = parseFloat(settings.churn_alert_threshold || "5");
    if (isNaN(threshold) || threshold <= 0) return;

    const currentMonth = new Date().toISOString().slice(0, 7);
    if (settings.churn_alert_last_notified_month === currentMonth) return;

    const lastMonthStart = new Date();
    lastMonthStart.setDate(1);
    lastMonthStart.setMonth(lastMonthStart.getMonth() - 1);
    lastMonthStart.setHours(0, 0, 0, 0);
    const thisMonthStart = new Date();
    thisMonthStart.setDate(1);
    thisMonthStart.setHours(0, 0, 0, 0);

    const cancellationsResult = await db.execute(sql`
      SELECT COUNT(*) AS cancellations FROM subscriptions
      WHERE canceled_at >= ${lastMonthStart.toISOString()}
        AND canceled_at < ${thisMonthStart.toISOString()}
    `);
    const cancellations = Number((cancellationsResult.rows as any[])[0]?.cancellations || 0);
    if (cancellations === 0) return;

    const activeAtStartResult = await db.execute(sql`
      SELECT COUNT(*) AS active_at_start FROM subscriptions
      WHERE created_at < ${lastMonthStart.toISOString()}
        AND (canceled_at IS NULL OR canceled_at >= ${lastMonthStart.toISOString()})
        AND status IN ('active', 'trialing', 'canceled')
    `);
    const activeAtStart = Number((activeAtStartResult.rows as any[])[0]?.active_at_start || 0);
    if (activeAtStart === 0) return;

    const churnRate = parseFloat(((cancellations / activeAtStart) * 100).toFixed(1));
    if (churnRate < threshold) return;

    const domain = (process.env.REPLIT_DOMAINS || "").split(",")[0]?.trim() || "buyshare.co";
    const sent = await sendChurnAlertEmail(churnRate, cancellations, activeAtStart, domain);
    if (sent) {
      await db.execute(sql`
        INSERT INTO platform_settings (key, value)
        VALUES ('churn_alert_last_notified_month', ${currentMonth})
        ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
      `);
    }
  } catch (err) {
    console.error("[churn-alert] Error checking churn:", err);
  }
}

export function startChurnAlertScheduler() {
  const INTERVAL_MS = 12 * 60 * 60 * 1000;
  setInterval(() => {
    checkAndAlertChurn().catch(err => console.error("[churn-alert] Scheduled check failed:", err));
  }, INTERVAL_MS);
  console.log("[churn-alert] Churn alert scheduler started (runs every 12h)");
}

// ── WEEKLY DIGEST ───────────────────────────────────────

function getISOWeekKey(date: Date): string {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + 3 - ((d.getDay() + 6) % 7));
  const week1 = new Date(d.getFullYear(), 0, 4);
  const weekNum = 1 + Math.round(((d.getTime() - week1.getTime()) / 86400000 - 3 + ((week1.getDay() + 6) % 7)) / 7);
  return `${d.getFullYear()}-W${String(weekNum).padStart(2, "0")}`;
}

const TIER_PRICE_CENTS: Record<string, number> = {
  pro: 500,
  thrift: 500,
  contractor: 1500,
};

function tierMrrCents(tier: string): number {
  return TIER_PRICE_CENTS[tier?.toLowerCase()] ?? 0;
}

async function sendWeeklyDigestEmail(opts: {
  newSubs: number;
  cancellations: number;
  netChange: number;
  currentMrrCents: number;
  mrrChangeCents: number;
  totalActive: number;
  weekLabel: string;
  domain: string;
}): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.log("[weekly-digest] Email skipped (no RESEND_API_KEY).");
    return false;
  }
  const to = await getMasterAdminEmail();
  if (!to) {
    console.error("[weekly-digest] No master admin email found — skipping digest");
    return false;
  }
  const from = process.env.RESEND_FROM_EMAIL
    ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
    : "Buyshare <onboarding@resend.dev>";

  const subsLink = `https://${opts.domain}/admin/subscriptions`;
  const mrrDollars = (opts.currentMrrCents / 100).toFixed(2);
  const mrrChangeDollars = (Math.abs(opts.mrrChangeCents) / 100).toFixed(2);
  const mrrChangeSign = opts.mrrChangeCents >= 0 ? "+" : "−";
  const mrrChangeColor = opts.mrrChangeCents >= 0 ? "#16a34a" : "#dc2626";
  const netChangeColor = opts.netChange >= 0 ? "#16a34a" : "#dc2626";
  const netChangeSign = opts.netChange >= 0 ? "+" : "";

  const html = `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;">
      <div style="background:#1e3a5f;padding:24px 32px;">
        <h1 style="color:#ffffff;margin:0;font-size:22px;">📊 Weekly Subscription Digest</h1>
        <p style="color:#93c5fd;margin:6px 0 0;">Week of ${opts.weekLabel}</p>
      </div>
      <div style="padding:32px;">
        <table style="width:100%;border-collapse:collapse;margin-bottom:28px;">
          <tr>
            <td style="padding:14px 16px;background:#f0fdf4;border-radius:8px;text-align:center;width:23%;">
              <div style="font-size:26px;font-weight:bold;color:#16a34a;">${opts.newSubs}</div>
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">New Subscribers</div>
            </td>
            <td style="padding:6px;width:2%;"></td>
            <td style="padding:14px 16px;background:#fef2f2;border-radius:8px;text-align:center;width:23%;">
              <div style="font-size:26px;font-weight:bold;color:#dc2626;">${opts.cancellations}</div>
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">Cancellations</div>
            </td>
            <td style="padding:6px;width:2%;"></td>
            <td style="padding:14px 16px;background:#f8fafc;border-radius:8px;text-align:center;width:23%;">
              <div style="font-size:26px;font-weight:bold;color:${netChangeColor};">${netChangeSign}${opts.netChange}</div>
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">Net Change</div>
            </td>
            <td style="padding:6px;width:2%;"></td>
            <td style="padding:14px 16px;background:#f8fafc;border-radius:8px;text-align:center;width:23%;">
              <div style="font-size:26px;font-weight:bold;color:#1e293b;">${opts.totalActive}</div>
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">Active Subs</div>
            </td>
          </tr>
        </table>

        <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:16px 20px;margin-bottom:24px;">
          <div style="font-size:13px;color:#0369a1;font-weight:600;margin-bottom:6px;">MRR Summary</div>
          <div style="display:flex;align-items:baseline;gap:12px;flex-wrap:wrap;">
            <span style="font-size:22px;font-weight:bold;color:#1e293b;">$${mrrDollars}</span>
            <span style="font-size:14px;font-weight:600;color:${mrrChangeColor};">${mrrChangeSign}$${mrrChangeDollars} this week</span>
          </div>
        </div>

        <p style="color:#374151;line-height:1.6;margin:0 0 24px;font-size:14px;">
          This week the platform gained <strong>${opts.newSubs} new subscriber${opts.newSubs !== 1 ? "s" : ""}</strong>
          and saw <strong>${opts.cancellations} cancellation${opts.cancellations !== 1 ? "s" : ""}</strong>,
          for a net change of <strong style="color:${netChangeColor};">${netChangeSign}${opts.netChange}</strong>.
          Current estimated MRR is <strong>$${mrrDollars}</strong>.
        </p>

        <a href="${subsLink}"
           style="display:inline-block;background:#2563eb;color:#ffffff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;">
          View Subscriptions →
        </a>
        <p style="color:#9ca3af;font-size:12px;margin-top:24px;">
          You can turn off this digest in Platform Settings → Alerts (set weekly_digest_enabled to false).
        </p>
      </div>
    </div>
  `;

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to, subject: `📊 Weekly Subscription Digest — ${opts.weekLabel}`, html }),
    });
    if (!response.ok) {
      const body = await response.text();
      console.error(`[weekly-digest] Resend error ${response.status}: ${body}`);
      return false;
    }
    console.log(`[weekly-digest] Digest sent to ${to} for week ${opts.weekLabel}`);
    return true;
  } catch (err) {
    console.error("[weekly-digest] Failed to send digest email:", err);
    return false;
  }
}

export async function runWeeklyDigestJob() {
  try {
    await initPlatformSettings();

    const settingsResult = await db.execute(sql`
      SELECT key, value FROM platform_settings
      WHERE key IN ('weekly_digest_enabled', 'weekly_digest_last_sent_week')
    `);
    const settings: Record<string, string> = {};
    for (const row of settingsResult.rows as any[]) settings[(row as any).key] = (row as any).value;

    if (settings.weekly_digest_enabled === "false") return;

    const now = new Date();
    const currentWeek = getISOWeekKey(now);
    if (settings.weekly_digest_last_sent_week === currentWeek) return;

    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - 7);
    weekStart.setHours(0, 0, 0, 0);
    const weekStartISO = weekStart.toISOString();

    const newSubsResult = await db.execute(sql`
      SELECT id, tier FROM subscriptions
      WHERE created_at >= ${weekStartISO}
        AND status IN ('active', 'trialing')
    `);
    const newSubRows = newSubsResult.rows as any[];
    const newSubs = newSubRows.length;

    const cancelResult = await db.execute(sql`
      SELECT id, tier FROM subscriptions
      WHERE canceled_at >= ${weekStartISO}
    `);
    const cancelRows = cancelResult.rows as any[];
    const cancellations = cancelRows.length;

    const activeResult = await db.execute(sql`
      SELECT id, tier FROM subscriptions
      WHERE status IN ('active', 'trialing')
    `);
    const activeRows = activeResult.rows as any[];
    const totalActive = activeRows.length;

    const currentMrrCents = activeRows.reduce((sum: number, r: any) => sum + tierMrrCents(r.tier), 0);
    const addedMrr = newSubRows.reduce((sum: number, r: any) => sum + tierMrrCents(r.tier), 0);
    const lostMrr = cancelRows.reduce((sum: number, r: any) => sum + tierMrrCents(r.tier), 0);
    const mrrChangeCents = addedMrr - lostMrr;
    const netChange = newSubs - cancellations;

    const weekDate = new Date(now);
    weekDate.setDate(now.getDate() - now.getDay() + 1);
    const weekLabel = weekDate.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });

    const domain = (process.env.REPLIT_DOMAINS || "").split(",")[0]?.trim() || "buyshare.co";

    const sent = await sendWeeklyDigestEmail({
      newSubs,
      cancellations,
      netChange,
      currentMrrCents,
      mrrChangeCents,
      totalActive,
      weekLabel,
      domain,
    });

    if (sent) {
      await db.execute(sql`
        INSERT INTO platform_settings (key, value)
        VALUES ('weekly_digest_last_sent_week', ${currentWeek})
        ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
      `);
    }
  } catch (err) {
    console.error("[weekly-digest] Error running digest job:", err);
  }
}

function shouldRunDigest(): boolean {
  const now = new Date();
  return now.getDay() === 1 && now.getHours() >= 8 && now.getHours() < 10;
}

export function startWeeklyDigestScheduler() {
  const INTERVAL_MS = 60 * 60 * 1000;
  if (shouldRunDigest()) {
    runWeeklyDigestJob().catch(err => console.error("[weekly-digest] Startup check failed:", err));
  }
  setInterval(() => {
    if (shouldRunDigest()) {
      runWeeklyDigestJob().catch(err => console.error("[weekly-digest] Scheduled job failed:", err));
    }
  }, INTERVAL_MS);
  console.log("[weekly-digest] Weekly digest scheduler started (checks hourly, fires Mon 8–10 AM)");
}

router.post("/admin/churn-alert/check", requireMasterAdmin, async (_req, res) => {
  try {
    await initPlatformSettings();

    const settingsResult = await db.execute(sql`
      SELECT key, value FROM platform_settings
      WHERE key IN ('churn_alert_threshold', 'churn_alert_last_notified_month')
    `);
    const settings: Record<string, string> = {};
    for (const row of settingsResult.rows as any[]) settings[(row as any).key] = (row as any).value;

    const threshold = parseFloat(settings.churn_alert_threshold || "5");

    const lastMonthStart = new Date();
    lastMonthStart.setDate(1);
    lastMonthStart.setMonth(lastMonthStart.getMonth() - 1);
    lastMonthStart.setHours(0, 0, 0, 0);
    const thisMonthStart = new Date();
    thisMonthStart.setDate(1);
    thisMonthStart.setHours(0, 0, 0, 0);

    const cancellationsResult = await db.execute(sql`
      SELECT COUNT(*) AS cancellations FROM subscriptions
      WHERE canceled_at >= ${lastMonthStart.toISOString()}
        AND canceled_at < ${thisMonthStart.toISOString()}
    `);
    const cancellations = Number((cancellationsResult.rows as any[])[0]?.cancellations || 0);

    const activeAtStartResult = await db.execute(sql`
      SELECT COUNT(*) AS active_at_start FROM subscriptions
      WHERE created_at < ${lastMonthStart.toISOString()}
        AND (canceled_at IS NULL OR canceled_at >= ${lastMonthStart.toISOString()})
        AND status IN ('active', 'trialing', 'canceled')
    `);
    const activeAtStart = Number((activeAtStartResult.rows as any[])[0]?.active_at_start || 0);
    const churnRate = activeAtStart > 0 ? parseFloat(((cancellations / activeAtStart) * 100).toFixed(1)) : 0;

    res.json({
      churnRate,
      cancellations,
      activeAtStart,
      threshold,
      willAlert: churnRate >= threshold,
      lastNotifiedMonth: settings.churn_alert_last_notified_month || null,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── CHURN ALERT RESET ──────────────────────────────────
router.delete("/admin/churn-alert/reset", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await initPlatformSettings();
    await db.execute(sql`
      DELETE FROM platform_settings WHERE key = 'churn_alert_last_notified_month'
    `);
    const adminEmail = req.user?.email || "unknown";
    await logAudit(adminEmail, "churn_alert_reset", "platform_settings", "churn_alert_last_notified_month", "Cleared churn alert last-notified month so it can re-fire this month");
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── SUBSCRIPTIONS ADMIN ────────────────────────────────
async function ensureSubCancelColumn() {
  await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS cancel_at_period_end BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS canceled_at TIMESTAMPTZ`).catch(() => {});
}

router.get("/admin/subscriptions", requireMasterAdmin, async (_req, res) => {
  try {
    await ensureSubCancelColumn();
    const result = await db.execute(sql`
      SELECT * FROM subscriptions ORDER BY created_at DESC LIMIT 500
    `);
    res.json({ subscriptions: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/subscriptions/:id/cancel", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureSubCancelColumn();
    const row = await db.execute(sql`SELECT * FROM subscriptions WHERE id = ${req.params.id} LIMIT 1`);
    const sub = (row.rows as any[])[0];
    if (!sub) { res.status(404).json({ error: "Subscription not found" }); return; }
    if (!sub.stripe_subscription_id) { res.status(400).json({ error: "No Stripe subscription ID on this record" }); return; }

    await stripe.subscriptions.update(sub.stripe_subscription_id, { cancel_at_period_end: true });
    // Keep status as-is (active/trialing) — access remains until period end
    await db.execute(sql`UPDATE subscriptions SET cancel_at_period_end = TRUE, canceled_at = NOW() WHERE id = ${req.params.id}`);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "cancel", "subscription", req.params.id, `Stripe sub ${sub.stripe_subscription_id} set cancel_at_period_end=true; access retained until period end`);
    res.json({ ok: true });
    checkAndAlertChurn().catch(err => console.error("[churn-alert] post-cancel check failed:", err));
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/subscriptions/:id/refund", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const row = await db.execute(sql`SELECT * FROM subscriptions WHERE id = ${req.params.id} LIMIT 1`);
    const sub = (row.rows as any[])[0];
    if (!sub) { res.status(404).json({ error: "Subscription not found" }); return; }
    if (!sub.stripe_subscription_id) { res.status(400).json({ error: "No Stripe subscription ID on this record" }); return; }

    const invoices = await stripe.invoices.list({ subscription: sub.stripe_subscription_id, limit: 1, status: "paid" });
    const invoice = invoices.data[0];
    if (!invoice || !invoice.payment_intent) {
      res.status(400).json({ error: "No paid invoice found for this subscription" }); return;
    }

    const paymentIntentId = invoice.payment_intent as string;
    const pi = await stripe.paymentIntents.retrieve(paymentIntentId);
    if ((pi as any).amount_received <= 0) {
      res.status(400).json({ error: "Payment intent has no captured amount to refund" }); return;
    }
    const alreadyRefunded = (pi.charges?.data?.[0] as any)?.amount_refunded;
    const amountCaptured = (pi.charges?.data?.[0] as any)?.amount_captured;
    if (alreadyRefunded && alreadyRefunded >= amountCaptured) {
      res.status(400).json({ error: "This invoice has already been fully refunded" }); return;
    }

    const refund = await stripe.refunds.create({ payment_intent: paymentIntentId });
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "refund", "subscription", req.params.id, `Refund ${refund.id} issued — $${(refund.amount / 100).toFixed(2)} for invoice ${invoice.id}`);
    res.json({ ok: true, refundId: refund.id, amount: refund.amount, currency: refund.currency });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── THRIFT LISTINGS ADMIN ──────────────────────────────
async function ensureThriftFlagColumn() {
  await db.execute(sql`ALTER TABLE thrift_listings ADD COLUMN IF NOT EXISTS flagged BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
}

router.get("/admin/thrift-listings", requireMasterAdmin, async (_req, res) => {
  try {
    await ensureThriftFlagColumn();
    const result = await db.execute(sql`
      SELECT * FROM thrift_listings ORDER BY created_at DESC LIMIT 500
    `);
    res.json({ listings: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function ensureThriftFeaturedColumn() {
  await db.execute(sql`ALTER TABLE thrift_listings ADD COLUMN IF NOT EXISTS featured BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
}

router.patch("/admin/thrift-listings/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await ensureThriftFlagColumn();
    await ensureThriftFeaturedColumn();
    const { status, title, description, flagged, featured } = req.body;
    const sets: string[] = [];
    const params: any[] = [req.params.id];
    const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
    add(status, "status");
    add(title, "title");
    add(description, "description");
    add(flagged, "flagged");
    add(featured, "featured");
    if (sets.length === 0) { res.json({ ok: true }); return; }
    const q = `UPDATE thrift_listings SET ${sets.join(", ")} WHERE id = $1 RETURNING *`;
    const result = await pool.query(q, params);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "thrift_listing", req.params.id, `Updated: ${Object.keys(req.body).join(", ")}`);
    res.json({ listing: (result.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/thrift-listings/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const adminEmail = (req as any).user?.email || "admin";
    await db.execute(sql`DELETE FROM thrift_listings WHERE id = ${req.params.id}`);
    await logAudit(adminEmail, "delete", "thrift_listing", req.params.id, "Thrift listing deleted by admin");
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── ENHANCED STATS (with subscriptions + thrift + MRR) ─
router.get("/admin/stats/extended", requireMasterAdmin, async (_req, res) => {
  try {
    await ensureSubCancelColumn();
    const subResult = await db.execute(sql`
      SELECT tier, status, COUNT(*) as cnt FROM subscriptions
      WHERE status IN ('active','trialing') GROUP BY tier, status
    `);
    const TIER_PRICE: Record<string, number> = { pro: 500, contractor: 1500, thrift: 500 };
    let mrr = 0;
    let activeSubCount = 0;
    let trialingSubCount = 0;
    for (const row of subResult.rows as any[]) {
      const n = Number(row.cnt);
      const price = TIER_PRICE[row.tier] || 0;
      mrr += n * price;
      if (row.status === "active") activeSubCount += n;
      if (row.status === "trialing") trialingSubCount += n;
    }

    const monthlyResult = await db.execute(sql`
      WITH months AS (
        SELECT generate_series(
          DATE_TRUNC('month', NOW() - INTERVAL '11 months'),
          DATE_TRUNC('month', NOW()),
          '1 month'::interval
        ) AS month
      )
      SELECT
        m.month,
        COALESCE(SUM(CASE WHEN s.tier = 'pro' THEN 500 ELSE 0 END), 0)        AS pro_mrr,
        COALESCE(SUM(CASE WHEN s.tier = 'contractor' THEN 1500 ELSE 0 END), 0) AS contractor_mrr,
        COALESCE(SUM(CASE WHEN s.tier = 'thrift' THEN 500 ELSE 0 END), 0)     AS thrift_mrr
      FROM months m
      LEFT JOIN subscriptions s ON
        s.created_at <= (m.month + INTERVAL '1 month' - INTERVAL '1 second')
        AND (
          s.status IN ('active', 'trialing')
          OR (s.status = 'canceled' AND s.current_period_end >= m.month)
        )
      GROUP BY m.month
      ORDER BY m.month ASC
    `);

    const churnResult = await db.execute(sql`
      WITH months AS (
        SELECT generate_series(
          DATE_TRUNC('month', NOW() - INTERVAL '11 months'),
          DATE_TRUNC('month', NOW()),
          '1 month'::interval
        ) AS month
      ),
      monthly_cancellations AS (
        SELECT DATE_TRUNC('month', canceled_at) AS month, COUNT(*) AS cancellations
        FROM subscriptions
        WHERE canceled_at IS NOT NULL
        GROUP BY DATE_TRUNC('month', canceled_at)
      ),
      monthly_active_at_start AS (
        SELECT m.month, COUNT(s.id) AS active_at_start
        FROM months m
        LEFT JOIN subscriptions s ON
          s.created_at < m.month
          AND (s.canceled_at IS NULL OR s.canceled_at >= m.month)
          AND s.status IN ('active', 'trialing', 'canceled')
        GROUP BY m.month
      )
      SELECT
        ma.month,
        COALESCE(mc.cancellations, 0) AS cancellations,
        ma.active_at_start,
        CASE WHEN ma.active_at_start > 0
          THEN ROUND((COALESCE(mc.cancellations, 0)::numeric / ma.active_at_start) * 100, 1)
          ELSE 0
        END AS churn_rate
      FROM monthly_active_at_start ma
      LEFT JOIN monthly_cancellations mc ON mc.month = ma.month
      ORDER BY ma.month ASC
    `).catch(() => ({ rows: [] }));

    const thriftResult = await db.execute(sql`SELECT COUNT(*) as count FROM thrift_listings`).catch(() => ({ rows: [{ count: 0 }] }));
    const thriftFlaggedResult = await db.execute(sql`SELECT COUNT(*) as count FROM thrift_listings WHERE flagged = TRUE OR status = 'flagged'`).catch(() => ({ rows: [{ count: 0 }] }));
    const pendingReportsResult = await db.execute(sql`SELECT COUNT(*) as count FROM thrift_reports WHERE status = 'pending'`).catch(() => ({ rows: [{ count: 0 }] }));

    const categoryResult = await db.execute(sql`
      SELECT category, COUNT(*) as count
      FROM listings
      GROUP BY category
      ORDER BY count DESC
    `).catch(() => ({ rows: [] }));

    const shareTypeResult = await db.execute(sql`
      SELECT share_type as category, COUNT(*) as count
      FROM share_listings
      GROUP BY share_type
      ORDER BY count DESC
    `).catch(() => ({ rows: [] }));

    res.json({
      mrr,
      activeSubscriptions: activeSubCount,
      trialingSubscriptions: trialingSubCount,
      totalSubscriptions: activeSubCount + trialingSubCount,
      thriftListings: Number((thriftResult.rows as any[])[0]?.count || 0),
      thriftFlagged: Number((thriftFlaggedResult.rows as any[])[0]?.count || 0),
      pendingReports: Number((pendingReportsResult.rows as any[])[0]?.count || 0),
      monthlyBreakdown: monthlyResult.rows,
      churnBreakdown: churnResult.rows,
      equipmentByCategory: categoryResult.rows,
      shareByType: shareTypeResult.rows,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── Investor Admin ─────────────────────────────────────────────────────────────
router.get("/admin/investors", requireMasterAdmin, async (_req, res) => {
  try {
    const result = await db.execute(sql`SELECT * FROM investors ORDER BY created_at DESC`);
    res.json({ investors: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/investors/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { status, notes } = req.body;
    const sets: string[] = [];
    const params: any[] = [req.params.id];
    const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
    add(status, "status");
    add(notes, "notes");
    if (!sets.length) { res.status(400).json({ error: "Nothing to update" }); return; }
    const q = `UPDATE investors SET ${sets.join(", ")} WHERE id = $1`;
    await pool.query(q, params);
    const adminEmail = (req as any).user?.email || "admin";
    await logAudit(adminEmail, "update", "investor", req.params.id, `Updated: ${Object.keys(req.body).join(", ")}`);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── PAYMENTS DASHBOARD ─────────────────────────────────────────────────────
router.get("/admin/payments", requireMasterAdmin, async (_req, res) => {
  try {
    const bookingsRes = await db.execute(sql`
      SELECT
        'booking' AS type,
        u.name AS user_name,
        u.email AS user_email,
        l.title AS item_title,
        b.total_charge_cents AS amount_cents,
        b.status,
        b.created_at
      FROM bookings b
      LEFT JOIN users u ON b.renter_id = u.id
      LEFT JOIN listings l ON b.listing_id = l.id
      ORDER BY b.created_at DESC LIMIT 500
    `);
    const subsRes = await db.execute(sql`
      SELECT
        'subscription' AS type,
        name AS user_name,
        email AS user_email,
        tier AS item_title,
        CASE tier WHEN 'pro' THEN 500 WHEN 'contractor' THEN 1500 WHEN 'thrift' THEN 500 ELSE 0 END AS amount_cents,
        status,
        created_at
      FROM subscriptions
      ORDER BY created_at DESC LIMIT 500
    `);
    let thriftRes: any = { rows: [] };
    try {
      thriftRes = await db.execute(sql`
        SELECT
          'thrift_purchase' AS type,
          buyer_name AS user_name,
          buyer_email AS user_email,
          listing_title AS item_title,
          amount_cents,
          status,
          created_at
        FROM thrift_purchases
        ORDER BY created_at DESC LIMIT 500
      `);
    } catch { /* table may not exist yet */ }

    const all = [
      ...(bookingsRes.rows as any[]),
      ...(subsRes.rows as any[]),
      ...(thriftRes.rows as any[]),
    ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    res.json({ payments: all });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/investors/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await db.execute(sql`DELETE FROM investors WHERE id = ${req.params.id}`);
    await logAudit(req, "investor.delete", { id: req.params.id });
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
