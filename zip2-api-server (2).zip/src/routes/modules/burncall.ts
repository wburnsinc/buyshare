import { Router } from "express";
import { pool } from "@workspace/db";
import { requireAuth, requireMasterAdmin, type AuthRequest } from "../../middleware/auth.js";
import { openai } from "@workspace/integrations-openai-ai-server";

const router = Router();

const RESEND_API_KEY = process.env.RESEND_API_KEY || process.env.RESEND_KEY || "";
const FROM_EMAIL = RESEND_API_KEY ? "BurnCall <onboarding@resend.dev>" : "";

async function sendEmail(to: string, subject: string, html: string): Promise<{ success: boolean; error?: string }> {
  if (!RESEND_API_KEY) return { success: false, error: "Email not configured" };
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, html }),
  });
  if (!r.ok) {
    const body = await r.text().catch(() => "");
    console.error(`[burncall] Resend error ${r.status}: ${body}`);
    return { success: false, error: `Resend ${r.status}` };
  }
  return { success: true };
}

async function ensureBurnCallTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_contacts (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      company TEXT,
      service_type TEXT,
      status TEXT NOT NULL DEFAULT 'new',
      tags TEXT[] DEFAULT '{}',
      notes TEXT,
      source TEXT DEFAULT 'manual',
      ai_qualification JSONB,
      ai_response_draft TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`ALTER TABLE bc_contacts ADD COLUMN IF NOT EXISTS ai_qualification JSONB`).catch(() => {});
  await pool.query(`ALTER TABLE bc_contacts ADD COLUMN IF NOT EXISTS ai_response_draft TEXT`).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_conversations (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      contact_id TEXT REFERENCES bc_contacts(id) ON DELETE CASCADE,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      title TEXT,
      messages JSONB NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'open',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_appointments (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      contact_id TEXT REFERENCES bc_contacts(id) ON DELETE SET NULL,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      description TEXT,
      scheduled_at TIMESTAMPTZ NOT NULL,
      duration_minutes INTEGER DEFAULT 60,
      status TEXT NOT NULL DEFAULT 'scheduled',
      location TEXT,
      notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_campaigns (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'email',
      status TEXT NOT NULL DEFAULT 'draft',
      subject TEXT,
      body TEXT,
      target_count INTEGER DEFAULT 0,
      sent_count INTEGER DEFAULT 0,
      open_count INTEGER DEFAULT 0,
      reply_count INTEGER DEFAULT 0,
      scheduled_at TIMESTAMPTZ,
      sent_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_notes (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      contact_id TEXT NOT NULL REFERENCES bc_contacts(id) ON DELETE CASCADE,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      content TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Revenue tracking — jobs won from leads
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_revenue_entries (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      contact_id TEXT REFERENCES bc_contacts(id) ON DELETE SET NULL,
      job_title TEXT NOT NULL,
      revenue_amount NUMERIC(10,2) NOT NULL,
      service_type TEXT,
      source TEXT DEFAULT 'manual',
      notes TEXT,
      closed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS bc_revenue_user_idx ON bc_revenue_entries (user_id)`).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS bc_revenue_closed_idx ON bc_revenue_entries (closed_at)`).catch(() => {});

  // Lead capture webhooks — external forms post leads here
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_lead_webhooks (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      webhook_key TEXT NOT NULL UNIQUE DEFAULT gen_random_uuid()::text,
      source_label TEXT DEFAULT 'Website Form',
      leads_captured INTEGER NOT NULL DEFAULT 0,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Automated reminders
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_reminders (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      contact_id TEXT REFERENCES bc_contacts(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      due_at TIMESTAMPTZ NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Business profile — personalizes AI responses
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_business_profile (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
      business_name TEXT,
      trade TEXT,
      service_area TEXT DEFAULT 'Southwest Florida',
      business_hours TEXT DEFAULT 'Mon–Fri 8am–5pm',
      response_tone TEXT DEFAULT 'professional',
      qualifying_questions TEXT[] DEFAULT '{}',
      custom_context TEXT,
      auto_respond_enabled BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`ALTER TABLE bc_business_profile ADD COLUMN IF NOT EXISTS auto_respond_enabled BOOLEAN DEFAULT FALSE`).catch(() => {});

  // Services offered by the business
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_services (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      description TEXT,
      price_range TEXT,
      duration_estimate TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Knowledge base FAQs
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_faqs (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Automations — pre-built and custom triggers
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bc_automations (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      description TEXT,
      trigger_event TEXT NOT NULL,
      action_type TEXT NOT NULL,
      action_config JSONB DEFAULT '{}',
      is_enabled BOOLEAN DEFAULT TRUE,
      runs INTEGER DEFAULT 0,
      last_run_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
}
ensureBurnCallTables();

const SYSTEM_PROMPT = `You are BurnCall AI — a smart lead response assistant for contractors and home service businesses in Southwest Florida.
You help contractors respond to new leads instantly, qualify customers, schedule estimates, and follow up automatically.
You serve HVAC, plumbing, roofing, electrical, cleaning, lawn care, pool care, painting, and other service trades in SWFL.
Keep responses professional, concise, and actionable. When qualifying a lead:
1. Assess the specific service needed
2. Detect spam (fake leads, irrelevant inquiries, bot submissions)
3. Detect emergencies (no hot water, AC out in summer heat, flooding, gas leak, no power, etc.)
4. Score the lead 0–100 (Hot: 70+, Warm: 40–69, Cold: below 40)
5. Estimate job value ($100–$500 / $500–$2,000 / $2,000+)
6. Suggest the best next step (call now / schedule estimate / send quote)
Always generate a ready-to-send customer reply that is warm, professional, and gets the customer to respond.`;

async function getBusinessContext(userId?: string | null): Promise<string> {
  if (!userId) return "";
  try {
    const [profile, services, faqs] = await Promise.all([
      pool.query(`SELECT * FROM bc_business_profile WHERE user_id = $1 LIMIT 1`, [userId]),
      pool.query(`SELECT * FROM bc_services WHERE user_id = $1 ORDER BY created_at LIMIT 20`, [userId]),
      pool.query(`SELECT * FROM bc_faqs WHERE user_id = $1 ORDER BY created_at LIMIT 20`, [userId]),
    ]);
    if (!profile.rows[0]) return "";
    const p = profile.rows[0];
    const parts: string[] = [
      `Business: ${p.business_name || "Home Service Business"}`,
      `Trade: ${p.trade || "General Contractor"}`,
      `Service Area: ${p.service_area || "Southwest Florida"}`,
      `Business Hours: ${p.business_hours || "Mon–Fri 8am–5pm"}`,
      `Response Tone: ${p.response_tone || "professional"}`,
    ];
    if (services.rows.length > 0) {
      parts.push(`Services Offered: ${services.rows.map((s: any) => `${s.name}${s.price_range ? ` (${s.price_range})` : ""}`).join(", ")}`);
    }
    if (faqs.rows.length > 0) {
      parts.push(`\nKnowledge Base FAQs:\n${faqs.rows.map((f: any) => `Q: ${f.question}\nA: ${f.answer}`).join("\n\n")}`);
    }
    if (p.qualifying_questions?.length > 0) {
      parts.push(`\nCustom Qualifying Questions to consider: ${p.qualifying_questions.join("; ")}`);
    }
    if (p.custom_context) parts.push(`\nAdditional Context: ${p.custom_context}`);
    return parts.join("\n");
  } catch { return ""; }
}

async function autoQualifyContact(contact: any) {
  try {
    const bizContext = await getBusinessContext(contact.user_id);
    const systemContent = bizContext
      ? `${SYSTEM_PROMPT}\n\n--- BUSINESS CONTEXT ---\n${bizContext}\n--- END CONTEXT ---`
      : SYSTEM_PROMPT;

    const prompt = `Qualify this new lead:\nName: ${contact.name}\nService Needed: ${contact.service_type || "Unknown"}\nInquiry: ${contact.notes || "No additional info"}\nPhone: ${contact.phone || "Not provided"}\nEmail: ${contact.email || "Not provided"}\n\nRespond ONLY with valid JSON (no markdown):\n{ "qualified": boolean, "score": 0-100, "tier": "hot|warm|cold", "isSpam": boolean, "isEmergency": boolean, "summary": "1-sentence lead summary", "urgency": "low|medium|high|emergency", "estimatedValue": "$range", "nextStep": "call now|schedule estimate|send quote|follow up", "draftResponse": "professional 2-3 sentence reply to send this customer" }`;

    const completion = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 700,
      messages: [{ role: "system", content: systemContent }, { role: "user", content: prompt }],
    });
    const text = completion.choices[0]?.message?.content || "{}";
    const json = JSON.parse(text.replace(/```json\n?|\n?```/g, "").trim());

    // Normalize score to 0-100
    if (json.score > 10 && json.score <= 100) { /* already 0-100 */ }
    else if (json.score <= 10) { json.score = Math.round(json.score * 10); }
    json.score = Math.max(0, Math.min(100, json.score || 0));

    // Derive tier from score
    if (!json.tier) {
      json.tier = json.score >= 70 ? "hot" : json.score >= 40 ? "warm" : "cold";
    }

    await pool.query(
      `UPDATE bc_contacts SET ai_qualification = $1, ai_response_draft = $2, updated_at = NOW() WHERE id = $3`,
      [JSON.stringify(json), json.draftResponse || null, contact.id]
    );

    // Auto-respond via email if enabled and contact has email and lead is not spam
    if (json.draftResponse && contact.email && !json.isSpam) {
      try {
        const biz = await pool.query(`SELECT auto_respond_enabled, business_name FROM bc_business_profile WHERE user_id = $1`, [contact.user_id]);
        if (biz.rows[0]?.auto_respond_enabled) {
          const bizName = biz.rows[0]?.business_name || "Our Team";
          // Look up booking link from first active webhook for this user
          let bookingLink = "";
          if (contact.user_id) {
            const wh = await pool.query(`SELECT webhook_key FROM bc_lead_webhooks WHERE user_id = $1 AND is_active = TRUE ORDER BY created_at LIMIT 1`, [contact.user_id]);
            if (wh.rows[0]) bookingLink = `https://buyshare.co/bc/${wh.rows[0].webhook_key}/book`;
          }
          const bookingBlock = bookingLink
            ? `<div style="margin:20px 0;padding:16px;background:#fff7ed;border:1px solid #fb923c;border-radius:8px;text-align:center">
                <p style="margin:0 0 10px;font-weight:bold;color:#ea580c">📅 Book Your Appointment Online</p>
                <a href="${bookingLink}" style="display:inline-block;background:#ea580c;color:white;text-decoration:none;padding:10px 24px;border-radius:6px;font-weight:bold;font-size:14px">Schedule Now →</a>
                <p style="margin:8px 0 0;font-size:11px;color:#9ca3af">Takes 2 minutes · No payment required</p>
              </div>`
            : "";
          await sendEmail(
            contact.email,
            `Re: Your ${contact.service_type || "service"} inquiry — ${bizName}`,
            `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;color:#1f2937">
              <div style="background:#0f172a;padding:16px 20px;border-radius:8px 8px 0 0;display:flex;align-items:center;gap:8px">
                <span style="font-size:20px">⚡</span>
                <span style="color:white;font-weight:bold">${bizName}</span>
                <span style="margin-left:auto;color:#94a3b8;font-size:11px">via BurnCall AI</span>
              </div>
              <div style="padding:24px;border:1px solid #e5e7eb;border-top:none;border-radius:0 0 8px 8px">
                <p style="margin:0 0 16px">${json.draftResponse.replace(/\n/g, "<br>")}</p>
                ${bookingBlock}
                <hr style="border-color:#e5e7eb;margin:20px 0">
                <p style="color:#9ca3af;font-size:11px;margin:0">— ${bizName} · Powered by BurnCall AI · AI responded in under 60 seconds</p>
              </div>
            </div>`
          );
          await pool.query(
            `UPDATE bc_automations SET runs = runs + 1, last_run_at = NOW() WHERE user_id = $1 AND trigger_event = 'new_lead' AND action_type = 'auto_respond' AND is_enabled = TRUE`,
            [contact.user_id]
          ).catch(() => {});
        }
      } catch { /* silent — don't fail qualification if email fails */ }
    }
  } catch { /* silent */ }
}

// ── CONTACTS ─────────────────────────────────────────────────────────────────

router.get("/burncall/contacts", requireAuth, async (req: AuthRequest, res) => {
  const { status, search, limit = "100", offset = "0" } = req.query as Record<string, string>;
  let q = `SELECT * FROM bc_contacts WHERE 1=1`;
  const params: any[] = [];
  if (status) { params.push(status); q += ` AND status = $${params.length}`; }
  if (search) { params.push(`%${search}%`); q += ` AND (name ILIKE $${params.length} OR phone ILIKE $${params.length} OR email ILIKE $${params.length})`; }
  q += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
  params.push(parseInt(limit), parseInt(offset));
  const { rows } = await pool.query(q, params);
  const total = await pool.query(`SELECT COUNT(*) FROM bc_contacts`);
  res.json({ contacts: rows, total: parseInt(total.rows[0].count) });
});

router.post("/burncall/contacts", requireAuth, async (req: AuthRequest, res) => {
  const { name, email, phone, company, serviceType, notes, source } = req.body;
  if (!name) return (res as any).status(400).json({ error: "name required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_contacts (name, email, phone, company, service_type, notes, source, user_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [name, email || null, phone || null, company || null, serviceType || null, notes || null, source || "manual", req.user?.id || null]
  );
  const contact = rows[0];
  res.json({ contact });
  if (contact) autoQualifyContact(contact);
});

router.post("/burncall/contacts/:id/qualify", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_contacts WHERE id = $1 LIMIT 1`, [req.params.id]);
  if (!rows.length) return (res as any).status(404).json({ error: "Contact not found" });
  await autoQualifyContact(rows[0]);
  const updated = await pool.query(`SELECT * FROM bc_contacts WHERE id = $1`, [req.params.id]);
  res.json({ contact: updated.rows[0] });
});

router.post("/burncall/contacts/:id/status", requireAuth, async (req: AuthRequest, res) => {
  const { status } = req.body;
  const valid = ["new", "contacted", "qualified", "scheduled", "closed", "lost"];
  if (!valid.includes(status)) return (res as any).status(400).json({ error: "invalid status" });
  await pool.query(`UPDATE bc_contacts SET status = $1, updated_at = NOW() WHERE id = $2`, [status, req.params.id]);
  res.json({ success: true });
});

router.patch("/burncall/contacts/:id", requireAuth, async (req: AuthRequest, res) => {
  const { name, email, phone, company, serviceType, status, notes, tags } = req.body;
  const sets: string[] = ["updated_at = NOW()"];
  const params: any[] = [];
  const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
  add(name, "name"); add(email, "email"); add(phone, "phone"); add(company, "company");
  add(serviceType, "service_type"); add(status, "status"); add(notes, "notes"); add(tags, "tags");
  params.push(req.params.id);
  await pool.query(`UPDATE bc_contacts SET ${sets.join(", ")} WHERE id = $${params.length}`, params);
  res.json({ success: true });
});

router.delete("/burncall/contacts/:id", requireAuth, async (req: AuthRequest, res) => {
  await pool.query(`DELETE FROM bc_contacts WHERE id = $1`, [req.params.id]);
  res.json({ success: true });
});

// ── NOTES ────────────────────────────────────────────────────────────────────

router.get("/burncall/contacts/:id/notes", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_notes WHERE contact_id = $1 ORDER BY created_at DESC`, [req.params.id]);
  res.json({ notes: rows });
});

router.post("/burncall/contacts/:id/notes", requireAuth, async (req: AuthRequest, res) => {
  const { content } = req.body;
  if (!content) return (res as any).status(400).json({ error: "content required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_notes (contact_id, user_id, content) VALUES ($1,$2,$3) RETURNING *`,
    [req.params.id, req.user?.id || null, content]
  );
  res.json({ note: rows[0] });
});

// ── APPOINTMENTS ─────────────────────────────────────────────────────────────

router.get("/burncall/appointments", requireAuth, async (_req, res) => {
  const { rows } = await pool.query(
    `SELECT a.*, c.name as contact_name, c.phone as contact_phone, c.service_type FROM bc_appointments a LEFT JOIN bc_contacts c ON c.id = a.contact_id ORDER BY a.scheduled_at ASC`
  );
  res.json({ appointments: rows });
});

router.post("/burncall/appointments", requireAuth, async (req: AuthRequest, res) => {
  const { contactId, title, description, scheduledAt, durationMinutes, location, notes } = req.body;
  if (!title || !scheduledAt) return (res as any).status(400).json({ error: "title and scheduledAt required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_appointments (contact_id, user_id, title, description, scheduled_at, duration_minutes, location, notes) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [contactId || null, req.user?.id || null, title, description || null, scheduledAt, durationMinutes || 60, location || null, notes || null]
  );
  if (contactId) { await pool.query(`UPDATE bc_contacts SET status = 'scheduled', updated_at = NOW() WHERE id = $1`, [contactId]).catch(() => {}); }
  res.json({ appointment: rows[0] });
});

router.patch("/burncall/appointments/:id", requireAuth, async (req: AuthRequest, res) => {
  const { status, notes, scheduledAt } = req.body;
  const sets: string[] = [];
  const params: any[] = [];
  const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
  add(status, "status"); add(notes, "notes"); add(scheduledAt, "scheduled_at");
  if (!sets.length) return (res as any).status(400).json({ error: "Nothing to update" });
  params.push(req.params.id);
  await pool.query(`UPDATE bc_appointments SET ${sets.join(", ")} WHERE id = $${params.length}`, params);
  res.json({ success: true });
});

// ── CAMPAIGNS ────────────────────────────────────────────────────────────────

router.get("/burncall/campaigns", requireAuth, async (_req, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_campaigns ORDER BY created_at DESC LIMIT 50`);
  res.json({ campaigns: rows });
});

router.post("/burncall/campaigns", requireAuth, async (req: AuthRequest, res) => {
  const { name, type, subject, body, scheduledAt } = req.body;
  if (!name) return (res as any).status(400).json({ error: "name required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_campaigns (user_id, name, type, subject, body, scheduled_at) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.user?.id || null, name, type || "email", subject || null, body || null, scheduledAt || null]
  );
  res.json({ campaign: rows[0] });
});

router.patch("/burncall/campaigns/:id", requireAuth, async (req: AuthRequest, res) => {
  const { status, name, subject, body } = req.body;
  const sets: string[] = ["updated_at = NOW()"];
  const params: any[] = [];
  const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
  add(status, "status"); add(name, "name"); add(subject, "subject"); add(body, "body");
  if (status === "sent") { sets.push("sent_at = NOW()"); sets.push("sent_count = target_count"); }
  params.push(req.params.id);
  await pool.query(`UPDATE bc_campaigns SET ${sets.join(", ")} WHERE id = $${params.length}`, params);
  res.json({ success: true });
});

// ── CAMPAIGN SEND (Resend email) ──────────────────────────────────────────────
router.post("/burncall/campaigns/:id/send", requireAuth, async (req: AuthRequest, res) => {
  const camp = await pool.query(`SELECT * FROM bc_campaigns WHERE id = $1 LIMIT 1`, [req.params.id]);
  if (!camp.rows.length) return (res as any).status(404).json({ error: "Campaign not found" });
  const c = camp.rows[0];
  if (!c.subject || !c.body) return (res as any).status(400).json({ error: "Campaign needs subject and body before sending" });

  const { to_emails } = req.body;
  const recipients: string[] = Array.isArray(to_emails) ? to_emails : [];

  // If no specific recipients, send to all contacts with emails
  let finalRecipients = recipients;
  if (!finalRecipients.length) {
    const { rows: contacts } = await pool.query(`SELECT DISTINCT email FROM bc_contacts WHERE email IS NOT NULL AND email != '' LIMIT 200`);
    finalRecipients = contacts.map((r: any) => r.email);
  }

  if (!finalRecipients.length) return (res as any).status(400).json({ error: "No email recipients found" });

  const htmlBody = `<div style="font-family:sans-serif;max-width:600px;margin:0 auto">
    <h2 style="color:#dc2626">${c.name}</h2>
    <div style="white-space:pre-wrap;line-height:1.6">${c.body.replace(/\n/g, "<br>")}</div>
    <hr style="margin:24px 0;border-color:#e5e7eb">
    <p style="color:#9ca3af;font-size:12px">Sent via BurnCall · Powered by Buyshare.co</p>
  </div>`;

  let successCount = 0;
  let failCount = 0;
  for (const email of finalRecipients.slice(0, 50)) {
    const result = await sendEmail(email, c.subject, htmlBody);
    if (result.success) successCount++; else failCount++;
  }

  await pool.query(
    `UPDATE bc_campaigns SET status = 'sent', sent_at = NOW(), sent_count = $1, target_count = $2, updated_at = NOW() WHERE id = $3`,
    [successCount, finalRecipients.length, c.id]
  );

  res.json({ success: true, sent: successCount, failed: failCount, total: finalRecipients.length });
});

// ── REVENUE ───────────────────────────────────────────────────────────────────

router.get("/burncall/revenue", requireAuth, async (req: AuthRequest, res) => {
  const [entries, monthly, bySource, byService] = await Promise.all([
    pool.query(`SELECT re.*, c.name AS contact_name FROM bc_revenue_entries re LEFT JOIN bc_contacts c ON c.id = re.contact_id ORDER BY re.closed_at DESC LIMIT 50`),
    pool.query(`
      SELECT DATE_TRUNC('month', closed_at) AS month, COUNT(*) AS jobs, SUM(revenue_amount) AS revenue
      FROM bc_revenue_entries WHERE closed_at >= NOW() - INTERVAL '12 months'
      GROUP BY DATE_TRUNC('month', closed_at) ORDER BY month ASC`),
    pool.query(`SELECT source, COUNT(*) AS count, SUM(revenue_amount) AS revenue FROM bc_revenue_entries GROUP BY source ORDER BY revenue DESC`),
    pool.query(`SELECT service_type, COUNT(*) AS count, SUM(revenue_amount) AS revenue FROM bc_revenue_entries WHERE service_type IS NOT NULL GROUP BY service_type ORDER BY revenue DESC`),
  ]);
  const totals = await pool.query(`SELECT COUNT(*) AS jobs, COALESCE(SUM(revenue_amount),0) AS total_revenue, COALESCE(AVG(revenue_amount),0) AS avg_job FROM bc_revenue_entries`);
  res.json({ entries: entries.rows, monthly: monthly.rows, bySource: bySource.rows, byService: byService.rows, totals: totals.rows[0] });
});

router.post("/burncall/revenue", requireAuth, async (req: AuthRequest, res) => {
  const { job_title, revenue_amount, service_type, contact_id, source, notes, closed_at } = req.body;
  if (!job_title || !revenue_amount) return (res as any).status(400).json({ error: "job_title and revenue_amount required" });
  const amt = parseFloat(revenue_amount);
  if (isNaN(amt) || amt <= 0) return (res as any).status(400).json({ error: "Invalid revenue_amount" });
  const { rows } = await pool.query(
    `INSERT INTO bc_revenue_entries (user_id, contact_id, job_title, revenue_amount, service_type, source, notes, closed_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [req.user?.id || null, contact_id || null, job_title, amt, service_type || null, source || "manual", notes || null, closed_at || new Date().toISOString()]
  );
  if (contact_id) {
    await pool.query(`UPDATE bc_contacts SET status = 'closed', updated_at = NOW() WHERE id = $1`, [contact_id]).catch(() => {});
  }
  res.status(201).json({ entry: rows[0] });
});

router.delete("/burncall/revenue/:id", requireAuth, async (req: AuthRequest, res) => {
  await pool.query(`DELETE FROM bc_revenue_entries WHERE id = $1`, [req.params.id]);
  res.json({ success: true });
});

// ── LEAD CAPTURE WEBHOOKS ────────────────────────────────────────────────────

router.get("/burncall/webhooks", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_lead_webhooks WHERE user_id = $1 ORDER BY created_at DESC`, [req.user!.id]);
  res.json({ webhooks: rows });
});

router.post("/burncall/webhooks", requireAuth, async (req: AuthRequest, res) => {
  const { name, source_label } = req.body;
  if (!name) return (res as any).status(400).json({ error: "name required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_lead_webhooks (user_id, name, source_label) VALUES ($1,$2,$3) RETURNING *`,
    [req.user!.id, name, source_label || "Website Form"]
  );
  res.status(201).json({ webhook: rows[0] });
});

router.delete("/burncall/webhooks/:id", requireAuth, async (req: AuthRequest, res) => {
  await pool.query(`DELETE FROM bc_lead_webhooks WHERE id = $1 AND user_id = $2`, [req.params.id, req.user!.id]);
  res.json({ success: true });
});

// Public webhook intake — external forms POST to this
router.post("/burncall/capture/:key", async (req, res) => {
  const { key } = req.params;
  const wh = await pool.query(`SELECT * FROM bc_lead_webhooks WHERE webhook_key = $1 AND is_active = TRUE LIMIT 1`, [key]);
  if (!wh.rows.length) return (res as any).status(404).json({ error: "Webhook not found" });
  const w = wh.rows[0];
  const { name, email, phone, company, service, message, service_type } = req.body;
  if (!name) return (res as any).status(400).json({ error: "name required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_contacts (name, email, phone, company, service_type, notes, source, user_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [name, email || null, phone || null, company || null, service_type || service || null, message || null, w.source_label, w.user_id]
  );
  await pool.query(`UPDATE bc_lead_webhooks SET leads_captured = leads_captured + 1 WHERE id = $1`, [w.id]);
  const contact = rows[0];
  res.json({ success: true, contact_id: contact.id });
  if (contact) autoQualifyContact(contact);
});

// ── REMINDERS ────────────────────────────────────────────────────────────────

router.get("/burncall/reminders", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT r.*, c.name AS contact_name FROM bc_reminders r LEFT JOIN bc_contacts c ON c.id = r.contact_id WHERE r.user_id = $1 ORDER BY r.due_at ASC LIMIT 50`,
    [req.user!.id]
  );
  res.json({ reminders: rows });
});

router.post("/burncall/reminders", requireAuth, async (req: AuthRequest, res) => {
  const { contact_id, title, due_at, notes } = req.body;
  if (!title || !due_at) return (res as any).status(400).json({ error: "title and due_at required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_reminders (user_id, contact_id, title, due_at, notes) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [req.user!.id, contact_id || null, title, due_at, notes || null]
  );
  res.json({ reminder: rows[0] });
});

router.patch("/burncall/reminders/:id", requireAuth, async (req: AuthRequest, res) => {
  const { status } = req.body;
  await pool.query(`UPDATE bc_reminders SET status = $1 WHERE id = $2 AND user_id = $3`, [status, req.params.id, req.user!.id]);
  res.json({ success: true });
});

// ── BUSINESS SETUP ─────────────────────────────────────────────────────────────

router.get("/burncall/setup", requireAuth, async (req: AuthRequest, res) => {
  const profile = await pool.query(`SELECT * FROM bc_business_profile WHERE user_id = $1 LIMIT 1`, [req.user!.id]);
  res.json({ profile: profile.rows[0] || null });
});

router.post("/burncall/setup", requireAuth, async (req: AuthRequest, res) => {
  const { business_name, trade, service_area, business_hours, response_tone, qualifying_questions, custom_context, auto_respond_enabled } = req.body;
  const existing = await pool.query(`SELECT id FROM bc_business_profile WHERE user_id = $1`, [req.user!.id]);
  if (existing.rows.length > 0) {
    await pool.query(
      `UPDATE bc_business_profile SET business_name=$1, trade=$2, service_area=$3, business_hours=$4, response_tone=$5, qualifying_questions=$6, custom_context=$7, auto_respond_enabled=$8, updated_at=NOW() WHERE user_id=$9`,
      [business_name || null, trade || null, service_area || "Southwest Florida", business_hours || "Mon–Fri 8am–5pm", response_tone || "professional", qualifying_questions || [], custom_context || null, auto_respond_enabled || false, req.user!.id]
    );
  } else {
    await pool.query(
      `INSERT INTO bc_business_profile (user_id, business_name, trade, service_area, business_hours, response_tone, qualifying_questions, custom_context, auto_respond_enabled) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [req.user!.id, business_name || null, trade || null, service_area || "Southwest Florida", business_hours || "Mon–Fri 8am–5pm", response_tone || "professional", qualifying_questions || [], custom_context || null, auto_respond_enabled || false]
    );
    // Seed default automations on first setup
    const defaults = [
      { name: "AI Auto-Respond", description: "AI sends a personalized reply to new leads within 60 seconds", trigger: "new_lead", action: "auto_respond" },
      { name: "Emergency Alert", description: "Flags emergency leads and escalates for immediate call-back", trigger: "emergency_lead", action: "alert_owner" },
      { name: "Spam Filter", description: "Automatically marks spam leads and removes them from pipeline", trigger: "new_lead", action: "spam_filter" },
      { name: "24h Appointment Reminder", description: "Sends email reminder to contacts 24 hours before scheduled appointment", trigger: "appointment_upcoming", action: "send_reminder" },
      { name: "Lead Score Notification", description: "Notifies you when a Hot lead (score 70+) comes in", trigger: "hot_lead", action: "alert_owner" },
    ];
    for (const d of defaults) {
      await pool.query(
        `INSERT INTO bc_automations (user_id, name, description, trigger_event, action_type, is_enabled) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING`,
        [req.user!.id, d.name, d.description, d.trigger, d.action, true]
      ).catch(() => {});
    }
  }
  res.json({ success: true });
});

// ── SERVICES ───────────────────────────────────────────────────────────────────

router.get("/burncall/services", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_services WHERE user_id = $1 ORDER BY created_at ASC`, [req.user!.id]);
  res.json({ services: rows });
});

router.post("/burncall/services", requireAuth, async (req: AuthRequest, res) => {
  const { name, description, price_range, duration_estimate } = req.body;
  if (!name) return (res as any).status(400).json({ error: "name required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_services (user_id, name, description, price_range, duration_estimate) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [req.user!.id, name, description || null, price_range || null, duration_estimate || null]
  );
  res.json({ service: rows[0] });
});

router.delete("/burncall/services/:id", requireAuth, async (req: AuthRequest, res) => {
  await pool.query(`DELETE FROM bc_services WHERE id = $1 AND user_id = $2`, [req.params.id, req.user!.id]);
  res.json({ success: true });
});

// ── FAQS ────────────────────────────────────────────────────────────────────────

router.get("/burncall/faqs", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_faqs WHERE user_id = $1 ORDER BY created_at ASC`, [req.user!.id]);
  res.json({ faqs: rows });
});

router.post("/burncall/faqs", requireAuth, async (req: AuthRequest, res) => {
  const { question, answer } = req.body;
  if (!question || !answer) return (res as any).status(400).json({ error: "question and answer required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_faqs (user_id, question, answer) VALUES ($1,$2,$3) RETURNING *`,
    [req.user!.id, question, answer]
  );
  res.json({ faq: rows[0] });
});

router.delete("/burncall/faqs/:id", requireAuth, async (req: AuthRequest, res) => {
  await pool.query(`DELETE FROM bc_faqs WHERE id = $1 AND user_id = $2`, [req.params.id, req.user!.id]);
  res.json({ success: true });
});

// ── AUTOMATIONS ────────────────────────────────────────────────────────────────

router.get("/burncall/automations", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_automations WHERE user_id = $1 ORDER BY created_at ASC`, [req.user!.id]);
  res.json({ automations: rows });
});

router.post("/burncall/automations", requireAuth, async (req: AuthRequest, res) => {
  const { name, description, trigger_event, action_type, action_config } = req.body;
  if (!name || !trigger_event || !action_type) return (res as any).status(400).json({ error: "name, trigger_event, action_type required" });
  const { rows } = await pool.query(
    `INSERT INTO bc_automations (user_id, name, description, trigger_event, action_type, action_config) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.user!.id, name, description || null, trigger_event, action_type, action_config || {}]
  );
  res.json({ automation: rows[0] });
});

router.patch("/burncall/automations/:id", requireAuth, async (req: AuthRequest, res) => {
  const { is_enabled, name, description } = req.body;
  const sets: string[] = [];
  const params: any[] = [];
  const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
  add(is_enabled, "is_enabled"); add(name, "name"); add(description, "description");
  if (!sets.length) return (res as any).status(400).json({ error: "Nothing to update" });
  params.push(req.params.id, req.user!.id);
  await pool.query(`UPDATE bc_automations SET ${sets.join(", ")} WHERE id = $${params.length - 1} AND user_id = $${params.length}`, params);
  res.json({ success: true });
});

router.delete("/burncall/automations/:id", requireAuth, async (req: AuthRequest, res) => {
  await pool.query(`DELETE FROM bc_automations WHERE id = $1 AND user_id = $2`, [req.params.id, req.user!.id]);
  res.json({ success: true });
});

// ── STATS ─────────────────────────────────────────────────────────────────────

router.get("/burncall/stats", requireAuth, async (_req, res) => {
  const [contacts, newLeads, qualified, scheduled, appointments, campaigns, revenue, revenueTotal] = await Promise.all([
    pool.query(`SELECT COUNT(*) FROM bc_contacts`),
    pool.query(`SELECT COUNT(*) FROM bc_contacts WHERE status = 'new'`),
    pool.query(`SELECT COUNT(*) FROM bc_contacts WHERE status = 'qualified'`),
    pool.query(`SELECT COUNT(*) FROM bc_contacts WHERE status = 'scheduled'`),
    pool.query(`SELECT COUNT(*) FROM bc_appointments WHERE status = 'scheduled' AND scheduled_at > NOW()`),
    pool.query(`SELECT COUNT(*) FROM bc_campaigns WHERE status = 'sent'`),
    pool.query(`SELECT COUNT(*) FROM bc_contacts WHERE status = 'closed'`),
    pool.query(`SELECT COALESCE(SUM(revenue_amount),0) AS total, COUNT(*) AS jobs FROM bc_revenue_entries`),
  ]);
  res.json({
    totalContacts: parseInt(contacts.rows[0].count),
    newLeads: parseInt(newLeads.rows[0].count),
    qualifiedLeads: parseInt(qualified.rows[0].count),
    scheduledLeads: parseInt(scheduled.rows[0].count),
    upcomingAppointments: parseInt(appointments.rows[0].count),
    campaignsSent: parseInt(campaigns.rows[0].count),
    closedDeals: parseInt(revenue.rows[0].count),
    totalRevenue: parseFloat(revenueTotal.rows[0].total),
    totalJobs: parseInt(revenueTotal.rows[0].jobs),
  });
});

// ── ANALYTICS ────────────────────────────────────────────────────────────────

router.get("/burncall/analytics", requireAuth, async (_req, res) => {
  const [byStatus, bySource, conversionRate, revenueByMonth, topServices, recentActivity] = await Promise.all([
    pool.query(`SELECT status, COUNT(*) FROM bc_contacts GROUP BY status`),
    pool.query(`SELECT source, COUNT(*) AS count, COUNT(CASE WHEN status='closed' THEN 1 END) AS converted FROM bc_contacts GROUP BY source ORDER BY count DESC`),
    pool.query(`SELECT COUNT(CASE WHEN status='closed' THEN 1 END)::float / NULLIF(COUNT(*),0) * 100 AS rate FROM bc_contacts`),
    pool.query(`
      SELECT DATE_TRUNC('month', closed_at) AS month, SUM(revenue_amount) AS revenue, COUNT(*) AS jobs
      FROM bc_revenue_entries WHERE closed_at >= NOW() - INTERVAL '6 months'
      GROUP BY DATE_TRUNC('month', closed_at) ORDER BY month`),
    pool.query(`SELECT service_type, COUNT(*) AS leads, SUM(revenue_amount) AS revenue FROM bc_contacts c LEFT JOIN bc_revenue_entries re ON re.contact_id = c.id WHERE c.service_type IS NOT NULL GROUP BY c.service_type ORDER BY leads DESC LIMIT 10`),
    pool.query(`SELECT status, COUNT(*) AS count, MAX(updated_at) AS last_activity FROM bc_contacts GROUP BY status ORDER BY last_activity DESC`),
  ]);
  res.json({
    byStatus: byStatus.rows,
    bySource: bySource.rows,
    conversionRate: parseFloat(conversionRate.rows[0]?.rate || 0),
    revenueByMonth: revenueByMonth.rows,
    topServices: topServices.rows,
    recentActivity: recentActivity.rows,
  });
});

// ── AI ───────────────────────────────────────────────────────────────────────

router.post("/burncall/ai/chat", requireAuth, async (req: AuthRequest, res) => {
  const { messages, contactContext } = req.body;
  if (!Array.isArray(messages)) return (res as any).status(400).json({ error: "messages array required" });
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  try {
    const systemMessages: any[] = [{ role: "system", content: SYSTEM_PROMPT }];
    if (contactContext) {
      systemMessages.push({ role: "system", content: `Current lead: Name: ${contactContext.name}, Service: ${contactContext.service_type || "Unknown"}, Status: ${contactContext.status}, Phone: ${contactContext.phone || "N/A"}, Notes: ${contactContext.notes || "None"}${contactContext.ai_qualification ? `, AI Score: ${contactContext.ai_qualification.score}/10, Urgency: ${contactContext.ai_qualification.urgency}` : ""}` });
    }
    const stream = await openai.chat.completions.create({ model: "gpt-5.4", max_completion_tokens: 8192, messages: [...systemMessages, ...messages], stream: true });
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) res.write(`data: ${JSON.stringify({ content })}\n\n`);
    }
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err: any) {
    res.write(`data: ${JSON.stringify({ error: err.message || "AI error" })}\n\n`);
    res.end();
  }
});

router.post("/burncall/ai/qualify-lead", requireAuth, async (req: AuthRequest, res) => {
  const { inquiry, contactName, serviceType } = req.body;
  if (!inquiry) return (res as any).status(400).json({ error: "inquiry required" });
  try {
    const bizContext = await getBusinessContext(req.user?.id);
    const systemContent = bizContext
      ? `${SYSTEM_PROMPT}\n\n--- BUSINESS CONTEXT ---\n${bizContext}\n--- END CONTEXT ---`
      : SYSTEM_PROMPT;
    const completion = await openai.chat.completions.create({
      model: "gpt-5.4", max_completion_tokens: 600,
      messages: [
        { role: "system", content: `${systemContent}\n\nRespond ONLY with valid JSON (no markdown): { "qualified": boolean, "score": 0-100, "tier": "hot|warm|cold", "isSpam": boolean, "isEmergency": boolean, "summary": "brief lead summary", "nextStep": "recommended action", "estimatedValue": "dollar range", "urgency": "low|medium|high|emergency", "draftResponse": "ready-to-send reply to the customer" }` },
        { role: "user", content: `Qualify this lead:\nName: ${contactName || "Unknown"}\nService: ${serviceType || "Unknown"}\nInquiry: ${inquiry}` }
      ],
    });
    const text = completion.choices[0]?.message?.content || "{}";
    const json = JSON.parse(text.replace(/```json\n?|\n?```/g, "").trim());
    if (json.score <= 10) json.score = Math.round(json.score * 10);
    json.score = Math.max(0, Math.min(100, json.score || 0));
    if (!json.tier) json.tier = json.score >= 70 ? "hot" : json.score >= 40 ? "warm" : "cold";
    res.json(json);
  } catch {
    res.json({ qualified: true, score: 50, tier: "warm", isSpam: false, isEmergency: false, summary: inquiry, nextStep: "Follow up by phone", urgency: "medium", draftResponse: `Hi! Thanks for reaching out about ${serviceType || "our services"}. We'd love to help — what's the best number to call you back?` });
  }
});

router.post("/burncall/ai/draft-campaign", requireAuth, async (req: AuthRequest, res) => {
  const { campaignType, targetAudience, goal, businessType } = req.body;
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-5.4", max_completion_tokens: 1024,
      messages: [
        { role: "system", content: `${SYSTEM_PROMPT}\nYou are drafting outreach campaigns for home service businesses.` },
        { role: "user", content: `Draft a ${campaignType || "follow-up"} campaign for a ${businessType || "home service"} business.\nTarget: ${targetAudience || "past customers"}\nGoal: ${goal || "win back business"}\n\nProvide: subject line, message body (SMS-friendly, under 160 chars for text; full email for email), and 3 subject line alternatives.` }
      ],
      stream: true,
    });
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) res.write(`data: ${JSON.stringify({ content })}\n\n`);
    }
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err: any) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    res.end();
  }
});

// ── PUBLIC BOOKING (no auth required — customer-facing) ──────────────────────

router.get("/burncall/public/:webhookKey", async (req, res) => {
  const { webhookKey } = req.params;
  try {
    const wh = await pool.query(
      `SELECT w.*, u.id as owner_id FROM bc_lead_webhooks w JOIN users u ON u.id = w.user_id WHERE w.webhook_key = $1 AND w.is_active = TRUE LIMIT 1`,
      [webhookKey]
    );
    if (!wh.rows.length) return (res as any).status(404).json({ error: "Business not found" });
    const userId = wh.rows[0].owner_id;
    const [profile, services] = await Promise.all([
      pool.query(`SELECT business_name, trade, service_area, business_hours, response_tone FROM bc_business_profile WHERE user_id = $1 LIMIT 1`, [userId]),
      pool.query(`SELECT id, name, description, price_range, duration_estimate FROM bc_services WHERE user_id = $1 ORDER BY created_at LIMIT 20`, [userId]),
    ]);
    res.json({
      business: profile.rows[0] || { business_name: "Home Service Business", trade: "General Contractor", service_area: "Southwest Florida", business_hours: "Mon–Fri 8am–5pm" },
      services: services.rows,
    });
  } catch { (res as any).status(500).json({ error: "Server error" }); }
});

router.post("/burncall/public/:webhookKey/book", async (req, res) => {
  const { webhookKey } = req.params;
  try {
    const wh = await pool.query(
      `SELECT w.*, u.id as owner_id, u.email as owner_email FROM bc_lead_webhooks w JOIN users u ON u.id = w.user_id WHERE w.webhook_key = $1 AND w.is_active = TRUE LIMIT 1`,
      [webhookKey]
    );
    if (!wh.rows.length) return (res as any).status(404).json({ error: "Business not found" });
    const w = wh.rows[0];
    const { name, email, phone, service_type, message, preferred_date, preferred_time } = req.body;
    if (!name) return (res as any).status(400).json({ error: "Name is required" });

    // Create contact tied to this contractor
    const contactResult = await pool.query(
      `INSERT INTO bc_contacts (name, email, phone, service_type, notes, source, user_id) VALUES ($1,$2,$3,$4,$5,'booking_page',$6) RETURNING *`,
      [name, email || null, phone || null, service_type || null, message || null, w.owner_id]
    );
    const contact = contactResult.rows[0];
    await pool.query(`UPDATE bc_lead_webhooks SET leads_captured = leads_captured + 1 WHERE id = $1`, [w.id]);

    // Create appointment if date/time selected
    let appointment: any = null;
    if (preferred_date && preferred_time) {
      const scheduledAt = new Date(`${preferred_date}T${preferred_time}:00`);
      if (!isNaN(scheduledAt.getTime())) {
        const apptResult = await pool.query(
          `INSERT INTO bc_appointments (contact_id, user_id, title, scheduled_at, duration_minutes, notes) VALUES ($1,$2,$3,$4,60,$5) RETURNING *`,
          [contact.id, w.owner_id, `${service_type || "Service"} Estimate — ${name}`, scheduledAt, "Booked via BurnCall public page"]
        );
        appointment = apptResult.rows[0];
        await pool.query(`UPDATE bc_contacts SET status = 'scheduled', updated_at = NOW() WHERE id = $1`, [contact.id]);
      }
    }

    // Get business profile for email personalization
    const profile = await pool.query(`SELECT * FROM bc_business_profile WHERE user_id = $1 LIMIT 1`, [w.owner_id]);
    const biz = profile.rows[0];
    const bizName = biz?.business_name || "Our Team";

    // Customer confirmation email
    if (email) {
      const apptText = appointment
        ? `<div style="background:#1e293b;border-radius:8px;padding:16px;margin:16px 0;border-left:4px solid #22c55e">
            <p style="margin:0 0 8px;font-weight:bold;color:#22c55e">📅 Appointment Requested</p>
            <p style="margin:0;color:#e2e8f0">${new Date(appointment.scheduled_at).toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})} at ${preferred_time}</p>
          </div>`
        : `<p style="color:#94a3b8">We'll reach out shortly to schedule your appointment.</p>`;
      await sendEmail(email, `✅ Booking Received — ${bizName}`, `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto;background:#0f172a;color:#e2e8f0;border-radius:12px;overflow:hidden">
          <div style="background:linear-gradient(135deg,#ea580c,#dc2626);padding:28px;text-align:center">
            <div style="font-size:32px">⚡</div>
            <h1 style="margin:8px 0 4px;font-size:22px;color:white">BurnCall AI</h1>
            <p style="margin:0;color:rgba(255,255,255,0.85);font-size:13px">Booking confirmation</p>
          </div>
          <div style="padding:28px">
            <p style="font-size:18px;font-weight:bold;margin:0 0 16px">Hi ${name}! 👋</p>
            <p style="color:#cbd5e1;margin:0 0 16px">We received your request to <strong>${service_type || "schedule a service"}</strong> with <strong>${bizName}</strong>.</p>
            ${apptText}
            <p style="color:#94a3b8;margin:20px 0 0;font-size:13px">⚡ Our AI has already started reviewing your request. We aim to respond within 60 seconds. · Powered by BurnCall AI</p>
          </div>
        </div>`).catch(() => {});
    }

    // Contractor new-lead alert
    if (w.owner_email) {
      const apptLine = appointment
        ? `${new Date(appointment.scheduled_at).toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})} at ${preferred_time}`
        : "No specific time — follow up to schedule";
      await sendEmail(w.owner_email, `🔥 New BurnCall Lead: ${name}`, `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#0f172a;color:white;padding:20px;border-radius:8px 8px 0 0;display:flex;align-items:center;gap:10px">
            <span style="font-size:24px">⚡</span>
            <div><strong style="font-size:18px;color:#fb923c">New Lead via BurnCall</strong><br><span style="color:#94a3b8;font-size:13px">Booking Page · ${new Date().toLocaleString()}</span></div>
          </div>
          <table style="width:100%;border-collapse:collapse;border:1px solid #e5e7eb;border-top:none">
            <tr><td style="padding:10px 14px;background:#f9fafb;font-weight:bold;width:130px">Name</td><td style="padding:10px 14px"><strong>${name}</strong></td></tr>
            <tr><td style="padding:10px 14px;background:#f3f4f6;font-weight:bold">Phone</td><td style="padding:10px 14px;color:${phone ? "#16a34a" : "#6b7280"}">${phone || "Not provided"}</td></tr>
            <tr><td style="padding:10px 14px;background:#f9fafb;font-weight:bold">Email</td><td style="padding:10px 14px">${email || "Not provided"}</td></tr>
            <tr><td style="padding:10px 14px;background:#f3f4f6;font-weight:bold">Service</td><td style="padding:10px 14px">${service_type || "Not specified"}</td></tr>
            <tr><td style="padding:10px 14px;background:#f9fafb;font-weight:bold">Appointment</td><td style="padding:10px 14px">${apptLine}</td></tr>
            <tr><td style="padding:10px 14px;background:#f3f4f6;font-weight:bold">Message</td><td style="padding:10px 14px;font-style:italic">${message || "No message"}</td></tr>
          </table>
          <p style="color:#6b7280;font-size:12px;padding:12px 14px;border:1px solid #e5e7eb;border-top:none;margin:0">BurnCall AI is qualifying this lead now. Log in to see the AI score and draft response.</p>
        </div>`).catch(() => {});
    }

    res.json({ success: true, contact_id: contact.id, appointment_id: appointment?.id || null });
    autoQualifyContact(contact);
  } catch (err: any) {
    (res as any).status(500).json({ error: err.message || "Server error" });
  }
});

// ── Admin ─────────────────────────────────────────────────────────────────────

router.get("/admin/burncall/contacts", requireMasterAdmin, async (_req, res) => {
  const { rows } = await pool.query(`SELECT * FROM bc_contacts ORDER BY created_at DESC LIMIT 200`);
  res.json({ contacts: rows });
});

router.get("/admin/burncall/stats", requireMasterAdmin, async (_req, res) => {
  const [contacts, byStatus, appointments, campaigns, revenue] = await Promise.all([
    pool.query(`SELECT COUNT(*) FROM bc_contacts`),
    pool.query(`SELECT status, COUNT(*) FROM bc_contacts GROUP BY status`),
    pool.query(`SELECT COUNT(*) FROM bc_appointments`),
    pool.query(`SELECT COUNT(*) FROM bc_campaigns`),
    pool.query(`SELECT COALESCE(SUM(revenue_amount),0) AS total FROM bc_revenue_entries`),
  ]);
  res.json({
    totalContacts: parseInt(contacts.rows[0].count),
    byStatus: byStatus.rows,
    totalAppointments: parseInt(appointments.rows[0].count),
    totalCampaigns: parseInt(campaigns.rows[0].count),
    totalRevenue: parseFloat(revenue.rows[0].total),
  });
});

export default router;
