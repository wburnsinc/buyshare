import { Router } from "express";
import { pool } from "@workspace/db";
import { requireMasterAdmin } from "../../middleware/auth.js";

const router = Router();

async function ensureFeatureFlagsTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS feature_flags (
      key TEXT PRIMARY KEY,
      enabled BOOLEAN NOT NULL DEFAULT FALSE,
      label TEXT,
      description TEXT,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`
    INSERT INTO feature_flags (key, label, description, enabled) VALUES
      ('burncall',   'BurnCall AI',    'AI-powered lead response, CRM, campaigns & calendar for contractors', FALSE),
      ('earntree',   'EarnTree',       'Referral & affiliate rewards engine for users and businesses', FALSE),
      ('pocketcash', 'PocketCash',     'Community peer-to-peer micro-lending platform for SWFL members', FALSE)
    ON CONFLICT (key) DO NOTHING
  `).catch(() => {});
}
ensureFeatureFlagsTable();

router.get("/feature-flags", async (_req, res) => {
  const { rows } = await pool.query(`SELECT * FROM feature_flags ORDER BY key`);
  const map: Record<string, boolean> = {};
  rows.forEach((r: any) => { map[r.key] = r.enabled; });
  res.json({ flags: map, rows });
});

router.patch("/admin/feature-flags/:key", requireMasterAdmin, async (req, res) => {
  const { key } = req.params;
  const { enabled } = req.body;
  if (typeof enabled !== "boolean") return (res as any).status(400).json({ error: "enabled must be boolean" });
  await pool.query(
    `UPDATE feature_flags SET enabled = $1, updated_at = NOW() WHERE key = $2`,
    [enabled, key]
  );
  res.json({ success: true, key, enabled });
});

export default router;
export { ensureFeatureFlagsTable };
