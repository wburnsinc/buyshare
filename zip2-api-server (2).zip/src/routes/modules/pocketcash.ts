import { Router } from "express";
import { pool } from "@workspace/db";
import { requireAuth, type AuthRequest } from "../../middleware/auth.js";

const router = Router();

const PLATFORM_FEE_PCT = 0.025;
const PLATFORM_FEE_FLAT = 1.0;

async function ensureTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pocketcash_campaigns (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      user_name TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      category TEXT NOT NULL DEFAULT 'General',
      goal_amount NUMERIC(10,2) NOT NULL,
      raised_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
      repaid_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
      duration_days INTEGER NOT NULL DEFAULT 14,
      status TEXT NOT NULL DEFAULT 'active',
      repayment_status TEXT NOT NULL DEFAULT 'none',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMPTZ
    )
  `).catch(() => {});
  await pool.query(`ALTER TABLE pocketcash_campaigns ADD COLUMN IF NOT EXISTS repaid_amount NUMERIC(10,2) NOT NULL DEFAULT 0`).catch(() => {});
  await pool.query(`ALTER TABLE pocketcash_campaigns ADD COLUMN IF NOT EXISTS repayment_status TEXT NOT NULL DEFAULT 'none'`).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS pocketcash_contributions (
      id TEXT PRIMARY KEY,
      campaign_id TEXT NOT NULL REFERENCES pocketcash_campaigns(id) ON DELETE CASCADE,
      contributor_id TEXT NOT NULL,
      contributor_name TEXT NOT NULL,
      amount NUMERIC(10,2) NOT NULL,
      note TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_repayments (
      id TEXT PRIMARY KEY,
      campaign_id TEXT NOT NULL REFERENCES pocketcash_campaigns(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      amount NUMERIC(10,2) NOT NULL,
      note TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Wallets — per-user balance (virtual, tracks platform credits)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_wallets (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      balance NUMERIC(10,2) NOT NULL DEFAULT 0,
      total_deposited NUMERIC(10,2) NOT NULL DEFAULT 0,
      total_withdrawn NUMERIC(10,2) NOT NULL DEFAULT 0,
      total_interest_earned NUMERIC(10,2) NOT NULL DEFAULT 0,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_wallet_transactions (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      type TEXT NOT NULL,
      amount NUMERIC(10,2) NOT NULL,
      description TEXT,
      ref_id TEXT,
      balance_after NUMERIC(10,2),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS pc_wallet_tx_user_idx ON pc_wallet_transactions (user_id)`).catch(() => {});

  // Formal loans — structured P2P lending
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_loans (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      borrower_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      borrower_name TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      purpose TEXT NOT NULL DEFAULT 'General',
      amount_requested NUMERIC(10,2) NOT NULL,
      amount_funded NUMERIC(10,2) NOT NULL DEFAULT 0,
      amount_repaid NUMERIC(10,2) NOT NULL DEFAULT 0,
      interest_rate NUMERIC(5,2) NOT NULL DEFAULT 5.0,
      term_months INTEGER NOT NULL DEFAULT 6,
      monthly_payment NUMERIC(10,2),
      status TEXT NOT NULL DEFAULT 'seeking',
      funded_at TIMESTAMPTZ,
      due_date TIMESTAMPTZ,
      next_payment_due TIMESTAMPTZ,
      total_interest_accrued NUMERIC(10,2) NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS pc_loans_borrower_idx ON pc_loans (borrower_id)`).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS pc_loans_status_idx ON pc_loans (status)`).catch(() => {});

  // Loan investments — multiple lenders can fund the same loan
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_loan_investments (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      loan_id TEXT NOT NULL REFERENCES pc_loans(id) ON DELETE CASCADE,
      lender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      amount NUMERIC(10,2) NOT NULL,
      pct_share NUMERIC(6,4),
      interest_earned NUMERIC(10,2) NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS pc_loan_invest_lender_idx ON pc_loan_investments (lender_id)`).catch(() => {});

  // Loan payments
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_loan_payments (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      loan_id TEXT NOT NULL REFERENCES pc_loans(id) ON DELETE CASCADE,
      borrower_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      amount NUMERIC(10,2) NOT NULL,
      principal_portion NUMERIC(10,2) NOT NULL DEFAULT 0,
      interest_portion NUMERIC(10,2) NOT NULL DEFAULT 0,
      note TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Withdraw requests
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_withdraw_requests (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      amount NUMERIC(10,2) NOT NULL,
      method TEXT NOT NULL DEFAULT 'ach',
      account_info TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      processed_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Favorites
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pc_favorites (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      loan_id TEXT REFERENCES pc_loans(id) ON DELETE CASCADE,
      campaign_id TEXT REFERENCES pocketcash_campaigns(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(user_id, loan_id)
    )
  `).catch(() => {});
}
ensureTables();

const CATEGORIES = ["Medical Expense", "Car Repair", "Home Repair", "Tuition / Education", "Community Support", "Small Business", "General"];
const LOAN_PURPOSES = ["Medical", "Home Repair", "Vehicle", "Education", "Small Business", "Debt Consolidation", "Emergency", "Other"];

async function getOrCreateWallet(userId: string) {
  const { rows } = await pool.query(
    `INSERT INTO pc_wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO UPDATE SET updated_at = NOW() RETURNING *`,
    [userId]
  );
  return rows[0];
}

async function recordWalletTx(userId: string, type: string, amount: number, description: string, refId?: string) {
  const wallet = await getOrCreateWallet(userId);
  const newBalance = parseFloat(wallet.balance) + amount;
  await pool.query(
    `UPDATE pc_wallets SET balance = $1, updated_at = NOW(),
     total_deposited = CASE WHEN $2 > 0 THEN total_deposited + $2 ELSE total_deposited END,
     total_withdrawn = CASE WHEN $2 < 0 THEN total_withdrawn + ABS($2) ELSE total_withdrawn END
     WHERE user_id = $3`,
    [newBalance, amount, userId]
  );
  await pool.query(
    `INSERT INTO pc_wallet_transactions (user_id, type, amount, description, ref_id, balance_after) VALUES ($1,$2,$3,$4,$5,$6)`,
    [userId, type, Math.abs(amount), description, refId || null, newBalance]
  );
  return newBalance;
}

// ─── WALLET ──────────────────────────────────────────────────────────────────

router.get("/pocketcash/wallet", requireAuth, async (req: AuthRequest, res) => {
  const wallet = await getOrCreateWallet(req.user!.id);
  const { rows: txs } = await pool.query(
    `SELECT * FROM pc_wallet_transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`,
    [req.user!.id]
  );
  res.json({ wallet, transactions: txs });
});

router.post("/pocketcash/wallet/add-funds", requireAuth, async (req: AuthRequest, res) => {
  const { amount } = req.body;
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt < 10 || amt > 5000) return (res as any).status(400).json({ error: "Amount must be $10–$5,000" });
  const newBal = await recordWalletTx(req.user!.id, "deposit", amt, "Funds added to wallet");
  res.json({ success: true, newBalance: newBal });
});

router.post("/pocketcash/wallet/withdraw", requireAuth, async (req: AuthRequest, res) => {
  const { amount, method = "ach", account_info } = req.body;
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt < 10) return (res as any).status(400).json({ error: "Minimum withdrawal is $10" });
  const wallet = await getOrCreateWallet(req.user!.id);
  if (parseFloat(wallet.balance) < amt) return (res as any).status(400).json({ error: "Insufficient balance" });
  const id = `pcwr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  await pool.query(
    `INSERT INTO pc_withdraw_requests (id, user_id, amount, method, account_info) VALUES ($1,$2,$3,$4,$5)`,
    [id, req.user!.id, amt, method, account_info || null]
  );
  await recordWalletTx(req.user!.id, "withdrawal", -amt, `Withdrawal requested (${method})`);
  res.json({ success: true, message: "Withdrawal request submitted (2–3 business days)" });
});

// ─── LOANS ────────────────────────────────────────────────────────────────────

router.get("/pocketcash/loans", async (req, res) => {
  const { status = "seeking", purpose, sort = "newest" } = req.query as any;
  let q = `
    SELECT l.*, u.name AS borrower_name,
      COALESCE((SELECT COUNT(DISTINCT lender_id) FROM pc_loan_investments WHERE loan_id = l.id), 0)::int AS lender_count
    FROM pc_loans l JOIN users u ON u.id = l.borrower_id
    WHERE l.status = $1`;
  const params: any[] = [status];
  if (purpose && purpose !== "All") { params.push(purpose); q += ` AND l.purpose = $${params.length}`; }
  q += sort === "amount" ? " ORDER BY l.amount_requested DESC"
    : sort === "rate" ? " ORDER BY l.interest_rate DESC"
    : " ORDER BY l.created_at DESC";
  q += " LIMIT 50";
  const { rows } = await pool.query(q, params);
  res.json({ loans: rows, purposes: LOAN_PURPOSES });
});

router.get("/pocketcash/loans/:id", async (req, res) => {
  const loan = await pool.query(`SELECT l.*, u.name AS borrower_name FROM pc_loans l JOIN users u ON u.id = l.borrower_id WHERE l.id = $1 LIMIT 1`, [req.params.id]);
  if (!loan.rows.length) return (res as any).status(404).json({ error: "Loan not found" });
  const investments = await pool.query(`SELECT li.*, u.name AS lender_name FROM pc_loan_investments li JOIN users u ON u.id = li.lender_id WHERE li.loan_id = $1 ORDER BY li.created_at ASC`, [req.params.id]);
  const payments = await pool.query(`SELECT * FROM pc_loan_payments WHERE loan_id = $1 ORDER BY created_at DESC`, [req.params.id]);
  res.json({ loan: loan.rows[0], investments: investments.rows, payments: payments.rows });
});

router.post("/pocketcash/loans", requireAuth, async (req: AuthRequest, res) => {
  const { title, description, purpose, amount_requested, interest_rate, term_months } = req.body;
  if (!title || !amount_requested) return (res as any).status(400).json({ error: "title and amount_requested required" });
  const amount = parseFloat(amount_requested);
  if (isNaN(amount) || amount < 100 || amount > 10000) return (res as any).status(400).json({ error: "Loan amount $100–$10,000" });
  const rate = Math.max(3, Math.min(25, parseFloat(interest_rate) || 8));
  const months = Math.max(1, Math.min(36, parseInt(term_months) || 6));
  const monthlyRate = rate / 100 / 12;
  const monthly = amount * (monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
  const userRows = await pool.query(`SELECT first_name, last_name, name FROM users WHERE id = $1 LIMIT 1`, [req.user!.id]);
  const u = userRows.rows[0] || {};
  const borrower_name = u.name || [u.first_name, u.last_name].filter(Boolean).join(" ") || req.user!.email.split("@")[0];
  const { rows } = await pool.query(
    `INSERT INTO pc_loans (borrower_id, borrower_name, title, description, purpose, amount_requested, interest_rate, term_months, monthly_payment)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [req.user!.id, borrower_name, title, description || null, purpose || "Other", amount, rate, months, monthly.toFixed(2)]
  );
  res.status(201).json({ loan: rows[0] });
});

router.post("/pocketcash/loans/:id/invest", requireAuth, async (req: AuthRequest, res) => {
  const { amount } = req.body;
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt < 25) return (res as any).status(400).json({ error: "Minimum investment is $25" });
  const loan = await pool.query(`SELECT * FROM pc_loans WHERE id = $1 LIMIT 1`, [req.params.id]);
  if (!loan.rows.length) return (res as any).status(404).json({ error: "Loan not found" });
  const l = loan.rows[0];
  if (l.status !== "seeking") return (res as any).status(400).json({ error: "Loan is not accepting investments" });
  if (l.borrower_id === req.user!.id) return (res as any).status(400).json({ error: "Cannot invest in your own loan" });
  const wallet = await getOrCreateWallet(req.user!.id);
  if (parseFloat(wallet.balance) < amt) return (res as any).status(400).json({ error: "Insufficient wallet balance" });
  const remaining = parseFloat(l.amount_requested) - parseFloat(l.amount_funded);
  const investAmt = Math.min(amt, remaining);
  await pool.query(
    `INSERT INTO pc_loan_investments (loan_id, lender_id, amount, pct_share) VALUES ($1,$2,$3,$4)`,
    [l.id, req.user!.id, investAmt, (investAmt / parseFloat(l.amount_requested)) * 100]
  );
  const newFunded = parseFloat(l.amount_funded) + investAmt;
  const fullyFunded = newFunded >= parseFloat(l.amount_requested);
  await pool.query(
    `UPDATE pc_loans SET amount_funded = $1, status = CASE WHEN $2 THEN 'funded' ELSE status END, funded_at = CASE WHEN $2 THEN NOW() ELSE funded_at END, updated_at = NOW() WHERE id = $3`,
    [newFunded, fullyFunded, l.id]
  );
  await recordWalletTx(req.user!.id, "investment", -investAmt, `Investment in loan "${l.title}"`, l.id);
  if (fullyFunded) {
    await recordWalletTx(l.borrower_id, "loan_received", parseFloat(l.amount_requested), `Loan funded: "${l.title}"`, l.id);
  }
  res.json({ success: true, invested: investAmt, fullyFunded });
});

router.post("/pocketcash/loans/:id/pay", requireAuth, async (req: AuthRequest, res) => {
  const { amount, note } = req.body;
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt <= 0) return (res as any).status(400).json({ error: "Invalid amount" });
  const loan = await pool.query(`SELECT * FROM pc_loans WHERE id = $1 LIMIT 1`, [req.params.id]);
  if (!loan.rows.length) return (res as any).status(404).json({ error: "Loan not found" });
  const l = loan.rows[0];
  if (l.borrower_id !== req.user!.id) return (res as any).status(403).json({ error: "Only borrower can make payments" });
  if (!["funded", "active"].includes(l.status)) return (res as any).status(400).json({ error: "Loan is not active" });
  const outstanding = parseFloat(l.amount_requested) - parseFloat(l.amount_repaid);
  const interestPortion = outstanding * (parseFloat(l.interest_rate) / 100 / 12);
  const principalPortion = Math.max(0, amt - interestPortion);
  const payId = `pclp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  await pool.query(
    `INSERT INTO pc_loan_payments (id, loan_id, borrower_id, amount, principal_portion, interest_portion, note) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [payId, l.id, req.user!.id, amt, principalPortion.toFixed(2), interestPortion.toFixed(2), note || null]
  );
  await pool.query(`UPDATE pc_loans SET amount_repaid = amount_repaid + $1, updated_at = NOW() WHERE id = $2`, [amt, l.id]);
  // Check if fully repaid
  const updated = await pool.query(`SELECT * FROM pc_loans WHERE id = $1`, [l.id]);
  if (parseFloat(updated.rows[0].amount_repaid) >= parseFloat(updated.rows[0].amount_requested)) {
    await pool.query(`UPDATE pc_loans SET status = 'repaid', updated_at = NOW() WHERE id = $1`, [l.id]);
    // Distribute interest to lenders
    const investments = await pool.query(`SELECT * FROM pc_loan_investments WHERE loan_id = $1`, [l.id]);
    for (const inv of investments.rows) {
      const lenderInterest = interestPortion * (parseFloat(inv.pct_share) / 100);
      await pool.query(`UPDATE pc_loan_investments SET interest_earned = interest_earned + $1 WHERE id = $2`, [lenderInterest.toFixed(2), inv.id]);
      await recordWalletTx(inv.lender_id, "interest", lenderInterest, `Interest earned on loan "${l.title}"`, l.id);
      await recordWalletTx(inv.lender_id, "repayment", parseFloat(inv.amount), `Principal repaid from loan "${l.title}"`, l.id);
    }
  }
  res.json({ success: true, payment: { amount: amt, principalPortion: principalPortion.toFixed(2), interestPortion: interestPortion.toFixed(2) } });
});

// ─── MY LOANS / INVESTMENTS ───────────────────────────────────────────────────

router.get("/pocketcash/my-loans", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT l.*, COALESCE((SELECT COUNT(DISTINCT lender_id) FROM pc_loan_investments WHERE loan_id = l.id), 0)::int AS lender_count
     FROM pc_loans l WHERE l.borrower_id = $1 ORDER BY l.created_at DESC`,
    [req.user!.id]
  );
  res.json({ loans: rows });
});

router.get("/pocketcash/my-investments", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT li.*, l.title, l.status AS loan_status, l.interest_rate, l.term_months, l.amount_requested, l.amount_funded, l.amount_repaid, l.borrower_name
     FROM pc_loan_investments li JOIN pc_loans l ON l.id = li.loan_id
     WHERE li.lender_id = $1 ORDER BY li.created_at DESC`,
    [req.user!.id]
  );
  res.json({ investments: rows });
});

router.get("/pocketcash/my-payments", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT lp.*, l.title FROM pc_loan_payments lp JOIN pc_loans l ON l.id = lp.loan_id WHERE lp.borrower_id = $1 ORDER BY lp.created_at DESC LIMIT 50`,
    [req.user!.id]
  );
  res.json({ payments: rows });
});

// ─── FAVORITES ───────────────────────────────────────────────────────────────

router.get("/pocketcash/favorites", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT f.*, l.title AS loan_title, l.status AS loan_status, l.amount_requested, l.interest_rate
     FROM pc_favorites f LEFT JOIN pc_loans l ON l.id = f.loan_id
     WHERE f.user_id = $1 ORDER BY f.created_at DESC`,
    [req.user!.id]
  );
  res.json({ favorites: rows });
});

router.post("/pocketcash/favorites", requireAuth, async (req: AuthRequest, res) => {
  const { loan_id, campaign_id } = req.body;
  await pool.query(
    `INSERT INTO pc_favorites (user_id, loan_id, campaign_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
    [req.user!.id, loan_id || null, campaign_id || null]
  );
  res.json({ success: true });
});

router.delete("/pocketcash/favorites/:id", requireAuth, async (req: AuthRequest, res) => {
  await pool.query(`DELETE FROM pc_favorites WHERE id = $1 AND user_id = $2`, [req.params.id, req.user!.id]);
  res.json({ success: true });
});

// ─── CAMPAIGNS (legacy crowd-funding) ────────────────────────────────────────

router.get("/pocketcash/campaigns", async (req, res) => {
  const { category, sort = "newest", status } = req.query as any;
  const showStatus = status || "active";
  let q = `SELECT c.*, COALESCE((SELECT COUNT(*) FROM pocketcash_contributions WHERE campaign_id = c.id),0)::int AS supporters
           FROM pocketcash_campaigns c WHERE c.status = $1`;
  const params: any[] = [showStatus];
  if (category && category !== "All") { params.push(category); q += ` AND c.category = $${params.length}`; }
  q += sort === "popular" ? " ORDER BY supporters DESC, c.raised_amount DESC"
     : sort === "ending" ? " ORDER BY c.expires_at ASC NULLS LAST"
     : sort === "funded" ? " ORDER BY c.raised_amount / NULLIF(c.goal_amount, 0) DESC"
     : " ORDER BY c.created_at DESC";
  q += " LIMIT 50";
  const { rows } = await pool.query(q, params);
  res.json({ campaigns: rows, categories: CATEGORIES });
});

router.get("/pocketcash/campaigns/:id", async (req, res) => {
  const camp = await pool.query(`
    SELECT c.*, COALESCE((SELECT COUNT(*) FROM pocketcash_contributions WHERE campaign_id = c.id),0)::int AS supporters
    FROM pocketcash_campaigns c WHERE c.id = $1 LIMIT 1`, [req.params.id]);
  if (!camp.rows.length) return (res as any).status(404).json({ error: "Campaign not found" });
  const contribs = await pool.query(`SELECT * FROM pocketcash_contributions WHERE campaign_id = $1 ORDER BY created_at DESC`, [req.params.id]);
  const repayments = await pool.query(`SELECT * FROM pc_repayments WHERE campaign_id = $1 ORDER BY created_at DESC`, [req.params.id]);
  res.json({ campaign: camp.rows[0], contributions: contribs.rows, repayments: repayments.rows });
});

router.post("/pocketcash/campaigns", requireAuth, async (req: AuthRequest, res) => {
  const { title, description, category, goal_amount, duration_days } = req.body;
  if (!title || !goal_amount) return (res as any).status(400).json({ error: "title and goal_amount required" });
  const amount = parseFloat(goal_amount);
  if (isNaN(amount) || amount < 100 || amount > 1000) return (res as any).status(400).json({ error: "goal_amount must be $100–$1,000" });
  const userRows = await pool.query(`SELECT first_name, last_name, name FROM users WHERE id = $1 LIMIT 1`, [req.user!.id]);
  const u = userRows.rows[0] || {};
  const user_name = u.name || [u.first_name, u.last_name].filter(Boolean).join(" ") || req.user!.email.split("@")[0];
  const id = `pc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const days = Math.min(Math.max(parseInt(duration_days) || 14, 3), 30);
  await pool.query(
    `INSERT INTO pocketcash_campaigns (id, user_id, user_name, title, description, category, goal_amount, duration_days, expires_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8, NOW() + INTERVAL '1 day' * $9)`,
    [id, req.user!.id, user_name, title, description || null, category || "General", amount, days, days]
  );
  const { rows } = await pool.query(`SELECT * FROM pocketcash_campaigns WHERE id = $1`, [id]);
  res.status(201).json({ campaign: rows[0] });
});

router.post("/pocketcash/campaigns/:id/contribute", requireAuth, async (req: AuthRequest, res) => {
  const { id } = req.params;
  const { amount, note } = req.body;
  const camp = await pool.query(`SELECT * FROM pocketcash_campaigns WHERE id = $1 LIMIT 1`, [id]);
  if (!camp.rows.length) return (res as any).status(404).json({ error: "Campaign not found" });
  const c = camp.rows[0];
  if (c.status !== "active") return (res as any).status(400).json({ error: "Campaign is not active" });
  if (c.user_id === req.user!.id) return (res as any).status(400).json({ error: "Cannot fund your own campaign" });
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt < 1) return (res as any).status(400).json({ error: "Minimum contribution is $1" });
  const userRows = await pool.query(`SELECT first_name, last_name, name FROM users WHERE id = $1 LIMIT 1`, [req.user!.id]);
  const u = userRows.rows[0] || {};
  const contributor_name = u.name || [u.first_name, u.last_name].filter(Boolean).join(" ") || req.user!.email.split("@")[0];
  const contribId = `pcc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  await pool.query(
    `INSERT INTO pocketcash_contributions (id, campaign_id, contributor_id, contributor_name, amount, note) VALUES ($1,$2,$3,$4,$5,$6)`,
    [contribId, id, req.user!.id, contributor_name, amt, note || null]
  );
  await pool.query(`UPDATE pocketcash_campaigns SET raised_amount = raised_amount + $1 WHERE id = $2`, [amt, id]);
  await pool.query(`
    UPDATE pocketcash_campaigns SET status = 'funded', repayment_status = 'pending'
    WHERE id = $1 AND raised_amount >= goal_amount AND status = 'active'
  `, [id]);
  const updated = await pool.query(`
    SELECT c.*, COALESCE((SELECT COUNT(*) FROM pocketcash_contributions WHERE campaign_id = c.id),0)::int AS supporters
    FROM pocketcash_campaigns c WHERE c.id = $1`, [id]);
  res.status(201).json({ success: true, campaign: updated.rows[0] });
});

router.post("/pocketcash/campaigns/:id/repay", requireAuth, async (req: AuthRequest, res) => {
  const { id } = req.params;
  const { amount, note } = req.body;
  const camp = await pool.query(`SELECT * FROM pocketcash_campaigns WHERE id = $1 LIMIT 1`, [id]);
  if (!camp.rows.length) return (res as any).status(404).json({ error: "Campaign not found" });
  const c = camp.rows[0];
  if (c.user_id !== req.user!.id) return (res as any).status(403).json({ error: "Only the campaign owner can mark repayments" });
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt <= 0) return (res as any).status(400).json({ error: "Invalid amount" });
  const repayId = `pcr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  await pool.query(`INSERT INTO pc_repayments (id, campaign_id, user_id, amount, note) VALUES ($1,$2,$3,$4,$5)`, [repayId, id, req.user!.id, amt, note || null]);
  await pool.query(`UPDATE pocketcash_campaigns SET repaid_amount = repaid_amount + $1 WHERE id = $2`, [amt, id]);
  await pool.query(`UPDATE pocketcash_campaigns SET repayment_status = 'complete' WHERE id = $1 AND repaid_amount >= raised_amount`, [id]);
  await pool.query(`UPDATE pocketcash_campaigns SET repayment_status = 'partial' WHERE id = $1 AND repaid_amount > 0 AND repaid_amount < raised_amount`, [id]);
  const updated = await pool.query(`SELECT * FROM pocketcash_campaigns WHERE id = $1`, [id]);
  res.json({ success: true, campaign: updated.rows[0] });
});

router.get("/pocketcash/campaigns/:id/repayments", async (req, res) => {
  const { rows } = await pool.query(`SELECT * FROM pc_repayments WHERE campaign_id = $1 ORDER BY created_at DESC`, [req.params.id]);
  res.json({ repayments: rows });
});

router.get("/pocketcash/my-campaigns", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT c.*, COALESCE((SELECT COUNT(*) FROM pocketcash_contributions WHERE campaign_id = c.id), 0)::int AS supporters,
     COALESCE((SELECT SUM(amount) FROM pc_repayments WHERE campaign_id = c.id), 0)::float AS repaid_total
     FROM pocketcash_campaigns c WHERE c.user_id = $1 ORDER BY c.created_at DESC`,
    [req.user!.id]
  );
  res.json({ campaigns: rows });
});

router.get("/pocketcash/my-contributions", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT co.*, c.title AS campaign_title, c.status AS campaign_status,
     c.raised_amount, c.goal_amount, c.repaid_amount, c.repayment_status, c.user_id AS campaign_owner_id
     FROM pocketcash_contributions co JOIN pocketcash_campaigns c ON co.campaign_id = c.id
     WHERE co.contributor_id = $1 ORDER BY co.created_at DESC`,
    [req.user!.id]
  );
  res.json({ contributions: rows });
});

// ─── DASHBOARD ────────────────────────────────────────────────────────────────

router.get("/pocketcash/dashboard", requireAuth, async (req: AuthRequest, res) => {
  const uid = req.user!.id;
  const [wallet, borrowing, lending, loans, investments, loanPayments, recent] = await Promise.all([
    getOrCreateWallet(uid),
    pool.query(`SELECT COALESCE(SUM(raised_amount),0) AS total_raised, COALESCE(SUM(goal_amount),0) AS total_goal, COUNT(*) AS campaigns, COUNT(CASE WHEN status='funded' THEN 1 END) AS funded_count FROM pocketcash_campaigns WHERE user_id=$1`, [uid]),
    pool.query(`SELECT COALESCE(SUM(amount),0) AS total_invested, COUNT(*) AS contributions FROM pocketcash_contributions WHERE contributor_id=$1`, [uid]),
    pool.query(`SELECT COUNT(*) AS total, COUNT(CASE WHEN status='seeking' THEN 1 END) AS seeking, COUNT(CASE WHEN status='funded' THEN 1 END) AS funded, COALESCE(SUM(amount_requested),0) AS total_borrowed FROM pc_loans WHERE borrower_id=$1`, [uid]),
    pool.query(`SELECT COUNT(*) AS count, COALESCE(SUM(amount),0) AS total, COALESCE(SUM(interest_earned),0) AS interest FROM pc_loan_investments WHERE lender_id=$1`, [uid]),
    pool.query(`SELECT COALESCE(SUM(amount),0) AS total FROM pc_loan_payments WHERE borrower_id=$1`, [uid]),
    pool.query(`
      SELECT 'contribution' AS type, co.amount::float AS amount, co.created_at, c.title AS label, c.status AS item_status
      FROM pocketcash_contributions co JOIN pocketcash_campaigns c ON co.campaign_id = c.id WHERE co.contributor_id=$1
      UNION ALL
      SELECT 'campaign' AS type, raised_amount::float AS amount, created_at, title AS label, status AS item_status FROM pocketcash_campaigns WHERE user_id=$1
      UNION ALL
      SELECT 'loan_payment' AS type, lp.amount::float AS amount, lp.created_at, l.title AS label, 'paid' AS item_status FROM pc_loan_payments lp JOIN pc_loans l ON l.id = lp.loan_id WHERE lp.borrower_id=$1
      ORDER BY created_at DESC LIMIT 15`, [uid]),
  ]);
  res.json({
    wallet,
    borrowing: {
      total_raised: parseFloat(borrowing.rows[0].total_raised),
      total_goal: parseFloat(borrowing.rows[0].total_goal),
      campaigns: parseInt(borrowing.rows[0].campaigns),
      funded_count: parseInt(borrowing.rows[0].funded_count),
      total_borrowed: parseFloat(loans.rows[0].total_borrowed),
      total_repaid: parseFloat(loanPayments.rows[0].total),
    },
    lending: {
      total_invested: parseFloat(lending.rows[0].total_invested) + parseFloat(investments.rows[0].total),
      contributions: parseInt(lending.rows[0].contributions),
      loan_investments: parseInt(investments.rows[0].count),
      interest_earned: parseFloat(investments.rows[0].interest),
    },
    recent: recent.rows,
  });
});

export default router;
