import { Router } from "express";
import { pool } from "@workspace/db";
import { requireAuth, requireMasterAdmin, type AuthRequest } from "../../middleware/auth.js";
import crypto from "crypto";

const router = Router();

const RESEND_API_KEY = process.env.RESEND_API_KEY || process.env.RESEND_KEY || "";
const FROM_EMAIL = RESEND_API_KEY ? "EarnTree <onboarding@resend.dev>" : "";

async function sendEmail(to: string, subject: string, html: string) {
  if (!RESEND_API_KEY) return;
  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, html }),
  }).catch(() => {});
}

async function ensureEarnTreeTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_referral_codes (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      code TEXT NOT NULL UNIQUE,
      clicks INTEGER NOT NULL DEFAULT 0,
      conversions INTEGER NOT NULL DEFAULT 0,
      total_earned_cents INTEGER NOT NULL DEFAULT 0,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS et_referral_codes_user_idx ON et_referral_codes (user_id)`).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS et_referral_codes_code_idx ON et_referral_codes (code)`).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_referrals (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      referrer_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      referred_user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      referred_email TEXT,
      code TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'clicked',
      reward_type TEXT NOT NULL DEFAULT 'signup',
      business_campaign_id TEXT,
      converted_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_commissions (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      referral_id TEXT REFERENCES et_referrals(id) ON DELETE SET NULL,
      share_submission_id TEXT,
      amount_cents INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      description TEXT,
      payout_method TEXT DEFAULT 'credit',
      paid_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_affiliate_tiers (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
      tier TEXT NOT NULL DEFAULT 'bronze',
      total_referrals INTEGER NOT NULL DEFAULT 0,
      total_shares INTEGER NOT NULL DEFAULT 0,
      total_earned_cents INTEGER NOT NULL DEFAULT 0,
      network_activated BOOLEAN NOT NULL DEFAULT FALSE,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`ALTER TABLE et_affiliate_tiers ADD COLUMN IF NOT EXISTS total_shares INTEGER NOT NULL DEFAULT 0`).catch(() => {});
  await pool.query(`ALTER TABLE et_affiliate_tiers ADD COLUMN IF NOT EXISTS network_activated BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_business_campaigns (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      business_name TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'General',
      description TEXT,
      website TEXT,
      phone TEXT,
      city TEXT,
      state TEXT DEFAULT 'FL',
      radius_miles INTEGER DEFAULT 25,
      reward_per_share_cents INTEGER NOT NULL DEFAULT 250,
      reward_per_signup_cents INTEGER NOT NULL DEFAULT 500,
      reward_per_booking_cents INTEGER NOT NULL DEFAULT 1500,
      weekly_budget_cents INTEGER NOT NULL DEFAULT 10000,
      spend_this_week_cents INTEGER NOT NULL DEFAULT 0,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      total_referrals INTEGER NOT NULL DEFAULT 0,
      total_shares INTEGER NOT NULL DEFAULT 0,
      total_paid_cents INTEGER NOT NULL DEFAULT 0,
      subscription_active BOOLEAN NOT NULL DEFAULT FALSE,
      subscription_expires_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS city TEXT`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS state TEXT DEFAULT 'FL'`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS radius_miles INTEGER DEFAULT 25`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS reward_per_share_cents INTEGER NOT NULL DEFAULT 250`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS weekly_budget_cents INTEGER NOT NULL DEFAULT 10000`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS spend_this_week_cents INTEGER NOT NULL DEFAULT 0`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS total_shares INTEGER NOT NULL DEFAULT 0`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS subscription_active BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await pool.query(`ALTER TABLE et_business_campaigns ADD COLUMN IF NOT EXISTS subscription_expires_at TIMESTAMPTZ`).catch(() => {});

  // Share submissions — core of the new model: users prove they shared on a platform
  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_share_submissions (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      business_campaign_id TEXT REFERENCES et_business_campaigns(id) ON DELETE SET NULL,
      platform TEXT NOT NULL,
      proof_url TEXT,
      caption TEXT,
      reward_cents INTEGER NOT NULL DEFAULT 250,
      status TEXT NOT NULL DEFAULT 'pending',
      reviewer_notes TEXT,
      reviewed_at TIMESTAMPTZ,
      reviewed_by TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS et_share_sub_user_idx ON et_share_submissions (user_id)`).catch(() => {});
  await pool.query(`CREATE INDEX IF NOT EXISTS et_share_sub_status_idx ON et_share_submissions (status)`).catch(() => {});

  // Network activation — user must share on 5 distinct platforms to unlock earning
  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_network_activations (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      platform TEXT NOT NULL,
      proof_url TEXT,
      activated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(user_id, platform)
    )
  `).catch(() => {});

  // Payout requests
  await pool.query(`
    CREATE TABLE IF NOT EXISTS et_payout_requests (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      amount_cents INTEGER NOT NULL,
      method TEXT NOT NULL DEFAULT 'check',
      paypal_email TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      processed_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`ALTER TABLE et_referrals ADD COLUMN IF NOT EXISTS business_campaign_id TEXT`).catch(() => {});
  await pool.query(`ALTER TABLE et_commissions ADD COLUMN IF NOT EXISTS share_submission_id TEXT`).catch(() => {});
}
ensureEarnTreeTables();

function generateCode(name: string): string {
  const base = name.replace(/\s+/g, "").toUpperCase().slice(0, 6);
  const suffix = crypto.randomBytes(3).toString("hex").toUpperCase();
  return `${base}${suffix}`;
}

function getTier(shares: number): string {
  if (shares >= 50) return "gold";
  if (shares >= 10) return "silver";
  return "bronze";
}

function getRewardCents(rewardType: string): number {
  const rewards: Record<string, number> = {
    share: 250,
    signup: 500,
    subscription: 1500,
    booking: 250,
    contractor_join: 2000,
    business_referral: 750,
  };
  return rewards[rewardType] ?? 250;
}

const SHARE_PLATFORMS = ["Facebook", "Instagram", "WhatsApp", "Nextdoor", "X (Twitter)", "TikTok", "LinkedIn", "Email", "SMS"];
const ACTIVATION_REQUIRED = 5;

// ── GET /api/earntree/my ──────────────────────────────────────────────────────
router.get("/earntree/my", requireAuth, async (req: AuthRequest, res) => {
  const userId = req.user!.id;

  let codeRow = await pool.query(`SELECT * FROM et_referral_codes WHERE user_id = $1 LIMIT 1`, [userId]);
  if (!codeRow.rows.length) {
    const code = generateCode(req.user!.name || req.user!.email || "USER");
    const ins = await pool.query(
      `INSERT INTO et_referral_codes (user_id, code) VALUES ($1,$2) ON CONFLICT (code) DO NOTHING RETURNING *`,
      [userId, code]
    );
    if (!ins.rows.length) {
      const retry = generateCode("USER");
      await pool.query(`INSERT INTO et_referral_codes (user_id, code) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [userId, retry]);
      codeRow = await pool.query(`SELECT * FROM et_referral_codes WHERE user_id = $1 LIMIT 1`, [userId]);
    } else {
      codeRow = ins;
    }
  }

  const [shares, commissions, tier, activations, payouts] = await Promise.all([
    pool.query(`SELECT ss.*, bc.business_name FROM et_share_submissions ss LEFT JOIN et_business_campaigns bc ON bc.id = ss.business_campaign_id WHERE ss.user_id = $1 ORDER BY ss.created_at DESC LIMIT 50`, [userId]),
    pool.query(`SELECT * FROM et_commissions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`, [userId]),
    pool.query(`SELECT * FROM et_affiliate_tiers WHERE user_id = $1 LIMIT 1`, [userId]),
    pool.query(`SELECT platform, activated_at FROM et_network_activations WHERE user_id = $1 ORDER BY activated_at ASC`, [userId]),
    pool.query(`SELECT * FROM et_payout_requests WHERE user_id = $1 ORDER BY created_at DESC LIMIT 20`, [userId]),
  ]);

  const approvedCents = commissions.rows.filter((c: any) => c.status === "approved" || c.status === "paid").reduce((sum: number, c: any) => sum + (c.amount_cents || 0), 0);
  const paidOutCents = commissions.rows.filter((c: any) => c.status === "paid").reduce((sum: number, c: any) => sum + (c.amount_cents || 0), 0);
  const pendingCents = commissions.rows.filter((c: any) => c.status === "pending").reduce((sum: number, c: any) => sum + (c.amount_cents || 0), 0);
  const availableBalanceCents = approvedCents - paidOutCents;
  const activePlatforms = activations.rows.map((a: any) => a.platform);
  const networkActivated = activePlatforms.length >= ACTIVATION_REQUIRED;

  res.json({
    code: codeRow.rows[0] || null,
    shares: shares.rows,
    commissions: commissions.rows,
    tier: tier.rows[0] || { tier: "bronze", total_referrals: 0, total_shares: 0, total_earned_cents: 0, network_activated: false },
    totalEarnedCents: approvedCents,
    pendingCents,
    availableBalanceCents,
    activePlatforms,
    networkActivated,
    payoutRequests: payouts.rows,
    platforms: SHARE_PLATFORMS,
    activationRequired: ACTIVATION_REQUIRED,
  });
});

// ── POST /api/earntree/track-click ────────────────────────────────────────────
router.post("/earntree/track-click", async (req, res) => {
  const { code } = req.body;
  if (!code) return (res as any).status(400).json({ error: "code required" });
  await pool.query(`UPDATE et_referral_codes SET clicks = clicks + 1 WHERE code = $1`, [code]).catch(() => {});
  res.json({ success: true });
});

// ── POST /api/earntree/network-activate ───────────────────────────────────────
router.post("/earntree/network-activate", requireAuth, async (req: AuthRequest, res) => {
  const { platform, proof_url } = req.body;
  const userId = req.user!.id;
  if (!platform || !SHARE_PLATFORMS.includes(platform)) {
    return (res as any).status(400).json({ error: "Invalid platform" });
  }
  await pool.query(
    `INSERT INTO et_network_activations (user_id, platform, proof_url) VALUES ($1,$2,$3)
     ON CONFLICT (user_id, platform) DO UPDATE SET proof_url = EXCLUDED.proof_url, activated_at = NOW()`,
    [userId, platform, proof_url || null]
  );
  const { rows } = await pool.query(`SELECT platform FROM et_network_activations WHERE user_id = $1`, [userId]);
  const count = rows.length;
  if (count >= ACTIVATION_REQUIRED) {
    await pool.query(
      `INSERT INTO et_affiliate_tiers (user_id, tier, network_activated) VALUES ($1,'bronze',TRUE)
       ON CONFLICT (user_id) DO UPDATE SET network_activated = TRUE, updated_at = NOW()`,
      [userId]
    );
  }
  res.json({ success: true, activated: rows.map((r: any) => r.platform), networkActivated: count >= ACTIVATION_REQUIRED });
});

// ── POST /api/earntree/share-submit ──────────────────────────────────────────
router.post("/earntree/share-submit", requireAuth, async (req: AuthRequest, res) => {
  const { platform, proof_url, caption, business_campaign_id } = req.body;
  const userId = req.user!.id;

  if (!platform || !SHARE_PLATFORMS.includes(platform)) {
    return (res as any).status(400).json({ error: "Invalid platform" });
  }
  if (!proof_url) {
    return (res as any).status(400).json({ error: "proof_url required (screenshot link or post URL)" });
  }

  // Check network is activated
  const tierRow = await pool.query(`SELECT network_activated FROM et_affiliate_tiers WHERE user_id = $1 LIMIT 1`, [userId]);
  if (!tierRow.rows.length || !tierRow.rows[0].network_activated) {
    return (res as any).status(403).json({ error: "Complete network activation (share on 5 platforms) first" });
  }

  // Fraud: max 3 shares per day
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todayCount = await pool.query(
    `SELECT COUNT(*) FROM et_share_submissions WHERE user_id = $1 AND created_at >= $2`,
    [userId, today.toISOString()]
  );
  if (parseInt(todayCount.rows[0].count) >= 3) {
    return (res as any).status(429).json({ error: "Maximum 3 share submissions per day" });
  }

  // Determine reward
  let rewardCents = 250;
  if (business_campaign_id) {
    const biz = await pool.query(`SELECT * FROM et_business_campaigns WHERE id = $1 AND is_active = TRUE`, [business_campaign_id]);
    if (biz.rows.length) {
      const b = biz.rows[0];
      if (b.spend_this_week_cents + rewardCents > b.weekly_budget_cents) {
        return (res as any).status(400).json({ error: "Campaign weekly budget reached" });
      }
      rewardCents = b.reward_per_share_cents || 250;
    }
  }

  const { rows } = await pool.query(
    `INSERT INTO et_share_submissions (user_id, business_campaign_id, platform, proof_url, caption, reward_cents)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [userId, business_campaign_id || null, platform, proof_url, caption || null, rewardCents]
  );

  res.status(201).json({ submission: rows[0], message: "Share submitted for review (12–48 hours)" });
});

// ── GET /api/earntree/my-share-submissions ────────────────────────────────────
router.get("/earntree/my-share-submissions", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(
    `SELECT ss.*, bc.business_name FROM et_share_submissions ss
     LEFT JOIN et_business_campaigns bc ON bc.id = ss.business_campaign_id
     WHERE ss.user_id = $1 ORDER BY ss.created_at DESC LIMIT 50`,
    [req.user!.id]
  );
  res.json({ submissions: rows });
});

// ── POST /api/earntree/payout-request ─────────────────────────────────────────
router.post("/earntree/payout-request", requireAuth, async (req: AuthRequest, res) => {
  const { method = "check", paypal_email } = req.body;
  const userId = req.user!.id;

  // Calculate available balance
  const [approved, paidOut, pendingPayouts] = await Promise.all([
    pool.query(`SELECT COALESCE(SUM(amount_cents),0) AS total FROM et_commissions WHERE user_id = $1 AND status IN ('approved','paid')`, [userId]),
    pool.query(`SELECT COALESCE(SUM(amount_cents),0) AS total FROM et_commissions WHERE user_id = $1 AND status = 'paid'`, [userId]),
    pool.query(`SELECT COUNT(*) FROM et_payout_requests WHERE user_id = $1 AND status = 'pending'`, [userId]),
  ]);

  if (parseInt(pendingPayouts.rows[0].count) > 0) {
    return (res as any).status(400).json({ error: "You already have a pending payout request" });
  }

  const availableCents = parseInt(approved.rows[0].total) - parseInt(paidOut.rows[0].total);
  const THRESHOLD = 10000; // $100

  if (availableCents < THRESHOLD) {
    return (res as any).status(400).json({ error: `Minimum payout is $100. Current balance: $${(availableCents / 100).toFixed(2)}` });
  }

  const { rows } = await pool.query(
    `INSERT INTO et_payout_requests (user_id, amount_cents, method, paypal_email) VALUES ($1,$2,$3,$4) RETURNING *`,
    [userId, availableCents, method, paypal_email || null]
  );

  res.status(201).json({ request: rows[0], message: "Payout request submitted (3–5 business days)" });
});

// ── GET /api/earntree/payout-balance ─────────────────────────────────────────
router.get("/earntree/payout-balance", requireAuth, async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const [approved, paidOut] = await Promise.all([
    pool.query(`SELECT COALESCE(SUM(amount_cents),0) AS total FROM et_commissions WHERE user_id = $1 AND status IN ('approved','paid')`, [userId]),
    pool.query(`SELECT COALESCE(SUM(amount_cents),0) AS total FROM et_commissions WHERE user_id = $1 AND status = 'paid'`, [userId]),
  ]);
  const availableCents = parseInt(approved.rows[0].total) - parseInt(paidOut.rows[0].total);
  res.json({ availableCents, availableDollars: (availableCents / 100).toFixed(2) });
});

// ── GET /api/earntree/analytics ───────────────────────────────────────────────
router.get("/earntree/analytics", requireAuth, async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const [byPlatform, byWeek, shareStats] = await Promise.all([
    pool.query(
      `SELECT platform, COUNT(*) AS count, SUM(reward_cents) AS earned_cents,
       COUNT(CASE WHEN status = 'approved' THEN 1 END) AS approved_count
       FROM et_share_submissions WHERE user_id = $1 GROUP BY platform`,
      [userId]
    ),
    pool.query(
      `SELECT DATE_TRUNC('week', created_at) AS week, COUNT(*) AS shares, SUM(reward_cents) AS earned_cents
       FROM et_share_submissions WHERE user_id = $1 AND status = 'approved'
       GROUP BY DATE_TRUNC('week', created_at) ORDER BY week DESC LIMIT 8`,
      [userId]
    ),
    pool.query(
      `SELECT COUNT(*) AS total, COUNT(CASE WHEN status = 'approved' THEN 1 END) AS approved,
       COUNT(CASE WHEN status = 'pending' THEN 1 END) AS pending,
       COUNT(CASE WHEN status = 'rejected' THEN 1 END) AS rejected
       FROM et_share_submissions WHERE user_id = $1`,
      [userId]
    ),
  ]);
  res.json({ byPlatform: byPlatform.rows, byWeek: byWeek.rows, shareStats: shareStats.rows[0] });
});

// ── POST /api/earntree/convert ────────────────────────────────────────────────
router.post("/earntree/convert", requireAuth, async (req: AuthRequest, res) => {
  const { code, rewardType = "signup", businessCampaignId } = req.body;
  if (!code) return (res as any).status(400).json({ error: "code required" });
  const codeRow = await pool.query(`SELECT * FROM et_referral_codes WHERE code = $1 AND is_active = TRUE`, [code]);
  if (!codeRow.rows.length) return (res as any).status(404).json({ error: "Invalid referral code" });
  const referrerId = codeRow.rows[0].user_id;
  const referredId = req.user!.id;
  if (referrerId === referredId) return (res as any).status(400).json({ error: "Cannot refer yourself" });
  const existing = await pool.query(`SELECT id FROM et_referrals WHERE referrer_user_id = $1 AND referred_user_id = $2`, [referrerId, referredId]);
  if (existing.rows.length) return (res as any).status(409).json({ error: "Already converted" });
  const referral = await pool.query(
    `INSERT INTO et_referrals (referrer_user_id, referred_user_id, referred_email, code, status, reward_type, business_campaign_id, converted_at)
     VALUES ($1,$2,$3,$4,'converted',$5,$6,NOW()) RETURNING *`,
    [referrerId, referredId, req.user!.email, code, rewardType, businessCampaignId || null]
  );
  let rewardCents = getRewardCents(rewardType);
  if (businessCampaignId) {
    const biz = await pool.query(`SELECT * FROM et_business_campaigns WHERE id = $1`, [businessCampaignId]);
    if (biz.rows.length) {
      rewardCents = rewardType === "booking" ? biz.rows[0].reward_per_booking_cents : biz.rows[0].reward_per_signup_cents;
      await pool.query(`UPDATE et_business_campaigns SET total_referrals = total_referrals + 1, total_paid_cents = total_paid_cents + $1 WHERE id = $2`, [rewardCents, businessCampaignId]);
    }
  }
  await pool.query(
    `INSERT INTO et_commissions (user_id, referral_id, amount_cents, description) VALUES ($1,$2,$3,$4)`,
    [referrerId, referral.rows[0].id, rewardCents, `Referral reward: ${rewardType}`]
  );
  await pool.query(`UPDATE et_referral_codes SET conversions = conversions + 1, total_earned_cents = total_earned_cents + $1 WHERE code = $2`, [rewardCents, code]);
  const totalRefs = await pool.query(`SELECT COUNT(*) FROM et_referrals WHERE referrer_user_id = $1 AND status = 'converted'`, [referrerId]);
  const totalCount = parseInt(totalRefs.rows[0].count);
  await pool.query(
    `INSERT INTO et_affiliate_tiers (user_id, tier, total_referrals, total_earned_cents) VALUES ($1,$2,$3,$4)
     ON CONFLICT (user_id) DO UPDATE SET tier = $2, total_referrals = $3, total_earned_cents = et_affiliate_tiers.total_earned_cents + $4, updated_at = NOW()`,
    [referrerId, getTier(totalCount), totalCount, rewardCents]
  );
  res.json({ success: true, rewardCents });
});

// ── GET /api/earntree/leaderboard ─────────────────────────────────────────────
router.get("/earntree/leaderboard", async (_req, res) => {
  const { rows } = await pool.query(`
    SELECT t.user_id, u.name, u.email, t.tier, t.total_referrals, t.total_shares, t.total_earned_cents, t.network_activated
    FROM et_affiliate_tiers t JOIN users u ON u.id = t.user_id
    ORDER BY t.total_earned_cents DESC LIMIT 20
  `).catch(() => ({ rows: [] }));
  res.json({ leaderboard: rows });
});

// ── GET /api/earntree/referral/:code ─────────────────────────────────────────
router.get("/earntree/referral/:code", async (req, res) => {
  const { rows } = await pool.query(
    `SELECT r.code, r.clicks, r.conversions, u.name as referrer_name FROM et_referral_codes r JOIN users u ON u.id = r.user_id WHERE r.code = $1`,
    [req.params.code]
  );
  if (!rows.length) return (res as any).status(404).json({ error: "Code not found" });
  res.json({ referral: rows[0] });
});

// ── GET /api/earntree/business-campaigns ──────────────────────────────────────
router.get("/earntree/business-campaigns", async (_req, res) => {
  const { rows } = await pool.query(`
    SELECT bc.*, u.email as owner_email,
      COALESCE((SELECT COUNT(*) FROM et_share_submissions WHERE business_campaign_id = bc.id AND status = 'approved'), 0)::int AS approved_shares
    FROM et_business_campaigns bc JOIN users u ON u.id = bc.user_id
    WHERE bc.is_active = TRUE ORDER BY bc.total_shares DESC, bc.created_at DESC LIMIT 50
  `);
  res.json({ campaigns: rows });
});

// ── GET /api/earntree/my-business-campaign ────────────────────────────────────
router.get("/earntree/my-business-campaign", requireAuth, async (req: AuthRequest, res) => {
  const { rows } = await pool.query(`SELECT * FROM et_business_campaigns WHERE user_id = $1 LIMIT 1`, [req.user!.id]);
  res.json({ campaign: rows[0] || null });
});

// ── POST /api/earntree/business-campaigns ─────────────────────────────────────
router.post("/earntree/business-campaigns", requireAuth, async (req: AuthRequest, res) => {
  const { business_name, category, description, website, phone, city, state, radius_miles,
    reward_per_share_cents, reward_per_signup_cents, reward_per_booking_cents, weekly_budget_cents } = req.body;
  if (!business_name) return (res as any).status(400).json({ error: "business_name required" });
  const existing = await pool.query(`SELECT id FROM et_business_campaigns WHERE user_id = $1`, [req.user!.id]);
  if (existing.rows.length) {
    await pool.query(
      `UPDATE et_business_campaigns SET business_name=$1, category=$2, description=$3, website=$4, phone=$5,
       city=$6, state=$7, radius_miles=$8, reward_per_share_cents=$9, reward_per_signup_cents=$10, reward_per_booking_cents=$11,
       weekly_budget_cents=$12, is_active=TRUE, updated_at=NOW() WHERE user_id=$13`,
      [business_name, category || "General", description || null, website || null, phone || null,
       city || null, state || "FL", parseInt(radius_miles) || 25,
       Math.max(50, parseInt(reward_per_share_cents) || 250),
       Math.max(100, parseInt(reward_per_signup_cents) || 500),
       Math.max(100, parseInt(reward_per_booking_cents) || 1500),
       Math.max(1000, parseInt(weekly_budget_cents) || 10000),
       req.user!.id]
    );
    const updated = await pool.query(`SELECT * FROM et_business_campaigns WHERE user_id = $1`, [req.user!.id]);
    return res.json({ campaign: updated.rows[0] });
  }
  const { rows } = await pool.query(
    `INSERT INTO et_business_campaigns (user_id, business_name, category, description, website, phone, city, state, radius_miles,
     reward_per_share_cents, reward_per_signup_cents, reward_per_booking_cents, weekly_budget_cents)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
    [req.user!.id, business_name, category || "General", description || null, website || null, phone || null,
     city || null, state || "FL", parseInt(radius_miles) || 25,
     Math.max(50, parseInt(reward_per_share_cents) || 250),
     Math.max(100, parseInt(reward_per_signup_cents) || 500),
     Math.max(100, parseInt(reward_per_booking_cents) || 1500),
     Math.max(1000, parseInt(weekly_budget_cents) || 10000)]
  );
  res.status(201).json({ campaign: rows[0] });
});

// ── PATCH /api/earntree/business-campaigns/:id ────────────────────────────────
router.patch("/earntree/business-campaigns/:id", requireAuth, async (req: AuthRequest, res) => {
  const { is_active, business_name, description, reward_per_share_cents, reward_per_signup_cents, reward_per_booking_cents, weekly_budget_cents } = req.body;
  const sets: string[] = ["updated_at = NOW()"];
  const params: any[] = [];
  const add = (v: any, col: string) => { if (v !== undefined) { params.push(v); sets.push(`${col} = $${params.length}`); } };
  add(is_active, "is_active"); add(business_name, "business_name"); add(description, "description");
  add(reward_per_share_cents, "reward_per_share_cents");
  add(reward_per_signup_cents, "reward_per_signup_cents");
  add(reward_per_booking_cents, "reward_per_booking_cents");
  add(weekly_budget_cents, "weekly_budget_cents");
  params.push(req.user!.id, req.params.id);
  await pool.query(`UPDATE et_business_campaigns SET ${sets.join(", ")} WHERE user_id = $${params.length - 1} AND id = $${params.length}`, params);
  res.json({ success: true });
});

// ── Admin ─────────────────────────────────────────────────────────────────────

router.get("/admin/earntree/stats", requireMasterAdmin, async (_req, res) => {
  const [codes, referrals, commissions, tiers, bizCampaigns, sharesPending, payoutsPending] = await Promise.all([
    pool.query(`SELECT COUNT(*) FROM et_referral_codes`),
    pool.query(`SELECT COUNT(*) FROM et_referrals WHERE status = 'converted'`),
    pool.query(`SELECT COALESCE(SUM(amount_cents),0) as total FROM et_commissions`),
    pool.query(`SELECT tier, COUNT(*) FROM et_affiliate_tiers GROUP BY tier`),
    pool.query(`SELECT COUNT(*) FROM et_business_campaigns WHERE is_active = TRUE`),
    pool.query(`SELECT COUNT(*) FROM et_share_submissions WHERE status = 'pending'`),
    pool.query(`SELECT COUNT(*) FROM et_payout_requests WHERE status = 'pending'`),
  ]);
  res.json({
    totalCodes: parseInt(codes.rows[0].count),
    totalConversions: parseInt(referrals.rows[0].count),
    totalEarnedCents: parseInt(commissions.rows[0].total),
    tierBreakdown: tiers.rows,
    activeBusinessCampaigns: parseInt(bizCampaigns.rows[0].count),
    pendingShareReviews: parseInt(sharesPending.rows[0].count),
    pendingPayouts: parseInt(payoutsPending.rows[0].count),
  });
});

router.get("/admin/earntree/commissions", requireMasterAdmin, async (_req, res) => {
  const { rows } = await pool.query(`
    SELECT c.*, u.name as user_name, u.email as user_email
    FROM et_commissions c JOIN users u ON u.id = c.user_id
    ORDER BY c.created_at DESC LIMIT 200
  `);
  res.json({ commissions: rows });
});

router.patch("/admin/earntree/commissions/:id", requireMasterAdmin, async (req, res) => {
  const { status } = req.body;
  await pool.query(`UPDATE et_commissions SET status = $1, paid_at = CASE WHEN $1 = 'paid' THEN NOW() ELSE paid_at END WHERE id = $2`, [status, req.params.id]);
  res.json({ success: true });
});

// Admin: list pending share submissions
router.get("/admin/earntree/share-submissions", requireMasterAdmin, async (req, res) => {
  const { status = "pending" } = req.query as any;
  const { rows } = await pool.query(`
    SELECT ss.*, u.name as user_name, u.email as user_email, bc.business_name
    FROM et_share_submissions ss
    JOIN users u ON u.id = ss.user_id
    LEFT JOIN et_business_campaigns bc ON bc.id = ss.business_campaign_id
    WHERE ss.status = $1 ORDER BY ss.created_at ASC LIMIT 100
  `, [status]);
  res.json({ submissions: rows });
});

// Admin: approve / reject share submission
router.patch("/admin/earntree/share-submissions/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  const { status, reviewer_notes } = req.body;
  if (!["approved", "rejected"].includes(status)) return (res as any).status(400).json({ error: "status must be approved or rejected" });

  const subRow = await pool.query(`SELECT * FROM et_share_submissions WHERE id = $1 LIMIT 1`, [req.params.id]);
  if (!subRow.rows.length) return (res as any).status(404).json({ error: "Submission not found" });
  const sub = subRow.rows[0];

  await pool.query(
    `UPDATE et_share_submissions SET status = $1, reviewer_notes = $2, reviewed_at = NOW(), reviewed_by = $3 WHERE id = $4`,
    [status, reviewer_notes || null, req.user!.email, req.params.id]
  );

  if (status === "approved") {
    // Create commission
    await pool.query(
      `INSERT INTO et_commissions (user_id, share_submission_id, amount_cents, status, description)
       VALUES ($1,$2,$3,'approved',$4)`,
      [sub.user_id, sub.id, sub.reward_cents, `Share reward: ${sub.platform}`]
    );
    // Update tier
    const totalShares = await pool.query(
      `SELECT COUNT(*) FROM et_share_submissions WHERE user_id = $1 AND status = 'approved'`,
      [sub.user_id]
    );
    const count = parseInt(totalShares.rows[0].count);
    await pool.query(
      `INSERT INTO et_affiliate_tiers (user_id, tier, total_shares, total_earned_cents)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (user_id) DO UPDATE SET tier = $2, total_shares = $3, total_earned_cents = et_affiliate_tiers.total_earned_cents + $4, updated_at = NOW()`,
      [sub.user_id, getTier(count), count, sub.reward_cents]
    );
    // Update campaign spend if tied to one
    if (sub.business_campaign_id) {
      await pool.query(
        `UPDATE et_business_campaigns SET spend_this_week_cents = spend_this_week_cents + $1, total_shares = total_shares + 1 WHERE id = $2`,
        [sub.reward_cents, sub.business_campaign_id]
      );
    }
  }

  res.json({ success: true });
});

// Admin: payout requests
router.get("/admin/earntree/payout-requests", requireMasterAdmin, async (_req, res) => {
  const { rows } = await pool.query(`
    SELECT pr.*, u.name as user_name, u.email as user_email
    FROM et_payout_requests pr JOIN users u ON u.id = pr.user_id
    ORDER BY pr.created_at DESC LIMIT 100
  `);
  res.json({ payouts: rows });
});

router.patch("/admin/earntree/payout-requests/:id", requireMasterAdmin, async (req, res) => {
  const { status, admin_notes } = req.body;
  if (!["approved", "rejected", "paid"].includes(status)) return (res as any).status(400).json({ error: "invalid status" });
  const pr = await pool.query(`SELECT * FROM et_payout_requests WHERE id = $1 LIMIT 1`, [req.params.id]);
  if (!pr.rows.length) return (res as any).status(404).json({ error: "Not found" });
  await pool.query(
    `UPDATE et_payout_requests SET status = $1, admin_notes = $2, processed_at = CASE WHEN $1 IN ('approved','paid') THEN NOW() ELSE processed_at END WHERE id = $3`,
    [status, admin_notes || null, req.params.id]
  );
  if (status === "paid") {
    // Mark commissions as paid for this user
    await pool.query(
      `UPDATE et_commissions SET status = 'paid', paid_at = NOW() WHERE user_id = $1 AND status = 'approved'`,
      [pr.rows[0].user_id]
    );
  }
  res.json({ success: true });
});

export default router;
