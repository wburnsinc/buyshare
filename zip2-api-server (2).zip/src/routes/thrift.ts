import { Router } from "express";
import jwt from "jsonwebtoken";
import { db, requestsTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { requireAuth, JWT_SECRET } from "../middleware/auth.js";
import { stripe } from "../lib/stripe.js";

const router = Router();
let tablesReady = false;

async function ensureTables() {
  if (tablesReady) return;
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_listings (
      id TEXT PRIMARY KEY,
      seller_email TEXT NOT NULL,
      seller_name TEXT,
      title TEXT NOT NULL,
      description TEXT,
      category TEXT NOT NULL,
      condition TEXT NOT NULL,
      price_type TEXT NOT NULL DEFAULT 'asking',
      price INTEGER DEFAULT 0,
      photo1_url TEXT,
      photo2_url TEXT,
      location_text TEXT,
      lat NUMERIC,
      lng NUMERIC,
      status TEXT DEFAULT 'available',
      pickup_date TEXT,
      views INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_comments (
      id TEXT PRIMARY KEY,
      listing_id TEXT NOT NULL,
      commenter_email TEXT NOT NULL,
      commenter_name TEXT,
      parent_id TEXT,
      body TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_messages (
      id TEXT PRIMARY KEY,
      from_email TEXT NOT NULL,
      from_name TEXT,
      to_email TEXT NOT NULL,
      listing_id TEXT,
      listing_title TEXT,
      body TEXT NOT NULL,
      is_read BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_reviews (
      id TEXT PRIMARY KEY,
      reviewer_email TEXT NOT NULL,
      reviewer_name TEXT,
      reviewee_email TEXT NOT NULL,
      listing_id TEXT,
      stars INTEGER NOT NULL,
      body TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_blocks (
      blocker_email TEXT NOT NULL,
      blocked_email TEXT NOT NULL,
      PRIMARY KEY (blocker_email, blocked_email)
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_delivery_requests (
      id TEXT PRIMARY KEY,
      listing_id TEXT,
      listing_title TEXT,
      seller_email TEXT,
      buyer_email TEXT NOT NULL,
      buyer_name TEXT,
      delivery_address TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_reports (
      id TEXT PRIMARY KEY,
      listing_id TEXT NOT NULL,
      reporter_email TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_purchases (
      id TEXT PRIMARY KEY,
      listing_id TEXT NOT NULL,
      listing_title TEXT,
      buyer_email TEXT NOT NULL,
      buyer_name TEXT,
      seller_email TEXT NOT NULL,
      amount_cents INTEGER NOT NULL,
      platform_fee_cents INTEGER NOT NULL DEFAULT 100,
      stripe_session_id TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  tablesReady = true;
}

/* ─── MIDDLEWARE ────────────────────────────────────────────────────────────── */

/**
 * Chains requireAuth → verifies active thrift subscription for the authenticated
 * user. Sets req.actorEmail from the JWT-verified user identity — never from
 * request body or query params.
 */
async function requireThrift(req: any, res: any, next: any) {
  await requireAuth(req, res, async () => {
    try {
      await ensureTables();
      const email = (req.user as any).email.toLowerCase();
      const result = await db.execute(sql`
        SELECT id FROM subscriptions
        WHERE LOWER(email) = ${email}
          AND tier = 'thrift'
          AND status IN ('active', 'trialing')
        LIMIT 1
      `);
      if (!(result.rows as any[]).length) {
        return res.status(403).json({
          error: "Thrift Girl membership required",
          joinUrl: "/thrift/join",
        });
      }
      req.actorEmail = email;
      next();
    } catch (err: any) {
      console.error("requireThrift error:", err);
      res.status(500).json({ error: "Auth check failed" });
    }
  });
}

function wrap(fn: (req: any, res: any) => Promise<void>) {
  return async (req: any, res: any) => {
    try {
      await ensureTables();
      await fn(req, res);
    } catch (err: any) {
      console.error("thrift error:", err);
      res.status(500).json({ error: err.message || "Server error" });
    }
  };
}

function uid(prefix = "thrift") {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

/** Extracts actor email from an optional Bearer token — used for read-only
 *  endpoints where auth is beneficial (block filtering) but not required. */
async function optionalActorEmail(authHeader: string | undefined): Promise<string | null> {
  if (!authHeader?.startsWith("Bearer ")) return null;
  try {
    const payload = jwt.verify(authHeader.slice(7), JWT_SECRET) as { userId: string };
    const result = await db.execute(sql`SELECT email FROM users WHERE id = ${payload.userId} LIMIT 1`);
    const u = (result.rows as any[])[0];
    return u ? u.email.toLowerCase() : null;
  } catch {
    return null;
  }
}

/* ─── LISTINGS ───────────────────────────────────────────────────────────── */

/** Public read — no auth required. If a valid Bearer token is present, filters
 *  out listings from sellers the authenticated user has blocked (and vice-versa). */
router.get("/thrift/listings", wrap(async (req, res) => {
  const { category, condition, status, q, email, min_price, max_price, limit = "50", offset = "0" } = req.query as any;
  const actorEmail = await optionalActorEmail(req.headers.authorization);

  let query = sql`SELECT * FROM thrift_listings WHERE 1=1`;
  if (category && category !== "all") query = sql`${query} AND category = ${category}`;
  if (condition && condition !== "all") query = sql`${query} AND condition = ${condition}`;
  if (status && status !== "all") query = sql`${query} AND status = ${status}`;
  else if (!status) query = sql`${query} AND status != 'gone'`;
  if (q) query = sql`${query} AND (title ILIKE ${"%" + q + "%"} OR description ILIKE ${"%" + q + "%"})`;
  if (email) query = sql`${query} AND seller_email = ${(email as string).toLowerCase()}`;

  if (actorEmail) {
    query = sql`${query}
      AND seller_email NOT IN (
        SELECT blocked_email FROM thrift_blocks WHERE blocker_email = ${actorEmail}
      )
      AND seller_email NOT IN (
        SELECT blocker_email FROM thrift_blocks WHERE blocked_email = ${actorEmail}
      )`;
  }
  if (min_price !== undefined && min_price !== "") query = sql`${query} AND price >= ${parseInt(min_price) * 100}`;
  if (max_price !== undefined && max_price !== "") query = sql`${query} AND price <= ${parseInt(max_price) * 100}`;

  query = sql`${query} ORDER BY created_at DESC LIMIT ${parseInt(limit)} OFFSET ${parseInt(offset)}`;
  const result = await db.execute(query);
  res.json({ listings: result.rows });
}));

/** Requires thrift membership. Actor identity bound from JWT. */
router.post("/thrift/listings", requireThrift, wrap(async (req, res) => {
  const seller_email = req.actorEmail;
  const { seller_name, title, description, category, condition, price_type, price, photo1_url, photo2_url, location_text, lat, lng } = req.body;

  if (!title || !category || !condition) {
    return res.status(400).json({ error: "title, category, condition required" });
  }
  const id = uid("tl");
  await db.execute(sql`
    INSERT INTO thrift_listings (id, seller_email, seller_name, title, description, category, condition, price_type, price, photo1_url, photo2_url, location_text, lat, lng)
    VALUES (${id}, ${seller_email}, ${seller_name || null}, ${title}, ${description || null},
            ${category}, ${condition}, ${price_type || "asking"}, ${price ?? 0},
            ${photo1_url || null}, ${photo2_url || null}, ${location_text || null},
            ${lat || null}, ${lng || null})
  `);
  const result = await db.execute(sql`SELECT * FROM thrift_listings WHERE id = ${id}`);
  res.status(201).json({ listing: (result.rows as any[])[0] });
}));

router.get("/thrift/listings/:id", wrap(async (req, res) => {
  const { id } = req.params;
  await db.execute(sql`UPDATE thrift_listings SET views = views + 1 WHERE id = ${id}`);
  const listing = await db.execute(sql`SELECT * FROM thrift_listings WHERE id = ${id}`);
  const comments = await db.execute(sql`SELECT * FROM thrift_comments WHERE listing_id = ${id} ORDER BY created_at ASC`);
  if (!(listing.rows as any[]).length) return res.status(404).json({ error: "Not found" });
  res.json({ listing: (listing.rows as any[])[0], comments: comments.rows });
}));

/** Actor must be the listing owner (verified via JWT). */
router.put("/thrift/listings/:id", requireThrift, wrap(async (req, res) => {
  const { id } = req.params;
  const actor = req.actorEmail;
  const { title, description, category, condition, price_type, price, photo1_url, photo2_url, location_text, lat, lng } = req.body;

  const existing = await db.execute(sql`SELECT * FROM thrift_listings WHERE id = ${id}`);
  const row = (existing.rows as any[])[0];
  if (!row) return res.status(404).json({ error: "Not found" });
  if (row.seller_email !== actor) return res.status(403).json({ error: "Unauthorized: not the listing owner" });

  await db.execute(sql`
    UPDATE thrift_listings SET
      title = ${title || row.title},
      description = ${description ?? row.description},
      category = ${category || row.category},
      condition = ${condition || row.condition},
      price_type = ${price_type || row.price_type},
      price = ${price ?? row.price},
      photo1_url = ${photo1_url ?? row.photo1_url},
      photo2_url = ${photo2_url ?? row.photo2_url},
      location_text = ${location_text ?? row.location_text},
      lat = ${lat ?? row.lat},
      lng = ${lng ?? row.lng}
    WHERE id = ${id}
  `);
  const updated = await db.execute(sql`SELECT * FROM thrift_listings WHERE id = ${id}`);
  res.json({ listing: (updated.rows as any[])[0] });
}));

/** Actor must be the listing owner. */
router.delete("/thrift/listings/:id", requireThrift, wrap(async (req, res) => {
  const { id } = req.params;
  const actor = req.actorEmail;

  const existing = await db.execute(sql`SELECT seller_email FROM thrift_listings WHERE id = ${id}`);
  const row = (existing.rows as any[])[0];
  if (!row) return res.status(404).json({ error: "Not found" });
  if (row.seller_email !== actor) return res.status(403).json({ error: "Unauthorized: not the listing owner" });

  await db.execute(sql`DELETE FROM thrift_listings WHERE id = ${id}`);
  res.json({ success: true });
}));

/** Actor must be the listing owner. */
router.put("/thrift/listings/:id/status", requireThrift, wrap(async (req, res) => {
  const { id } = req.params;
  const actor = req.actorEmail;
  const { status, pickup_date } = req.body;
  if (!["available", "pending", "gone"].includes(status)) return res.status(400).json({ error: "Invalid status" });

  await db.execute(sql`
    UPDATE thrift_listings SET status = ${status}, pickup_date = ${pickup_date || null}
    WHERE id = ${id} AND seller_email = ${actor}
  `);
  res.json({ success: true });
}));

/** Buyer sends a pickup request to seller — NON-DESTRUCTIVE.
 *  Does NOT mutate listing status. Seller must confirm via inbox before status changes. */
router.put("/thrift/listings/:id/pickup", requireThrift, wrap(async (req, res) => {
  const { id } = req.params;
  const actor = req.actorEmail;
  const { preferred_date, contact_phone } = req.body;

  if (!preferred_date) return res.status(400).json({ error: "preferred_date required" });

  const listingResult = await db.execute(sql`SELECT seller_email, title, status FROM thrift_listings WHERE id = ${id}`);
  const l = (listingResult.rows as any[])[0];
  if (!l) return res.status(404).json({ error: "Listing not found" });
  if (l.status === "gone") return res.status(400).json({ error: "This listing is no longer available" });
  if (l.seller_email === actor) return res.status(400).json({ error: "Cannot request pickup on your own listing" });

  // Save preferred pickup date to the listing record (non-status-mutating)
  await db.execute(sql`UPDATE thrift_listings SET pickup_date = ${preferred_date} WHERE id = ${id}`);

  // Send a message to the seller — they must confirm before any status change
  const msgId = uid("tm");
  const pickupMsg = `📅 Pickup Request: "${l.title}" — Proposed date: ${preferred_date}${contact_phone ? ` · Contact: ${contact_phone}` : ""}. Reply to confirm. (Status won't change until you confirm.)`;
  await db.execute(sql`
    INSERT INTO thrift_messages (id, from_email, from_name, to_email, listing_id, listing_title, body)
    VALUES (${msgId}, ${actor}, ${"Buyer"}, ${l.seller_email}, ${id}, ${l.title}, ${pickupMsg})
  `);

  res.json({ success: true, message: "Pickup request sent! The seller will confirm via inbox." });
}));

/* ─── COMMENTS ───────────────────────────────────────────────────────────── */

router.get("/thrift/comments/:listingId", wrap(async (req, res) => {
  const { listingId } = req.params;
  const result = await db.execute(sql`SELECT * FROM thrift_comments WHERE listing_id = ${listingId} ORDER BY created_at ASC`);
  res.json({ comments: result.rows });
}));

/** Any authenticated user may comment (public comments). */
router.post("/thrift/comments", requireAuth, wrap(async (req, res) => {
  const commenter_email = (req.user as any).email;
  const { commenter_name, listing_id, body, parent_id } = req.body;

  if (!listing_id || !body) return res.status(400).json({ error: "listing_id and body required" });
  const id = uid("tc");
  await db.execute(sql`
    INSERT INTO thrift_comments (id, listing_id, commenter_email, commenter_name, body, parent_id)
    VALUES (${id}, ${listing_id}, ${commenter_email}, ${commenter_name || null}, ${body}, ${parent_id || null})
  `);
  const result = await db.execute(sql`SELECT * FROM thrift_comments WHERE id = ${id}`);
  res.status(201).json({ comment: (result.rows as any[])[0] });
}));

/* ─── MESSAGES ───────────────────────────────────────────────────────────── */

/** Only the authenticated inbox owner may read their inbox. */
router.get("/thrift/inbox/:email", requireAuth, wrap(async (req, res) => {
  const email = req.params.email.toLowerCase();
  const authedEmail = (req.user as any).email.toLowerCase();
  if (authedEmail !== email) {
    return res.status(403).json({ error: "Cannot access another user's inbox" });
  }
  const result = await db.execute(sql`
    SELECT DISTINCT ON (LEAST(from_email, to_email), GREATEST(from_email, to_email))
      *, CASE WHEN to_email = ${email} AND is_read = FALSE THEN TRUE ELSE FALSE END as has_unread
    FROM thrift_messages
    WHERE from_email = ${email} OR to_email = ${email}
    ORDER BY LEAST(from_email, to_email), GREATEST(from_email, to_email), created_at DESC
  `);
  res.json({ conversations: result.rows });
}));

/** Only a conversation participant may read or mark-read messages. */
router.get("/thrift/conversation", requireAuth, wrap(async (req, res) => {
  const { from, to } = req.query as any;
  if (!from || !to) return res.status(400).json({ error: "from and to required" });
  const f = from.toLowerCase(), t = to.toLowerCase();
  const authedEmail = (req.user as any).email.toLowerCase();

  if (authedEmail !== f && authedEmail !== t) {
    return res.status(403).json({ error: "Not a participant in this conversation" });
  }

  const result = await db.execute(sql`
    SELECT * FROM thrift_messages
    WHERE (from_email = ${f} AND to_email = ${t}) OR (from_email = ${t} AND to_email = ${f})
    ORDER BY created_at ASC
  `);
  // Only mark as read for the authenticated recipient
  await db.execute(sql`
    UPDATE thrift_messages SET is_read = TRUE
    WHERE to_email = ${authedEmail} AND from_email = ${authedEmail === f ? t : f}
  `);
  res.json({ messages: result.rows });
}));

/** Requires thrift membership. from_email derived from JWT. */
router.post("/thrift/messages", requireThrift, wrap(async (req, res) => {
  const from_email = req.actorEmail;
  const { from_name, to_email, listing_id, listing_title, body } = req.body;

  if (!to_email || !body) return res.status(400).json({ error: "to_email and body required" });

  const blocked = await db.execute(sql`
    SELECT 1 FROM thrift_blocks
    WHERE blocker_email = ${to_email.toLowerCase()} AND blocked_email = ${from_email}
  `);
  if ((blocked.rows as any[]).length) {
    return res.status(403).json({ error: "Cannot send message to this user" });
  }

  const id = uid("tm");
  await db.execute(sql`
    INSERT INTO thrift_messages (id, from_email, from_name, to_email, listing_id, listing_title, body)
    VALUES (${id}, ${from_email}, ${from_name || null}, ${to_email.toLowerCase()},
            ${listing_id || null}, ${listing_title || null}, ${body})
  `);
  res.status(201).json({ success: true });
}));

/** Only the authenticated recipient may query their unread count. */
router.get("/thrift/unread/:email", requireAuth, wrap(async (req, res) => {
  const email = req.params.email.toLowerCase();
  const authedEmail = (req.user as any).email.toLowerCase();
  if (authedEmail !== email) {
    return res.status(403).json({ error: "Cannot access another user's unread count" });
  }
  const result = await db.execute(sql`SELECT COUNT(*) as count FROM thrift_messages WHERE to_email = ${email} AND is_read = FALSE`);
  res.json({ count: parseInt((result.rows as any[])[0]?.count || "0") });
}));

/* ─── REVIEWS ────────────────────────────────────────────────────────────── */

router.get("/thrift/reviews/:email", wrap(async (req, res) => {
  const email = req.params.email.toLowerCase();
  const result = await db.execute(sql`SELECT * FROM thrift_reviews WHERE reviewee_email = ${email} ORDER BY created_at DESC`);
  const rows = result.rows as any[];
  const avg = rows.reduce((s: number, r: any) => s + r.stars, 0) / (rows.length || 1);
  res.json({ reviews: rows, avgStars: Math.round(avg * 10) / 10, count: rows.length });
}));

/** Requires thrift membership. reviewer_email from JWT. */
router.post("/thrift/reviews", requireThrift, wrap(async (req, res) => {
  const reviewer_email = req.actorEmail;
  const { reviewer_name, reviewee_email, listing_id, stars, body } = req.body;

  if (!reviewee_email || !stars) return res.status(400).json({ error: "reviewee_email and stars required" });
  if (stars < 1 || stars > 5) return res.status(400).json({ error: "Stars must be 1-5" });
  if (reviewer_email === reviewee_email.toLowerCase()) return res.status(400).json({ error: "Cannot review yourself" });

  // Enforce review eligibility: reviewer must have transacted or messaged with reviewee
  const txCheck = await db.execute(sql`
    SELECT 1 FROM thrift_delivery_requests
    WHERE (buyer_email = ${reviewer_email} AND LOWER(seller_email) = ${reviewee_email.toLowerCase()})
       OR (buyer_email = ${reviewee_email.toLowerCase()} AND LOWER(seller_email) = ${reviewer_email})
    UNION ALL
    SELECT 1 FROM thrift_messages
    WHERE (from_email = ${reviewer_email} AND to_email = ${reviewee_email.toLowerCase()})
       OR (from_email = ${reviewee_email.toLowerCase()} AND to_email = ${reviewer_email})
    LIMIT 1
  `);
  if (!(txCheck.rows as any[]).length) {
    return res.status(403).json({ error: "You can only review users you have transacted or communicated with" });
  }

  const dupCheck = listing_id
    ? await db.execute(sql`SELECT id FROM thrift_reviews WHERE reviewer_email = ${reviewer_email} AND listing_id = ${listing_id}`)
    : await db.execute(sql`SELECT id FROM thrift_reviews WHERE reviewer_email = ${reviewer_email} AND reviewee_email = ${reviewee_email.toLowerCase()}`);
  if ((dupCheck.rows as any[]).length) return res.status(409).json({ error: "Already reviewed" });

  const id = uid("tr");
  await db.execute(sql`
    INSERT INTO thrift_reviews (id, reviewer_email, reviewer_name, reviewee_email, listing_id, stars, body)
    VALUES (${id}, ${reviewer_email}, ${reviewer_name || null}, ${reviewee_email.toLowerCase()},
            ${listing_id || null}, ${stars}, ${body || null})
  `);
  res.status(201).json({ success: true });
}));

/* ─── USER PROFILE (public) ─────────────────────────────────────────────── */

router.get("/thrift/user/:email", wrap(async (req, res) => {
  const email = req.params.email.toLowerCase();
  const [listings, reviews, subResult, userResult] = await Promise.all([
    db.execute(sql`SELECT * FROM thrift_listings WHERE seller_email = ${email} ORDER BY created_at DESC`),
    db.execute(sql`SELECT * FROM thrift_reviews WHERE reviewee_email = ${email} ORDER BY created_at DESC`),
    db.execute(sql`SELECT created_at FROM subscriptions WHERE LOWER(email) = ${email} AND tier = 'thrift' ORDER BY created_at ASC LIMIT 1`),
    db.execute(sql`SELECT avatar_url FROM users WHERE LOWER(email) = ${email} LIMIT 1`),
  ]);
  const rows = reviews.rows as any[];
  const avgStars = rows.reduce((s: number, r: any) => s + r.stars, 0) / (rows.length || 1);
  const completed = (listings.rows as any[]).filter((l: any) => l.status === "gone").length;
  const memberSince = (subResult.rows as any[])[0]?.created_at || null;
  const avatarUrl = (userResult.rows as any[])[0]?.avatar_url || null;
  res.json({
    email,
    listings: listings.rows,
    reviews: rows,
    avgStars: Math.round(avgStars * 10) / 10,
    reviewCount: rows.length,
    listingCount: (listings.rows as any[]).length,
    completedTrades: completed,
    memberSince,
    avatarUrl,
  });
}));

/** Update avatar URL on the authenticated user's profile. */
router.put("/thrift/profile", requireAuth, wrap(async (req, res) => {
  const actor = (req.user as any).email.toLowerCase();
  const { avatar_url } = req.body;
  if (avatar_url !== undefined) {
    await db.execute(sql`UPDATE users SET avatar_url = ${avatar_url || null} WHERE LOWER(email) = ${actor}`);
  }
  res.json({ success: true });
}));

/* ─── BLOCKS ─────────────────────────────────────────────────────────────── */

/** Requires thrift membership. blocker_email from JWT. */
router.post("/thrift/blocks", requireThrift, wrap(async (req, res) => {
  const blocker_email = req.actorEmail;
  const { blocked_email } = req.body;
  if (!blocked_email) return res.status(400).json({ error: "blocked_email required" });
  await db.execute(sql`
    INSERT INTO thrift_blocks (blocker_email, blocked_email)
    VALUES (${blocker_email}, ${blocked_email.toLowerCase()})
    ON CONFLICT DO NOTHING
  `);
  res.json({ success: true });
}));

/** Requires thrift membership. blocker_email from JWT. */
router.delete("/thrift/blocks", requireThrift, wrap(async (req, res) => {
  const blocker_email = req.actorEmail;
  const { blocked_email } = req.body;
  await db.execute(sql`DELETE FROM thrift_blocks WHERE blocker_email = ${blocker_email} AND blocked_email = ${(blocked_email || "").toLowerCase()}`);
  res.json({ success: true });
}));

router.get("/thrift/blocks/:email", requireAuth, wrap(async (req, res) => {
  const email = req.params.email.toLowerCase();
  if ((req.user as any).email.toLowerCase() !== email) {
    return res.status(403).json({ error: "Cannot view another user's block list" });
  }
  const result = await db.execute(sql`SELECT blocked_email FROM thrift_blocks WHERE blocker_email = ${email}`);
  res.json({ blocked: (result.rows as any[]).map((r: any) => r.blocked_email) });
}));

/* ─── REPORTS ────────────────────────────────────────────────────────────── */

router.post("/thrift/report", requireThrift, wrap(async (req, res) => {
  const reporter_email = req.actorEmail;
  const { listing_id, reason } = req.body;
  if (!listing_id || !reason) return res.status(400).json({ error: "listing_id and reason required" });
  const id = `report-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  await db.execute(sql`
    INSERT INTO thrift_reports (id, listing_id, reporter_email, reason)
    VALUES (${id}, ${listing_id}, ${reporter_email}, ${reason})
  `);
  res.json({ success: true, message: "Report received. Our team will review within 24 hours." });
}));

/* ─── DELIVERY REQUESTS ─────────────────────────────────────────────────── */

/** Requires thrift membership. Routes through existing requests table for platform-wide visibility.
 *  buyer identity derived from JWT. Seller notified via inbox. */
router.post("/thrift/delivery-request", requireThrift, wrap(async (req, res) => {
  const buyer_email = req.actorEmail;
  const buyerUserId = (req.user as any).id;
  const { listing_id, listing_title, seller_email, buyer_name, delivery_address } = req.body;

  if (!delivery_address) return res.status(400).json({ error: "delivery_address required" });

  // Route through existing requests table with thrift context
  const reqId = uid("req");
  await db.insert(requestsTable).values({
    id: reqId,
    userId: buyerUserId,
    title: `Thrift Delivery: ${listing_title || "Item"}`,
    description: `Delivery requested for thrift listing${listing_id ? ` (${listing_id})` : ""}. Seller: ${seller_email || "unknown"}. Deliver to: ${delivery_address}`,
    location: delivery_address,
  });

  // Save thrift-specific record for transaction tracking (review eligibility)
  const id = uid("tdr");
  await db.execute(sql`
    INSERT INTO thrift_delivery_requests
      (id, listing_id, listing_title, seller_email, buyer_email, buyer_name, delivery_address, status)
    VALUES (${id}, ${listing_id || null}, ${listing_title || null}, ${seller_email || null},
            ${buyer_email}, ${buyer_name || null}, ${delivery_address}, 'pending')
  `);

  // Notify seller via thrift inbox
  if (seller_email) {
    const msgId = uid("tm");
    const msgBody = `🚚 Delivery Requested: "${listing_title || "your listing"}" → Deliver to: ${delivery_address}. Buyshare.co will coordinate. Reply to confirm.`;
    await db.execute(sql`
      INSERT INTO thrift_messages (id, from_email, from_name, to_email, listing_id, listing_title, body)
      VALUES (${msgId}, ${buyer_email}, ${buyer_name || "Buyer"}, ${seller_email.toLowerCase()},
              ${listing_id || null}, ${listing_title || null}, ${msgBody})
    `).catch(() => {});
  }

  res.status(201).json({
    success: true,
    id,
    message: "Delivery request submitted! Buyshare.co will contact you within 2 hours.",
  });
}));

// ─── Community filler listings (realistic SWFL/Port Charlotte free & cheap items) ──
router.get("/thrift/community-listings", wrap(async (_req, res) => {
  const items = [
    { id: "cl001", title: "Free — Moving boxes, all sizes", category: "household", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9901, lng: -82.0916, seller_name: "Jessica M.", status: "available", photo1_url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=70" },
    { id: "cl002", title: "Gently used sofa — FREE pickup only", category: "furniture", price_type: "free", price: 0, location_text: "Punta Gorda, FL", lat: 26.9300, lng: -82.0450, seller_name: "Tom R.", status: "available", photo1_url: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&q=70" },
    { id: "cl003", title: "Toddler toys bundle — FREE to good home", category: "kids", price_type: "free", price: 0, location_text: "North Port, FL", lat: 27.0442, lng: -82.2359, seller_name: "Alicia B.", status: "available", photo1_url: "https://images.unsplash.com/photo-1519340241574-2cec6aef0c01?w=400&q=70" },
    { id: "cl004", title: "Women's clothing lot — size M, $5 each", category: "clothing", price_type: "asking", price: 500, location_text: "Port Charlotte, FL", lat: 26.9758, lng: -82.1143, seller_name: "Diane L.", status: "available", photo1_url: "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=400&q=70" },
    { id: "cl005", title: "Free plants — Pothos, cuttings available", category: "garden", price_type: "free", price: 0, location_text: "Englewood, FL", lat: 26.9628, lng: -82.3527, seller_name: "Mary C.", status: "available", photo1_url: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&q=70" },
    { id: "cl006", title: "Kitchen items — pots, pans, utensils FREE", category: "household", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9854, lng: -82.0812, seller_name: "Sandra K.", status: "available", photo1_url: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=70" },
    { id: "cl007", title: "Boy's bike — 20\" — $25 OBO", category: "kids", price_type: "asking", price: 2500, location_text: "Port Charlotte, FL", lat: 26.9992, lng: -82.0671, seller_name: "Dave H.", status: "available", photo1_url: "https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?w=400&q=70" },
    { id: "cl008", title: "FREE — 4 tires (take all)", category: "automotive", price_type: "free", price: 0, location_text: "Punta Gorda, FL", lat: 26.9198, lng: -82.0560, seller_name: "Bob F.", status: "available", photo1_url: "https://images.unsplash.com/photo-1558981359-219d6364c9c8?w=400&q=70" },
    { id: "cl009", title: "Vintage lamps — pair, $40 both", category: "home decor", price_type: "asking", price: 4000, location_text: "North Port, FL", lat: 27.0631, lng: -82.2021, seller_name: "Helen W.", status: "available", photo1_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=70" },
    { id: "cl010", title: "FREE garden soil — several bags", category: "garden", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9672, lng: -82.1240, seller_name: "Larry P.", status: "available", photo1_url: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&q=70" },
    { id: "cl011", title: "Dog crate — large, FREE", category: "pets", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9823, lng: -82.0950, seller_name: "Angela S.", status: "available", photo1_url: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&q=70" },
    { id: "cl012", title: "Surfboard — 7ft, $85", category: "sports", price_type: "asking", price: 8500, location_text: "Englewood, FL", lat: 26.9554, lng: -82.3680, seller_name: "Mike V.", status: "available", photo1_url: "https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=400&q=70" },
    { id: "cl013", title: "FREE — patio furniture cushions (6)", category: "outdoor", price_type: "free", price: 0, location_text: "Cape Coral, FL", lat: 26.5629, lng: -81.9495, seller_name: "Cindy T.", status: "available", photo1_url: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&q=70" },
    { id: "cl014", title: "Children's books — box of 30, FREE", category: "books", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9911, lng: -82.1055, seller_name: "Karen D.", status: "available", photo1_url: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400&q=70" },
    { id: "cl015", title: "Electric fan — box, $15", category: "appliances", price_type: "asking", price: 1500, location_text: "Punta Gorda, FL", lat: 26.9385, lng: -82.0389, seller_name: "Phil M.", status: "available", photo1_url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=70" },
    { id: "cl016", title: "FREE — 20 gallon fish tank w/ filter", category: "pets", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9737, lng: -82.0803, seller_name: "Rachel N.", status: "available", photo1_url: "https://images.unsplash.com/photo-1519340241574-2cec6aef0c01?w=400&q=70" },
    { id: "cl017", title: "Kayak paddle — aluminum, $20", category: "sports", price_type: "asking", price: 2000, location_text: "North Port, FL", lat: 27.0289, lng: -82.1943, seller_name: "Jason C.", status: "available", photo1_url: "https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=400&q=70" },
    { id: "cl018", title: "FREE — old wooden dresser (needs tlc)", category: "furniture", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9647, lng: -82.1188, seller_name: "Lisa B.", status: "available", photo1_url: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&q=70" },
    { id: "cl019", title: "Treadmill — works great, $95", category: "sports", price_type: "asking", price: 9500, location_text: "Punta Gorda, FL", lat: 26.9250, lng: -82.0530, seller_name: "Frank J.", status: "available", photo1_url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=70" },
    { id: "cl020", title: "FREE — bricks (approx 40)", category: "building", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9790, lng: -82.0924, seller_name: "Carl E.", status: "available", photo1_url: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&q=70" },
    { id: "cl021", title: "Baby stroller — good condition, $45", category: "kids", price_type: "asking", price: 4500, location_text: "Englewood, FL", lat: 26.9701, lng: -82.3420, seller_name: "Patty A.", status: "available", photo1_url: "https://images.unsplash.com/photo-1519340241574-2cec6aef0c01?w=400&q=70" },
    { id: "cl022", title: "FREE — big bag of dog food (opened)", category: "pets", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9843, lng: -82.1001, seller_name: "Donna O.", status: "available", photo1_url: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&q=70" },
    { id: "cl023", title: "Craft supplies — paint, glue, brushes, FREE", category: "arts", price_type: "free", price: 0, location_text: "North Port, FL", lat: 27.0498, lng: -82.2285, seller_name: "Brenda G.", status: "available", photo1_url: "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=400&q=70" },
    { id: "cl024", title: "Golf clubs set — $75 for all", category: "sports", price_type: "asking", price: 7500, location_text: "Port Charlotte, FL", lat: 26.9715, lng: -82.0862, seller_name: "George Y.", status: "available", photo1_url: "https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=400&q=70" },
    { id: "cl025", title: "FREE — riding lawn mower (for parts)", category: "garden", price_type: "free", price: 0, location_text: "Port Charlotte, FL", lat: 26.9952, lng: -82.0735, seller_name: "Rick Z.", status: "available", photo1_url: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&q=70" },
  ];
  res.json({ listings: items, total: items.length, source: "community" });
}));

/* ─── PURCHASE FLOW ─────────────────────────────────────────────────────────── */

/** Create a Stripe checkout for a thrift listing + $1 platform fee.
 *  Marks the listing 'pending' and notifies the seller. */
router.post("/thrift/listings/:id/purchase", requireThrift, wrap(async (req, res) => {
  const buyerEmail = (req as any).actorEmail as string;
  const listingId = req.params.id;

  const listingRes = await db.execute(sql`SELECT * FROM thrift_listings WHERE id = ${listingId} LIMIT 1`);
  const listing = (listingRes.rows as any[])[0];
  if (!listing) { res.status(404).json({ error: "Listing not found" }); return; }
  if (listing.status !== "available") { res.status(409).json({ error: "This item is no longer available" }); return; }
  if (listing.seller_email === buyerEmail) { res.status(400).json({ error: "You cannot buy your own listing" }); return; }
  if (!listing.price || listing.price <= 0) { res.status(400).json({ error: "This item has no price set" }); return; }

  const buyerRes = await db.execute(sql`SELECT name FROM users WHERE LOWER(email) = ${buyerEmail} LIMIT 1`);
  const buyerName = (buyerRes.rows as any[])[0]?.name || buyerEmail.split("@")[0];

  const baseUrl = process.env.FRONTEND_URL || "https://buyshare.co";
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    mode: "payment",
    customer_email: buyerEmail,
    line_items: [
      {
        price_data: {
          currency: "usd",
          product_data: { name: listing.title, description: `THRIFTgirl — pickup from seller in ${listing.location_text || "Southwest Florida"}` },
          unit_amount: listing.price,
        },
        quantity: 1,
      },
      {
        price_data: {
          currency: "usd",
          product_data: { name: "Platform Fee", description: "Buyshare.co THRIFTgirl service fee" },
          unit_amount: 100,
        },
        quantity: 1,
      },
    ],
    metadata: {
      type: "thrift_purchase",
      thrift_listing_id: listingId,
      buyer_email: buyerEmail,
      seller_email: listing.seller_email,
      listing_title: listing.title,
    },
    success_url: `${baseUrl}/thrift/listing/${listingId}?purchase_session={CHECKOUT_SESSION_ID}`,
    cancel_url: `${baseUrl}/thrift/listing/${listingId}`,
  });

  // Record purchase attempt
  const purchaseId = uid("tpurchase");
  await db.execute(sql`
    INSERT INTO thrift_purchases (id, listing_id, listing_title, buyer_email, buyer_name, seller_email, amount_cents, platform_fee_cents, stripe_session_id, status)
    VALUES (${purchaseId}, ${listingId}, ${listing.title}, ${buyerEmail}, ${buyerName}, ${listing.seller_email}, ${listing.price}, 100, ${session.id}, 'pending')
  `);

  // Mark listing pending
  await db.execute(sql`UPDATE thrift_listings SET status = 'pending' WHERE id = ${listingId}`);

  // Notify seller in-app
  await db.execute(sql`
    INSERT INTO notifications (user_email, type, title, body, data)
    VALUES (${listing.seller_email}, 'thrift_purchase', 'Someone reserved your item! 🎉',
      ${`${buyerName} has paid for "${listing.title}". Contact them to arrange pickup.`},
      ${JSON.stringify({ listing_id: listingId, buyer_email: buyerEmail })})
  `).catch(() => {});

  // Email seller
  const _apiKey = process.env.RESEND_API_KEY;
  if (_apiKey) {
    const _from = process.env.RESEND_FROM_EMAIL
      ? `THRIFTgirl <${process.env.RESEND_FROM_EMAIL}>`
      : "THRIFTgirl <onboarding@resend.dev>";
    fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: _from,
        to: [listing.seller_email],
        subject: `💸 Your item was reserved — "${listing.title}"`,
        html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px;color:#111827">
          <h2 style="color:#e8507e">Great news — someone bought your item!</h2>
          <p><strong>${buyerName}</strong> has paid for your listing <strong>"${listing.title}"</strong> on THRIFTgirl.</p>
          <p>Please reach out to them via your THRIFTgirl inbox to arrange a pickup time and location.</p>
          <a href="${baseUrl}/thrift/inbox" style="display:inline-block;background:#e8507e;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin-top:16px">Go to Your Inbox →</a>
          <p style="font-size:12px;color:#6b7280;margin-top:24px">THRIFTgirl by Buyshare.co · Southwest Florida</p>
        </div>`,
      }),
    }).catch(() => {});
  }

  res.json({ checkoutUrl: session.url });
}));

/** Confirm a thrift purchase after Stripe payment succeeds. */
router.post("/thrift/listings/:id/confirm-purchase", requireThrift, wrap(async (req, res) => {
  const buyerEmail = (req as any).actorEmail as string;
  const listingId = req.params.id;
  const { session_id } = req.body;
  if (!session_id) { res.status(400).json({ error: "session_id required" }); return; }

  const session = await stripe.checkout.sessions.retrieve(session_id);
  if (session.payment_status !== "paid") {
    res.status(402).json({ error: "Payment not completed" }); return;
  }
  if (session.metadata?.thrift_listing_id !== listingId) {
    res.status(400).json({ error: "Session does not match this listing" }); return;
  }

  // Mark listing gone
  await db.execute(sql`UPDATE thrift_listings SET status = 'gone' WHERE id = ${listingId}`);

  // Update purchase record
  await db.execute(sql`UPDATE thrift_purchases SET status = 'paid' WHERE stripe_session_id = ${session_id}`).catch(() => {});

  const listingRes = await db.execute(sql`SELECT title, seller_email FROM thrift_listings WHERE id = ${listingId} LIMIT 1`);
  const listing = (listingRes.rows as any[])[0];
  const sellerEmail = listing?.seller_email || session.metadata?.seller_email;
  const listingTitle = listing?.title || session.metadata?.listing_title || "Your item";

  // Notify buyer in-app
  await db.execute(sql`
    INSERT INTO notifications (user_email, type, title, body, data)
    VALUES (${buyerEmail}, 'thrift_paid', 'Purchase confirmed! 🎉',
      ${`Payment confirmed for "${listingTitle}". The seller will contact you to arrange pickup.`},
      ${JSON.stringify({ listing_id: listingId })})
  `).catch(() => {});

  // Email buyer
  const _apiKey = process.env.RESEND_API_KEY;
  if (_apiKey) {
    const _from = process.env.RESEND_FROM_EMAIL
      ? `THRIFTgirl <${process.env.RESEND_FROM_EMAIL}>`
      : "THRIFTgirl <onboarding@resend.dev>";
    fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: _from,
        to: [buyerEmail],
        subject: `✅ Purchase confirmed — "${listingTitle}"`,
        html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px;color:#111827">
          <h2 style="color:#e8507e">Payment confirmed!</h2>
          <p>Your purchase of <strong>"${listingTitle}"</strong> is confirmed. The seller will contact you soon via THRIFTgirl inbox to arrange a pickup time.</p>
          <a href="${process.env.FRONTEND_URL || "https://buyshare.co"}/thrift/inbox" style="display:inline-block;background:#e8507e;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin-top:16px">Go to Your Inbox →</a>
          <p style="font-size:12px;color:#6b7280;margin-top:24px">THRIFTgirl by Buyshare.co · Southwest Florida</p>
        </div>`,
      }),
    }).catch(() => {});
    // Also notify seller of confirmed payment
    if (sellerEmail) {
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: _from,
          to: [sellerEmail],
          subject: `💰 Payment confirmed for "${listingTitle}"`,
          html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px;color:#111827">
            <h2 style="color:#e8507e">Payment is confirmed!</h2>
            <p>The buyer's payment for <strong>"${listingTitle}"</strong> has been successfully processed. Reach out via inbox to schedule pickup.</p>
            <a href="${process.env.FRONTEND_URL || "https://buyshare.co"}/thrift/inbox" style="display:inline-block;background:#e8507e;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin-top:16px">Contact Buyer →</a>
            <p style="font-size:12px;color:#6b7280;margin-top:24px">THRIFTgirl by Buyshare.co · Southwest Florida</p>
          </div>`,
        }),
      }).catch(() => {});
    }
  }

  res.json({ ok: true, status: "paid" });
}));

export default router;
