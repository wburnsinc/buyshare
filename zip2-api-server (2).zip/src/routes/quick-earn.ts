import { Router } from "express";
import { pool } from "@workspace/db";
import { requireAuth, AuthRequest } from "../middleware/auth.js";

const router = Router();

let tablesReady = false;
async function ensureTables() {
  if (tablesReady) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS quick_earn_jobs (
      id TEXT PRIMARY KEY,
      poster_user_id TEXT NOT NULL,
      poster_name TEXT NOT NULL,
      poster_email TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL,
      rate TEXT NOT NULL,
      location_text TEXT,
      zip_code TEXT,
      deadline TEXT,
      status TEXT DEFAULT 'open',
      approved_bid_id TEXT,
      views INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS quick_earn_bids (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      bidder_user_id TEXT NOT NULL,
      bidder_name TEXT NOT NULL,
      bidder_email TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW(),
      CONSTRAINT quick_earn_bids_unique UNIQUE(job_id, bidder_user_id)
    )
  `);
  tablesReady = true;
}

const CATEGORIES = [
  "Lawn Care", "Cleaning", "Moving", "Handyman", "Painting",
  "Pool Care", "Pressure Washing", "Delivery", "Pet Care", "Assembly",
  "Errands", "Tree Trimming", "Hauling", "Other"
];

function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function wrap(fn: (req: any, res: any) => Promise<void>) {
  return async (req: any, res: any) => {
    try {
      await ensureTables();
      await fn(req, res);
    } catch (err: any) {
      console.error("quick-earn error:", err);
      if (!res.headersSent) res.status(500).json({ error: err.message || "Server error" });
    }
  };
}

router.get("/quick-earn/categories", (_req, res) => res.json({ categories: CATEGORIES }));

router.get("/quick-earn/jobs", wrap(async (req, res) => {
  const { category, status = "open", q, limit = "30", page = "1" } = req.query as any;
  const limitNum = Math.min(50, parseInt(limit) || 30);
  const offset = (Math.max(1, parseInt(page) || 1) - 1) * limitNum;

  const conditions: string[] = ["1=1"];
  const params: any[] = [];

  if (status && status !== "all") { params.push(status); conditions.push(`qj.status = $${params.length}`); }
  if (category && category !== "all") { params.push(category); conditions.push(`qj.category = $${params.length}`); }
  if (q) { params.push(`%${q}%`); conditions.push(`(qj.title ILIKE $${params.length} OR qj.description ILIKE $${params.length})`); }

  const where = conditions.join(" AND ");
  const [{ rows }, { rows: countRows }] = await Promise.all([
    pool.query(
      `SELECT qj.*, (SELECT COUNT(*) FROM quick_earn_bids qb WHERE qb.job_id = qj.id) AS bid_count
       FROM quick_earn_jobs qj WHERE ${where} ORDER BY qj.created_at DESC LIMIT ${limitNum} OFFSET ${offset}`,
      params
    ),
    pool.query(`SELECT COUNT(*) FROM quick_earn_jobs qj WHERE ${where}`, params),
  ]);
  res.json({ jobs: rows, total: parseInt(countRows[0].count) });
}));

router.get("/quick-earn/jobs/:id", wrap(async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM quick_earn_jobs WHERE id = $1 LIMIT 1", [req.params.id]);
  if (!rows.length) { res.status(404).json({ error: "Not found" }); return; }
  await pool.query("UPDATE quick_earn_jobs SET views = COALESCE(views,0)+1 WHERE id = $1", [req.params.id]).catch(() => {});
  const { rows: bids } = await pool.query(
    "SELECT * FROM quick_earn_bids WHERE job_id = $1 ORDER BY status DESC, created_at ASC",
    [req.params.id]
  );
  res.json({ job: rows[0], bids });
}));

router.post("/quick-earn/jobs", requireAuth, wrap(async (req: AuthRequest, res) => {
  const user = req.user!;
  const { title, description, category, rate, location_text, zip_code, deadline } = req.body;
  if (!title?.trim() || !description?.trim() || !category || !rate?.trim()) {
    res.status(400).json({ error: "title, description, category, and rate are required" }); return;
  }
  const id = uid("qej");
  const { rows } = await pool.query(
    `INSERT INTO quick_earn_jobs (id, poster_user_id, poster_name, poster_email, title, description, category, rate, location_text, zip_code, deadline)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [id, user.id, user.name || user.email, user.email.toLowerCase(),
     title.trim(), description.trim(), category, rate.trim(),
     location_text?.trim() || null, zip_code?.trim() || null, deadline || null]
  );
  res.status(201).json({ job: rows[0] });
}));

router.patch("/quick-earn/jobs/:id/close", requireAuth, wrap(async (req: AuthRequest, res) => {
  const user = req.user!;
  const { rows } = await pool.query("SELECT poster_user_id FROM quick_earn_jobs WHERE id = $1 LIMIT 1", [req.params.id]);
  if (!rows.length) { res.status(404).json({ error: "Not found" }); return; }
  if (rows[0].poster_user_id !== user.id && !user.is_admin) { res.status(403).json({ error: "Forbidden" }); return; }
  await pool.query("UPDATE quick_earn_jobs SET status = 'closed' WHERE id = $1", [req.params.id]);
  res.json({ ok: true });
}));

router.delete("/quick-earn/jobs/:id", requireAuth, wrap(async (req: AuthRequest, res) => {
  const user = req.user!;
  const { rows } = await pool.query("SELECT poster_user_id FROM quick_earn_jobs WHERE id = $1 LIMIT 1", [req.params.id]);
  if (!rows.length) { res.status(404).json({ error: "Not found" }); return; }
  if (rows[0].poster_user_id !== user.id && !user.is_admin) { res.status(403).json({ error: "Forbidden" }); return; }
  await pool.query("DELETE FROM quick_earn_bids WHERE job_id = $1", [req.params.id]);
  await pool.query("DELETE FROM quick_earn_jobs WHERE id = $1", [req.params.id]);
  res.json({ ok: true });
}));

router.post("/quick-earn/jobs/:id/bids", requireAuth, wrap(async (req: AuthRequest, res) => {
  const user = req.user!;
  const jobId = req.params.id;
  const { message } = req.body;
  if (!message?.trim()) { res.status(400).json({ error: "message is required" }); return; }

  const { rows: jobRows } = await pool.query("SELECT * FROM quick_earn_jobs WHERE id = $1 LIMIT 1", [jobId]);
  const job = jobRows[0];
  if (!job) { res.status(404).json({ error: "Job not found" }); return; }
  if (job.status !== "open") { res.status(409).json({ error: "This job is no longer accepting applications" }); return; }
  if (job.poster_user_id === user.id) { res.status(400).json({ error: "You cannot apply to your own job" }); return; }

  const id = uid("qeb");
  try {
    const { rows } = await pool.query(
      `INSERT INTO quick_earn_bids (id, job_id, bidder_user_id, bidder_name, bidder_email, message)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [id, jobId, user.id, user.name || user.email, user.email.toLowerCase(), message.trim()]
    );

    await pool.query(
      `INSERT INTO notifications (user_email, type, title, body, data) VALUES ($1,$2,$3,$4,$5)`,
      [job.poster_email, "quick_earn_bid", "New application on your job! 💰",
       `${user.name || "Someone"} applied for "${job.title}"`,
       JSON.stringify({ job_id: jobId })]
    ).catch(() => {});

    res.status(201).json({ bid: rows[0] });
  } catch (err: any) {
    if (err.code === "23505" || err.message?.includes("unique")) {
      res.status(409).json({ error: "You've already applied to this job" }); return;
    }
    throw err;
  }
}));

router.patch("/quick-earn/jobs/:id/bids/:bidId/approve", requireAuth, wrap(async (req: AuthRequest, res) => {
  const user = req.user!;
  const { id: jobId, bidId } = req.params;

  const { rows: jobRows } = await pool.query("SELECT * FROM quick_earn_jobs WHERE id = $1 LIMIT 1", [jobId]);
  const job = jobRows[0];
  if (!job) { res.status(404).json({ error: "Not found" }); return; }
  if (job.poster_user_id !== user.id) { res.status(403).json({ error: "Only the poster can approve" }); return; }
  if (job.status === "filled") { res.status(409).json({ error: "A bid is already approved" }); return; }

  const { rows: bidRows } = await pool.query("SELECT * FROM quick_earn_bids WHERE id = $1 AND job_id = $2 LIMIT 1", [bidId, jobId]);
  const bid = bidRows[0];
  if (!bid) { res.status(404).json({ error: "Bid not found" }); return; }

  await pool.query("UPDATE quick_earn_jobs SET status = 'filled', approved_bid_id = $1 WHERE id = $2", [bidId, jobId]);
  await pool.query("UPDATE quick_earn_bids SET status = 'approved' WHERE id = $1", [bidId]);

  await pool.query(
    `INSERT INTO notifications (user_email, type, title, body, data) VALUES ($1,$2,$3,$4,$5)`,
    [bid.bidder_email, "quick_earn_approved", "You got selected! 🎉",
     `${job.poster_name || "A homeowner"} selected you for "${job.title}". Coordinate the details!`,
     JSON.stringify({ job_id: jobId })]
  ).catch(() => {});

  const resendKey = process.env.RESEND_API_KEY;
  if (resendKey) {
    const from = process.env.RESEND_FROM_EMAIL
      ? `SWFL Quick Earn <${process.env.RESEND_FROM_EMAIL}>`
      : "SWFL Quick Earn <onboarding@resend.dev>";
    fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from, to: [bid.bidder_email],
        subject: `🎉 You got selected for "${job.title}"`,
        html: `<div style="font-family:sans-serif;max-width:560px;margin:auto;padding:24px;color:#111">
          <div style="background:#16a34a;color:#fff;padding:20px;border-radius:12px;text-align:center;margin-bottom:24px">
            <h2 style="margin:0;font-size:22px">You got the job! 🎉</h2>
          </div>
          <p><strong>${job.poster_name || "A homeowner"}</strong> selected your application for:</p>
          <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:16px;margin:16px 0">
            <h3 style="margin:0 0 8px;color:#15803d">${job.title}</h3>
            <p style="margin:0;color:#374151">📍 ${job.location_text || "SWFL Area"} &nbsp;·&nbsp; 💰 ${job.rate}</p>
            ${job.deadline ? `<p style="margin:4px 0 0;color:#374151">📅 Needed by: ${job.deadline}</p>` : ""}
          </div>
          <p>The homeowner will reach out to coordinate. Be professional, on time, and ready to work!</p>
          <a href="https://buyshare.co/quick-earn" style="display:inline-block;background:#16a34a;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin-top:8px">View on Quick Earn →</a>
          <p style="font-size:12px;color:#9ca3af;margin-top:24px">SWFL Quick Earn · Powered by Buyshare.co</p>
        </div>`,
      }),
    }).catch(() => {});
  }

  res.json({ ok: true });
}));

router.get("/quick-earn/my-jobs", requireAuth, wrap(async (req: AuthRequest, res) => {
  const user = req.user!;
  const { rows } = await pool.query(
    `SELECT qj.*, (SELECT COUNT(*) FROM quick_earn_bids qb WHERE qb.job_id = qj.id) AS bid_count
     FROM quick_earn_jobs qj WHERE qj.poster_user_id = $1 ORDER BY qj.created_at DESC LIMIT 50`,
    [user.id]
  );
  res.json({ jobs: rows });
}));

router.get("/quick-earn/my-bids", requireAuth, wrap(async (req: AuthRequest, res) => {
  const user = req.user!;
  const { rows } = await pool.query(
    `SELECT qb.*, qj.title AS job_title, qj.rate AS job_rate, qj.location_text AS job_location,
            qj.status AS job_status, qj.poster_name AS job_poster_name, qj.deadline AS job_deadline
     FROM quick_earn_bids qb JOIN quick_earn_jobs qj ON qb.job_id = qj.id
     WHERE qb.bidder_user_id = $1 ORDER BY qb.created_at DESC LIMIT 50`,
    [user.id]
  );
  res.json({ bids: rows });
}));

export default router;
