import { Router } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { requireMasterAdmin, requireAuth, type AuthRequest } from "../middleware/auth.js";
import { logAudit } from "./admin.js";
import nodemailer from "nodemailer";

const ADMIN_EMAIL = "burnsinc@outlook.com";

function getTransport() {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!host || !user || !pass) return null;
  return nodemailer.createTransport({
    host,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user, pass },
  });
}

async function sendAdminNameChangeNotification(change: {
  proId: string;
  oldBusinessName: string;
  newBusinessName: string;
  oldContactName: string;
  newContactName: string;
}) {
  const transport = getTransport();
  const changedFields: string[] = [];
  if (change.oldBusinessName !== change.newBusinessName) changedFields.push("business name");
  if (change.oldContactName !== change.newContactName) changedFields.push("contact name");
  if (changedFields.length === 0) return;

  const label = changedFields.join(" and ");
  const subject = `Pro Profile Update: ${label} changed (${change.newBusinessName})`;

  if (!transport) {
    console.log(`[pro-requests] Email skipped (no SMTP config). Pro ${change.proId} changed ${label}.`);
    return;
  }

  const rows = [];
  if (change.oldBusinessName !== change.newBusinessName) {
    rows.push(`
      <tr><td style="padding:8px 0;color:#555;font-weight:bold;width:160px;">Business Name (old)</td><td style="padding:8px 0;">${change.oldBusinessName}</td></tr>
      <tr><td style="padding:8px 0;color:#555;font-weight:bold;">Business Name (new)</td><td style="padding:8px 0;color:#2563eb;font-weight:bold;">${change.newBusinessName}</td></tr>
    `);
  }
  if (change.oldContactName !== change.newContactName) {
    rows.push(`
      <tr><td style="padding:8px 0;color:#555;font-weight:bold;">Contact Name (old)</td><td style="padding:8px 0;">${change.oldContactName}</td></tr>
      <tr><td style="padding:8px 0;color:#555;font-weight:bold;">Contact Name (new)</td><td style="padding:8px 0;color:#2563eb;font-weight:bold;">${change.newContactName}</td></tr>
    `);
  }

  try {
    await transport.sendMail({
      from: process.env.SMTP_FROM || "noreply@buyshare.co",
      to: ADMIN_EMAIL,
      subject,
      html: `
        <h2 style="font-family:sans-serif;color:#1a1a1a;">Pro Profile Name Change</h2>
        <p style="font-family:sans-serif;color:#555;">A pro has updated their ${label}. Please review the change below.</p>
        <table style="font-family:sans-serif;border-collapse:collapse;width:100%;max-width:540px;">
          <tr><td style="padding:8px 0;color:#555;font-weight:bold;width:160px;">Pro ID</td><td style="padding:8px 0;">${change.proId}</td></tr>
          ${rows.join("")}
        </table>
        <p style="font-family:sans-serif;margin-top:24px;">
          <a href="https://${process.env.REPLIT_DOMAINS?.split(",")[0] ?? "buyshare.co"}/admin/pro-requests"
             style="background:#2563eb;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-family:sans-serif;">
            Review in Admin Panel
          </a>
        </p>
      `,
    });
    console.log(`[pro-requests] Admin notified of name change for pro ${change.proId}: ${label} changed.`);
  } catch (err) {
    console.error("[pro-requests] Failed to send name change notification email:", err);
  }
}

async function sendAdminProNotification(applicant: {
  contact_name: string;
  business_name: string;
  category: string;
  location: string | null;
  phone: string;
}) {
  const transport = getTransport();
  if (!transport) {
    console.log(`[pro-requests] Email skipped (no SMTP config). New pro application from: ${applicant.contact_name}`);
    return;
  }
  try {
    await transport.sendMail({
      from: process.env.SMTP_FROM || "noreply@buyshare.co",
      to: ADMIN_EMAIL,
      subject: `New Pro Application: ${applicant.business_name}`,
      html: `
        <h2 style="font-family:sans-serif;color:#1a1a1a;">New Pro Listing Application</h2>
        <table style="font-family:sans-serif;border-collapse:collapse;width:100%;max-width:500px;">
          <tr><td style="padding:8px 0;color:#555;font-weight:bold;width:140px;">Name</td><td style="padding:8px 0;">${applicant.contact_name}</td></tr>
          <tr><td style="padding:8px 0;color:#555;font-weight:bold;">Business</td><td style="padding:8px 0;">${applicant.business_name}</td></tr>
          <tr><td style="padding:8px 0;color:#555;font-weight:bold;">Category</td><td style="padding:8px 0;">${applicant.category}</td></tr>
          <tr><td style="padding:8px 0;color:#555;font-weight:bold;">Location</td><td style="padding:8px 0;">${applicant.location || "Not provided"}</td></tr>
          <tr><td style="padding:8px 0;color:#555;font-weight:bold;">Phone</td><td style="padding:8px 0;">${applicant.phone}</td></tr>
        </table>
        <p style="font-family:sans-serif;margin-top:24px;">
          <a href="https://${process.env.REPLIT_DOMAINS?.split(",")[0] ?? "buyshare.co"}/admin/pro-requests"
             style="background:#2563eb;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-family:sans-serif;">
            Review Application
          </a>
        </p>
      `,
    });
    console.log(`[pro-requests] Admin notified of new application from ${applicant.contact_name}`);
  } catch (err) {
    console.error("[pro-requests] Failed to send admin notification email:", err);
  }
}

const router = Router();

function sanitizeUrl(url: string | undefined | null): string | null {
  if (!url) return null;
  try {
    const u = new URL(url.startsWith("http") ? url : "https://" + url);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.href;
  } catch {
    return null;
  }
}

async function initTables() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS pro_requests (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      business_name TEXT NOT NULL,
      contact_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      title TEXT,
      location TEXT,
      website TEXT,
      photo_url TEXT,
      service_areas TEXT,
      years_experience TEXT,
      license_number TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS title TEXT`);
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS location TEXT`);
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS claim_code TEXT DEFAULT gen_random_uuid()::text`);
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS claimed_by_user_id TEXT`);
  await db.execute(sql`UPDATE pro_requests SET claim_code = gen_random_uuid()::text WHERE claim_code IS NULL`);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS vetted_pros (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      request_id TEXT REFERENCES pro_requests(id) ON DELETE CASCADE,
      business_name TEXT NOT NULL,
      contact_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      title TEXT,
      location TEXT,
      website TEXT,
      photo_url TEXT,
      lat NUMERIC,
      lng NUMERIC,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`ALTER TABLE vetted_pros ADD COLUMN IF NOT EXISTS request_id TEXT`);
  await db.execute(sql`ALTER TABLE vetted_pros ADD COLUMN IF NOT EXISTS lat NUMERIC`);
  await db.execute(sql`ALTER TABLE vetted_pros ADD COLUMN IF NOT EXISTS lng NUMERIC`);
  await db.execute(sql`ALTER TABLE vetted_pros ADD COLUMN IF NOT EXISTS email TEXT`);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS pro_reviews (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      pro_id TEXT NOT NULL REFERENCES vetted_pros(id) ON DELETE CASCADE,
      reviewer_name TEXT NOT NULL,
      stars INTEGER NOT NULL CHECK (stars >= 1 AND stars <= 5),
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

router.get("/vetted-pros", async (_req, res) => {
  try {
    await initTables();
    const result = await db.execute(sql`
      SELECT id, business_name, contact_name, title, category, description,
             phone, website, photo_url, location, lat, lng
      FROM vetted_pros
      ORDER BY updated_at DESC
    `);
    res.json({ pros: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/vetted-pros/:id", async (req, res) => {
  try {
    await initTables();
    const result = await db.execute(sql`
      SELECT id, business_name, contact_name, title, category, description,
             phone, website, photo_url, location, lat, lng, created_at
      FROM vetted_pros
      WHERE id = ${req.params.id}
      LIMIT 1
    `);
    const pro = (result.rows as any[])[0];
    if (!pro) return res.status(404).json({ error: "Pro not found" });
    res.json({ pro });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/pro-requests/portal/me", requireAuth, async (req: AuthRequest, res) => {
  try {
    await initTables();
    const userId = req.user?.id;
    if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

    const byClaim = await db.execute(sql`
      SELECT id, business_name, contact_name, email, phone, category, description,
             title, location, website, photo_url, service_areas, years_experience,
             license_number, status, admin_notes, claimed_by_user_id, created_at
      FROM pro_requests
      WHERE claimed_by_user_id = ${userId}
      ORDER BY created_at DESC
      LIMIT 1
    `);
    if ((byClaim.rows as any[]).length > 0) {
      res.json({ request: (byClaim.rows as any[])[0], claim_required: false });
      return;
    }

    res.status(404).json({ error: "no_application" });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/pro-requests/portal/claim", requireAuth, async (req: AuthRequest, res) => {
  try {
    await initTables();
    const userId = req.user?.id;
    if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
    const { claim_code } = req.body;
    if (!claim_code) { res.status(400).json({ error: "Claim code required." }); return; }

    const found = await db.execute(sql`
      SELECT id, claimed_by_user_id FROM pro_requests
      WHERE claim_code = ${String(claim_code).trim()}
      LIMIT 1
    `);
    const record = (found.rows as any[])[0];
    if (!record) {
      res.status(404).json({ error: "Invalid claim code. Please check the code and try again." });
      return;
    }
    if (record.claimed_by_user_id && record.claimed_by_user_id !== userId) {
      res.status(409).json({ error: "This listing is already claimed by another account." });
      return;
    }
    if (record.claimed_by_user_id === userId) {
      const existing = await db.execute(sql`
        SELECT id, business_name, contact_name, email, phone, category, description,
               title, location, website, photo_url, service_areas, years_experience,
               license_number, status, admin_notes, claimed_by_user_id, created_at
        FROM pro_requests WHERE id = ${record.id}
      `);
      res.json({ request: (existing.rows as any[])[0] });
      return;
    }

    await db.execute(sql`
      UPDATE pro_requests SET claimed_by_user_id = ${userId}, updated_at = NOW()
      WHERE id = ${record.id}
    `);
    const updated = await db.execute(sql`
      SELECT id, business_name, contact_name, email, phone, category, description,
             title, location, website, photo_url, service_areas, years_experience,
             license_number, status, admin_notes, claimed_by_user_id, created_at
      FROM pro_requests WHERE id = ${record.id}
    `);
    res.json({ request: (updated.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/pro-requests/portal/edit", requireAuth, async (req: AuthRequest, res) => {
  try {
    await initTables();
    const userId = req.user?.id;
    if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

    const current = await db.execute(sql`
      SELECT id, status FROM pro_requests
      WHERE claimed_by_user_id = ${userId}
      ORDER BY created_at DESC
      LIMIT 1
    `);
    const currentRecord = (current.rows as any[])[0];
    if (!currentRecord) { res.status(403).json({ error: "You must claim this listing before you can edit it." }); return; }

    const proId = currentRecord.id;
    const {
      business_name, contact_name, phone, title, location,
      description, website, photo_url
    } = req.body;

    const sanitizedWebsite = website !== undefined ? sanitizeUrl(website) : undefined;
    const sanitizedPhotoUrl = photo_url !== undefined ? sanitizeUrl(photo_url) : undefined;

    const autoPublishResult = await db.execute(sql`
      SELECT value FROM platform_settings WHERE key = 'pro_edits_auto_publish' LIMIT 1
    `).catch(() => ({ rows: [] }));
    const autoPublish = ((autoPublishResult.rows as any[])[0]?.value === "true");

    const newStatus = (currentRecord.status === "listed" || currentRecord.status === "approved")
      ? (autoPublish ? currentRecord.status : "pending_edit")
      : currentRecord.status;

    await db.execute(sql`
      UPDATE pro_requests SET
        business_name = COALESCE(${business_name ?? null}, business_name),
        contact_name  = COALESCE(${contact_name ?? null}, contact_name),
        phone         = COALESCE(${phone ?? null}, phone),
        title         = COALESCE(${title ?? null}, title),
        location      = COALESCE(${location ?? null}, location),
        description   = COALESCE(${description ?? null}, description),
        website       = COALESCE(${sanitizedWebsite !== undefined ? sanitizedWebsite : null}, website),
        photo_url     = COALESCE(${sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : null}, photo_url),
        status        = ${newStatus},
        updated_at    = NOW()
      WHERE id = ${proId}
    `);

    if (autoPublish && (newStatus === "listed" || newStatus === "approved")) {
      const updated = await db.execute(sql`SELECT * FROM pro_requests WHERE id = ${proId}`);
      const u = (updated.rows as any[])[0];
      if (u) {
        const existing = await db.execute(sql`SELECT id FROM vetted_pros WHERE request_id = ${proId}`);
        if ((existing.rows as any[]).length > 0) {
          const vettedId = (existing.rows as any[])[0].id;
          await db.execute(sql`
            UPDATE vetted_pros SET
              business_name = ${u.business_name},
              contact_name  = ${u.contact_name},
              phone         = ${u.phone},
              description   = ${u.description},
              title         = ${u.title || null},
              location      = ${u.location || null},
              website       = ${u.website || null},
              photo_url     = ${u.photo_url || null},
              updated_at    = NOW()
            WHERE id = ${vettedId}
          `);
        }
      }
    }

    const updated = await db.execute(sql`SELECT * FROM pro_requests WHERE id = ${proId}`);
    res.json({ request: (updated.rows as any[])[0], autoPublish });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/pro-requests", async (req, res) => {
  try {
    await initTables();
    const {
      business_name, contact_name, email, phone, category, description,
      title, location, website, photo_url, service_areas, years_experience, license_number
    } = req.body;
    if (!business_name || !contact_name || !email || !phone || !category || !description) {
      res.status(400).json({ error: "Required fields missing" }); return;
    }
    const result = await db.execute(sql`
      INSERT INTO pro_requests
        (business_name, contact_name, email, phone, category, description,
         title, location, website, photo_url, service_areas, years_experience, license_number)
      VALUES
        (${business_name}, ${contact_name}, ${email}, ${phone}, ${category}, ${description},
         ${title || null}, ${location || null}, ${sanitizeUrl(website)}, ${sanitizeUrl(photo_url)},
         ${service_areas || null}, ${years_experience || null}, ${license_number || null})
      RETURNING *
    `);
    const saved = (result.rows as any[])[0];
    res.json({ request: saved });
    sendAdminProNotification({
      contact_name: saved.contact_name,
      business_name: saved.business_name,
      category: saved.category,
      location: saved.location ?? null,
      phone: saved.phone,
    }).catch(() => {});
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/pro-requests/portal/vetted-pro", requireAuth, async (req: AuthRequest, res) => {
  try {
    await initTables();
    const userEmail = req.user?.email?.toLowerCase();
    if (!userEmail) { res.status(401).json({ error: "Unauthorized" }); return; }

    const result = await db.execute(sql`
      SELECT vp.id, vp.business_name, vp.contact_name, vp.title, vp.category,
             vp.description, vp.phone, vp.website, vp.photo_url, vp.location,
             vp.lat, vp.lng, vp.created_at
      FROM vetted_pros vp
      LEFT JOIN pro_requests pr ON pr.id = vp.request_id
      WHERE LOWER(pr.email) = ${userEmail}
         OR LOWER(vp.email) = ${userEmail}
      LIMIT 1
    `);
    const vp = (result.rows as any[])[0];
    if (!vp) { res.status(404).json({ error: "no_vetted_pro" }); return; }
    res.json({ pro: vp });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/vetted-pros/:id", requireAuth, async (req: AuthRequest, res) => {
  try {
    await initTables();
    const userEmail = req.user?.email?.toLowerCase();
    if (!userEmail) { res.status(401).json({ error: "Unauthorized" }); return; }

    const vettedId = req.params.id;

    const ownerCheck = await db.execute(sql`
      SELECT vp.id, vp.request_id
      FROM vetted_pros vp
      LEFT JOIN pro_requests pr ON pr.id = vp.request_id
      WHERE vp.id = ${vettedId}
        AND (LOWER(pr.email) = ${userEmail} OR LOWER(vp.email) = ${userEmail})
      LIMIT 1
    `);
    if ((ownerCheck.rows as any[]).length === 0) {
      const exists = await db.execute(sql`SELECT id FROM vetted_pros WHERE id = ${vettedId} LIMIT 1`);
      if ((exists.rows as any[]).length === 0) {
        res.status(404).json({ error: "Pro not found" }); return;
      }
      res.status(403).json({ error: "You do not have permission to edit this profile." }); return;
    }

    const vp = (ownerCheck.rows as any[])[0];

    const beforeResult = await db.execute(sql`
      SELECT business_name, contact_name FROM vetted_pros WHERE id = ${vettedId} LIMIT 1
    `);
    const before = (beforeResult.rows as any[])[0] ?? {};

    const { bio, description, photo_url, website, phone, location, business_name, contact_name, title, category } = req.body;
    const descriptionValue = bio ?? description;
    const sanitizedPhotoUrl = photo_url !== undefined ? sanitizeUrl(photo_url) : undefined;
    const sanitizedWebsite = website !== undefined ? sanitizeUrl(website) : undefined;

    const VALID_CATEGORIES = ["handyman","electrician","plumber","painter","landscaper","cleaner","realtor","mortgage","contractor","other"];
    const sanitizedCategory = category !== undefined
      ? (VALID_CATEGORIES.includes(String(category).toLowerCase()) ? String(category).toLowerCase() : null)
      : undefined;

    await db.execute(sql`
      UPDATE vetted_pros SET
        description   = COALESCE(${descriptionValue ?? null}, description),
        photo_url     = COALESCE(${sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : null}, photo_url),
        website       = COALESCE(${sanitizedWebsite !== undefined ? sanitizedWebsite : null}, website),
        phone         = COALESCE(${phone ?? null}, phone),
        location      = COALESCE(${location ?? null}, location),
        business_name = COALESCE(${business_name ?? null}, business_name),
        contact_name  = COALESCE(${contact_name ?? null}, contact_name),
        title         = COALESCE(${title !== undefined ? (title || null) : null}, title),
        category      = COALESCE(${sanitizedCategory !== undefined ? sanitizedCategory : null}, category),
        updated_at    = NOW()
      WHERE id = ${vettedId}
    `);

    if (vp.request_id) {
      await db.execute(sql`
        UPDATE pro_requests SET
          description   = COALESCE(${descriptionValue ?? null}, description),
          photo_url     = COALESCE(${sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : null}, photo_url),
          website       = COALESCE(${sanitizedWebsite !== undefined ? sanitizedWebsite : null}, website),
          phone         = COALESCE(${phone ?? null}, phone),
          location      = COALESCE(${location ?? null}, location),
          business_name = COALESCE(${business_name ?? null}, business_name),
          contact_name  = COALESCE(${contact_name ?? null}, contact_name),
          title         = COALESCE(${title !== undefined ? (title || null) : null}, title),
          category      = COALESCE(${sanitizedCategory !== undefined ? sanitizedCategory : null}, category),
          updated_at    = NOW()
        WHERE id = ${vp.request_id}
      `);
    }

    const updated = await db.execute(sql`
      SELECT id, business_name, contact_name, title, category, description,
             phone, website, photo_url, location, lat, lng, created_at
      FROM vetted_pros WHERE id = ${vettedId} LIMIT 1
    `);
    const after = (updated.rows as any[])[0];
    res.json({ pro: after });

    const newBusinessName = after?.business_name ?? before.business_name;
    const newContactName = after?.contact_name ?? before.contact_name;
    if (newBusinessName !== before.business_name || newContactName !== before.contact_name) {
      sendAdminNameChangeNotification({
        proId: String(vettedId),
        oldBusinessName: before.business_name,
        newBusinessName,
        oldContactName: before.contact_name,
        newContactName,
      }).catch(() => {});
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/vetted-pros/:id/reviews", async (req, res) => {
  try {
    await initTables();
    const result = await db.execute(sql`
      SELECT id, reviewer_name, stars, body, created_at
      FROM pro_reviews
      WHERE pro_id = ${req.params.id}
      ORDER BY created_at ASC
    `);
    res.json({ reviews: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/vetted-pros/:id/reviews", async (req, res) => {
  try {
    await initTables();
    const proId = req.params.id;
    const { reviewer_name, stars, body } = req.body;

    if (!reviewer_name || !reviewer_name.trim()) {
      res.status(400).json({ error: "Your name is required." }); return;
    }
    const starsNum = parseInt(stars, 10);
    if (!starsNum || starsNum < 1 || starsNum > 5) {
      res.status(400).json({ error: "A star rating between 1 and 5 is required." }); return;
    }
    if (!body || !body.trim()) {
      res.status(400).json({ error: "A review message is required." }); return;
    }

    const proCheck = await db.execute(sql`SELECT id FROM vetted_pros WHERE id = ${proId} LIMIT 1`);
    if ((proCheck.rows as any[]).length === 0) {
      res.status(404).json({ error: "Pro not found." }); return;
    }

    const result = await db.execute(sql`
      INSERT INTO pro_reviews (pro_id, reviewer_name, stars, body)
      VALUES (${proId}, ${reviewer_name.trim()}, ${starsNum}, ${body.trim()})
      RETURNING id, reviewer_name, stars, body, created_at
    `);
    res.status(201).json({ review: (result.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/vetted-pros/:id", requireMasterAdmin, async (req, res) => {
  try {
    await initTables();
    const id = req.params.id;

    const existing = await db.execute(sql`SELECT id, request_id FROM vetted_pros WHERE id = ${id} LIMIT 1`);
    const vp = (existing.rows as any[])[0];
    if (!vp) { res.status(404).json({ error: "Vetted pro not found" }); return; }

    await db.execute(sql`DELETE FROM vetted_pros WHERE id = ${id}`);

    if (vp.request_id) {
      await db.execute(sql`
        UPDATE pro_requests SET status = 'approved', updated_at = NOW()
        WHERE id = ${vp.request_id}
      `);
    }

    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/pro-reviews/:id", requireMasterAdmin, async (req, res) => {
  try {
    await initTables();
    await db.execute(sql`DELETE FROM pro_reviews WHERE id = ${req.params.id}`);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/vetted-pros", requireMasterAdmin, async (_req, res) => {
  try {
    await initTables();
    const result = await db.execute(sql`
      SELECT vp.*, pr.email, pr.service_areas, pr.years_experience, pr.license_number,
             pr.admin_notes, pr.claim_code, pr.claimed_by_user_id, pr.status as request_status,
             (
               SELECT al.admin_email
               FROM audit_log al
               WHERE al.target_id = vp.id
                 AND al.action IN ('vetted_pro_updated', 'vetted_pro_reverted')
               ORDER BY al.created_at DESC
               LIMIT 1
             ) AS last_edited_by
      FROM vetted_pros vp
      LEFT JOIN pro_requests pr ON pr.id = vp.request_id
      ORDER BY vp.updated_at DESC
    `);
    res.json({ pros: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/vetted-pros/:id/history", requireMasterAdmin, async (req, res) => {
  try {
    await initTables();
    const id = req.params.id;
    const result = await db.execute(sql`
      SELECT id, admin_email, action, details, created_at
      FROM audit_log
      WHERE action IN ('vetted_pro_updated', 'vetted_pro_reverted') AND target_id = ${id}
      ORDER BY created_at DESC
      LIMIT 3
    `);
    res.json({ history: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/vetted-pros/:id/snapshot/:auditLogId", requireMasterAdmin, async (req, res) => {
  try {
    await initTables();
    const { id, auditLogId } = req.params;

    // Current live profile
    const existing = await db.execute(sql`SELECT * FROM vetted_pros WHERE id = ${id} LIMIT 1`);
    const vp = (existing.rows as any[])[0];
    if (!vp) { res.status(404).json({ error: "Vetted pro not found" }); return; }

    // All audit entries for this pro, newest first (no limit so we can walk the full chain)
    const allLogs = await db.execute(sql`
      SELECT id, details, action, created_at
      FROM audit_log
      WHERE action IN ('vetted_pro_updated', 'vetted_pro_reverted') AND target_id = ${id}
      ORDER BY created_at DESC
    `);
    const entries = allLogs.rows as any[];

    // Find the target entry
    const targetIndex = entries.findIndex((e: any) => e.id === auditLogId);
    if (targetIndex === -1) { res.status(404).json({ error: "Audit log entry not found" }); return; }

    // Start from the current snapshot and walk backwards through every entry
    // that is NEWER than (or equal to) the target, applying "from" values.
    // After walking entries[0..targetIndex] (inclusive) we arrive at the state
    // just BEFORE that edit was applied — i.e., what the profile looked like at
    // the moment the admin would have been looking at it before clicking Save.
    const allowed = ["business_name","contact_name","phone","title","location","description","website","photo_url","lat","lng"];
    const snapshot: Record<string, string | null> = {};
    for (const f of allowed) {
      snapshot[f] = vp[f] !== null && vp[f] !== undefined ? String(vp[f]) : null;
    }

    for (let i = 0; i <= targetIndex; i++) {
      let diff: Record<string, unknown> = {};
      try { diff = JSON.parse(entries[i].details); } catch { continue; }
      for (const field of allowed) {
        if (!(field in diff)) continue;
        const entry = diff[field];
        if (entry !== null && typeof entry === "object" && "from" in (entry as object)) {
          snapshot[field] = (entry as { from: string | null }).from;
        } else if (entry === null || typeof entry === "string" || typeof entry === "number") {
          // legacy scalar shape — treat as the from value
          snapshot[field] = entry === null ? null : String(entry);
        }
      }
    }

    res.json({ snapshot });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/vetted-pros/:id/revert", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await initTables();
    const id = req.params.id;
    const { audit_log_id } = req.body;
    if (!audit_log_id) { res.status(400).json({ error: "audit_log_id required" }); return; }

    const logResult = await db.execute(sql`
      SELECT id, details, action FROM audit_log
      WHERE id = ${audit_log_id}
        AND target_id = ${id}
        AND action IN ('vetted_pro_updated', 'vetted_pro_reverted')
      LIMIT 1
    `);
    const logEntry = (logResult.rows as any[])[0];
    if (!logEntry) { res.status(404).json({ error: "Audit log entry not found" }); return; }

    let rawDiff: Record<string, unknown> = {};
    try { rawDiff = JSON.parse(logEntry.details); } catch {
      res.status(400).json({ error: "Invalid audit log details" }); return;
    }

    const existing = await db.execute(sql`SELECT * FROM vetted_pros WHERE id = ${id} LIMIT 1`);
    const vp = (existing.rows as any[])[0];
    if (!vp) { res.status(404).json({ error: "Vetted pro not found" }); return; }

    const allowed = ["business_name","contact_name","phone","title","location","description","website","photo_url","lat","lng"];

    // Extract the snapshot value for each field.
    // Handles two audit detail shapes:
    //   1. { field: { from, to } }  — written by vetted_pro_updated (and new vetted_pro_reverted)
    //   2. { field: scalar | null } — written by the (now-fixed) old vetted_pro_reverted path
    const toRestore: Record<string, string | null> = {};
    for (const field of allowed) {
      if (!(field in rawDiff)) continue;
      const entry = rawDiff[field];
      if (entry !== null && typeof entry === "object" && "from" in (entry as object)) {
        toRestore[field] = (entry as { from: string | null }).from;
      } else if (entry === null || typeof entry === "string" || typeof entry === "number") {
        toRestore[field] = entry === null ? null : String(entry);
      }
    }

    if (Object.keys(toRestore).length === 0) {
      res.status(400).json({ error: "No restorable fields in this entry" }); return;
    }

    const latRaw = toRestore.lat;
    const lngRaw = toRestore.lng;
    const latVal = latRaw !== undefined && latRaw !== null && latRaw !== "" && !isNaN(Number(latRaw)) ? Number(latRaw) : null;
    const lngVal = lngRaw !== undefined && lngRaw !== null && lngRaw !== "" && !isNaN(Number(lngRaw)) ? Number(lngRaw) : null;
    const sanitizedPhotoUrl = toRestore.photo_url !== undefined ? sanitizeUrl(toRestore.photo_url) : undefined;
    const sanitizedWebsite = toRestore.website !== undefined ? sanitizeUrl(toRestore.website) : undefined;

    await db.execute(sql`
      UPDATE vetted_pros SET
        business_name = ${toRestore.business_name !== undefined ? toRestore.business_name : vp.business_name},
        contact_name  = ${toRestore.contact_name  !== undefined ? toRestore.contact_name  : vp.contact_name},
        phone         = ${toRestore.phone         !== undefined ? toRestore.phone         : vp.phone},
        title         = ${toRestore.title         !== undefined ? toRestore.title         : vp.title},
        location      = ${toRestore.location      !== undefined ? toRestore.location      : vp.location},
        description   = ${toRestore.description   !== undefined ? toRestore.description   : vp.description},
        website       = ${toRestore.website       !== undefined ? sanitizedWebsite        : vp.website},
        photo_url     = ${toRestore.photo_url     !== undefined ? sanitizedPhotoUrl       : vp.photo_url},
        lat           = ${toRestore.lat           !== undefined ? (latVal !== null ? String(latVal) : null) : vp.lat},
        lng           = ${toRestore.lng           !== undefined ? (lngVal !== null ? String(lngVal) : null) : vp.lng},
        updated_at    = NOW()
      WHERE id = ${id}
    `);

    if (vp.request_id) {
      await db.execute(sql`
        UPDATE pro_requests SET
          business_name = ${toRestore.business_name !== undefined ? toRestore.business_name : vp.business_name},
          contact_name  = ${toRestore.contact_name  !== undefined ? toRestore.contact_name  : vp.contact_name},
          phone         = ${toRestore.phone         !== undefined ? toRestore.phone         : vp.phone},
          title         = ${toRestore.title         !== undefined ? toRestore.title         : vp.title},
          location      = ${toRestore.location      !== undefined ? toRestore.location      : vp.location},
          description   = ${toRestore.description   !== undefined ? toRestore.description   : vp.description},
          website       = ${toRestore.website       !== undefined ? sanitizedWebsite        : vp.website},
          photo_url     = ${toRestore.photo_url     !== undefined ? sanitizedPhotoUrl       : vp.photo_url},
          updated_at    = NOW()
        WHERE id = ${vp.request_id}
      `);
    }

    // Build a {from, to} diff for the audit entry so reverted entries use
    // the same shape as vetted_pro_updated and can themselves be reverted.
    const adminEmail = req.user?.email || "admin";
    const revertDiff: Record<string, { from: string | null; to: string | null }> = {};
    for (const [field, restoredValue] of Object.entries(toRestore)) {
      const currentNorm = vp[field] !== null && vp[field] !== undefined ? String(vp[field]).trim() : null;
      const restoredNorm = restoredValue !== null ? String(restoredValue).trim() : null;
      revertDiff[field] = { from: currentNorm, to: restoredNorm };
    }
    await logAudit(adminEmail, "vetted_pro_reverted", "vetted_pro", id, JSON.stringify(revertDiff));

    const updated = await db.execute(sql`
      SELECT vp.*, pr.email, pr.service_areas, pr.years_experience, pr.license_number,
             pr.admin_notes, pr.claim_code, pr.claimed_by_user_id, pr.status as request_status
      FROM vetted_pros vp
      LEFT JOIN pro_requests pr ON pr.id = vp.request_id
      WHERE vp.id = ${id}
      LIMIT 1
    `);
    res.json({ pro: (updated.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/vetted-pros/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    await initTables();
    const id = req.params.id;
    const { title, location, photo_url, website, lat, lng, description, business_name, contact_name, phone } = req.body;

    const latVal = lat !== undefined && lat !== "" && !isNaN(Number(lat)) ? Number(lat) : null;
    const lngVal = lng !== undefined && lng !== "" && !isNaN(Number(lng)) ? Number(lng) : null;
    const sanitizedPhotoUrl = photo_url !== undefined ? sanitizeUrl(photo_url) : undefined;
    const sanitizedWebsite = website !== undefined ? sanitizeUrl(website) : undefined;

    const existing = await db.execute(sql`SELECT * FROM vetted_pros WHERE id = ${id} LIMIT 1`);
    const vp = (existing.rows as any[])[0];
    if (!vp) { res.status(404).json({ error: "Vetted pro not found" }); return; }

    await db.execute(sql`
      UPDATE vetted_pros SET
        title         = COALESCE(${title ?? null}, title),
        location      = COALESCE(${location ?? null}, location),
        photo_url     = COALESCE(${sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : null}, photo_url),
        website       = COALESCE(${sanitizedWebsite !== undefined ? sanitizedWebsite : null}, website),
        lat           = ${latVal !== null ? String(latVal) : (lat === "" ? null : vp.lat)},
        lng           = ${lngVal !== null ? String(lngVal) : (lng === "" ? null : vp.lng)},
        description   = COALESCE(${description ?? null}, description),
        business_name = COALESCE(${business_name ?? null}, business_name),
        contact_name  = COALESCE(${contact_name ?? null}, contact_name),
        phone         = COALESCE(${phone ?? null}, phone),
        updated_at    = NOW()
      WHERE id = ${id}
    `);

    const diffFields: Record<string, { from: any; to: any }> = {};
    const fieldMap: Record<string, { incoming: any; oldVal: any }> = {
      business_name: { incoming: business_name, oldVal: vp.business_name },
      contact_name:  { incoming: contact_name,  oldVal: vp.contact_name },
      phone:         { incoming: phone,          oldVal: vp.phone },
      title:         { incoming: title,          oldVal: vp.title },
      location:      { incoming: location,       oldVal: vp.location },
      description:   { incoming: description,    oldVal: vp.description },
      website:       { incoming: sanitizedWebsite !== undefined ? sanitizedWebsite : undefined, oldVal: vp.website },
      photo_url:     { incoming: sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : undefined, oldVal: vp.photo_url },
      lat:           { incoming: latVal !== null ? String(latVal) : (lat === "" ? null : vp.lat), oldVal: vp.lat !== null ? String(vp.lat) : null },
      lng:           { incoming: lngVal !== null ? String(lngVal) : (lng === "" ? null : vp.lng), oldVal: vp.lng !== null ? String(vp.lng) : null },
    };
    for (const [field, { incoming, oldVal }] of Object.entries(fieldMap)) {
      if (incoming === undefined) continue;
      const newNorm = incoming === null ? null : String(incoming).trim();
      const oldNorm = oldVal === null || oldVal === undefined ? null : String(oldVal).trim();
      if (newNorm !== oldNorm) {
        diffFields[field] = { from: oldNorm, to: newNorm };
      }
    }

    if (Object.keys(diffFields).length > 0) {
      const adminEmail = req.user?.email || "admin";
      await logAudit(adminEmail, "vetted_pro_updated", "vetted_pro", id, JSON.stringify(diffFields));
    }

    if (vp.request_id) {
      await db.execute(sql`
        UPDATE pro_requests SET
          title         = COALESCE(${title ?? null}, title),
          location      = COALESCE(${location ?? null}, location),
          photo_url     = COALESCE(${sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : null}, photo_url),
          website       = COALESCE(${sanitizedWebsite !== undefined ? sanitizedWebsite : null}, website),
          description   = COALESCE(${description ?? null}, description),
          business_name = COALESCE(${business_name ?? null}, business_name),
          contact_name  = COALESCE(${contact_name ?? null}, contact_name),
          phone         = COALESCE(${phone ?? null}, phone),
          updated_at    = NOW()
        WHERE id = ${vp.request_id}
      `);
    }

    const updated = await db.execute(sql`
      SELECT vp.*, pr.email, pr.service_areas, pr.years_experience, pr.license_number,
             pr.admin_notes, pr.claim_code, pr.claimed_by_user_id, pr.status as request_status
      FROM vetted_pros vp
      LEFT JOIN pro_requests pr ON pr.id = vp.request_id
      WHERE vp.id = ${id}
      LIMIT 1
    `);
    res.json({ pro: (updated.rows as any[])[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/pro-requests/:id/relist", requireMasterAdmin, async (req, res) => {
  try {
    await initTables();
    const id = req.params.id;

    const reqResult = await db.execute(sql`SELECT * FROM pro_requests WHERE id = ${id} LIMIT 1`);
    const pr = (reqResult.rows as any[])[0];
    if (!pr) { res.status(404).json({ error: "Pro request not found" }); return; }
    if (pr.status !== "approved") {
      res.status(400).json({ error: "Only approved requests can be re-listed" }); return;
    }

    const existing = await db.execute(sql`SELECT id FROM vetted_pros WHERE request_id = ${id} LIMIT 1`);
    if ((existing.rows as any[]).length > 0) {
      const vettedId = (existing.rows as any[])[0].id;
      await db.execute(sql`
        UPDATE vetted_pros SET
          business_name = ${pr.business_name},
          contact_name  = ${pr.contact_name},
          phone         = ${pr.phone},
          category      = ${pr.category},
          description   = ${pr.description},
          title         = ${pr.title || null},
          location      = ${pr.location || pr.service_areas || null},
          website       = ${pr.website || null},
          photo_url     = ${pr.photo_url || null},
          lat           = ${pr.lat !== null && pr.lat !== undefined ? String(pr.lat) : null},
          lng           = ${pr.lng !== null && pr.lng !== undefined ? String(pr.lng) : null},
          updated_at    = NOW()
        WHERE id = ${vettedId}
      `);
    } else {
      await db.execute(sql`
        INSERT INTO vetted_pros
          (request_id, business_name, contact_name, phone, category, description,
           title, location, website, photo_url, lat, lng)
        VALUES
          (${id}, ${pr.business_name}, ${pr.contact_name}, ${pr.phone},
           ${pr.category}, ${pr.description},
           ${pr.title || null}, ${pr.location || pr.service_areas || null},
           ${pr.website || null}, ${pr.photo_url || null},
           ${pr.lat !== null && pr.lat !== undefined ? String(pr.lat) : null},
           ${pr.lng !== null && pr.lng !== undefined ? String(pr.lng) : null})
      `);
    }

    await db.execute(sql`
      UPDATE pro_requests SET status = 'listed', updated_at = NOW() WHERE id = ${id}
    `);

    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/pro-requests", requireMasterAdmin, async (_req, res) => {
  try {
    await initTables();
    const result = await db.execute(sql`
      SELECT pr.*, vp.id AS vetted_pro_id,
             (
               SELECT al.admin_email
               FROM audit_log al
               WHERE al.target_id = pr.id
                 AND al.action IN ('pro_request_approved', 'pro_request_rejected')
               ORDER BY al.created_at DESC
               LIMIT 1
             ) AS approved_by
      FROM pro_requests pr
      LEFT JOIN vetted_pros vp ON vp.request_id = pr.id
      ORDER BY pr.created_at DESC
    `);
    res.json({ requests: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.patch("/admin/pro-requests/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  try {
    const { status, admin_notes, lat, lng, title, location, photo_url, website } = req.body;
    const id = req.params.id;

    const latVal = lat !== undefined && lat !== "" && !isNaN(Number(lat)) ? Number(lat) : null;
    const lngVal = lng !== undefined && lng !== "" && !isNaN(Number(lng)) ? Number(lng) : null;
    const sanitizedPhotoUrl = photo_url !== undefined ? sanitizeUrl(photo_url) : undefined;
    const sanitizedWebsite = website !== undefined ? sanitizeUrl(website) : undefined;

    if (status !== undefined) {
      await db.execute(sql`
        UPDATE pro_requests SET
          status = ${status},
          admin_notes = COALESCE(${admin_notes ?? null}, admin_notes),
          title = COALESCE(${title ?? null}, title),
          location = COALESCE(${location ?? null}, location),
          photo_url = COALESCE(${sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : null}, photo_url),
          website = COALESCE(${sanitizedWebsite !== undefined ? sanitizedWebsite : null}, website),
          updated_at = NOW()
        WHERE id = ${id}
      `);
      const adminEmail = (req as AuthRequest).user?.email || "admin";
      if (status === "approved" || status === "listed") {
        await logAudit(adminEmail, "pro_request_approved", "pro_request", id, `Status set to ${status}`);
      } else if (status === "rejected") {
        await logAudit(adminEmail, "pro_request_rejected", "pro_request", id, "Application rejected");
      }
    } else {
      await db.execute(sql`
        UPDATE pro_requests SET
          admin_notes = COALESCE(${admin_notes ?? null}, admin_notes),
          title = COALESCE(${title ?? null}, title),
          location = COALESCE(${location ?? null}, location),
          photo_url = COALESCE(${sanitizedPhotoUrl !== undefined ? sanitizedPhotoUrl : null}, photo_url),
          website = COALESCE(${sanitizedWebsite !== undefined ? sanitizedWebsite : null}, website),
          updated_at = NOW()
        WHERE id = ${id}
      `);
    }

    const reqResult = await db.execute(sql`SELECT * FROM pro_requests WHERE id = ${id}`);
    const updated = (reqResult.rows as any[])[0];

    if (updated && (updated.status === "listed" || updated.status === "approved")) {
      const existing = await db.execute(sql`SELECT id FROM vetted_pros WHERE request_id = ${id}`);
      const displayTitle = title ?? updated.title;
      const displayLocation = location ?? updated.location ?? updated.service_areas;

      if ((existing.rows as any[]).length > 0) {
        const vettedId = (existing.rows as any[])[0].id;
        await db.execute(sql`
          UPDATE vetted_pros SET
            business_name = ${updated.business_name},
            contact_name = ${updated.contact_name},
            phone = ${updated.phone},
            category = ${updated.category},
            description = ${updated.description},
            title = ${displayTitle || null},
            location = ${displayLocation || null},
            website = ${updated.website || null},
            photo_url = ${updated.photo_url || null},
            lat = ${latVal !== null ? String(latVal) : null},
            lng = ${lngVal !== null ? String(lngVal) : null},
            updated_at = NOW()
          WHERE id = ${vettedId}
        `);
      } else {
        await db.execute(sql`
          INSERT INTO vetted_pros
            (request_id, business_name, contact_name, phone, category, description,
             title, location, website, photo_url, lat, lng)
          VALUES
            (${id}, ${updated.business_name}, ${updated.contact_name}, ${updated.phone},
             ${updated.category}, ${updated.description},
             ${displayTitle || null}, ${displayLocation || null},
             ${updated.website || null}, ${updated.photo_url || null},
             ${latVal !== null ? String(latVal) : null},
             ${lngVal !== null ? String(lngVal) : null})
        `);
      }
    } else if (updated && updated.status === "rejected") {
      await db.execute(sql`DELETE FROM vetted_pros WHERE request_id = ${id}`);
    }

    res.json({ request: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
