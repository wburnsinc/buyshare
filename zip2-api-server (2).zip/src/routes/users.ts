import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, listingsTable, bookingsTable } from "@workspace/db";
import { eq, or } from "drizzle-orm";

const router = Router();

router.post("/users", async (req, res) => {
  try {
    const { id, email, name, phone, avatarUrl, role } = req.body;
    const existing = await db.select().from(usersTable).where(eq(usersTable.id, id)).limit(1);
    if (existing.length > 0) {
      res.json(existing[0]);
      return;
    }
    const [user] = await db.insert(usersTable).values({ id, email, name, phone, avatarUrl, role: role ?? "both" }).returning();
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.get("/users/:id", async (req, res) => {
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.params.id)).limit(1);
    if (!user) { res.status(404).json({ error: "User not found" }); return; }
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.patch("/users/:id", async (req, res) => {
  try {
    const { name, phone, bio, location, address, hideAddress, avatarUrl, passFeesToRenter } = req.body;
    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (name !== undefined) updates.name = name;
    if (phone !== undefined) updates.phone = phone;
    if (bio !== undefined) updates.bio = bio;
    if (location !== undefined) updates.location = location;
    if (address !== undefined) updates.address = address;
    if (hideAddress !== undefined) updates.hideAddress = hideAddress;
    if (avatarUrl !== undefined) updates.avatarUrl = avatarUrl;
    if (passFeesToRenter !== undefined) updates.passFeesToRenter = passFeesToRenter;
    const [user] = await db.update(usersTable).set(updates).where(eq(usersTable.id, req.params.id)).returning();
    if (!user) { res.status(404).json({ error: "User not found" }); return; }
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.get("/users/:id/listings", async (req, res) => {
  try {
    const listings = await db.select().from(listingsTable).where(eq(listingsTable.ownerId, req.params.id));
    res.json(listings);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.get("/users/:id/bookings", async (req, res) => {
  try {
    const { role } = req.query as { role?: string };
    let rows;
    if (role === "renter") {
      rows = await db.select().from(bookingsTable).where(eq(bookingsTable.renterId, req.params.id));
    } else if (role === "owner") {
      rows = await db.select().from(bookingsTable).where(eq(bookingsTable.ownerId, req.params.id));
    } else {
      rows = await db.select().from(bookingsTable).where(
        or(eq(bookingsTable.renterId, req.params.id), eq(bookingsTable.ownerId, req.params.id))
      );
    }
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

export default router;
