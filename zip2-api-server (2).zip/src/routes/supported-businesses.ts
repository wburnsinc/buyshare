import { Router, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middleware/auth.js";

const router = Router();

async function ensureTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS supported_businesses (
      id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      name        TEXT NOT NULL,
      description TEXT,
      photo_url   TEXT,
      video_url   TEXT,
      website_url TEXT,
      category    TEXT DEFAULT 'General',
      is_active   BOOLEAN DEFAULT true,
      sort_order  INTEGER DEFAULT 0,
      created_at  TIMESTAMP DEFAULT NOW(),
      updated_at  TIMESTAMP DEFAULT NOW()
    )
  `);
}

let ready = false;
async function withTable(fn: () => Promise<void>, res: Response) {
  try {
    if (!ready) { await ensureTable(); ready = true; }
    await fn();
  } catch (err: any) {
    console.error("supported_businesses error:", err);
    res.status(500).json({ error: "Server error" });
  }
}

/* ── PUBLIC ─────────────────────────────────────────────── */

router.get("/api/supported-businesses", async (req: Request, res: Response) => {
  await withTable(async () => {
    const result = await db.execute(sql`
      SELECT * FROM supported_businesses
      WHERE is_active = true
      ORDER BY sort_order ASC, created_at DESC
    `);
    res.json({ businesses: result.rows });
  }, res);
});

/* ── ADMIN ──────────────────────────────────────────────── */

function requireAdmin(req: AuthRequest, res: Response): boolean {
  if (!req.user?.is_admin) {
    res.status(403).json({ error: "Admin only" });
    return false;
  }
  return true;
}

router.get("/api/admin/supported-businesses", requireAuth, async (req: Request, res: Response) => {
  const authReq = req as AuthRequest;
  await withTable(async () => {
    if (!requireAdmin(authReq, res)) return;
    const result = await db.execute(sql`
      SELECT * FROM supported_businesses ORDER BY sort_order ASC, created_at DESC
    `);
    res.json({ businesses: result.rows });
  }, res);
});

router.post("/api/admin/supported-businesses", requireAuth, async (req: Request, res: Response) => {
  const authReq = req as AuthRequest;
  await withTable(async () => {
    if (!requireAdmin(authReq, res)) return;
    const { name, description, photo_url, video_url, website_url, category, sort_order } = req.body;
    if (!name?.trim()) { res.status(400).json({ error: "Name required" }); return; }
    const result = await db.execute(sql`
      INSERT INTO supported_businesses (name, description, photo_url, video_url, website_url, category, sort_order)
      VALUES (${name.trim()}, ${description || null}, ${photo_url || null}, ${video_url || null}, ${website_url || null}, ${category || "General"}, ${sort_order ?? 0})
      RETURNING *
    `);
    res.json({ business: result.rows[0] });
  }, res);
});

router.put("/api/admin/supported-businesses/:id", requireAuth, async (req: Request, res: Response) => {
  const authReq = req as AuthRequest;
  await withTable(async () => {
    if (!requireAdmin(authReq, res)) return;
    const { name, description, photo_url, video_url, website_url, category, is_active, sort_order } = req.body;
    const result = await db.execute(sql`
      UPDATE supported_businesses SET
        name        = COALESCE(${name ?? null}, name),
        description = COALESCE(${description ?? null}, description),
        photo_url   = ${photo_url ?? null},
        video_url   = ${video_url ?? null},
        website_url = ${website_url ?? null},
        category    = COALESCE(${category ?? null}, category),
        is_active   = COALESCE(${is_active ?? null}, is_active),
        sort_order  = COALESCE(${sort_order ?? null}, sort_order),
        updated_at  = NOW()
      WHERE id = ${req.params.id}
      RETURNING *
    `);
    if (!result.rows.length) { res.status(404).json({ error: "Not found" }); return; }
    res.json({ business: result.rows[0] });
  }, res);
});

router.delete("/api/admin/supported-businesses/:id", requireAuth, async (req: Request, res: Response) => {
  const authReq = req as AuthRequest;
  await withTable(async () => {
    if (!requireAdmin(authReq, res)) return;
    await db.execute(sql`DELETE FROM supported_businesses WHERE id = ${req.params.id}`);
    res.json({ success: true });
  }, res);
});

export default router;
