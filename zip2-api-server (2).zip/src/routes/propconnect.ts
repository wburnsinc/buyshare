import { Router } from "express";
import { pool } from "@workspace/db";
import { requireAuth } from "../middleware/auth.js";
import crypto from "crypto";

const router = Router();

export const RE_ROLES = [
  "Realtor / Real Estate Agent",
  "Loan Officer",
  "Mortgage Lender / Broker",
  "Real Estate Investor",
  "Title Company",
  "Home Inspector",
  "Property Manager",
  "Real Estate Attorney",
];

export const RE_REGIONS = ["Southwest Florida (SWFL)", "Central Pennsylvania (PA)"];

export const RE_FORUM_CATS = [
  "Fix & Flip Opportunities",
  "Market Updates",
  "Lending Rates & Products",
  "Testimonials & Success Stories",
  "Investment Tips",
  "For Sale by Agent",
  "General Discussion",
];

export const RE_LISTING_TYPES = [
  "Single Family", "Condo / Townhouse", "Fix & Flip",
  "Multi-Family", "Land / Lot", "Commercial", "Rental Property",
];

async function geocodeAddress(address: string): Promise<{ lat: number; lng: number } | null> {
  const key = process.env.GOOGLE_API_KEY;
  if (!key) return null;
  try {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${key}`;
    const r = await fetch(url);
    const data = await r.json() as any;
    if (data.status === "OK" && data.results?.[0]) {
      const { lat, lng } = data.results[0].geometry.location;
      return { lat, lng };
    }
  } catch {}
  return null;
}

// ── TABLE INIT (also called from ensureAllTables in index.ts) ─────────────────
export async function ensureREtables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS re_profiles (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL,
      company TEXT,
      license_number TEXT,
      nmls_number TEXT,
      phone TEXT NOT NULL,
      email TEXT,
      website TEXT,
      bio TEXT,
      years_experience INTEGER,
      photo_url TEXT,
      business_card_url TEXT,
      region TEXT NOT NULL DEFAULT 'Southwest Florida (SWFL)',
      city TEXT,
      state TEXT,
      zip TEXT,
      address TEXT,
      specialties TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS re_map_pins (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL UNIQUE REFERENCES re_profiles(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      label TEXT,
      address TEXT,
      lat DOUBLE PRECISION NOT NULL,
      lng DOUBLE PRECISION NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS re_listings (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL REFERENCES re_profiles(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      listing_type TEXT NOT NULL,
      price INTEGER,
      address TEXT,
      city TEXT NOT NULL,
      state TEXT NOT NULL,
      zip TEXT,
      beds INTEGER,
      baths NUMERIC(3,1),
      sqft INTEGER,
      mls_number TEXT,
      description TEXT,
      photos JSONB NOT NULL DEFAULT '[]',
      region TEXT NOT NULL DEFAULT 'Southwest Florida (SWFL)',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS re_forum_posts (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      author_name TEXT NOT NULL,
      author_role TEXT,
      category TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      photos JSONB NOT NULL DEFAULT '[]',
      upvotes INTEGER NOT NULL DEFAULT 0,
      comment_count INTEGER NOT NULL DEFAULT 0,
      region TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS re_forum_comments (
      id TEXT PRIMARY KEY,
      post_id TEXT NOT NULL REFERENCES re_forum_posts(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      author_name TEXT NOT NULL,
      author_role TEXT,
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS re_forum_votes (
      post_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      PRIMARY KEY(post_id, user_id)
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS re_reviews (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL REFERENCES re_profiles(id) ON DELETE CASCADE,
      reviewer_user_id TEXT NOT NULL,
      reviewer_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
      comment TEXT,
      transaction_type TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(profile_id, reviewer_user_id)
    )
  `).catch(() => {});
}

ensureREtables();

// ── PROFILES ─────────────────────────────────────────────────────────────────

router.get("/api/propconnect/profiles", async (req, res) => {
  try {
    const { role, region, city, q, limit = 60, offset = 0 } = req.query as Record<string, string>;
    const params: unknown[] = [];
    let pi = 1;
    const where: string[] = ["p.status = 'active'"];

    if (role) { where.push(`p.role = $${pi++}`); params.push(role); }
    if (region) { where.push(`p.region = $${pi++}`); params.push(region); }
    if (city) { where.push(`LOWER(p.city) LIKE LOWER($${pi++})`); params.push(`%${city}%`); }
    if (q) {
      where.push(`(LOWER(p.full_name) LIKE LOWER($${pi}) OR LOWER(p.company) LIKE LOWER($${pi}) OR LOWER(p.bio) LIKE LOWER($${pi}))`);
      params.push(`%${q}%`); pi++;
    }

    params.push(Number(limit), Number(offset));
    const result = await pool.query(`
      SELECT p.*,
        COALESCE((SELECT ROUND(AVG(rating)::numeric,1) FROM re_reviews WHERE profile_id = p.id), 0) AS avg_rating,
        (SELECT COUNT(*)::int FROM re_reviews WHERE profile_id = p.id) AS review_count,
        (SELECT row_to_json(mp) FROM re_map_pins mp WHERE mp.profile_id = p.id) AS map_pin
      FROM re_profiles p
      WHERE ${where.join(" AND ")}
      ORDER BY avg_rating DESC, p.created_at DESC
      LIMIT $${pi++} OFFSET $${pi}
    `, params);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/propconnect/profiles/me", requireAuth, async (req: any, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*,
        COALESCE((SELECT ROUND(AVG(rating)::numeric,1) FROM re_reviews WHERE profile_id = p.id), 0) AS avg_rating,
        (SELECT COUNT(*)::int FROM re_reviews WHERE profile_id = p.id) AS review_count,
        (SELECT row_to_json(mp) FROM re_map_pins mp WHERE mp.profile_id = p.id) AS map_pin
       FROM re_profiles p WHERE p.user_id = $1`,
      [req.user.id]
    );
    res.json(result.rows[0] || null);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/propconnect/profiles/:id", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT p.*,
        COALESCE((SELECT ROUND(AVG(rating)::numeric,1) FROM re_reviews WHERE profile_id = p.id), 0) AS avg_rating,
        (SELECT COUNT(*)::int FROM re_reviews WHERE profile_id = p.id) AS review_count,
        COALESCE(
          (SELECT json_agg(json_build_object(
            'id', r.id, 'reviewer_name', r.reviewer_name, 'rating', r.rating,
            'comment', r.comment, 'transaction_type', r.transaction_type, 'created_at', r.created_at
          ) ORDER BY r.created_at DESC) FROM re_reviews r WHERE r.profile_id = p.id),
          '[]'::json
        ) AS reviews,
        (SELECT row_to_json(mp) FROM re_map_pins mp WHERE mp.profile_id = p.id) AS map_pin
      FROM re_profiles p WHERE p.id = $1
    `, [req.params.id]);
    if (!result.rows.length) return res.status(404).json({ error: "Not found" });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/propconnect/profiles", requireAuth, async (req: any, res) => {
  try {
    const {
      full_name, role, company, license_number, nmls_number, phone, email,
      website, bio, years_experience, photo_url, business_card_url, region,
      city, state, zip, address, specialties,
    } = req.body;

    if (!full_name || !role || !phone) {
      return res.status(400).json({ error: "full_name, role, phone required" });
    }

    const existing = await pool.query("SELECT id FROM re_profiles WHERE user_id = $1", [req.user.id]);
    if (existing.rows.length) {
      return res.status(409).json({ error: "Profile exists", profile_id: existing.rows[0].id });
    }

    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO re_profiles(id,user_id,full_name,role,company,license_number,nmls_number,phone,email,website,bio,years_experience,photo_url,business_card_url,region,city,state,zip,address,specialties,status,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,'active',NOW())
    `, [id, req.user.id, full_name, role, company || null, license_number || null,
       nmls_number || null, phone, email || req.user.email, website || null,
       bio || null, years_experience || null, photo_url || null, business_card_url || null,
       region || "Southwest Florida (SWFL)", city || null, state || null,
       zip || null, address || null, specialties || null]);

    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.patch("/api/propconnect/profiles/:id", requireAuth, async (req: any, res) => {
  try {
    const own = await pool.query("SELECT id FROM re_profiles WHERE id=$1 AND user_id=$2", [req.params.id, req.user.id]);
    if (!own.rows.length) return res.status(403).json({ error: "Not authorized" });

    const {
      full_name, role, company, license_number, nmls_number, phone, email,
      website, bio, years_experience, photo_url, business_card_url, region,
      city, state, zip, address, specialties,
    } = req.body;

    await pool.query(`
      UPDATE re_profiles SET
        full_name=COALESCE($2,full_name), role=COALESCE($3,role), company=COALESCE($4,company),
        license_number=COALESCE($5,license_number), nmls_number=COALESCE($6,nmls_number),
        phone=COALESCE($7,phone), email=COALESCE($8,email), website=COALESCE($9,website),
        bio=COALESCE($10,bio), years_experience=COALESCE($11,years_experience),
        photo_url=COALESCE($12,photo_url), business_card_url=COALESCE($13,business_card_url),
        region=COALESCE($14,region), city=COALESCE($15,city), state=COALESCE($16,state),
        zip=COALESCE($17,zip), address=COALESCE($18,address), specialties=COALESCE($19,specialties),
        updated_at=NOW()
      WHERE id=$1
    `, [req.params.id, full_name, role, company, license_number, nmls_number,
       phone, email, website, bio, years_experience, photo_url, business_card_url,
       region, city, state, zip, address, specialties]);

    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/propconnect/profiles/:id/reviews", requireAuth, async (req: any, res) => {
  try {
    const { rating, comment, transaction_type } = req.body;
    if (!rating || rating < 1 || rating > 5) return res.status(400).json({ error: "rating 1-5 required" });
    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO re_reviews(id,profile_id,reviewer_user_id,reviewer_name,rating,comment,transaction_type,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,NOW())
      ON CONFLICT(profile_id,reviewer_user_id) DO UPDATE SET rating=$5,comment=$6,transaction_type=$7
    `, [id, req.params.id, req.user.id, req.user.full_name || req.user.email,
       rating, comment || null, transaction_type || null]);
    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// ── MAP PINS ─────────────────────────────────────────────────────────────────

router.get("/api/propconnect/pins", async (_req, res) => {
  try {
    const result = await pool.query(`
      SELECT mp.*, p.full_name, p.role, p.company, p.phone, p.photo_url
      FROM re_map_pins mp
      JOIN re_profiles p ON p.id = mp.profile_id
      ORDER BY mp.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/propconnect/pins", requireAuth, async (req: any, res) => {
  try {
    const profile = await pool.query("SELECT id FROM re_profiles WHERE user_id=$1", [req.user.id]);
    if (!profile.rows.length) return res.status(400).json({ error: "Create a profile first" });
    const profileId = profile.rows[0].id;

    const { label, address, lat, lng } = req.body;

    let finalLat = lat;
    let finalLng = lng;

    if ((!lat || !lng) && address) {
      const geo = await geocodeAddress(address);
      if (geo) { finalLat = geo.lat; finalLng = geo.lng; }
    }

    if (!finalLat || !finalLng) return res.status(400).json({ error: "Could not determine coordinates. Provide lat/lng or a valid address." });

    const existing = await pool.query("SELECT id FROM re_map_pins WHERE profile_id=$1", [profileId]);
    if (existing.rows.length) {
      await pool.query("UPDATE re_map_pins SET label=$2,address=$3,lat=$4,lng=$5 WHERE profile_id=$1",
        [profileId, label || null, address || null, finalLat, finalLng]);
      return res.json({ updated: true });
    }

    const id = crypto.randomUUID();
    await pool.query("INSERT INTO re_map_pins(id,profile_id,user_id,label,address,lat,lng,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,NOW())",
      [id, profileId, req.user.id, label || null, address || null, finalLat, finalLng]);
    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/propconnect/pins", requireAuth, async (req: any, res) => {
  try {
    const profile = await pool.query("SELECT id FROM re_profiles WHERE user_id=$1", [req.user.id]);
    if (!profile.rows.length) return res.status(404).json({ error: "No profile" });
    await pool.query("DELETE FROM re_map_pins WHERE profile_id=$1", [profile.rows[0].id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// ── LISTINGS ─────────────────────────────────────────────────────────────────

router.get("/api/propconnect/listings", async (req, res) => {
  try {
    const { listing_type, region, city, min_price, max_price, limit = 50, offset = 0 } = req.query as Record<string, string>;
    const params: unknown[] = [];
    let pi = 1;
    const where: string[] = ["l.status = 'active'"];

    if (listing_type) { where.push(`l.listing_type = $${pi++}`); params.push(listing_type); }
    if (region) { where.push(`l.region = $${pi++}`); params.push(region); }
    if (city) { where.push(`LOWER(l.city) LIKE LOWER($${pi++})`); params.push(`%${city}%`); }
    if (min_price) { where.push(`l.price >= $${pi++}`); params.push(Number(min_price)); }
    if (max_price) { where.push(`l.price <= $${pi++}`); params.push(Number(max_price)); }

    params.push(Number(limit), Number(offset));
    const result = await pool.query(`
      SELECT l.*, p.full_name AS agent_name, p.role AS agent_role, p.phone AS agent_phone,
        p.company AS agent_company, p.photo_url AS agent_photo
      FROM re_listings l
      JOIN re_profiles p ON p.id = l.profile_id
      WHERE ${where.join(" AND ")}
      ORDER BY l.created_at DESC
      LIMIT $${pi++} OFFSET $${pi}
    `, params);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/propconnect/listings/:id", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT l.*, p.full_name AS agent_name, p.role AS agent_role, p.phone AS agent_phone,
        p.email AS agent_email, p.company AS agent_company, p.photo_url AS agent_photo,
        p.id AS agent_profile_id
      FROM re_listings l
      JOIN re_profiles p ON p.id = l.profile_id
      WHERE l.id = $1
    `, [req.params.id]);
    if (!result.rows.length) return res.status(404).json({ error: "Not found" });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/propconnect/listings", requireAuth, async (req: any, res) => {
  try {
    const profile = await pool.query("SELECT id FROM re_profiles WHERE user_id=$1", [req.user.id]);
    if (!profile.rows.length) return res.status(400).json({ error: "Create a profile first" });

    const { title, listing_type, price, address, city, state, zip, beds, baths,
            sqft, mls_number, description, photos = [], region } = req.body;

    if (!title || !listing_type || !city || !state) {
      return res.status(400).json({ error: "title, listing_type, city, state required" });
    }

    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO re_listings(id,profile_id,user_id,title,listing_type,price,address,city,state,zip,beds,baths,sqft,mls_number,description,photos,region,status,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,'active',NOW())
    `, [id, profile.rows[0].id, req.user.id, title, listing_type, price || null,
       address || null, city, state, zip || null, beds || null, baths || null,
       sqft || null, mls_number || null, description || null,
       JSON.stringify(photos), region || "Southwest Florida (SWFL)"]);

    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.patch("/api/propconnect/listings/:id", requireAuth, async (req: any, res) => {
  try {
    const own = await pool.query("SELECT id FROM re_listings WHERE id=$1 AND user_id=$2", [req.params.id, req.user.id]);
    if (!own.rows.length) return res.status(403).json({ error: "Not authorized" });
    const { status, price, description, photos } = req.body;
    await pool.query(
      "UPDATE re_listings SET status=COALESCE($2,status),price=COALESCE($3,price),description=COALESCE($4,description),photos=COALESCE($5::jsonb,photos) WHERE id=$1",
      [req.params.id, status, price, description, photos ? JSON.stringify(photos) : null]
    );
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/propconnect/listings/:id", requireAuth, async (req: any, res) => {
  try {
    await pool.query("DELETE FROM re_listings WHERE id=$1 AND user_id=$2", [req.params.id, (req as any).user.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// ── FORUM ─────────────────────────────────────────────────────────────────────

router.get("/api/propconnect/forum", async (req, res) => {
  try {
    const { category, region, limit = 50, offset = 0 } = req.query as Record<string, string>;
    const params: unknown[] = [];
    let pi = 1;
    const where: string[] = [];

    if (category) { where.push(`category = $${pi++}`); params.push(category); }
    if (region) { where.push(`(region = $${pi} OR region IS NULL)`); params.push(region); pi++; }

    const wc = where.length ? `WHERE ${where.join(" AND ")}` : "";
    params.push(Number(limit), Number(offset));
    const result = await pool.query(
      `SELECT * FROM re_forum_posts ${wc} ORDER BY created_at DESC LIMIT $${pi++} OFFSET $${pi}`,
      params
    );
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/propconnect/forum/:id", async (req, res) => {
  try {
    const post = await pool.query("SELECT * FROM re_forum_posts WHERE id=$1", [req.params.id]);
    if (!post.rows.length) return res.status(404).json({ error: "Not found" });
    const comments = await pool.query(
      "SELECT * FROM re_forum_comments WHERE post_id=$1 ORDER BY created_at ASC",
      [req.params.id]
    );
    res.json({ ...post.rows[0], comments: comments.rows });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/propconnect/forum", requireAuth, async (req: any, res) => {
  try {
    const { title, body, category, photos = [], region } = req.body;
    if (!title || !body || !category) return res.status(400).json({ error: "title, body, category required" });

    const profile = await pool.query("SELECT role FROM re_profiles WHERE user_id=$1", [req.user.id]);
    const role = profile.rows[0]?.role || null;

    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO re_forum_posts(id,user_id,author_name,author_role,category,title,body,photos,upvotes,comment_count,region,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,0,0,$9,NOW())
    `, [id, req.user.id, req.user.full_name || req.user.email, role, category,
       title, body, JSON.stringify(photos), region || null]);

    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/propconnect/forum/:id/vote", requireAuth, async (req: any, res) => {
  try {
    const existing = await pool.query(
      "SELECT 1 FROM re_forum_votes WHERE post_id=$1 AND user_id=$2",
      [req.params.id, req.user.id]
    );
    if (existing.rows.length) {
      await pool.query("DELETE FROM re_forum_votes WHERE post_id=$1 AND user_id=$2", [req.params.id, req.user.id]);
      await pool.query("UPDATE re_forum_posts SET upvotes = GREATEST(0, upvotes - 1) WHERE id=$1", [req.params.id]);
      return res.json({ voted: false });
    }
    await pool.query("INSERT INTO re_forum_votes VALUES($1,$2) ON CONFLICT DO NOTHING", [req.params.id, req.user.id]);
    await pool.query("UPDATE re_forum_posts SET upvotes = upvotes + 1 WHERE id=$1", [req.params.id]);
    res.json({ voted: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/propconnect/forum/:id/comments", requireAuth, async (req: any, res) => {
  try {
    const { body } = req.body;
    if (!body?.trim()) return res.status(400).json({ error: "body required" });
    const profile = await pool.query("SELECT role FROM re_profiles WHERE user_id=$1", [req.user.id]);
    const role = profile.rows[0]?.role || null;
    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO re_forum_comments(id,post_id,user_id,author_name,author_role,body,created_at)
      VALUES($1,$2,$3,$4,$5,$6,NOW())
    `, [id, req.params.id, req.user.id, req.user.full_name || req.user.email, role, body]);
    await pool.query("UPDATE re_forum_posts SET comment_count = comment_count + 1 WHERE id=$1", [req.params.id]);
    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

export default router;
