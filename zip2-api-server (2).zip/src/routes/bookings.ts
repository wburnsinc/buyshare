import { Router } from "express";
import { db } from "@workspace/db";
import { bookingsTable, listingsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { stripe, calculateSplit, getRentalDays } from "../lib/stripe.js";
import { requireAuth, type AuthRequest } from "../middleware/auth.js";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";

const router = Router();

const uploadDir = "./public/uploads/proofs";
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, _file, cb) => cb(null, `${req.params.id}-${Date.now()}-${randomUUID().slice(0, 6)}${path.extname(_file.originalname)}`),
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

// GET listing+owner helper
async function getListingWithOwner(listingId: string) {
  const [row] = await db
    .select({ listing: listingsTable, owner: usersTable })
    .from(listingsTable)
    .leftJoin(usersTable, eq(listingsTable.ownerId, usersTable.id))
    .where(eq(listingsTable.id, listingId))
    .limit(1);
  return row;
}

// Calculate booking costs
router.post("/bookings/calculate", async (req, res) => {
  try {
    const { listingId, startDate, endDate, addProtection, deliveryRequested } = req.body;
    const row = await getListingWithOwner(listingId);
    if (!row) { res.status(404).json({ error: "Listing not found" }); return; }

    const { listing, owner } = row;
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = getRentalDays(start, end);

    let rentalCents: number;
    if (days >= 7 && listing.weeklyRate) {
      rentalCents = listing.weeklyRate * Math.ceil(days / 7);
    } else if (days === 2 && listing.weekendRate) {
      rentalCents = listing.weekendRate;
    } else {
      rentalCents = listing.dailyRate * days;
    }

    const deliveryFeeCents = deliveryRequested && listing.deliveryFee ? listing.deliveryFee : 0;
    const passFees = owner?.passFeesToRenter ?? true;

    const split = calculateSplit({
      rentalCents,
      depositCents: listing.securityDeposit ?? 0,
      addProtection: addProtection ?? false,
      passFeesToRenter: passFees,
      deliveryFeeCents,
    });

    res.json({ rentalDays: days, ...split });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Create Stripe PaymentIntent + booking record
router.post("/bookings/checkout", async (req, res) => {
  try {
    const { listingId, renterId, startDate, endDate, addProtection, deliveryRequested, renterNotes } = req.body;

    const row = await getListingWithOwner(listingId);
    if (!row) { res.status(404).json({ error: "Listing not found" }); return; }
    const { listing, owner } = row;

    if (!owner?.stripeAccountId) {
      res.status(400).json({ error: "Owner has not completed Stripe Connect onboarding. They cannot accept payments yet." });
      return;
    }
    if (listing.status !== "available") {
      res.status(400).json({ error: "This item is not currently available for rental" });
      return;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = getRentalDays(start, end);

    let rentalCents: number;
    if (days >= 7 && listing.weeklyRate) {
      rentalCents = listing.weeklyRate * Math.ceil(days / 7);
    } else if (days === 2 && listing.weekendRate) {
      rentalCents = listing.weekendRate;
    } else {
      rentalCents = listing.dailyRate * days;
    }

    const deliveryFeeCents = deliveryRequested && listing.deliveryFee ? listing.deliveryFee : 0;
    const passFees = owner.passFeesToRenter ?? true;

    const split = calculateSplit({
      rentalCents,
      depositCents: listing.securityDeposit ?? 0,
      addProtection: addProtection ?? false,
      passFeesToRenter: passFees,
      deliveryFeeCents,
    });

    const bookingId = randomUUID();

    const paymentIntent = await stripe.paymentIntents.create({
      amount: split.totalChargeCents,
      currency: "usd",
      application_fee_amount: split.platformFeeCents,
      transfer_data: {
        destination: owner.stripeAccountId,
      },
      metadata: {
        bookingId,
        listingId,
        renterId,
        ownerId: owner.id,
        rentalDays: String(days),
        depositCents: String(split.depositCents),
      },
      description: `Buyshare rental: ${listing.title} (${days} day${days !== 1 ? "s" : ""})`,
    });

    const [booking] = await db
      .insert(bookingsTable)
      .values({
        id: bookingId,
        renterId,
        listingId,
        ownerId: owner.id,
        status: "pending",
        startDate: start,
        endDate: end,
        totalDays: days,
        rentalAmountCents: split.rentalCents,
        securityDepositCents: split.depositCents,
        platformFeeCents: split.platformFeeCents,
        stripeFeesCents: split.stripeFeesCents,
        protectionFeeCents: split.protectionFeeCents,
        deliveryFeeCents: split.deliveryFeeCents,
        totalChargeCents: split.totalChargeCents,
        ownerPayoutCents: split.ownerPayoutCents,
        addedProtection: addProtection ?? false,
        deliveryRequested: deliveryRequested ?? false,
        stripePaymentIntentId: paymentIntent.id,
        renterNotes,
      })
      .returning();

    res.json({
      clientSecret: paymentIntent.client_secret,
      bookingId,
      totalChargeCents: split.totalChargeCents,
      calculation: { rentalDays: days, ...split },
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Get booking by ID with details
router.get("/bookings/:id", async (req, res) => {
  try {
    const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, req.params.id)).limit(1);
    if (!booking) { res.status(404).json({ error: "Booking not found" }); return; }

    const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, booking.listingId)).limit(1);
    const [renter] = await db.select().from(usersTable).where(eq(usersTable.id, booking.renterId)).limit(1);
    const [owner] = await db.select().from(usersTable).where(eq(usersTable.id, booking.ownerId)).limit(1);

    res.json({ ...booking, listing, renter, owner });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Upload proof photos (check-in or check-out)
router.post("/bookings/:id/proof/:type", upload.array("photos", 10), async (req, res) => {
  try {
    const { id, type } = req.params;
    if (!["checkin", "checkout"].includes(type)) {
      res.status(400).json({ error: "Type must be checkin or checkout" }); return;
    }
    if (!req.files || !Array.isArray(req.files) || req.files.length < 3) {
      res.status(400).json({ error: "Minimum of 3 photos required" }); return;
    }

    const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, id)).limit(1);
    if (!booking) { res.status(404).json({ error: "Booking not found" }); return; }

    const urls = (req.files as Express.Multer.File[]).map((f) => `/uploads/proofs/${f.filename}`);

    let updates: Record<string, unknown>;
    let newStatus: string;

    if (type === "checkin") {
      newStatus = "active";
      updates = { checkInPhotos: urls, checkInTimestamp: new Date(), status: "active", updatedAt: new Date() };
      // mark listing as rented
      await db.update(listingsTable).set({ status: "rented", updatedAt: new Date() }).where(eq(listingsTable.id, booking.listingId));
    } else {
      newStatus = "completed";
      updates = { checkOutPhotos: urls, checkOutTimestamp: new Date(), status: "completed", updatedAt: new Date() };
    }

    await db.update(bookingsTable).set(updates).where(eq(bookingsTable.id, id));
    res.json({ success: true, urls, newStatus });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Release security deposit back to renter
router.post("/bookings/:id/release-deposit", async (req, res) => {
  try {
    const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, req.params.id)).limit(1);
    if (!booking) { res.status(404).json({ error: "Booking not found" }); return; }
    if (booking.depositReleased) { res.status(400).json({ error: "Deposit already released" }); return; }
    if (!booking.stripePaymentIntentId) { res.status(400).json({ error: "No payment found" }); return; }
    if (booking.securityDepositCents === 0) { res.status(400).json({ error: "No deposit to release" }); return; }

    const pi = await stripe.paymentIntents.retrieve(booking.stripePaymentIntentId);
    const chargeId = typeof pi.latest_charge === "string" ? pi.latest_charge : pi.latest_charge?.id;
    if (!chargeId) { res.status(400).json({ error: "No charge found on payment intent" }); return; }

    const refund = await stripe.refunds.create({
      charge: chargeId,
      amount: booking.securityDepositCents,
      reason: "requested_by_customer",
      metadata: { bookingId: booking.id, type: "security_deposit_release" },
    });

    await db
      .update(bookingsTable)
      .set({ depositReleased: true, depositRefundId: refund.id, updatedAt: new Date() })
      .where(eq(bookingsTable.id, req.params.id));

    res.json({ success: true, refundId: refund.id, amountCents: booking.securityDepositCents });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Raise a dispute
router.post("/bookings/:id/dispute", async (req, res) => {
  try {
    const { reason } = req.body;
    const [booking] = await db
      .update(bookingsTable)
      .set({ status: "disputed", disputeReason: reason, updatedAt: new Date() })
      .where(eq(bookingsTable.id, req.params.id))
      .returning();
    if (!booking) { res.status(404).json({ error: "Booking not found" }); return; }

    const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, booking.listingId)).limit(1);
    const [renter] = await db.select().from(usersTable).where(eq(usersTable.id, booking.renterId)).limit(1);
    const [owner] = await db.select().from(usersTable).where(eq(usersTable.id, booking.ownerId)).limit(1);
    res.json({ ...booking, listing, renter, owner });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Create Stripe Checkout Session for mobile handoff (auth required — renterId derived from token)
router.post("/bookings/stripe-checkout", requireAuth, async (req: AuthRequest, res) => {
  try {
    const {
      listingId,
      startDate,
      endDate,
      addProtection,
      deliveryRequested,
      renterNotes,
      successUrl,
      cancelUrl,
    } = req.body;

    const renterId: string = req.user!.id;

    if (!listingId || !startDate || !endDate) {
      res.status(400).json({ error: "listingId, startDate and endDate are required" });
      return;
    }

    const row = await getListingWithOwner(listingId);
    if (!row) { res.status(404).json({ error: "Listing not found" }); return; }
    const { listing, owner } = row;

    // Stripe Connect is optional — if owner has a connected account, funds transfer to them;
    // otherwise Buyshare collects the full payment and pays the owner manually.
    const hasConnect = !!(owner?.stripeAccountId);

    if (listing.status !== "available") {
      res.status(400).json({ error: "This item is not currently available for rental" });
      return;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = getRentalDays(start, end);

    let rentalCents: number;
    if (days >= 7 && listing.weeklyRate) {
      rentalCents = listing.weeklyRate * Math.ceil(days / 7);
    } else if (days === 2 && listing.weekendRate) {
      rentalCents = listing.weekendRate;
    } else {
      rentalCents = listing.dailyRate * days;
    }

    const deliveryFeeCents = deliveryRequested && listing.deliveryFee ? listing.deliveryFee : 0;
    const passFees = owner?.passFeesToRenter ?? true;

    const split = calculateSplit({
      rentalCents,
      depositCents: listing.securityDeposit ?? 0,
      addProtection: addProtection ?? false,
      passFeesToRenter: passFees,
      deliveryFeeCents,
    });

    const bookingId = randomUUID();

    const lineItems: import("stripe").Stripe.Checkout.SessionCreateParams.LineItem[] = [
      {
        price_data: {
          currency: "usd",
          product_data: {
            name: `${listing.title} — ${days} day${days !== 1 ? "s" : ""} rental`,
            description: `${start.toLocaleDateString()} to ${end.toLocaleDateString()}`,
          },
          unit_amount: split.rentalCents,
        },
        quantity: 1,
      },
    ];

    if (split.depositCents > 0) {
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: { name: "Security Deposit (held in escrow, refundable)" },
          unit_amount: split.depositCents,
        },
        quantity: 1,
      });
    }

    if (split.protectionFeeCents > 0) {
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: { name: "Buyshare Protection" },
          unit_amount: split.protectionFeeCents,
        },
        quantity: 1,
      });
    }

    if (split.deliveryFeeCents > 0) {
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: { name: "Delivery Fee" },
          unit_amount: split.deliveryFeeCents,
        },
        quantity: 1,
      });
    }

    if (split.stripeFeesCents > 0) {
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: { name: "Processing Fee" },
          unit_amount: split.stripeFeesCents,
        },
        quantity: 1,
      });
    }

    // successUrl/cancelUrl from web clients may contain {BOOKING_ID} placeholder
    const finalSuccessUrl = successUrl
      ? successUrl.replace("{BOOKING_ID}", bookingId)
      : `buyshare-mobile://booking-confirm?bookingId=${bookingId}&status=success`;
    const finalCancelUrl = cancelUrl
      ? cancelUrl.replace("{BOOKING_ID}", bookingId)
      : `buyshare-mobile://booking-confirm?bookingId=${bookingId}&status=cancel`;

    const paymentIntentData: import("stripe").Stripe.Checkout.SessionCreateParams.PaymentIntentData = {
      metadata: { bookingId, listingId, renterId, ownerId: owner?.id ?? "" },
    };
    if (hasConnect) {
      paymentIntentData.application_fee_amount = split.platformFeeCents;
      paymentIntentData.transfer_data = { destination: owner!.stripeAccountId! };
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: "payment",
      success_url: finalSuccessUrl,
      cancel_url: finalCancelUrl,
      payment_intent_data: paymentIntentData,
      metadata: { bookingId, listingId, renterId },
    });

    // stripePaymentIntentId is intentionally left null here — the checkout session ID
    // (cs_...) is stored in Stripe metadata. A webhook on checkout.session.completed
    // should update this booking with the real PaymentIntent ID (pi_...) and advance
    // status to "confirmed". The cancel endpoint handles abandoned checkouts.
    const [booking] = await db
      .insert(bookingsTable)
      .values({
        id: bookingId,
        renterId,
        listingId,
        ownerId: owner.id,
        status: "pending",
        startDate: start,
        endDate: end,
        totalDays: days,
        rentalAmountCents: split.rentalCents,
        securityDepositCents: split.depositCents,
        platformFeeCents: split.platformFeeCents,
        stripeFeesCents: split.stripeFeesCents,
        protectionFeeCents: split.protectionFeeCents,
        deliveryFeeCents: split.deliveryFeeCents,
        totalChargeCents: split.totalChargeCents,
        ownerPayoutCents: split.ownerPayoutCents,
        addedProtection: addProtection ?? false,
        deliveryRequested: deliveryRequested ?? false,
        renterNotes,
      })
      .returning();

    res.json({
      checkoutUrl: session.url,
      bookingId: booking.id,
      calculation: { rentalDays: days, ...split },
    });

    // Fire-and-forget: admin alert for new booking/rental
    const _apiKey = process.env.RESEND_API_KEY;
    if (_apiKey) {
      const _from = process.env.RESEND_FROM_EMAIL
        ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
        : "Buyshare <onboarding@resend.dev>";
      const totalDollars = (split.totalChargeCents / 100).toFixed(2);
      const platformDollars = (split.platformFeeCents / 100).toFixed(2);
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: _from,
          to: ["burnsinc@outlook.com", "admin@buyshare.co"],
          subject: `📦 New rental booking — $${totalDollars} · ${listing.title}`,
          html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px">
            <h2 style="color:#0369a1">New Rental Booking</h2>
            <table style="border-collapse:collapse;width:100%">
              <tr><td style="padding:6px 0;font-weight:600;width:140px">Listing</td><td>${listing.title}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Listing ID</td><td style="font-size:12px;color:#6b7280">${listingId}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Renter ID</td><td style="font-size:12px;color:#6b7280">${renterId}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Dates</td><td>${start.toDateString()} → ${end.toDateString()} (${days}d)</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Total Charge</td><td><strong>$${totalDollars}</strong></td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Platform Fee</td><td>$${platformDollars}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Booking ID</td><td style="font-size:12px;color:#6b7280">${bookingId}</td></tr>
            </table>
            <a href="https://buyshare.co/admin/bookings" style="display:inline-block;background:#0369a1;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;margin-top:16px">View Bookings</a>
          </div>`,
        }),
      }).catch(() => {});
    }
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Cancel a pending booking (renter can abort an abandoned checkout session)
router.post("/bookings/:id/cancel", requireAuth, async (req: AuthRequest, res) => {
  try {
    const [booking] = await db
      .select()
      .from(bookingsTable)
      .where(eq(bookingsTable.id, req.params.id))
      .limit(1);

    if (!booking) { res.status(404).json({ error: "Booking not found" }); return; }

    if (booking.renterId !== req.user!.id) {
      res.status(403).json({ error: "Only the renter can cancel this booking" });
      return;
    }

    if (!["pending"].includes(booking.status)) {
      res.status(400).json({ error: `Cannot cancel a booking with status "${booking.status}"` });
      return;
    }

    const [updated] = await db
      .update(bookingsTable)
      .set({ status: "cancelled", updatedAt: new Date() })
      .where(eq(bookingsTable.id, req.params.id))
      .returning();

    res.json({ success: true, bookingId: updated.id, status: updated.status });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

export default router;
