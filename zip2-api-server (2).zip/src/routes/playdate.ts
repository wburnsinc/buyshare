import { Router } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { requireMasterAdmin, requireAuth, AuthRequest } from "../middleware/auth.js";
import nodemailer from "nodemailer";

const router = Router();

async function ensureTables() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS meetups (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      location TEXT NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      description TEXT,
      host_name TEXT NOT NULL,
      contact TEXT,
      category TEXT DEFAULT 'general',
      max_attendees INTEGER DEFAULT 20,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS meetup_rsvps (
      id TEXT PRIMARY KEY,
      meetup_id TEXT NOT NULL REFERENCES meetups(id) ON DELETE CASCADE,
      first_name TEXT NOT NULL,
      last_initial TEXT NOT NULL,
      contact TEXT NOT NULL,
      num_children INTEGER NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    ALTER TABLE meetups ADD COLUMN IF NOT EXISTS host_code TEXT
  `);
  await db.execute(sql`
    ALTER TABLE meetup_rsvps ADD COLUMN IF NOT EXISTS reminded_at TIMESTAMP
  `);
  await db.execute(sql`
    ALTER TABLE meetups ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active'
  `);
  await db.execute(sql`
    ALTER TABLE meetup_rsvps ADD COLUMN IF NOT EXISTS emailed_at TIMESTAMP
  `);
  await db.execute(sql`
    ALTER TABLE meetup_rsvps ADD COLUMN IF NOT EXISTS emailed_type TEXT
  `);
  await db.execute(sql`ALTER TABLE meetups ADD COLUMN IF NOT EXISTS lat FLOAT`);
  await db.execute(sql`ALTER TABLE meetups ADD COLUMN IF NOT EXISTS lng FLOAT`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS meetup_comments (
      id TEXT PRIMARY KEY,
      meetup_id TEXT NOT NULL REFERENCES meetups(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      user_name TEXT NOT NULL,
      user_initials TEXT NOT NULL DEFAULT '',
      body TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
}

async function geocodeLocation(location: string): Promise<{ lat: number; lng: number } | null> {
  try {
    const apiKey = process.env.GOOGLE_API_KEY;
    if (!apiKey) return null;
    const q = encodeURIComponent(location + ", Southwest Florida, FL");
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${q}&key=${apiKey}`;
    const r = await fetch(url);
    const d = await r.json();
    if (d.status === "OK" && d.results?.length > 0) {
      const loc = d.results[0].geometry.location;
      return { lat: loc.lat, lng: loc.lng };
    }
    return null;
  } catch { return null; }
}

let ready = false;
async function withDB(fn: () => Promise<void>, res: any) {
  try {
    if (!ready) { await ensureTables(); ready = true; }
    await fn();
  } catch (err: any) {
    console.error("playdate error:", err);
    res.status(500).json({ error: err.message || "Server error" });
  }
}

function isEmail(contact: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.trim());
}

function getTransport() {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!host || !user || !pass) return null;
  return nodemailer.createTransport({
    host,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user, pass },
  });
}

async function sendEmail(to: string, subject: string, html: string): Promise<boolean> {
  const transport = getTransport();
  if (!transport) {
    console.log(`[playdate] Email skipped (no SMTP config). To: ${to} — ${subject}`);
    return false;
  }
  try {
    await transport.sendMail({
      from: process.env.SMTP_FROM || "noreply@buyshare.co",
      to,
      subject,
      html,
    });
    console.log(`[playdate] Email sent. To: ${to} — ${subject}`);
    return true;
  } catch (err) {
    console.error("[playdate] Email error:", err);
    return false;
  }
}

function formatDate(dateStr: string): string {
  const [year, month, day] = dateStr.split("-").map(Number);
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
}

function confirmationHtml(firstName: string, meetup: any): string {
  return `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#1a1a1a">
      <div style="background:#4f46e5;border-radius:12px 12px 0 0;padding:24px;text-align:center">
        <h1 style="margin:0;color:#fff;font-size:22px">🎉 You're In!</h1>
        <p style="margin:8px 0 0;color:#c7d2fe;font-size:14px">RSVP Confirmed</p>
      </div>
      <div style="background:#f9fafb;border-radius:0 0 12px 12px;padding:28px">
        <p style="margin:0 0 16px">Hi <strong>${firstName}</strong>, your spot is saved!</p>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:20px">
          <h2 style="margin:0 0 14px;font-size:18px;color:#111827">${meetup.title}</h2>
          <table style="border-collapse:collapse;width:100%">
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📅 Date</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${formatDate(meetup.date)}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">🕐 Time</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.time}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📍 Location</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.location}</td>
            </tr>
            ${meetup.description ? `
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;vertical-align:top;white-space:nowrap">📝 Details</td>
              <td style="padding:6px 0;font-size:14px">${meetup.description}</td>
            </tr>` : ""}
          </table>
        </div>
        <p style="margin:0 0 8px;font-size:13px;color:#6b7280">
          We're excited to see you there. If something comes up and you can't make it, please let the organiser know.
        </p>
        <p style="margin:0;font-size:13px;color:#6b7280">— The Buyshare Team</p>
      </div>
    </div>
  `;
}

function cancellationHtml(firstName: string, meetup: any): string {
  return `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#1a1a1a">
      <div style="background:#dc2626;border-radius:12px 12px 0 0;padding:24px;text-align:center">
        <h1 style="margin:0;color:#fff;font-size:22px">❌ Meetup Cancelled</h1>
        <p style="margin:8px 0 0;color:#fecaca;font-size:14px">We're sorry — this one won't be happening</p>
      </div>
      <div style="background:#f9fafb;border-radius:0 0 12px 12px;padding:28px">
        <p style="margin:0 0 16px">Hi <strong>${firstName}</strong>, unfortunately the meetup you RSVP'd to has been cancelled by the host.</p>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:20px">
          <h2 style="margin:0 0 14px;font-size:18px;color:#111827;text-decoration:line-through;color:#9ca3af">${meetup.title}</h2>
          <table style="border-collapse:collapse;width:100%">
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📅 Date</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600;color:#6b7280">${formatDate(meetup.date)}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📍 Location</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600;color:#6b7280">${meetup.location}</td>
            </tr>
          </table>
        </div>
        <p style="margin:0 0 16px;font-size:13px;color:#6b7280">
          No action is needed on your part. Keep an eye on the PLAYDATE board for other upcoming family meetups in your area!
        </p>
        <a href="https://buyshare.co/playdate" style="display:inline-block;background:#f59e0b;color:#fff;font-weight:700;padding:12px 24px;border-radius:8px;text-decoration:none;font-size:14px">Browse Other Meetups</a>
        <p style="margin:20px 0 0;font-size:13px;color:#6b7280">— The Buyshare Team</p>
      </div>
    </div>
  `;
}

function reopenHtml(firstName: string, meetup: any): string {
  return `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#1a1a1a">
      <div style="background:#059669;border-radius:12px 12px 0 0;padding:24px;text-align:center">
        <h1 style="margin:0;color:#fff;font-size:22px">🎉 Great News — It's Back On!</h1>
        <p style="margin:8px 0 0;color:#a7f3d0;font-size:14px">Sign-ups are open again</p>
      </div>
      <div style="background:#f9fafb;border-radius:0 0 12px 12px;padding:28px">
        <p style="margin:0 0 16px">Hi <strong>${firstName}</strong>, the meetup you previously RSVP'd to has been reopened by the host — you're still on the list!</p>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:20px">
          <h2 style="margin:0 0 14px;font-size:18px;color:#111827">${meetup.title}</h2>
          <table style="border-collapse:collapse;width:100%">
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📅 Date</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${formatDate(meetup.date)}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">🕐 Time</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.time}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📍 Location</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.location}</td>
            </tr>
            ${meetup.description ? `
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;vertical-align:top;white-space:nowrap">📝 Details</td>
              <td style="padding:6px 0;font-size:14px">${meetup.description}</td>
            </tr>` : ""}
          </table>
        </div>
        <p style="margin:0 0 8px;font-size:13px;color:#6b7280">
          We're looking forward to seeing you. If plans have changed on your end, please let the host know.
        </p>
        <p style="margin:0;font-size:13px;color:#6b7280">— The Buyshare Team</p>
      </div>
    </div>
  `;
}

function updateAlertHtml(firstName: string, meetup: any, changes: { field: string; old: string; new: string }[]): string {
  const changeRows = changes.map(c => `
    <tr>
      <td style="padding:8px 12px 8px 0;color:#6b7280;font-size:14px;white-space:nowrap;vertical-align:top">${c.field}</td>
      <td style="padding:8px 0;font-size:14px">
        <span style="text-decoration:line-through;color:#9ca3af">${c.old}</span>
        <span style="margin:0 6px;color:#d97706">→</span>
        <span style="font-weight:700;color:#111827">${c.new}</span>
      </td>
    </tr>
  `).join("");
  return `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#1a1a1a">
      <div style="background:#d97706;border-radius:12px 12px 0 0;padding:24px;text-align:center">
        <h1 style="margin:0;color:#fff;font-size:22px">⚠️ Meetup Update</h1>
        <p style="margin:8px 0 0;color:#fef3c7;font-size:14px">Details have changed — please take note</p>
      </div>
      <div style="background:#f9fafb;border-radius:0 0 12px 12px;padding:28px">
        <p style="margin:0 0 16px">Hi <strong>${firstName}</strong>, the host has updated the details for a meetup you RSVP'd to.</p>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:20px">
          <h2 style="margin:0 0 14px;font-size:18px;color:#111827">${meetup.title}</h2>
          <p style="margin:0 0 12px;font-size:13px;font-weight:600;color:#d97706;text-transform:uppercase;letter-spacing:0.05em">What changed:</p>
          <table style="border-collapse:collapse;width:100%">
            ${changeRows}
          </table>
        </div>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:20px">
          <p style="margin:0 0 10px;font-size:13px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.05em">Updated details:</p>
          <table style="border-collapse:collapse;width:100%">
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📅 Date</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${formatDate(meetup.date)}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">🕐 Time</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.time}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📍 Location</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.location}</td>
            </tr>
          </table>
        </div>
        <p style="margin:0 0 8px;font-size:13px;color:#6b7280">
          If these new details don't work for you, please let the host know as soon as possible.
        </p>
        <p style="margin:0;font-size:13px;color:#6b7280">— The Buyshare Team</p>
      </div>
    </div>
  `;
}

function reminderHtml(firstName: string, meetup: any): string {
  return `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#1a1a1a">
      <div style="background:#059669;border-radius:12px 12px 0 0;padding:24px;text-align:center">
        <h1 style="margin:0;color:#fff;font-size:22px">⏰ Reminder: Meetup Tomorrow!</h1>
        <p style="margin:8px 0 0;color:#a7f3d0;font-size:14px">Don't forget — see you there!</p>
      </div>
      <div style="background:#f9fafb;border-radius:0 0 12px 12px;padding:28px">
        <p style="margin:0 0 16px">Hi <strong>${firstName}</strong>, just a friendly heads-up that your meetup is tomorrow.</p>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:20px">
          <h2 style="margin:0 0 14px;font-size:18px;color:#111827">${meetup.title}</h2>
          <table style="border-collapse:collapse;width:100%">
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📅 Date</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${formatDate(meetup.date)}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">🕐 Time</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.time}</td>
            </tr>
            <tr>
              <td style="padding:6px 12px 6px 0;color:#6b7280;font-size:14px;white-space:nowrap">📍 Location</td>
              <td style="padding:6px 0;font-size:14px;font-weight:600">${meetup.location}</td>
            </tr>
          </table>
        </div>
        <p style="margin:0;font-size:13px;color:#6b7280">— The Buyshare Team</p>
      </div>
    </div>
  `;
}

export async function runReminderJob() {
  try {
    if (!ready) { await ensureTables(); ready = true; }

    const now = new Date();
    const windowStart = new Date(now.getTime() + 23 * 60 * 60 * 1000);
    const windowEnd = new Date(now.getTime() + 25 * 60 * 60 * 1000);

    const result = await db.execute(sql`
      SELECT r.id, r.first_name, r.contact,
             m.title, m.date, m.time, m.location, m.description
      FROM meetup_rsvps r
      JOIN meetups m ON r.meetup_id = m.id
      WHERE r.reminded_at IS NULL
        AND r.contact ~ '^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$'
    `);

    const candidates = result.rows as any[];

    for (const rsvp of candidates) {
      const [year, month, day] = rsvp.date.split("-").map(Number);
      let hour = 0;
      let minute = 0;
      const timeMatch = String(rsvp.time).match(/(\d+):(\d+)\s*(AM|PM)?/i);
      if (timeMatch) {
        hour = parseInt(timeMatch[1], 10);
        minute = parseInt(timeMatch[2], 10);
        const meridiem = timeMatch[3]?.toUpperCase();
        if (meridiem === "PM" && hour !== 12) hour += 12;
        if (meridiem === "AM" && hour === 12) hour = 0;
      }
      const meetupTime = new Date(year, month - 1, day, hour, minute);

      if (meetupTime >= windowStart && meetupTime <= windowEnd) {
        const sent = await sendEmail(
          rsvp.contact,
          `Reminder: "${rsvp.title}" is tomorrow!`,
          reminderHtml(rsvp.first_name, rsvp)
        );
        if (sent) {
          await db.execute(sql`
            UPDATE meetup_rsvps SET reminded_at = NOW(), emailed_at = NOW(), emailed_type = 'reminded' WHERE id = ${rsvp.id}
          `);
        }
      }
    }
  } catch (err) {
    console.error("[playdate] Reminder job error:", err);
  }
}

export function startReminderScheduler() {
  const INTERVAL_MS = 30 * 60 * 1000;
  runReminderJob();
  setInterval(runReminderJob, INTERVAL_MS);
  console.log("[playdate] Reminder scheduler started (runs every 30 min)");
}

router.get("/playdate/meetups", async (req, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`
      SELECT m.id, m.title, m.location, m.date, m.time, m.description,
             m.host_name, m.contact, m.category, m.max_attendees, m.created_at,
             m.lat, m.lng,
             COALESCE(m.status, 'active') AS status,
        COALESCE((SELECT COUNT(*) FROM meetup_rsvps r WHERE r.meetup_id = m.id), 0)::int AS rsvp_count
      FROM meetups m
      ORDER BY m.date ASC, m.created_at DESC
    `);
    res.json({ meetups: result.rows });
  }, res);
});

router.post("/playdate/meetups", async (req, res) => {
  await withDB(async () => {
    const { title, location, date, time, description, host_name, contact, category, max_attendees } = req.body;
    if (!title || !location || !date || !time || !host_name) {
      res.status(400).json({ error: "title, location, date, time, and host_name are required" });
      return;
    }
    const id = `meetup-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const host_code = Math.random().toString(36).slice(2, 8).toUpperCase();
    const coords = await geocodeLocation(location);
    await db.execute(sql`
      INSERT INTO meetups (id, title, location, date, time, description, host_name, contact, category, max_attendees, host_code, lat, lng)
      VALUES (${id}, ${title}, ${location}, ${date}, ${time}, ${description || null}, ${host_name}, ${contact || null}, ${category || 'general'}, ${max_attendees || 20}, ${host_code}, ${coords?.lat ?? null}, ${coords?.lng ?? null})
    `);
    const row = await db.execute(sql`SELECT *, 0 AS rsvp_count FROM meetups WHERE id = ${id} LIMIT 1`);
    const meetup = (row.rows as any[])[0];
    res.status(201).json({ meetup: { ...meetup, host_code: undefined }, host_code });

    // Fire-and-forget: notify all users who have previously RSVPed to any playdate meetup
    db.execute(sql`
      SELECT DISTINCT u.id
      FROM users u
      INNER JOIN meetup_rsvps mr ON mr.email = u.email
      WHERE u.id IS NOT NULL
    `).then(async (rsvpUsers: any) => {
      const userIds: string[] = (rsvpUsers.rows as any[]).map((r: any) => r.id).filter(Boolean);
      if (userIds.length === 0) return;
      const msg = `🎉 New PLAYDATE meetup: ${title} at ${location} on ${date}!`;
      await Promise.all(userIds.map((uid: string) =>
        db.execute(sql`
          INSERT INTO notifications (user_id, type, message, link)
          VALUES (${uid}, 'playdate', ${msg}, '/playdate')
        `).catch(() => {})
      ));
    }).catch(() => {});
  }, res);
});

router.patch("/playdate/meetups/:id", async (req, res) => {
  await withDB(async () => {
    const { id } = req.params;
    const { host_code, date, time, location, title, description, max_attendees } = req.body;

    if (!host_code) {
      res.status(400).json({ error: "host_code is required" });
      return;
    }

    const meetupRows = await db.execute(sql`SELECT * FROM meetups WHERE id = ${id} LIMIT 1`);
    if ((meetupRows.rows as any[]).length === 0) {
      res.status(404).json({ error: "Meetup not found" });
      return;
    }
    const meetup = (meetupRows.rows as any[])[0];

    if (!meetup.host_code || meetup.host_code.toUpperCase() !== String(host_code).toUpperCase()) {
      res.status(403).json({ error: "Invalid host code. Please check your code and try again." });
      return;
    }

    const changes: { field: string; old: string; new: string }[] = [];
    if (date && date !== meetup.date) {
      changes.push({ field: "📅 Date", old: formatDate(meetup.date), new: formatDate(date) });
    }
    if (time && time !== meetup.time) {
      changes.push({ field: "🕐 Time", old: meetup.time, new: time });
    }
    if (location && location !== meetup.location) {
      changes.push({ field: "📍 Location", old: meetup.location, new: location });
    }

    const newDate = date ?? meetup.date;
    const newTime = time ?? meetup.time;
    const newLocation = location ?? meetup.location;
    const newTitle = title ?? meetup.title;
    const newDescription = description !== undefined ? description : meetup.description;
    const newMaxAttendees = max_attendees ?? meetup.max_attendees;

    await db.execute(sql`
      UPDATE meetups
      SET date = ${newDate}, time = ${newTime}, location = ${newLocation},
          title = ${newTitle}, description = ${newDescription || null},
          max_attendees = ${newMaxAttendees}
      WHERE id = ${id}
    `);

    const updatedRow = await db.execute(sql`
      SELECT m.*, COALESCE((SELECT COUNT(*) FROM meetup_rsvps r WHERE r.meetup_id = m.id), 0)::int AS rsvp_count
      FROM meetups m WHERE m.id = ${id} LIMIT 1
    `);
    const updatedMeetup = (updatedRow.rows as any[])[0];

    let notified = 0;
    if (changes.length > 0) {
      const rsvpsResult = await db.execute(sql`
        SELECT id, first_name, contact FROM meetup_rsvps WHERE meetup_id = ${id}
      `);
      for (const rsvp of rsvpsResult.rows as any[]) {
        if (isEmail(rsvp.contact)) {
          const sent = await sendEmail(
            rsvp.contact,
            `Update: "${updatedMeetup.title}" details have changed`,
            updateAlertHtml(rsvp.first_name, updatedMeetup, changes)
          );
          if (sent) {
            notified++;
            await db.execute(sql`UPDATE meetup_rsvps SET emailed_at = NOW(), emailed_type = 'updated' WHERE id = ${rsvp.id}`);
          }
        }
      }
    }

    res.json({ ok: true, meetup: { ...updatedMeetup, host_code: undefined }, notified });
  }, res);
});

router.delete("/playdate/meetups/:id", async (req, res) => {
  await withDB(async () => {
    const { host_code } = req.body;
    if (!host_code) {
      res.status(400).json({ error: "host_code is required" });
      return;
    }

    const meetupRows = await db.execute(sql`SELECT * FROM meetups WHERE id = ${req.params.id} LIMIT 1`);
    if ((meetupRows.rows as any[]).length === 0) {
      res.status(404).json({ error: "Meetup not found" });
      return;
    }
    const meetup = (meetupRows.rows as any[])[0];

    if (!meetup.host_code || meetup.host_code.toUpperCase() !== String(host_code).toUpperCase()) {
      res.status(403).json({ error: "Invalid host code. Please check your code and try again." });
      return;
    }

    const rsvpsResult = await db.execute(sql`
      SELECT id, first_name, contact FROM meetup_rsvps WHERE meetup_id = ${req.params.id}
    `);
    let notified = 0;
    for (const rsvp of rsvpsResult.rows as any[]) {
      if (isEmail(rsvp.contact)) {
        const sent = await sendEmail(
          rsvp.contact,
          `Meetup cancelled: "${meetup.title}"`,
          cancellationHtml(rsvp.first_name, meetup)
        );
        if (sent) {
          notified++;
          await db.execute(sql`UPDATE meetup_rsvps SET emailed_at = NOW(), emailed_type = 'cancelled' WHERE id = ${rsvp.id}`);
        }
      }
    }

    await db.execute(sql`DELETE FROM meetups WHERE id = ${req.params.id}`);
    res.json({ ok: true, notified });
  }, res);
});

router.post("/playdate/meetups/:id/rsvp", async (req, res) => {
  await withDB(async () => {
    const { id } = req.params;
    const { first_name, last_initial, contact, num_children } = req.body;

    if (!first_name || !last_initial || !contact) {
      res.status(400).json({ error: "first_name, last_initial, and contact are required" });
      return;
    }

    const meetupRows = await db.execute(sql`SELECT * FROM meetups WHERE id = ${id} LIMIT 1`);
    if ((meetupRows.rows as any[]).length === 0) {
      res.status(404).json({ error: "Meetup not found" });
      return;
    }
    const meetup = (meetupRows.rows as any[])[0];

    if (meetup.status === "cancelled") {
      res.status(409).json({ error: "This meetup has been cancelled." });
      return;
    }
    if (meetup.status === "closed") {
      res.status(409).json({ error: "Sign-ups for this meetup are closed." });
      return;
    }

    const countRows = await db.execute(sql`SELECT COUNT(*) AS cnt FROM meetup_rsvps WHERE meetup_id = ${id}`);
    const current = parseInt((countRows.rows as any[])[0]?.cnt ?? "0", 10);
    if (current >= meetup.max_attendees) {
      res.status(409).json({ error: "This meetup is already at capacity." });
      return;
    }

    const rsvpId = `rsvp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    await db.execute(sql`
      INSERT INTO meetup_rsvps (id, meetup_id, first_name, last_initial, contact, num_children)
      VALUES (${rsvpId}, ${id}, ${first_name.trim()}, ${last_initial.trim().charAt(0).toUpperCase()}, ${contact.trim()}, ${num_children || 1})
    `);

    const newCount = current + 1;
    res.status(201).json({ ok: true, rsvp_count: newCount });

    if (isEmail(contact)) {
      sendEmail(
        contact.trim(),
        `You're signed up for "${meetup.title}"!`,
        confirmationHtml(first_name.trim(), meetup)
      ).then((sent) => {
        if (sent) {
          db.execute(sql`UPDATE meetup_rsvps SET emailed_at = NOW(), emailed_type = 'confirmed' WHERE id = ${rsvpId}`)
            .catch((err) => console.error("[playdate] emailed_at update error:", err));
        }
      }).catch((err) => console.error("[playdate] Confirmation email error:", err));
    }
  }, res);
});

router.patch("/playdate/meetups/:id/status", async (req, res) => {
  await withDB(async () => {
    const { id } = req.params;
    const { host_code, action } = req.body;

    if (!host_code || !action) {
      res.status(400).json({ error: "host_code and action are required" });
      return;
    }
    if (action !== "cancel" && action !== "close" && action !== "reopen") {
      res.status(400).json({ error: "action must be 'cancel', 'close', or 'reopen'" });
      return;
    }

    const meetupRows = await db.execute(sql`SELECT * FROM meetups WHERE id = ${id} LIMIT 1`);
    if ((meetupRows.rows as any[]).length === 0) {
      res.status(404).json({ error: "Meetup not found" });
      return;
    }
    const meetup = (meetupRows.rows as any[])[0];

    if (!meetup.host_code || meetup.host_code.toUpperCase() !== String(host_code).toUpperCase()) {
      res.status(403).json({ error: "Invalid host code. Please check your code and try again." });
      return;
    }

    const prevStatus = meetup.status;
    const newStatus = action === "cancel" ? "cancelled" : action === "close" ? "closed" : "active";
    await db.execute(sql`UPDATE meetups SET status = ${newStatus} WHERE id = ${id}`);

    let notified = 0;
    if (action === "cancel") {
      const rsvpsResult = await db.execute(sql`
        SELECT id, first_name, contact FROM meetup_rsvps WHERE meetup_id = ${id}
      `);
      for (const rsvp of rsvpsResult.rows as any[]) {
        if (isEmail(rsvp.contact)) {
          const sent = await sendEmail(
            rsvp.contact,
            `Meetup cancelled: "${meetup.title}"`,
            cancellationHtml(rsvp.first_name, meetup)
          );
          if (sent) {
            notified++;
            await db.execute(sql`UPDATE meetup_rsvps SET emailed_at = NOW(), emailed_type = 'cancelled' WHERE id = ${rsvp.id}`);
          }
        }
      }
    } else if (action === "reopen" && prevStatus === "cancelled" && req.body.notify_rsvps) {
      const rsvpsResult = await db.execute(sql`
        SELECT id, first_name, contact FROM meetup_rsvps WHERE meetup_id = ${id}
      `);
      for (const rsvp of rsvpsResult.rows as any[]) {
        if (isEmail(rsvp.contact)) {
          const sent = await sendEmail(
            rsvp.contact,
            `It's back on! "${meetup.title}" has been reopened`,
            reopenHtml(rsvp.first_name, meetup)
          );
          if (sent) {
            notified++;
            await db.execute(sql`UPDATE meetup_rsvps SET emailed_at = NOW(), emailed_type = 'reopened' WHERE id = ${rsvp.id}`);
          }
        }
      }
    }

    res.json({ ok: true, status: newStatus, notified });
  }, res);
});

router.patch("/admin/playdate/meetups/:id/status", requireMasterAdmin, async (req, res) => {
  await withDB(async () => {
    const { id } = req.params;
    const { action } = req.body;

    if (!action || (action !== "cancel" && action !== "close" && action !== "reopen")) {
      res.status(400).json({ error: "action must be 'cancel', 'close', or 'reopen'" });
      return;
    }

    const meetupRows = await db.execute(sql`SELECT * FROM meetups WHERE id = ${id} LIMIT 1`);
    if ((meetupRows.rows as any[]).length === 0) {
      res.status(404).json({ error: "Meetup not found" });
      return;
    }
    const meetup = (meetupRows.rows as any[])[0];

    const prevStatus = meetup.status;
    const newStatus = action === "cancel" ? "cancelled" : action === "close" ? "closed" : "active";
    await db.execute(sql`UPDATE meetups SET status = ${newStatus} WHERE id = ${id}`);

    let notified = 0;
    if (action === "cancel") {
      const rsvpsResult = await db.execute(sql`
        SELECT id, first_name, contact FROM meetup_rsvps WHERE meetup_id = ${id}
      `);
      for (const rsvp of rsvpsResult.rows as any[]) {
        if (isEmail(rsvp.contact)) {
          const sent = await sendEmail(
            rsvp.contact,
            `Meetup cancelled: "${meetup.title}"`,
            cancellationHtml(rsvp.first_name, meetup)
          );
          if (sent) {
            notified++;
            await db.execute(sql`UPDATE meetup_rsvps SET emailed_at = NOW(), emailed_type = 'cancelled' WHERE id = ${rsvp.id}`);
          }
        }
      }
    } else if (action === "reopen" && prevStatus === "cancelled" && req.body.notify_rsvps) {
      const rsvpsResult = await db.execute(sql`
        SELECT id, first_name, contact FROM meetup_rsvps WHERE meetup_id = ${id}
      `);
      for (const rsvp of rsvpsResult.rows as any[]) {
        if (isEmail(rsvp.contact)) {
          const sent = await sendEmail(
            rsvp.contact,
            `It's back on! "${meetup.title}" has been reopened`,
            reopenHtml(rsvp.first_name, meetup)
          );
          if (sent) {
            notified++;
            await db.execute(sql`UPDATE meetup_rsvps SET emailed_at = NOW(), emailed_type = 'reopened' WHERE id = ${rsvp.id}`);
          }
        }
      }
    }

    res.json({ ok: true, status: newStatus, notified });
  }, res);
});

router.delete("/admin/playdate/meetups/:id", requireMasterAdmin, async (req, res) => {
  await withDB(async () => {
    const { id } = req.params;

    const meetupRows = await db.execute(sql`SELECT * FROM meetups WHERE id = ${id} LIMIT 1`);
    if ((meetupRows.rows as any[]).length === 0) {
      res.status(404).json({ error: "Meetup not found" });
      return;
    }

    await db.execute(sql`DELETE FROM meetups WHERE id = ${id}`);
    res.json({ ok: true });
  }, res);
});

router.get("/playdate/meetups/:id/rsvps", async (req, res) => {
  await withDB(async () => {
    const { id } = req.params;
    const { host_code } = req.query;

    if (!host_code) {
      res.status(400).json({ error: "host_code is required" });
      return;
    }

    const meetupRows = await db.execute(sql`SELECT * FROM meetups WHERE id = ${id} LIMIT 1`);
    if ((meetupRows.rows as any[]).length === 0) {
      res.status(404).json({ error: "Meetup not found" });
      return;
    }
    const meetup = (meetupRows.rows as any[])[0];

    if (!meetup.host_code || meetup.host_code.toUpperCase() !== String(host_code).toUpperCase()) {
      res.status(403).json({ error: "Invalid host code. Please check your code and try again." });
      return;
    }

    const rsvpsResult = await db.execute(sql`
      SELECT id, first_name, last_initial, contact, num_children, created_at, emailed_at, emailed_type
      FROM meetup_rsvps
      WHERE meetup_id = ${id}
      ORDER BY created_at ASC
    `);

    res.json({
      meetup: {
        id: meetup.id,
        title: meetup.title,
        date: meetup.date,
        time: meetup.time,
        location: meetup.location,
        max_attendees: meetup.max_attendees,
      },
      rsvps: rsvpsResult.rows,
    });
  }, res);
});

router.get("/admin/playdate/rsvps", requireMasterAdmin, async (req, res) => {
  await withDB(async () => {
    const meetupsResult = await db.execute(sql`
      SELECT m.id, m.title, m.location, m.date, m.time, m.description,
             m.host_name, m.contact, m.category, m.max_attendees, m.created_at,
             COALESCE(m.status, 'active') AS status,
        COALESCE((SELECT COUNT(*) FROM meetup_rsvps r WHERE r.meetup_id = m.id), 0)::int AS rsvp_count
      FROM meetups m
      ORDER BY m.date ASC, m.created_at DESC
    `);

    const rsvpsResult = await db.execute(sql`
      SELECT r.*, m.title AS meetup_title, m.date AS meetup_date
      FROM meetup_rsvps r
      JOIN meetups m ON r.meetup_id = m.id
      ORDER BY r.created_at DESC
    `);

    res.json({
      meetups: meetupsResult.rows,
      rsvps: rsvpsResult.rows,
    });
  }, res);
});

// ── MEETUP COMMENTS ──────────────────────────────────────────────────────────

router.get("/playdate/meetups/:id/comments", async (req, res) => {
  await withDB(async () => {
    const { id } = req.params;
    const result = await db.execute(sql`
      SELECT * FROM meetup_comments WHERE meetup_id = ${id} ORDER BY created_at ASC
    `);
    res.json({ comments: result.rows });
  }, res);
});

router.post("/playdate/meetups/:id/comments", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const { id } = req.params;
    const { body } = req.body;
    if (!body?.trim()) { res.status(400).json({ error: "Comment body required" }); return; }
    const meetupCheck = await db.execute(sql`SELECT id FROM meetups WHERE id = ${id} LIMIT 1`);
    if ((meetupCheck.rows as any[]).length === 0) { res.status(404).json({ error: "Meetup not found" }); return; }
    const userRows = await db.execute(sql`SELECT first_name, last_name FROM users WHERE id = ${req.user!.id} LIMIT 1`);
    const u = (userRows.rows as any[])[0];
    const fn = u?.first_name || "";
    const ln = u?.last_name || "";
    const user_name = [fn, ln].filter(Boolean).join(" ") || req.user!.email.split("@")[0];
    const initials = ((fn[0] || "") + (ln[0] || "")).toUpperCase() || req.user!.email[0].toUpperCase();
    const commentId = `mc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    await db.execute(sql`
      INSERT INTO meetup_comments (id, meetup_id, user_id, user_name, user_initials, body)
      VALUES (${commentId}, ${id}, ${req.user!.id}, ${user_name}, ${initials}, ${body.trim()})
    `);
    const row = await db.execute(sql`SELECT * FROM meetup_comments WHERE id = ${commentId} LIMIT 1`);
    res.status(201).json({ comment: (row.rows as any[])[0] });
  }, res);
});

router.patch("/playdate/meetups/:id/comments/:commentId", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const { commentId } = req.params;
    const { body } = req.body;
    if (!body?.trim()) { res.status(400).json({ error: "Comment body required" }); return; }
    const row = await db.execute(sql`SELECT * FROM meetup_comments WHERE id = ${commentId} LIMIT 1`);
    const comment = (row.rows as any[])[0];
    if (!comment) { res.status(404).json({ error: "Comment not found" }); return; }
    if (comment.user_id !== req.user!.id) { res.status(403).json({ error: "Cannot edit another user's comment" }); return; }
    await db.execute(sql`UPDATE meetup_comments SET body = ${body.trim()} WHERE id = ${commentId}`);
    res.json({ success: true });
  }, res);
});

router.delete("/playdate/meetups/:id/comments/:commentId", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const { commentId } = req.params;
    const row = await db.execute(sql`SELECT * FROM meetup_comments WHERE id = ${commentId} LIMIT 1`);
    const comment = (row.rows as any[])[0];
    if (!comment) { res.status(404).json({ error: "Comment not found" }); return; }
    if (comment.user_id !== req.user!.id) { res.status(403).json({ error: "Cannot delete another user's comment" }); return; }
    await db.execute(sql`DELETE FROM meetup_comments WHERE id = ${commentId}`);
    res.json({ success: true });
  }, res);
});

export default router;
