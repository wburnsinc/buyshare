import { Router, type Request, type Response } from "express";
import { stripe } from "../lib/stripe.js";
import { db } from "@workspace/db";
import { bookingsTable, listingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "../lib/logger.js";

const router = Router();

// Stripe webhooks need the raw body — mount BEFORE express.json()
router.post(
  "/webhooks/stripe",
  // express.raw is applied in app.ts for this path
  async (req: Request, res: Response) => {
    const sig = req.headers["stripe-signature"] as string;
    const secret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!secret) {
      logger.error("STRIPE_WEBHOOK_SECRET not configured");
      res.status(500).send("Webhook secret not configured");
      return;
    }

    let event;
    try {
      event = stripe.webhooks.constructEvent(req.body as Buffer, sig, secret);
    } catch (err) {
      logger.error({ err }, "Stripe webhook signature verification failed");
      res.status(400).send(`Webhook Error: ${String(err)}`);
      return;
    }

    logger.info({ type: event.type }, "Stripe webhook received");

    try {
      switch (event.type) {
        case "payment_intent.succeeded": {
          const pi = event.data.object;
          const bookingId = pi.metadata?.bookingId;
          if (bookingId) {
            await db
              .update(bookingsTable)
              .set({ status: "pending", updatedAt: new Date() })
              .where(eq(bookingsTable.id, bookingId));
            logger.info({ bookingId }, "Payment succeeded — booking confirmed pending check-in");
          }
          break;
        }

        case "payment_intent.payment_failed": {
          const pi = event.data.object;
          const bookingId = pi.metadata?.bookingId;
          if (bookingId) {
            const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, bookingId)).limit(1);
            if (booking) {
              await db.update(bookingsTable).set({ status: "cancelled", updatedAt: new Date() }).where(eq(bookingsTable.id, bookingId));
              await db.update(listingsTable).set({ status: "available", updatedAt: new Date() }).where(eq(listingsTable.id, booking.listingId));
            }
            logger.info({ bookingId }, "Payment failed — booking cancelled");
          }
          break;
        }

        case "account.updated": {
          // Stripe Connect account updated — refresh onboarding status
          logger.info({ accountId: (event.data.object as { id: string }).id }, "Connect account updated");
          break;
        }

        default:
          logger.info({ type: event.type }, "Unhandled webhook event");
      }
    } catch (err) {
      logger.error({ err }, "Error processing webhook event");
    }

    res.json({ received: true });
  },
);

export default router;
