import { Router } from "express";
import { db } from "@workspace/db";
import { requestsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

const router = Router();

router.get("/requests", async (_req, res) => {
  try {
    const rows = await db
      .select({ request: requestsTable, user: usersTable })
      .from(requestsTable)
      .leftJoin(usersTable, eq(requestsTable.userId, usersTable.id))
      .where(eq(requestsTable.isActive, true));
    res.json(rows.map((r) => ({ ...r.request, user: r.user })));
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.post("/requests", async (req, res) => {
  try {
    const body = req.body;
    const id = body.id ?? randomUUID();
    const [request] = await db
      .insert(requestsTable)
      .values({
        id,
        userId: body.userId,
        title: body.title,
        description: body.description,
        location: body.location,
        budgetPerDaycents: body.budgetPerDayCents,
        neededBy: body.neededBy ? new Date(body.neededBy) : undefined,
      })
      .returning();
    res.status(201).json(request);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.delete("/requests/:id", async (req, res) => {
  try {
    await db.update(requestsTable).set({ isActive: false, updatedAt: new Date() }).where(eq(requestsTable.id, req.params.id));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

export default router;
