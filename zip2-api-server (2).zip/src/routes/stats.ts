import { Router } from "express";
import { db } from "@workspace/db";
import { bookingsTable, listingsTable, usersTable, reviewsTable } from "@workspace/db";
import { eq, and, sql, count } from "drizzle-orm";

const router = Router();

router.get("/stats/platform", async (_req, res) => {
  try {
    const [listings] = await db.select({ count: count() }).from(listingsTable);
    const [active] = await db.select({ count: count() }).from(bookingsTable).where(eq(bookingsTable.status, "active"));
    const [total] = await db.select({ count: count() }).from(bookingsTable);
    const [verified] = await db.select({ count: count() }).from(usersTable).where(eq(usersTable.isVerified, true));

    const completedBookings = await db.select().from(bookingsTable).where(eq(bookingsTable.status, "completed"));
    const totalRevenueCents = completedBookings.reduce((s, b) => s + (b.platformFeeCents ?? 0), 0);
    const protectionPoolCents = completedBookings.filter((b) => b.addedProtection).reduce((s, b) => s + (b.protectionFeeCents ?? 0), 0);

    res.json({
      totalListings: listings.count,
      activeRentals: active.count,
      totalBookings: total.count,
      totalRevenueCents,
      protectionPoolCents,
      verifiedUsers: verified.count,
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.get("/stats/owner/:userId", async (req, res) => {
  try {
    const allBookings = await db
      .select()
      .from(bookingsTable)
      .where(eq(bookingsTable.ownerId, req.params.userId));

    const completed = allBookings.filter((b) => b.status === "completed");
    const active = allBookings.filter((b) => b.status === "active");
    const totalEarnings = completed.reduce((s, b) => s + b.ownerPayoutCents, 0);

    const myListings = await db.select().from(listingsTable).where(eq(listingsTable.ownerId, req.params.userId));

    const reviews = await db.select().from(reviewsTable).where(eq(reviewsTable.revieweeId, req.params.userId));
    const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

    const recentBookings = allBookings.slice(-5).reverse();

    res.json({
      totalEarningsCents: totalEarnings,
      pendingPayoutCents: active.reduce((s, b) => s + b.ownerPayoutCents, 0),
      activeBookings: active.length,
      completedBookings: completed.length,
      totalListings: myListings.length,
      averageRating: Math.round(avgRating * 10) / 10,
      recentBookings,
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

export default router;
