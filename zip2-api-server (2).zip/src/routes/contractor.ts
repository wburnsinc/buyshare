import { Router } from "express";
import jwt from "jsonwebtoken";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { JWT_SECRET } from "../middleware/auth.js";

const router = Router();

const CONTRACTOR_TOKEN_TTL = "24h";

function signContractorToken(email: string): string {
  return jwt.sign({ contractorEmail: email, type: "contractor" }, JWT_SECRET, { expiresIn: CONTRACTOR_TOKEN_TTL });
}

function verifyContractorToken(authHeader?: string): { ok: true; email: string } | { ok: false; status: number; error: string } {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { ok: false, status: 401, error: "Contractor authentication required" };
  }
  try {
    const payload = jwt.verify(authHeader.slice(7), JWT_SECRET) as any;
    if (payload.type !== "contractor" || !payload.contractorEmail) {
      return { ok: false, status: 403, error: "Invalid contractor token" };
    }
    return { ok: true, email: payload.contractorEmail };
  } catch {
    return { ok: false, status: 401, error: "Contractor token expired or invalid" };
  }
}

async function ensureContractorsTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractors (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      business_name TEXT,
      services TEXT,
      zip_code TEXT,
      bio TEXT,
      license_number TEXT,
      years_experience INTEGER,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS photo_url TEXT`);
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS address TEXT`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractor_jobs (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      location TEXT NOT NULL,
      address TEXT,
      pay TEXT NOT NULL,
      pay_amount NUMERIC DEFAULT 0,
      description TEXT,
      client_name TEXT,
      client_phone TEXT,
      scheduled_date TEXT,
      scheduled_time TEXT,
      tags TEXT,
      status TEXT DEFAULT 'open',
      posted_at TIMESTAMP DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractor_claims (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      contractor_email TEXT NOT NULL,
      status TEXT DEFAULT 'claimed',
      notes TEXT,
      claimed_at TIMESTAMP DEFAULT NOW(),
      completed_at TIMESTAMP,
      UNIQUE(job_id, contractor_email)
    )
  `);
  await db.execute(sql`
    CREATE UNIQUE INDEX IF NOT EXISTS contractor_claims_active_job_idx
    ON contractor_claims (job_id)
    WHERE status IN ('claimed', 'in-progress')
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractor_ratings (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      contractor_email TEXT NOT NULL,
      client_name TEXT,
      rating INTEGER DEFAULT 5,
      review TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
}

async function seedJobsIfEmpty() {
  const count = await db.execute(sql`SELECT COUNT(*) as cnt FROM contractor_jobs`);
  const cnt = parseInt((count.rows[0] as any).cnt, 10);
  if (cnt > 0) return;
  const jobs = [
    { id: "job-001", title: "Weekly Pool Care — Port Charlotte", category: "Pool Care", location: "Port Charlotte, FL 33952", address: "1420 Harbor Blvd, Port Charlotte, FL 33952", pay: "$99/mo", pay_amount: 99, description: "Recurring weekly pool service: test and balance water chemistry, skim surface, brush walls, vacuum floor, empty skimmer/pump baskets.", client_name: "Robert M.", client_phone: "(941) 555-0101", scheduled_date: "2026-06-20", scheduled_time: "9:00 AM", tags: '["Recurring","Weekly"]', status: "open" },
    { id: "job-002", title: "Lawn Mow & Edge — Punta Gorda Home", category: "Lawn Care", location: "Punta Gorda, FL 33950", address: "887 Aqui Esta Dr, Punta Gorda, FL 33950", pay: "$45/visit", pay_amount: 45, description: "Mow front and back lawn, edge driveway and sidewalks, blow clippings.", client_name: "Sandra T.", client_phone: "(941) 555-0202", scheduled_date: "2026-06-19", scheduled_time: "8:00 AM", tags: '["One-time"]', status: "open" },
    { id: "job-003", title: "Screen & Door Repair — North Port", category: "Handyman", location: "North Port, FL 34287", address: "4910 Gulfstream Blvd, North Port, FL 34287", pay: "$120 est.", pay_amount: 120, description: "Replace torn pool cage screen panels (approx 4 panels) and repair sliding door track. Homeowner has materials on-site.", client_name: "Bill K.", client_phone: "(941) 555-0303", scheduled_date: "2026-06-21", scheduled_time: "10:30 AM", tags: '["One-time","Quoted"]', status: "open" },
    { id: "job-004", title: "Pressure Wash Driveway — Deep Creek", category: "Pressure Washing", location: "Deep Creek, FL 33983", address: "22415 Westchester Blvd, Deep Creek, FL 33983", pay: "$150 est.", pay_amount: 150, description: "Pressure wash 2-car driveway and front walkway. Approx 800 sq ft. Algae buildup on left side.", client_name: "Maria G.", client_phone: "(941) 555-0404", scheduled_date: "2026-06-22", scheduled_time: "8:00 AM", tags: '["One-time"]', status: "open" },
    { id: "job-005", title: "Pool + Lawn Bundle — Burnt Store", category: "Bundle", location: "Burnt Store, FL 33955", address: "16710 Burnt Store Rd, Punta Gorda, FL 33955", pay: "$180/mo", pay_amount: 180, description: "Combined weekly pool maintenance and bi-weekly lawn mow. Large property (0.3 acres). Pool is 15k gallon screened enclosure.", client_name: "Dave & Carol P.", client_phone: "(941) 555-0505", scheduled_date: "2026-06-20", scheduled_time: "7:30 AM", tags: '["Recurring","Bundle"]', status: "open" },
    { id: "job-006", title: "Gutter Clean — Venice Home", category: "Handyman", location: "Venice, FL 34285", address: "1208 Venetia Rd, Venice, FL 34285", pay: "$85 est.", pay_amount: 85, description: "Clean gutters front and back, flush downspouts, remove debris. Single-story home.", client_name: "Patricia H.", client_phone: "(941) 555-0606", scheduled_date: "2026-06-23", scheduled_time: "9:00 AM", tags: '["One-time"]', status: "open" },
    { id: "job-007", title: "Mulch Install — Englewood Yard", category: "Lawn Care", location: "Englewood, FL 34223", address: "555 Pine St, Englewood, FL 34223", pay: "$200 est.", pay_amount: 200, description: "Install 4 yards of brown mulch in front beds and side yard. Homeowner purchasing mulch, need labor only.", client_name: "Tom B.", client_phone: "(941) 555-0707", scheduled_date: "2026-06-24", scheduled_time: "8:30 AM", tags: '["One-time"]', status: "open" },
    { id: "job-008", title: "AC Filter + Unit Inspection — Sarasota", category: "Handyman", location: "Sarasota, FL 34231", address: "3312 Swift Rd, Sarasota, FL 34231", pay: "$75 est.", pay_amount: 75, description: "Replace 3 HVAC filters (20x25x1), clean external coils, and do a basic visual inspection of the system.", client_name: "Karen L.", client_phone: "(941) 555-0808", scheduled_date: "2026-06-25", scheduled_time: "11:00 AM", tags: '["One-time"]', status: "open" },
  ];
  for (const j of jobs) {
    await db.execute(sql`
      INSERT INTO contractor_jobs (id, title, category, location, address, pay, pay_amount, description, client_name, client_phone, scheduled_date, scheduled_time, tags, status)
      VALUES (${j.id}, ${j.title}, ${j.category}, ${j.location}, ${j.address}, ${j.pay}, ${j.pay_amount}, ${j.description}, ${j.client_name}, ${j.client_phone}, ${j.scheduled_date}, ${j.scheduled_time}, ${j.tags}, ${j.status})
      ON CONFLICT (id) DO NOTHING
    `);
  }
}

let ready = false;
async function withDB(fn: () => Promise<void>, res: any) {
  try {
    if (!ready) {
      await ensureContractorsTable();
      await seedJobsIfEmpty();
      ready = true;
    }
    await fn();
  } catch (err: any) {
    console.error("contractor error:", err);
    res.status(500).json({ error: err.message || "Server error" });
  }
}

router.post("/contractor/apply", async (req, res) => {
  await withDB(async () => {
    const { name, email, phone, business_name, services, zip_code, address, bio, license_number, years_experience } = req.body;
    if (!name || !email || !phone) {
      res.status(400).json({ error: "name, email, and phone are required" });
      return;
    }
    const existing = await db.execute(sql`SELECT id FROM contractors WHERE email = ${email.toLowerCase()} LIMIT 1`);
    if ((existing.rows as any[]).length > 0) {
      res.status(409).json({ error: "An application with this email already exists" });
      return;
    }
    const id = `con-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    await db.execute(sql`
      INSERT INTO contractors (id, name, email, phone, business_name, services, zip_code, address, bio, license_number, years_experience)
      VALUES (${id}, ${name}, ${email.toLowerCase()}, ${phone}, ${business_name || null}, ${services ? JSON.stringify(services) : null}, ${zip_code || null}, ${address || null}, ${bio || null}, ${license_number || null}, ${years_experience || null})
    `);
    const row = await db.execute(sql`SELECT * FROM contractors WHERE id = ${id} LIMIT 1`);
    res.status(201).json({ contractor: (row.rows as any[])[0], message: "Application submitted! We'll be in touch within 3 business days." });

    // Fire-and-forget: admin alert + contractor welcome + BurnCall AI pitch
    const _apiKey = process.env.RESEND_API_KEY;
    if (_apiKey) {
      const _from = process.env.RESEND_FROM_EMAIL
        ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
        : "Buyshare <onboarding@resend.dev>";
      // Admin alert
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: _from,
          to: ["burnsinc@outlook.com", "admin@buyshare.co"],
          subject: `🔧 New BlueTruck contractor application — ${name}`,
          html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px">
            <h2 style="color:#b45309">New Contractor Application</h2>
            <table style="border-collapse:collapse;width:100%">
              <tr><td style="padding:6px 0;font-weight:600;width:140px">Name</td><td>${name}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Email</td><td>${email.toLowerCase()}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Phone</td><td>${phone || "—"}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Business</td><td>${business_name || "—"}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Address</td><td>${address || zip_code || "—"}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Services</td><td>${Array.isArray(services) ? services.join(", ") : (services || "—")}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Experience</td><td>${years_experience ? `${years_experience} yrs` : "—"}</td></tr>
            </table>
            <a href="https://buyshare.co/admin/contractors" style="display:inline-block;background:#b45309;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;margin-top:16px">Review Application</a>
          </div>`,
        }),
      }).catch(() => {});
      // BurnCall AI follow-up email to contractor
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: _from,
          to: [email.toLowerCase()],
          subject: `Thanks for joining BlueTruck, ${name.split(" ")[0]}! 🚛 + a tool to help you grow`,
          html: `<div style="font-family:sans-serif;max-width:560px;margin:auto;padding:24px;color:#111827">
            <h2 style="color:#b45309;font-size:22px">We received your application!</h2>
            <p>Hi <strong>${name.split(" ")[0]}</strong>, thanks for applying to the BlueTruck contractor network. Our team reviews applications within 3 business days — we'll be in touch soon.</p>
            <hr style="border:none;border-top:1px solid #e5e7eb;margin:20px 0"/>
            <h3 style="color:#111827;font-size:18px;margin-bottom:8px">🤖 While you wait — meet BurnCall AI</h3>
            <p style="color:#374151;line-height:1.6">We built <strong>BurnCall AI</strong> specifically for contractors and service professionals like you. It's an AI-powered CRM that handles the business side so you can focus on the work:</p>
            <ul style="color:#374151;line-height:2;padding-left:20px">
              <li>📞 <strong>AI call summaries</strong> — never lose track of what a client asked for</li>
              <li>📋 <strong>Lead pipeline</strong> — track every prospect from first contact to closed job</li>
              <li>💬 <strong>Client chat</strong> — message clients directly from your dashboard</li>
              <li>📊 <strong>Revenue tracking</strong> — see what's coming in and what's pending</li>
              <li>🔔 <strong>Follow-up reminders</strong> — never let a warm lead go cold</li>
            </ul>
            <p style="color:#374151">Contractors using BurnCall AI report <strong>30% more repeat clients</strong> and spend less time on admin. It's already built into the BlueTruck platform — ready to use the moment you're approved.</p>
            <a href="https://buyshare.co/burncall" style="display:inline-block;background:#b45309;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin-top:16px;margin-bottom:24px">Learn More About BurnCall AI →</a>
            <p style="font-size:12px;color:#6b7280">BlueTruck by Buyshare.co · Southwest Florida · Questions? Reply to this email.</p>
          </div>`,
        }),
      }).catch(() => {});
    }
  }, res);
});

router.get("/contractor/status", async (req, res) => {
  await withDB(async () => {
    const { email } = req.query as { email?: string };
    if (!email) { res.status(400).json({ error: "email required" }); return; }
    const row = await db.execute(sql`SELECT * FROM contractors WHERE email = ${email.toLowerCase()} LIMIT 1`);
    const contractor = (row.rows as any[])[0];
    if (!contractor) { res.status(404).json({ error: "No application found" }); return; }
    res.json({ contractor });
  }, res);
});

router.post("/contractor/login", async (req, res) => {
  await withDB(async () => {
    const { email } = req.body;
    if (!email) { res.status(400).json({ error: "email required" }); return; }
    const conRow = await db.execute(sql`SELECT status FROM contractors WHERE email = ${email.toLowerCase()} LIMIT 1`);
    const contractor = (conRow.rows as any[])[0];
    if (!contractor) { res.status(403).json({ error: "No contractor account found for this email" }); return; }
    if (contractor.status !== "approved") { res.status(403).json({ error: "Contractor application is not approved" }); return; }
    const subRow = await db.execute(sql`
      SELECT id FROM subscriptions WHERE email = ${email.toLowerCase()} AND tier = 'contractor' AND status IN ('active', 'trialing')
      ORDER BY created_at DESC LIMIT 1
    `);
    if (!(subRow.rows as any[])[0]) { res.status(403).json({ error: "Active Contractor Pro subscription required" }); return; }
    const token = signContractorToken(email.toLowerCase());
    res.json({ token });
  }, res);
});

router.get("/contractor/all", async (req, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`SELECT * FROM contractors ORDER BY created_at DESC`);
    res.json({ contractors: result.rows });
  }, res);
});

router.patch("/contractor/:id/status", async (req, res) => {
  await withDB(async () => {
    const { status } = req.body;
    await db.execute(sql`UPDATE contractors SET status = ${status} WHERE id = ${req.params.id}`);
    res.json({ ok: true });
  }, res);
});

router.get("/contractor/jobs", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const jobs = await db.execute(sql`SELECT * FROM contractor_jobs ORDER BY posted_at DESC`);
    const claims = await db.execute(sql`SELECT * FROM contractor_claims WHERE contractor_email = ${email}`);
    const claimMap: Record<string, any> = {};
    for (const c of claims.rows as any[]) claimMap[c.job_id] = c;
    const result = (jobs.rows as any[]).map(j => ({
      ...j,
      tags: (() => { try { return JSON.parse(j.tags || "[]"); } catch { return []; } })(),
      claim: claimMap[j.id] || null,
    }));
    res.json({ jobs: result });
  }, res);
});

router.post("/contractor/jobs/:jobId/claim", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const { jobId } = req.params;
    const jobCheck = await db.execute(sql`SELECT id FROM contractor_jobs WHERE id = ${jobId} LIMIT 1`);
    if (!(jobCheck.rows as any[])[0]) { res.status(404).json({ error: "Job not found" }); return; }
    const locked = await db.execute(sql`
      UPDATE contractor_jobs SET status = 'claimed' WHERE id = ${jobId} AND status = 'open'
      RETURNING id
    `);
    if ((locked.rows as any[]).length === 0) {
      res.status(409).json({ error: "This job has already been claimed by another contractor" });
      return;
    }
    const id = `clm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    try {
      await db.execute(sql`
        INSERT INTO contractor_claims (id, job_id, contractor_email, status)
        VALUES (${id}, ${jobId}, ${email}, 'claimed')
        ON CONFLICT (job_id, contractor_email) DO UPDATE SET status = 'claimed', claimed_at = NOW()
      `);
    } catch (insertErr: any) {
      await db.execute(sql`UPDATE contractor_jobs SET status = 'open' WHERE id = ${jobId}`);
      res.status(409).json({ error: "Could not claim this job — it may already be claimed" });
      return;
    }
    res.json({ ok: true });
  }, res);
});

router.post("/contractor/jobs/:jobId/start", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const { jobId } = req.params;
    const claimRes = await db.execute(sql`
      SELECT id FROM contractor_claims WHERE job_id = ${jobId} AND contractor_email = ${email} AND status = 'claimed' LIMIT 1
    `);
    if (!(claimRes.rows as any[])[0]) { res.status(403).json({ error: "You do not have a claimed (not yet started) job here" }); return; }
    await db.execute(sql`UPDATE contractor_claims SET status = 'in-progress' WHERE job_id = ${jobId} AND contractor_email = ${email}`);
    await db.execute(sql`UPDATE contractor_jobs SET status = 'in-progress' WHERE id = ${jobId}`);
    res.json({ ok: true });
  }, res);
});

router.post("/contractor/jobs/:jobId/unclaim", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const { jobId } = req.params;
    const claimRes = await db.execute(sql`
      SELECT id FROM contractor_claims
      WHERE job_id = ${jobId} AND contractor_email = ${email} AND status IN ('claimed', 'in-progress') LIMIT 1
    `);
    if (!(claimRes.rows as any[])[0]) { res.status(403).json({ error: "You do not have an active claim on this job" }); return; }
    await db.execute(sql`DELETE FROM contractor_claims WHERE job_id = ${jobId} AND contractor_email = ${email}`);
    const remaining = await db.execute(sql`
      SELECT id FROM contractor_claims WHERE job_id = ${jobId} AND status IN ('claimed', 'in-progress') LIMIT 1
    `);
    if ((remaining.rows as any[]).length === 0) {
      await db.execute(sql`UPDATE contractor_jobs SET status = 'open' WHERE id = ${jobId}`);
    }
    res.json({ ok: true });
  }, res);
});

router.post("/contractor/jobs/:jobId/complete", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const { jobId } = req.params;
    const claimRes = await db.execute(sql`
      SELECT id FROM contractor_claims
      WHERE job_id = ${jobId} AND contractor_email = ${email} AND status IN ('claimed', 'in-progress') LIMIT 1
    `);
    if (!(claimRes.rows as any[])[0]) { res.status(403).json({ error: "You do not have an active claim on this job" }); return; }
    await db.execute(sql`
      UPDATE contractor_claims SET status = 'completed', completed_at = NOW()
      WHERE job_id = ${jobId} AND contractor_email = ${email}
    `);
    await db.execute(sql`UPDATE contractor_jobs SET status = 'completed' WHERE id = ${jobId}`);
    res.json({ ok: true });
  }, res);
});

router.get("/contractor/schedule", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const result = await db.execute(sql`
      SELECT j.*, cc.status as claim_status, cc.claimed_at
      FROM contractor_claims cc
      JOIN contractor_jobs j ON cc.job_id = j.id
      WHERE cc.contractor_email = ${email} AND cc.status IN ('claimed', 'in-progress')
      ORDER BY j.scheduled_date ASC, j.scheduled_time ASC
    `);
    const jobs = (result.rows as any[]).map(j => ({
      ...j,
      tags: (() => { try { return JSON.parse(j.tags || "[]"); } catch { return []; } })(),
    }));
    res.json({ jobs });
  }, res);
});

router.get("/contractor/earnings", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const completed = await db.execute(sql`
      SELECT j.*, cc.completed_at, cc.status as claim_status
      FROM contractor_claims cc
      JOIN contractor_jobs j ON cc.job_id = j.id
      WHERE cc.contractor_email = ${email} AND cc.status = 'completed'
      ORDER BY cc.completed_at DESC
    `);
    const jobs = completed.rows as any[];
    const totalEarned = jobs.reduce((sum, j) => sum + parseFloat(j.pay_amount || 0), 0);
    const byMonth: Record<string, number> = {};
    for (const j of jobs) {
      const d = j.completed_at ? new Date(j.completed_at) : new Date();
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      byMonth[key] = (byMonth[key] || 0) + parseFloat(j.pay_amount || 0);
    }
    const months = Object.entries(byMonth)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, amount]) => ({
        month: new Date(month + "-01").toLocaleString("en-US", { month: "short", year: "2-digit" }),
        amount,
      }));
    const lastCompletedAt = jobs[0]?.completed_at || null;
    let nextPayoutEstimate: string | null = null;
    if (lastCompletedAt) {
      const payoutDate = new Date(lastCompletedAt);
      payoutDate.setHours(payoutDate.getHours() + 48);
      const now = new Date();
      nextPayoutEstimate = payoutDate > now
        ? payoutDate.toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })
        : "Processed";
    }
    res.json({
      totalEarned,
      jobsCompleted: jobs.length,
      byMonth: months,
      lastPayoutDate: lastCompletedAt,
      nextPayoutEstimate,
      history: jobs.map(j => ({
        id: j.id,
        title: j.title,
        category: j.category,
        pay: j.pay,
        pay_amount: j.pay_amount,
        completed_at: j.completed_at,
        client_name: j.client_name,
      })),
    });
  }, res);
});

router.get("/contractor/clients", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const result = await db.execute(sql`
      SELECT j.id as job_id, j.client_name, j.client_phone, j.category, j.title, j.location, cc.completed_at,
             r.rating, r.review
      FROM contractor_claims cc
      JOIN contractor_jobs j ON cc.job_id = j.id
      LEFT JOIN contractor_ratings r ON r.job_id = j.id AND r.contractor_email = ${email}
      WHERE cc.contractor_email = ${email} AND cc.status = 'completed'
      ORDER BY cc.completed_at DESC
    `);
    res.json({ clients: result.rows });
  }, res);
});

router.patch("/contractor/profile", async (req, res) => {
  await withDB(async () => {
    const auth = verifyContractorToken(req.headers.authorization);
    if (!auth.ok) { res.status(auth.status).json({ error: auth.error }); return; }
    const email = auth.email;
    const { bio, services, zip_code, photo_url, phone } = req.body;
    await db.execute(sql`
      UPDATE contractors SET
        bio = COALESCE(${bio !== undefined ? bio : null}, bio),
        services = COALESCE(${services !== undefined ? JSON.stringify(services) : null}, services),
        zip_code = COALESCE(${zip_code !== undefined ? zip_code : null}, zip_code),
        photo_url = COALESCE(${photo_url !== undefined ? photo_url : null}, photo_url),
        phone = COALESCE(${phone !== undefined ? phone : null}, phone)
      WHERE email = ${email}
    `);
    const row = await db.execute(sql`SELECT * FROM contractors WHERE email = ${email} LIMIT 1`);
    res.json({ contractor: (row.rows as any[])[0] });
  }, res);
});

export default router;
