import { Router } from "express";
import { stripe } from "../lib/stripe.js";

const router = Router();

const PARTNER_SERVICES = {
  pool_cleaning: {
    name: "BlueTruck Pool Care — Monthly Service",
    description: "Weekly visits · chemicals included · resort-ready pool year-round",
    amount: 9900,
    provider: "BlueTruck LLC",
    recurring: true,
  },
  lawn_care: {
    name: "Lawn Care Service — Per Visit",
    description: "Mow · edge · trim · cleanup · blowdown",
    amount: 4500,
    provider: "Layton's Lawncare / BlueTruck LLC",
    recurring: false,
  },
  pool_lawn_bundle: {
    name: "Pool + Lawn Bundle — Monthly (Save 15%)",
    description: "Weekly pool care + weekly lawn maintenance · best value · priority scheduling",
    amount: 18000,
    provider: "BlueTruck LLC",
    recurring: true,
  },
  handyman: {
    name: "Handyman Service — Assessment & First Hour",
    description: "Florida-licensed · plumbing, electrical, drywall, screen & door repairs",
    amount: 7500,
    provider: "BlueTruck LLC",
    recurring: false,
  },
};

router.post("/partner-checkout", async (req, res) => {
  const { service, customerName, customerEmail, customerPhone, propertyAddress, notes } = req.body;

  const svc = PARTNER_SERVICES[service as keyof typeof PARTNER_SERVICES];
  if (!svc) {
    res.status(400).json({ error: "Unknown service type" });
    return;
  }

  const origin = req.headers.origin || req.headers.referer?.replace(/\/$/, "") || "https://buyshare.co";
  const baseUrl = origin.includes("localhost") ? `http://localhost:${process.env.PORT || 3000}` : origin;

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: "usd",
          product_data: {
            name: svc.name,
            description: svc.description,
            metadata: {
              provider: svc.provider,
              propertyAddress: propertyAddress || "",
              customerPhone: customerPhone || "",
            },
          },
          unit_amount: svc.amount,
        },
        quantity: 1,
      },
    ],
    customer_email: customerEmail || undefined,
    metadata: {
      service,
      customerName: customerName || "",
      customerPhone: customerPhone || "",
      propertyAddress: propertyAddress || "",
      notes: notes || "",
      provider: svc.provider,
    },
    success_url: `${baseUrl}/partner-checkout/success?service=${encodeURIComponent(svc.name)}&provider=${encodeURIComponent(svc.provider)}`,
    cancel_url: `${baseUrl}/${service.includes("pool") ? "poolshare" : service.includes("lawn") || service.includes("bundle") ? "yardshare" : "roomshare"}`,
  });

  res.json({ url: session.url, sessionId: session.id });
});

export default router;
