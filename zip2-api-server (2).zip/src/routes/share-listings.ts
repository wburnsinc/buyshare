import { Router } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { stripe } from "../lib/stripe.js";
import { randomUUID } from "crypto";

const router = Router();

async function ensureTables() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS share_listings (
      id SERIAL PRIMARY KEY,
      share_type TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      address TEXT,
      city TEXT DEFAULT 'Punta Gorda',
      price_per_hour NUMERIC(10,2),
      price_per_day NUMERIC(10,2),
      max_guests INTEGER,
      amenities TEXT[],
      rules TEXT,
      host_name TEXT,
      host_email TEXT,
      photo_urls TEXT[],
      status TEXT NOT NULL DEFAULT 'active',
      average_rating NUMERIC(3,2),
      review_count INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  await db.execute(sql`
    ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS host_email TEXT
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS share_bookings (
      id SERIAL PRIMARY KEY,
      listing_id INTEGER REFERENCES share_listings(id),
      share_type TEXT NOT NULL,
      guest_name TEXT NOT NULL,
      guest_email TEXT,
      guest_phone TEXT,
      start_date TIMESTAMPTZ,
      end_date TIMESTAMPTZ,
      guest_count INTEGER DEFAULT 1,
      message TEXT,
      amount_cents INTEGER DEFAULT 0,
      stripe_session_id TEXT,
      stripe_payment_status TEXT DEFAULT 'pending',
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  await db.execute(sql`ALTER TABLE share_bookings ADD COLUMN IF NOT EXISTS amount_cents INTEGER DEFAULT 0`);
  await db.execute(sql`ALTER TABLE share_bookings ADD COLUMN IF NOT EXISTS stripe_session_id TEXT`);
  await db.execute(sql`ALTER TABLE share_bookings ADD COLUMN IF NOT EXISTS stripe_payment_status TEXT DEFAULT 'pending'`);
  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS photo_urls TEXT[]`);
  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS stripe_account_id TEXT`);
  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS onboard_token TEXT`);
}

let tablesReady = false;

async function withTables(fn: () => Promise<void>, res: any) {
  try {
    if (!tablesReady) {
      await ensureTables();
      tablesReady = true;
    }
    await fn();
  } catch (err: any) {
    console.error("share-listings error:", err);
    res.status(500).json({ error: err.message || "Server error" });
  }
}

async function sendEmail(to: string, subject: string, html: string) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.log(`[share-bookings] Email skipped (no RESEND_API_KEY). To: ${to} — ${subject}`);
    return;
  }
  try {
    const from = process.env.RESEND_FROM_EMAIL
      ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
      : "Buyshare <onboarding@resend.dev>";
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from, to, subject, html }),
    });
    if (!response.ok) {
      const body = await response.text();
      console.error(`[share-bookings] Resend error ${response.status}: ${body}`);
    } else {
      console.log(`[share-bookings] Email sent via Resend. To: ${to} — ${subject}`);
    }
  } catch (err) {
    console.error("[share-bookings] Email error:", err);
  }
}

const SHARE_LABELS: Record<string, string> = {
  pool: "PoolShare",
  boat: "BoatShare",
  yard: "YardShare",
  room: "RoomShare",
  park: "ParkShare",
  rv: "RVShare",
};

function formatDate(d: Date | string | null) {
  if (!d) return "TBD";
  return new Date(d).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
}

function formatCents(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

// GET /api/share-listings?shareType=pool
router.get("/share-listings", async (req, res) => {
  await withTables(async () => {
    const shareType = req.query.shareType as string;
    if (!shareType) {
      res.status(400).json({ error: "shareType query param required" });
      return;
    }
    const rows = await db.execute(
      sql`SELECT * FROM share_listings WHERE share_type = ${shareType} AND status = 'active' ORDER BY created_at DESC`
    );
    const listings = rows.rows.map((r: any) => ({
      id: r.id,
      shareType: r.share_type,
      title: r.title,
      description: r.description,
      address: r.address,
      city: r.city,
      pricePerHour: r.price_per_hour,
      pricePerDay: r.price_per_day,
      maxGuests: r.max_guests,
      amenities: r.amenities,
      rules: r.rules,
      hostName: r.host_name,
      photoUrls: r.photo_urls,
      averageRating: r.average_rating,
      reviewCount: r.review_count,
      createdAt: r.created_at,
    }));
    res.json({ listings });
  }, res);
});

// POST /api/share-listings
router.post("/share-listings", async (req, res) => {
  await withTables(async () => {
    const { shareType, title, description, address, city, pricePerHour, pricePerDay, maxGuests, amenities, rules, hostName, hostEmail, photoUrls } = req.body;
    if (!shareType || !title) {
      res.status(400).json({ error: "shareType and title are required" });
      return;
    }
    // Convert JS arrays to PostgreSQL array literals (e.g. ["a","b"] → '{"a","b"}')
    function toPgArray(arr: string[] | null | undefined): string | null {
      if (!Array.isArray(arr) || arr.length === 0) return null;
      const escaped = arr.map(s => `"${String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`);
      return `{${escaped.join(",")}}`;
    }
    const photoParam = toPgArray(Array.isArray(photoUrls) ? photoUrls : null);
    const amenitiesParam = toPgArray(Array.isArray(amenities) ? amenities : null);
    const onboardToken = randomUUID();
    const result = await db.execute(
      sql`INSERT INTO share_listings (share_type, title, description, address, city, price_per_hour, price_per_day, max_guests, amenities, rules, host_name, host_email, photo_urls, status, onboard_token)
          VALUES (${shareType}, ${title}, ${description || null}, ${address || null}, ${city || "Punta Gorda"},
                  ${pricePerHour ? Number(pricePerHour) : null}, ${pricePerDay ? Number(pricePerDay) : null},
                  ${maxGuests ? Number(maxGuests) : null}, ${amenitiesParam}::text[], ${rules || null},
                  ${hostName || "Anonymous"}, ${hostEmail || null}, ${photoParam}::text[], 'pending', ${onboardToken})
          RETURNING *`
    );
    const r = result.rows[0] as any;
    res.status(201).json({
      listing: {
        id: r.id, shareType: r.share_type, title: r.title, description: r.description,
        address: r.address, city: r.city, pricePerHour: r.price_per_hour, pricePerDay: r.price_per_day,
        maxGuests: r.max_guests, amenities: r.amenities, rules: r.rules, hostName: r.host_name,
        photoUrls: r.photo_urls, status: r.status, createdAt: r.created_at,
        onboardToken: r.onboard_token,
      }
    });
  }, res);
});

// POST /api/share-bookings/checkout — create Stripe Checkout Session + pending booking
router.post("/share-bookings/checkout", async (req, res) => {
  await withTables(async () => {
    const {
      listingId, shareType, guestName, guestEmail, guestPhone,
      startDate, endDate, guestCount, message,
    } = req.body;

    if (!shareType || !guestName || !guestEmail) {
      res.status(400).json({ error: "shareType, guestName, and guestEmail are required" });
      return;
    }

    let listing: any = null;
    if (listingId) {
      const row = await db.execute(sql`SELECT * FROM share_listings WHERE id = ${Number(listingId)} LIMIT 1`);
      listing = (row.rows as any[])[0] || null;
    }

    const shareLabel = SHARE_LABELS[shareType] || shareType;

    let amountCents = 0;
    let productName = listing?.title || shareLabel + " Booking";
    let productDescription = "";

    if (listing && startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const msPerHour = 1000 * 60 * 60;
      const msPerDay = msPerHour * 24;
      const ms = end.getTime() - start.getTime();

      if (listing.price_per_hour && ms < msPerDay) {
        const hours = Math.max(1, Math.ceil(ms / msPerHour));
        amountCents = Math.round(Number(listing.price_per_hour) * hours * 100);
        productDescription = `${hours} hour${hours > 1 ? "s" : ""} · ${formatDate(startDate)}`;
      } else if (listing.price_per_day) {
        const days = Math.max(1, Math.ceil(ms / msPerDay));
        amountCents = Math.round(Number(listing.price_per_day) * days * 100);
        productDescription = `${days} day${days > 1 ? "s" : ""} · ${formatDate(startDate)} – ${formatDate(endDate)}`;
      } else if (listing.price_per_hour) {
        const hours = Math.max(1, Math.ceil(ms / msPerHour));
        amountCents = Math.round(Number(listing.price_per_hour) * hours * 100);
        productDescription = `${hours} hour${hours > 1 ? "s" : ""} · ${formatDate(startDate)}`;
      }
    }

    if (amountCents < 50) {
      res.status(400).json({ error: "Booking amount is too low. Please select valid dates and a priced listing." });
      return;
    }

    const platformFeePercent = 0.10;
    const platformFeeCents = Math.round(amountCents * platformFeePercent);
    const hostStripeAccountId: string | undefined = listing?.stripe_account_id || undefined;

    const origin = req.headers.origin || req.headers.referer?.replace(/\/[^/]*$/, "") || "https://buyshare.co";
    const baseUrl = origin.includes("localhost") || origin.includes("repl") ? origin : "https://buyshare.co";

    const sessionParams: Parameters<typeof stripe.checkout.sessions.create>[0] = {
      mode: "payment",
      payment_method_types: ["card"],
      customer_email: guestEmail,
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: `${shareLabel} — ${productName}`,
              description: productDescription || `Booking on Buyshare.co`,
            },
            unit_amount: amountCents,
          },
          quantity: 1,
        },
        ...(!hostStripeAccountId && platformFeeCents > 0 ? [{
          price_data: {
            currency: "usd",
            product_data: {
              name: "Buyshare Service Fee (10%)",
              description: "Platform booking fee",
            },
            unit_amount: platformFeeCents,
          },
          quantity: 1,
        }] : []),
      ],
      metadata: {
        shareType,
        listingId: String(listingId || ""),
        guestName,
        guestEmail,
        guestPhone: guestPhone || "",
        guestCount: String(guestCount || 1),
        startDate: startDate || "",
        endDate: endDate || "",
        message: message || "",
        amountCents: String(amountCents),
        hostEmail: listing?.host_email || "",
      },
      success_url: `${baseUrl}/share-booking-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/${shareType}share`,
    };

    if (hostStripeAccountId && platformFeeCents > 0) {
      sessionParams.payment_intent_data = {
        application_fee_amount: platformFeeCents,
        transfer_data: { destination: hostStripeAccountId },
      };
    }

    const session = await stripe.checkout.sessions.create(sessionParams);

    const insertResult = await db.execute(sql`
      INSERT INTO share_bookings
        (listing_id, share_type, guest_name, guest_email, guest_phone, start_date, end_date, guest_count, message, amount_cents, stripe_session_id, stripe_payment_status, status)
      VALUES
        (${listingId ? Number(listingId) : null}, ${shareType}, ${guestName}, ${guestEmail}, ${guestPhone || null},
         ${startDate || null}, ${endDate || null}, ${Number(guestCount) || 1}, ${message || null},
         ${amountCents}, ${session.id}, 'pending', 'pending')
      RETURNING id
    `);

    const bookingId = (insertResult.rows as any[])[0]?.id;

    res.json({ url: session.url, sessionId: session.id, bookingId, amountCents });
  }, res);
});

// GET /api/share-bookings/confirm?session_id=X — called on success page to confirm payment + send emails
router.get("/share-bookings/confirm", async (req, res) => {
  await withTables(async () => {
    const { session_id } = req.query as { session_id?: string };
    if (!session_id) {
      res.status(400).json({ error: "session_id required" });
      return;
    }

    const session = await stripe.checkout.sessions.retrieve(session_id);

    const bookingRow = await db.execute(sql`
      SELECT sb.*, sl.title as listing_title, sl.host_name, sl.host_email, sl.address, sl.city
      FROM share_bookings sb
      LEFT JOIN share_listings sl ON sb.listing_id = sl.id
      WHERE sb.stripe_session_id = ${session_id}
      LIMIT 1
    `);
    const booking = (bookingRow.rows as any[])[0];

    if (!booking) {
      res.status(404).json({ error: "Booking not found" });
      return;
    }

    const paid = session.payment_status === "paid";
    const newStatus = paid ? "confirmed" : "pending";

    if (booking.stripe_payment_status !== "paid") {
      await db.execute(sql`
        UPDATE share_bookings
        SET stripe_payment_status = ${paid ? "paid" : "pending"}, status = ${newStatus}
        WHERE stripe_session_id = ${session_id}
      `);

      if (paid) {
        const shareLabel = SHARE_LABELS[booking.share_type] || booking.share_type;
        const listingTitle = booking.listing_title || shareLabel;
        const dateRange = booking.start_date
          ? `${formatDate(booking.start_date)}${booking.end_date ? " – " + formatDate(booking.end_date) : ""}`
          : "Dates TBD";

        const guestHtml = `
          <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
            <h2 style="color:#0E7490">Your ${shareLabel} booking is confirmed!</h2>
            <p>Hi <strong>${booking.guest_name}</strong>,</p>
            <p>Your booking on Buyshare.co has been confirmed. Here's a summary:</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0">
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Listing</td><td style="padding:8px;border-bottom:1px solid #eee;font-weight:bold">${listingTitle}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Dates</td><td style="padding:8px;border-bottom:1px solid #eee">${dateRange}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Guests</td><td style="padding:8px;border-bottom:1px solid #eee">${booking.guest_count}</td></tr>
              <tr><td style="padding:8px;color:#666">Total Paid</td><td style="padding:8px;font-weight:bold;color:#059669">${formatCents(booking.amount_cents)}</td></tr>
            </table>
            ${booking.address ? `<p style="color:#666">Location: ${booking.address}${booking.city ? ", " + booking.city : ""}</p>` : ""}
            ${booking.message ? `<p style="color:#666">Your message: <em>${booking.message}</em></p>` : ""}
            <p>The host will be in touch to confirm details. Questions? Reply to this email or call (223) 254-8299.</p>
            <p style="color:#999;font-size:12px">Buyshare.co — Charlotte County's Sharing Marketplace</p>
          </div>
        `;

        const ownerHtml = `
          <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
            <h2 style="color:#0E7490">New ${shareLabel} Booking Request!</h2>
            <p>You have a new paid booking on Buyshare.co for <strong>${listingTitle}</strong>.</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0">
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Guest</td><td style="padding:8px;border-bottom:1px solid #eee;font-weight:bold">${booking.guest_name}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Email</td><td style="padding:8px;border-bottom:1px solid #eee"><a href="mailto:${booking.guest_email}">${booking.guest_email}</a></td></tr>
              ${booking.guest_phone ? `<tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Phone</td><td style="padding:8px;border-bottom:1px solid #eee">${booking.guest_phone}</td></tr>` : ""}
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Dates</td><td style="padding:8px;border-bottom:1px solid #eee">${dateRange}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Guests</td><td style="padding:8px;border-bottom:1px solid #eee">${booking.guest_count}</td></tr>
              <tr><td style="padding:8px;color:#666">Amount Paid</td><td style="padding:8px;font-weight:bold;color:#059669">${formatCents(booking.amount_cents)}</td></tr>
            </table>
            ${booking.message ? `<p><strong>Guest message:</strong> <em>${booking.message}</em></p>` : ""}
            <p>Please contact your guest to confirm the details. Payout will be processed after the booking is complete.</p>
            <p style="color:#999;font-size:12px">Buyshare.co — Charlotte County's Sharing Marketplace</p>
          </div>
        `;

        const adminHtml = `
          <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
            <h2>New ${shareLabel} Booking — Admin Alert</h2>
            <p>A new paid ${shareLabel} booking was made on Buyshare.co.</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0">
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Booking ID</td><td style="padding:8px;border-bottom:1px solid #eee">${booking.id}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Guest</td><td style="padding:8px;border-bottom:1px solid #eee">${booking.guest_name} (${booking.guest_email})</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Listing</td><td style="padding:8px;border-bottom:1px solid #eee">${listingTitle}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;color:#666">Dates</td><td style="padding:8px;border-bottom:1px solid #eee">${dateRange}</td></tr>
              <tr><td style="padding:8px;color:#666">Total</td><td style="padding:8px;font-weight:bold">${formatCents(booking.amount_cents)}</td></tr>
            </table>
          </div>
        `;

        await Promise.all([
          sendEmail(booking.guest_email, `Your ${shareLabel} booking is confirmed! — Buyshare.co`, guestHtml),
          ...(booking.host_email ? [sendEmail(booking.host_email, `New booking for your ${shareLabel} listing — Buyshare.co`, ownerHtml)] : []),
          sendEmail("admin@buyshare.co", `[Admin] New ${shareLabel} booking #${booking.id}`, adminHtml),
        ]);
      }
    }

    const updated = (await db.execute(sql`
      SELECT sb.*, sl.title as listing_title, sl.host_name, sl.address, sl.city
      FROM share_bookings sb
      LEFT JOIN share_listings sl ON sb.listing_id = sl.id
      WHERE sb.stripe_session_id = ${session_id}
      LIMIT 1
    `)).rows[0] as any;

    res.json({
      booking: {
        id: updated?.id,
        shareType: updated?.share_type,
        guestName: updated?.guest_name,
        guestEmail: updated?.guest_email,
        startDate: updated?.start_date,
        endDate: updated?.end_date,
        guestCount: updated?.guest_count,
        amountCents: updated?.amount_cents,
        status: updated?.status,
        stripePaymentStatus: updated?.stripe_payment_status,
        listingTitle: updated?.listing_title,
        hostName: updated?.host_name,
        address: updated?.address,
        city: updated?.city,
      },
      paid,
    });
  }, res);
});

// POST /api/share-bookings — legacy simple booking (no payment)
router.post("/share-bookings", async (req, res) => {
  await withTables(async () => {
    const { listingId, shareType, guestName, guestEmail, guestPhone, startDate, endDate, guestCount, message } = req.body;
    if (!shareType || !guestName) {
      res.status(400).json({ error: "shareType and guestName are required" });
      return;
    }
    const result = await db.execute(
      sql`INSERT INTO share_bookings (listing_id, share_type, guest_name, guest_email, guest_phone, start_date, end_date, guest_count, message)
          VALUES (${listingId || null}, ${shareType}, ${guestName}, ${guestEmail || null}, ${guestPhone || null},
                  ${startDate || null}, ${endDate || null}, ${guestCount ? Number(guestCount) : 1}, ${message || null})
          RETURNING *`
    );
    const r = result.rows[0] as any;
    res.status(201).json({
      booking: {
        id: r.id, shareType: r.share_type, guestName: r.guest_name,
        status: r.status, createdAt: r.created_at,
      },
      message: "Booking request sent! The host will contact you within 24 hours."
    });
  }, res);
});

// GET /api/share-bookings/by-email?email=X — guest lookup of their own bookings
router.get("/share-bookings/by-email", async (req, res) => {
  await withTables(async () => {
    const { email } = req.query as { email?: string };
    if (!email || !email.includes("@")) {
      res.status(400).json({ error: "A valid email address is required" });
      return;
    }
    const rows = await db.execute(sql`
      SELECT
        sb.id,
        sb.share_type,
        sb.guest_name,
        sb.guest_email,
        sb.start_date,
        sb.end_date,
        sb.guest_count,
        sb.amount_cents,
        sb.stripe_payment_status,
        sb.status,
        sb.created_at,
        sl.title    AS listing_title,
        sl.address  AS listing_address,
        sl.city     AS listing_city,
        sl.host_name,
        sl.host_email
      FROM share_bookings sb
      LEFT JOIN share_listings sl ON sb.listing_id = sl.id
      WHERE LOWER(sb.guest_email) = LOWER(${email})
      ORDER BY sb.created_at DESC
    `);
    const bookings = (rows.rows as any[]).map((r) => ({
      id: r.id,
      shareType: r.share_type,
      guestName: r.guest_name,
      guestEmail: r.guest_email,
      startDate: r.start_date,
      endDate: r.end_date,
      guestCount: r.guest_count,
      amountCents: r.amount_cents,
      stripePaymentStatus: r.stripe_payment_status,
      status: r.status,
      createdAt: r.created_at,
      listingTitle: r.listing_title,
      listingAddress: r.listing_address,
      listingCity: r.listing_city,
      hostName: r.host_name,
      hostEmail: r.host_email,
    }));
    res.json({ bookings });
  }, res);
});

// GET /api/share-bookings?shareType=X — admin listing of bookings
router.get("/share-bookings", async (req, res) => {
  await withTables(async () => {
    const { shareType } = req.query as { shareType?: string };
    const rows = shareType
      ? await db.execute(sql`SELECT sb.*, sl.title as listing_title FROM share_bookings sb LEFT JOIN share_listings sl ON sb.listing_id = sl.id WHERE sb.share_type = ${shareType} ORDER BY sb.created_at DESC`)
      : await db.execute(sql`SELECT sb.*, sl.title as listing_title FROM share_bookings sb LEFT JOIN share_listings sl ON sb.listing_id = sl.id ORDER BY sb.created_at DESC`);
    res.json({ bookings: rows.rows });
  }, res);
});

export default router;
