import { Router } from "express";
import { db } from "@workspace/db";
import { listingsTable, usersTable, reviewsTable } from "@workspace/db";
import { eq, and, ilike, or, lte, sql } from "drizzle-orm";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";

const router = Router();

const uploadDir = "./public/uploads/listings";
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (_req, file, cb) => cb(null, `${randomUUID()}${path.extname(file.originalname)}`),
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

router.get("/listings", async (req, res) => {
  try {
    const { category, search, deliveryAvailable, maxDailyRate, verifiedOnly } = req.query as Record<string, string>;

    let rows = await db
      .select({
        listing: listingsTable,
        owner: usersTable,
      })
      .from(listingsTable)
      .leftJoin(usersTable, eq(listingsTable.ownerId, usersTable.id))
      .where(eq(listingsTable.status, "available"));

    if (category) {
      rows = rows.filter((r) => r.listing.category === category);
    }
    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter(
        (r) =>
          r.listing.title.toLowerCase().includes(q) ||
          r.listing.description.toLowerCase().includes(q) ||
          r.listing.location.toLowerCase().includes(q),
      );
    }
    if (deliveryAvailable === "true") {
      rows = rows.filter((r) => r.listing.deliveryAvailable);
    }
    if (maxDailyRate) {
      rows = rows.filter((r) => r.listing.dailyRate <= parseInt(maxDailyRate) * 100);
    }
    if (verifiedOnly === "true") {
      rows = rows.filter((r) => r.owner?.isVerified);
    }

    const result = rows.map((r) => ({ ...r.listing, owner: r.owner, averageRating: 0, reviewCount: 0 }));
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.post("/listings", async (req, res) => {
  try {
    const body = req.body;
    const id = body.id ?? randomUUID();
    const [listing] = await db
      .insert(listingsTable)
      .values({
        id,
        ownerId: body.ownerId,
        title: body.title,
        description: body.description,
        category: body.category ?? "other",
        dailyRate: body.dailyRate,
        weekendRate: body.weekendRate,
        weeklyRate: body.weeklyRate,
        securityDeposit: body.securityDeposit ?? 0,
        location: body.location,
        latitude: body.latitude,
        longitude: body.longitude,
        deliveryAvailable: body.deliveryAvailable ?? false,
        deliveryFee: body.deliveryFee,
        deliveryRadiusMiles: body.deliveryRadiusMiles,
        requiresVerified: body.requiresVerified ?? false,
      })
      .returning();
    res.status(201).json(listing);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.get("/listings/:id", async (req, res) => {
  try {
    const [row] = await db
      .select({ listing: listingsTable, owner: usersTable })
      .from(listingsTable)
      .leftJoin(usersTable, eq(listingsTable.ownerId, usersTable.id))
      .where(eq(listingsTable.id, req.params.id))
      .limit(1);

    if (!row) { res.status(404).json({ error: "Listing not found" }); return; }

    // increment view count
    await db
      .update(listingsTable)
      .set({ viewCount: sql`${listingsTable.viewCount} + 1` })
      .where(eq(listingsTable.id, req.params.id));

    const reviews = await db.select().from(reviewsTable).where(eq(reviewsTable.listingId, req.params.id));
    const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

    res.json({ ...row.listing, owner: row.owner, averageRating: avgRating, reviewCount: reviews.length });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.patch("/listings/:id", async (req, res) => {
  try {
    const body = req.body;
    const requesterId = body.requesterId as string | undefined;

    const [existing] = await db.select().from(listingsTable).where(eq(listingsTable.id, req.params.id)).limit(1);
    if (!existing) { res.status(404).json({ error: "Listing not found" }); return; }
    if (requesterId && existing.ownerId !== requesterId) {
      res.status(403).json({ error: "Forbidden" }); return;
    }

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    const allowed = ["title", "description", "category", "dailyRate", "weekendRate", "weeklyRate",
      "securityDeposit", "status", "location", "deliveryAvailable", "deliveryFee", "deliveryRadiusMiles", "requiresVerified"];
    for (const key of allowed) {
      if (body[key] !== undefined) updates[key] = body[key];
    }
    const [listing] = await db.update(listingsTable).set(updates).where(eq(listingsTable.id, req.params.id)).returning();
    res.json(listing);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.delete("/listings/:id", async (req, res) => {
  try {
    const requesterId = (req.query.requesterId || req.body?.requesterId) as string | undefined;
    const [existing] = await db.select().from(listingsTable).where(eq(listingsTable.id, req.params.id)).limit(1);
    if (!existing) { res.status(404).json({ error: "Listing not found" }); return; }
    if (requesterId && existing.ownerId !== requesterId) {
      res.status(403).json({ error: "Forbidden" }); return;
    }
    await db.delete(listingsTable).where(eq(listingsTable.id, req.params.id));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.post("/listings/:id/photos", upload.array("photos", 10), async (req, res) => {
  try {
    if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
      res.status(400).json({ error: "No photos uploaded" }); return;
    }
    const urls = (req.files as Express.Multer.File[]).map((f) => `/uploads/listings/${f.filename}`);
    const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, req.params.id)).limit(1);
    if (!listing) { res.status(404).json({ error: "Listing not found" }); return; }
    const updatedPhotos = [...(listing.photos ?? []), ...urls];
    await db.update(listingsTable).set({ photos: updatedPhotos, updatedAt: new Date() }).where(eq(listingsTable.id, req.params.id));
    res.json({ urls });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

export default router;
