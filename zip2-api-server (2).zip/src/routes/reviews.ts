import { Router } from "express";
import { db } from "@workspace/db";
import { reviewsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

const router = Router();

router.post("/reviews", async (req, res) => {
  try {
    const body = req.body;
    const id = body.id ?? randomUUID();
    const [review] = await db.insert(reviewsTable).values({
      id,
      bookingId: body.bookingId,
      reviewerId: body.reviewerId,
      revieweeId: body.revieweeId,
      listingId: body.listingId,
      rating: body.rating,
      comment: body.comment,
    }).returning();
    res.status(201).json(review);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

router.get("/reviews/listing/:listingId", async (req, res) => {
  try {
    const rows = await db
      .select({ review: reviewsTable, reviewer: usersTable })
      .from(reviewsTable)
      .leftJoin(usersTable, eq(reviewsTable.reviewerId, usersTable.id))
      .where(eq(reviewsTable.listingId, req.params.listingId));
    res.json(rows.map((r) => ({ ...r.review, reviewer: r.reviewer })));
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

export default router;
