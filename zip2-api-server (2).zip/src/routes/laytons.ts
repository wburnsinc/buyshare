import { Router } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { requireMasterAdmin } from "../middleware/auth.js";
import nodemailer from "nodemailer";
import { stripe } from "../lib/stripe.js";

const SERVICE_PRICES: Record<string, { name: string; cents: number }> = {
  "mow-edge":      { name: "Mow & Edge",          cents: 4500 },
  "full-lawn":     { name: "Full Lawn Care",       cents: 7500 },
  "fertilization": { name: "Fertilization",        cents: 5500 },
  "hedge-trim":    { name: "Hedge Trim",           cents: 6000 },
  "cleanup":       { name: "Yard Cleanup",         cents: 8000 },
  "mulch":         { name: "Mulch Installation",   cents: 12000 },
};

const router = Router();

async function initTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS laytons_bookings (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      service TEXT NOT NULL,
      address TEXT NOT NULL,
      preferred_date TEXT NOT NULL,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await db.execute(sql`ALTER TABLE laytons_bookings ADD COLUMN IF NOT EXISTS stripe_session_id TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE laytons_bookings ADD COLUMN IF NOT EXISTS stripe_payment_status TEXT DEFAULT 'pending'`).catch(() => {});
  await db.execute(sql`ALTER TABLE laytons_bookings ADD COLUMN IF NOT EXISTS amount_cents INTEGER DEFAULT 0`).catch(() => {});
}

function getTransport() {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!host || !user || !pass) return null;
  return nodemailer.createTransport({
    host,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user, pass },
  });
}

async function sendEmail(to: string, subject: string, html: string) {
  const transport = getTransport();
  if (!transport) {
    console.log(`[laytons] Email skipped (no SMTP config). To: ${to} — ${subject}`);
    return;
  }
  try {
    await transport.sendMail({
      from: process.env.SMTP_FROM || "noreply@buyshare.co",
      to,
      subject,
      html,
    });
  } catch (err) {
    console.error("[laytons] Email error:", err);
  }
}

function bookingConfirmationHtml(booking: any) {
  return `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
      <div style="text-align:center;margin-bottom:24px;">
        <span style="font-size:28px;font-weight:700;letter-spacing:-1px;">🌿 Layton's Lawncare</span>
      </div>
      <h2 style="color:#2d6a2d;margin-bottom:4px;">Booking Request Received!</h2>
      <p style="color:#555;margin-top:0;">Hi ${booking.name}, thanks for reaching out. We've received your lawn care request and will be in touch shortly to confirm your appointment.</p>
      <div style="background:#ffffff;border:1px solid #e0e0e0;border-radius:6px;padding:20px;margin:20px 0;">
        <h3 style="color:#2d6a2d;margin-top:0;">Booking Details</h3>
        <table style="width:100%;border-collapse:collapse;font-size:15px;">
          <tr><td style="padding:6px 0;color:#888;width:140px;">Service</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.service}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Preferred Date</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.preferred_date}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Address</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.address}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Phone</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.phone}</td></tr>
          ${booking.notes ? `<tr><td style="padding:6px 0;color:#888;">Notes</td><td style="padding:6px 0;color:#222;">${booking.notes}</td></tr>` : ""}
        </table>
      </div>
      <div style="text-align:center;margin:28px 0;">
        <a href="https://buyshare.co/laytons/track" style="display:inline-block;background:#2d6a2d;color:#ffffff;font-size:16px;font-weight:700;text-decoration:none;padding:14px 32px;border-radius:8px;letter-spacing:0.3px;">🌿 Track My Booking</a>
      </div>
      <p style="color:#555;font-size:14px;text-align:center;margin-top:0;">Use your email address to check your booking status anytime.</p>
      <p style="color:#555;">Questions? Call or text us at <a href="tel:+19414801074" style="color:#2d6a2d;font-weight:600;">(941) 480-1074</a>.</p>
      <hr style="border:none;border-top:1px solid #e0e0e0;margin:24px 0;">
      <p style="color:#aaa;font-size:12px;text-align:center;">Layton's Lawncare · Punta Gorda, FL · Powered by <a href="https://buyshare.co" style="color:#aaa;">Buyshare.co</a></p>
    </div>
  `;
}

function statusUpdateHtml(booking: any, newStatus: string) {
  const isConfirmed = newStatus === "confirmed";
  const isCompleted = newStatus === "completed";
  const isCancelled = newStatus === "cancelled";

  let heading = "";
  let message = "";
  let color = "#2d6a2d";

  if (isConfirmed) {
    heading = "Your Appointment is Confirmed! ✅";
    message = "Great news — your lawn care appointment has been confirmed. We'll see you soon!";
    color = "#2d6a2d";
  } else if (isCompleted) {
    heading = "Service Complete — Thanks for Choosing Layton's! 🌿";
    message = "Your lawn care service has been completed. We hope you love the results! Feel free to reach out if you have any questions.";
    color = "#2d6a2d";
  } else if (isCancelled) {
    heading = "Booking Cancelled";
    message = "Your booking has been cancelled. Please contact us if you'd like to reschedule.";
    color = "#c0392b";
  } else {
    heading = `Booking Update: ${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}`;
    message = `Your booking status has been updated to <strong>${newStatus}</strong>.`;
    color = "#555";
  }

  return `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
      <div style="text-align:center;margin-bottom:24px;">
        <span style="font-size:28px;font-weight:700;letter-spacing:-1px;">🌿 Layton's Lawncare</span>
      </div>
      <h2 style="color:${color};margin-bottom:4px;">${heading}</h2>
      <p style="color:#555;margin-top:0;">Hi ${booking.name}, ${message}</p>
      <div style="background:#ffffff;border:1px solid #e0e0e0;border-radius:6px;padding:20px;margin:20px 0;">
        <h3 style="color:#2d6a2d;margin-top:0;">Booking Details</h3>
        <table style="width:100%;border-collapse:collapse;font-size:15px;">
          <tr><td style="padding:6px 0;color:#888;width:140px;">Service</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.service}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Preferred Date</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.preferred_date}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Address</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.address}</td></tr>
          ${booking.admin_notes ? `<tr><td style="padding:6px 0;color:#888;">Note from us</td><td style="padding:6px 0;color:#222;">${booking.admin_notes}</td></tr>` : ""}
        </table>
      </div>
      <div style="text-align:center;margin:28px 0;">
        <a href="https://buyshare.co/laytons/track" style="display:inline-block;background:#2d6a2d;color:#ffffff;font-size:16px;font-weight:700;text-decoration:none;padding:14px 32px;border-radius:8px;letter-spacing:0.3px;">🌿 Track My Booking</a>
      </div>
      <p style="color:#555;">Questions? Call or text us at <a href="tel:+19414801074" style="color:#2d6a2d;font-weight:600;">(941) 480-1074</a>.</p>
      <hr style="border:none;border-top:1px solid #e0e0e0;margin:24px 0;">
      <p style="color:#aaa;font-size:12px;text-align:center;">Layton's Lawncare · Punta Gorda, FL · Powered by <a href="https://buyshare.co" style="color:#aaa;">Buyshare.co</a></p>
    </div>
  `;
}

function adminBookingNotificationHtml(booking: any) {
  return `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
      <div style="text-align:center;margin-bottom:24px;">
        <span style="font-size:28px;font-weight:700;letter-spacing:-1px;">🌿 Layton's Lawncare</span>
      </div>
      <h2 style="color:#2d6a2d;margin-bottom:4px;">New Booking Request</h2>
      <p style="color:#555;margin-top:0;">A new lawn care booking has been submitted. Review the details below and confirm or update the status from your admin panel.</p>
      <div style="background:#ffffff;border:1px solid #e0e0e0;border-radius:6px;padding:20px;margin:20px 0;">
        <h3 style="color:#2d6a2d;margin-top:0;">Customer & Booking Details</h3>
        <table style="width:100%;border-collapse:collapse;font-size:15px;">
          <tr><td style="padding:6px 0;color:#888;width:140px;">Name</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.name}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Email</td><td style="padding:6px 0;font-weight:600;color:#222;"><a href="mailto:${booking.email}" style="color:#2d6a2d;">${booking.email}</a></td></tr>
          <tr><td style="padding:6px 0;color:#888;">Phone</td><td style="padding:6px 0;font-weight:600;color:#222;"><a href="tel:${booking.phone}" style="color:#2d6a2d;">${booking.phone}</a></td></tr>
          <tr><td style="padding:6px 0;color:#888;">Service</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.service}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Preferred Date</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.preferred_date}</td></tr>
          <tr><td style="padding:6px 0;color:#888;">Address</td><td style="padding:6px 0;font-weight:600;color:#222;">${booking.address}</td></tr>
          ${booking.notes ? `<tr><td style="padding:6px 0;color:#888;">Notes</td><td style="padding:6px 0;color:#222;">${booking.notes}</td></tr>` : ""}
        </table>
      </div>
      <div style="text-align:center;margin:28px 0;">
        <a href="https://buyshare.co/admin/laytons" style="display:inline-block;background:#2d6a2d;color:#ffffff;font-size:16px;font-weight:700;text-decoration:none;padding:14px 32px;border-radius:8px;letter-spacing:0.3px;">Manage Bookings</a>
      </div>
      <hr style="border:none;border-top:1px solid #e0e0e0;margin:24px 0;">
      <p style="color:#aaa;font-size:12px;text-align:center;">Layton's Lawncare · Punta Gorda, FL · Powered by <a href="https://buyshare.co" style="color:#aaa;">Buyshare.co</a></p>
    </div>
  `;
}

router.post("/laytons/book", async (req, res) => {
  try {
    await initTable();
    const { name, email, phone, service, address, preferred_date, notes } = req.body;
    if (!name || !email || !phone || !service || !address || !preferred_date) {
      res.status(400).json({ error: "All fields are required" });
      return;
    }

    const svcInfo = SERVICE_PRICES[service];
    if (!svcInfo) {
      res.status(400).json({ error: "Unknown service type" });
      return;
    }

    const result = await db.execute(sql`
      INSERT INTO laytons_bookings (name, email, phone, service, address, preferred_date, notes, status, amount_cents)
      VALUES (${name}, ${email}, ${phone}, ${service}, ${address}, ${preferred_date}, ${notes || null}, 'pending_payment', ${svcInfo.cents})
      RETURNING *
    `);
    const booking = (result.rows as any[])[0];

    const origin = req.headers.origin || req.headers.referer?.replace(/\/[^/]*$/, "") || "https://buyshare.co";
    const baseUrl = origin.includes("localhost") || origin.includes("repl") ? origin : "https://buyshare.co";

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: email,
      line_items: [
        {
          quantity: 1,
          price_data: {
            currency: "usd",
            unit_amount: svcInfo.cents,
            product_data: {
              name: `Layton's Lawncare — ${svcInfo.name}`,
              description: `Service at ${address} on ${preferred_date}`,
            },
          },
        },
      ],
      metadata: { bookingId: booking.id, bookingType: "layton" },
      success_url: `${baseUrl}/laytons?payment=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/laytons?payment=cancelled`,
    });

    await db.execute(sql`
      UPDATE laytons_bookings
      SET stripe_session_id = ${session.id}
      WHERE id = ${booking.id}
    `);

    res.json({ url: session.url, bookingId: booking.id });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/laytons/payment-status", async (req, res) => {
  try {
    await initTable();
    const { session_id } = req.query as { session_id?: string };
    if (!session_id) { res.status(400).json({ error: "session_id required" }); return; }

    const session = await stripe.checkout.sessions.retrieve(session_id);
    const paid = session.payment_status === "paid";

    const existing = await db.execute(sql`
      SELECT * FROM laytons_bookings WHERE stripe_session_id = ${session_id} LIMIT 1
    `);
    const booking = (existing.rows as any[])[0];
    if (!booking) { res.status(404).json({ error: "Booking not found" }); return; }

    if (paid && booking.stripe_payment_status !== "paid") {
      await db.execute(sql`
        UPDATE laytons_bookings
        SET stripe_payment_status = 'paid', status = 'pending', updated_at = NOW()
        WHERE stripe_session_id = ${session_id}
      `);

      sendEmail(
        booking.email,
        "Booking Confirmed — Layton's Lawncare",
        bookingConfirmationHtml({ ...booking, status: "pending" })
      ).catch(() => {});

      const adminEmail = process.env.LAYTONS_ADMIN_EMAIL || "burnsinc@outlook.com";
      sendEmail(
        adminEmail,
        `Payment Received — Layton's Booking from ${booking.name}`,
        adminBookingNotificationHtml({ ...booking, status: "pending" })
      ).catch(() => {});
    }

    const updatedRow = await db.execute(sql`
      SELECT * FROM laytons_bookings WHERE stripe_session_id = ${session_id} LIMIT 1
    `);
    res.json({ booking: (updatedRow.rows as any[])[0], paid });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function getAllBookings(_req: any, res: any) {
  try {
    await initTable();
    const result = await db.execute(sql`SELECT * FROM laytons_bookings ORDER BY created_at DESC`);
    const bookings = result.rows as any[];
    const stats = {
      total: bookings.length,
      pending: bookings.filter(b => b.status === "pending").length,
      confirmed: bookings.filter(b => b.status === "confirmed").length,
      completed: bookings.filter(b => b.status === "completed").length,
      cancelled: bookings.filter(b => b.status === "cancelled").length,
    };
    res.json({ bookings, stats });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
}

router.get("/laytons/status", async (req, res) => {
  try {
    await initTable();
    const email = (req.query.email as string || "").trim().toLowerCase();
    if (!email) {
      res.status(400).json({ error: "email is required" });
      return;
    }
    const result = await db.execute(sql`
      SELECT id, name, service, address, preferred_date, notes, status, admin_notes, created_at, updated_at
      FROM laytons_bookings
      WHERE LOWER(email) = ${email}
      ORDER BY created_at DESC
    `);
    res.json({ bookings: result.rows as any[] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/laytons/booking-status", async (req, res) => {
  try {
    await initTable();
    const email = (req.query.email as string || "").trim().toLowerCase();
    if (!email) {
      res.status(400).json({ error: "email is required" });
      return;
    }
    const result = await db.execute(sql`
      SELECT id, name, service, address, preferred_date, notes, status, admin_notes, created_at, updated_at
      FROM laytons_bookings
      WHERE LOWER(email) = ${email}
      ORDER BY created_at DESC
    `);
    res.json({ bookings: result.rows as any[] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/laytons/bookings", requireMasterAdmin, getAllBookings);
router.get("/laytons/admin", requireMasterAdmin, getAllBookings);

router.patch("/laytons/bookings/:id", requireMasterAdmin, async (req, res) => {
  try {
    const { status, admin_notes } = req.body;
    const id = req.params.id;

    if (status !== undefined && admin_notes !== undefined) {
      await db.execute(sql`
        UPDATE laytons_bookings
        SET status = ${status}, admin_notes = ${admin_notes}, updated_at = NOW()
        WHERE id = ${id}
      `);
    } else if (status !== undefined) {
      await db.execute(sql`
        UPDATE laytons_bookings
        SET status = ${status}, updated_at = NOW()
        WHERE id = ${id}
      `);
    } else if (admin_notes !== undefined) {
      await db.execute(sql`
        UPDATE laytons_bookings
        SET admin_notes = ${admin_notes}, updated_at = NOW()
        WHERE id = ${id}
      `);
    }

    const result = await db.execute(sql`SELECT * FROM laytons_bookings WHERE id = ${id}`);
    const booking = (result.rows as any[])[0];

    if (status !== undefined && booking) {
      sendEmail(
        booking.email,
        `Your Layton's Lawncare Booking: ${status.charAt(0).toUpperCase() + status.slice(1)}`,
        statusUpdateHtml(booking, status)
      ).catch(() => {});
    }

    res.json({ booking });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
