import { Router } from "express";
import { stripe } from "../lib/stripe.js";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

router.post("/connect/onboard", async (req, res) => {
  try {
    const { userId, listingId, email, name, returnUrl, refreshUrl } = req.body;

    if (!email) { res.status(400).json({ error: "email is required" }); return; }

    const origin = req.headers.origin || "https://buyshare.co";

    if (listingId && !userId) {
      const { onboardToken } = req.body;
      if (!onboardToken) {
        res.status(400).json({ error: "onboardToken is required for listing onboarding" });
        return;
      }

      const listingRow = (await db.execute(
        sql`SELECT id, host_email, stripe_account_id, onboard_token FROM share_listings WHERE id = ${Number(listingId)} LIMIT 1`
      )).rows[0] as any;

      if (!listingRow) { res.status(404).json({ error: "Listing not found" }); return; }

      if (!listingRow.onboard_token || listingRow.onboard_token !== onboardToken) {
        res.status(403).json({ error: "Invalid onboarding token" });
        return;
      }

      if (listingRow.stripe_account_id) {
        const accountLink = await stripe.accountLinks.create({
          account: listingRow.stripe_account_id,
          refresh_url: refreshUrl || `${origin}/connect/onboard`,
          return_url: returnUrl || `${origin}/connect/return`,
          type: "account_onboarding",
        });
        res.json({ url: accountLink.url, accountId: listingRow.stripe_account_id });
        return;
      }

      const nameParts = (name || "").trim().split(/\s+/);
      const account = await stripe.accounts.create({
        type: "express",
        email,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_type: "individual",
        ...(nameParts[0] ? {
          individual: {
            first_name: nameParts[0],
            ...(nameParts.length > 1 ? { last_name: nameParts.slice(1).join(" ") } : {}),
          }
        } : {}),
        metadata: { listingId: String(listingId), email },
      });
      const accountId = account.id;
      await db.execute(
        sql`UPDATE share_listings SET stripe_account_id = ${accountId} WHERE id = ${Number(listingId)} AND onboard_token = ${onboardToken}`
      );

      const accountLink = await stripe.accountLinks.create({
        account: accountId,
        refresh_url: refreshUrl || `${origin}/connect/onboard`,
        return_url: returnUrl || `${origin}/connect/return`,
        type: "account_onboarding",
      });

      res.json({ url: accountLink.url, accountId });
      return;
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    if (!user) { res.status(404).json({ error: "User not found" }); return; }

    let accountId = user.stripeAccountId;

    if (!accountId) {
      const account = await stripe.accounts.create({
        type: "express",
        email,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_type: "individual",
        metadata: { userId },
      });
      accountId = account.id;
      await db.update(usersTable)
        .set({ stripeAccountId: accountId, updatedAt: new Date() })
        .where(eq(usersTable.id, userId));
    }

    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: refreshUrl || `${origin}/connect/onboard`,
      return_url: returnUrl || `${origin}/connect/return`,
      type: "account_onboarding",
    });

    res.json({ url: accountLink.url, accountId });
  } catch (err: any) {
    const msg = err?.message || String(err);
    if (msg.includes("signed up for Connect") || err?.code === "account_invalid") {
      res.status(503).json({
        error: "Direct payouts via Stripe are not yet available. Buyshare will contact you at your email to arrange payment.",
      });
      return;
    }
    console.error("[connect/onboard]", err);
    res.status(500).json({ error: "Could not start payout setup. Please contact support@buyshare.co." });
  }
});

router.get("/connect/status/:userId", async (req, res) => {
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.params.userId)).limit(1);
    if (!user) { res.status(404).json({ error: "User not found" }); return; }

    if (!user.stripeAccountId) {
      res.json({ userId: user.id, hasAccount: false, onboardingComplete: false });
      return;
    }

    const account = await stripe.accounts.retrieve(user.stripeAccountId);
    const complete = account.details_submitted && !account.requirements?.currently_due?.length;

    if (complete && !user.stripeOnboardingComplete) {
      await db.update(usersTable)
        .set({ stripeOnboardingComplete: true, updatedAt: new Date() })
        .where(eq(usersTable.id, user.id));
    }

    res.json({
      userId: user.id,
      hasAccount: true,
      onboardingComplete: complete ?? false,
      accountId: user.stripeAccountId,
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

export default router;
