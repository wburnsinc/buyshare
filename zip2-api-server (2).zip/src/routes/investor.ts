import { Router } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { stripe } from "../lib/stripe.js";

const router = Router();

const TIERS = {
  seed: { min: 10000, max: 99999, label: "Seed Investor", returnPct: 7, color: "blue" },
  growth: { min: 100000, max: 999999, label: "Growth Investor", returnPct: 10, color: "gold" },
  strategic: { min: 1000000, max: 99999999, label: "Strategic Partner", returnPct: 12, color: "platinum" },
};

async function ensureInvestorsTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS investors (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      amount INTEGER NOT NULL,
      tier TEXT NOT NULL,
      annual_return_pct NUMERIC NOT NULL,
      stripe_session_id TEXT,
      stripe_payment_status TEXT DEFAULT 'pending',
      status TEXT DEFAULT 'pending',
      notes TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
}

let ready = false;
async function withDB(fn: () => Promise<void>, res: any) {
  try {
    if (!ready) { await ensureInvestorsTable(); ready = true; }
    await fn();
  } catch (err: any) {
    console.error("investor error:", err);
    res.status(500).json({ error: err.message || "Server error" });
  }
}

router.post("/investor/checkout", async (req, res) => {
  await withDB(async () => {
    const { name, email, phone, amount, notes } = req.body;
    if (!name || !email || !amount) {
      res.status(400).json({ error: "name, email, and amount are required" });
      return;
    }

    const amountCents = Math.round(Number(amount));
    if (amountCents < 1000000) {
      res.status(400).json({ error: "Minimum investment is $10,000" });
      return;
    }

    let tier = "seed";
    let returnPct = 7;
    if (amountCents >= 100000000) { tier = "strategic"; returnPct = 12; }
    else if (amountCents >= 10000000) { tier = "growth"; returnPct = 10; }

    const id = `inv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

    const origin = req.headers.origin || req.headers.referer?.replace(/\/$/, "") || "https://buyshare.co";
    const baseUrl = origin.includes("localhost") ? `http://localhost:${process.env.PORT || 3000}` : origin;

    const amountDollars = amountCents / 100;
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: [{
        price_data: {
          currency: "usd",
          product_data: {
            name: `BlueTruck LLC / Buyshare.co — ${tier === "growth" ? "Growth" : tier === "strategic" ? "Strategic" : "Seed"} Investment`,
            description: `$${amountDollars.toLocaleString()} at ${returnPct}% annual return · Paid annually · BlueTruck LLC & BURNS INC.`,
          },
          unit_amount: amountCents,
        },
        quantity: 1,
      }],
      customer_email: email,
      metadata: { investorId: id, name, phone: phone || "", amount: String(amountCents), tier, returnPct: String(returnPct), notes: notes || "" },
      success_url: `${baseUrl}/investor-portal?session_id={CHECKOUT_SESSION_ID}&email=${encodeURIComponent(email)}`,
      cancel_url: `${baseUrl}/invest`,
    });

    await db.execute(sql`
      INSERT INTO investors (id, name, email, phone, amount, tier, annual_return_pct, stripe_session_id, stripe_payment_status, status, notes)
      VALUES (${id}, ${name}, ${email}, ${phone || null}, ${amountCents}, ${tier}, ${returnPct}, ${session.id}, 'pending', 'pending', ${notes || null})
    `);

    res.json({ url: session.url, sessionId: session.id, investorId: id });
  }, res);
});

router.get("/investor/portal", async (req, res) => {
  await withDB(async () => {
    const { session_id, email } = req.query as { session_id?: string; email?: string };
    if (!session_id && !email) {
      res.status(400).json({ error: "session_id or email required" });
      return;
    }

    let investor: any = null;
    if (session_id) {
      try {
        const session = await stripe.checkout.sessions.retrieve(session_id as string);
        if (session.payment_status === "paid") {
          await db.execute(sql`UPDATE investors SET stripe_payment_status = 'paid', status = 'active' WHERE stripe_session_id = ${session_id}`);
        }
        const row = await db.execute(sql`SELECT * FROM investors WHERE stripe_session_id = ${session_id} LIMIT 1`);
        investor = (row.rows as any[])[0];
      } catch {}
    }

    if (!investor && email) {
      const row = await db.execute(sql`SELECT * FROM investors WHERE email = ${email} ORDER BY created_at DESC LIMIT 1`);
      investor = (row.rows as any[])[0];
    }

    if (!investor) {
      res.status(404).json({ error: "Investor record not found" });
      return;
    }

    const statsRow = await db.execute(sql`
      SELECT
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM listings) as total_listings,
        (SELECT COUNT(*) FROM bookings) as total_bookings
    `);
    const stats = (statsRow.rows as any[])[0] || {};

    res.json({ investor, stats });
  }, res);
});

router.get("/investor/all", async (req, res) => {
  await withDB(async () => {
    const authHeader = req.headers.authorization;
    if (!authHeader) { res.status(401).json({ error: "Unauthorized" }); return; }
    const result = await db.execute(sql`SELECT * FROM investors ORDER BY created_at DESC`);
    res.json({ investors: result.rows });
  }, res);
});

export default router;
