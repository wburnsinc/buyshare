import { Router } from "express";
import { db, pool } from "@workspace/db";
import { sql } from "drizzle-orm";
import { requireAuth, requireMasterAdmin, AuthRequest } from "../middleware/auth";
import { fetchPlaces } from "../utils/fetchPlaces.js";

const ADMIN_EMAILS = ["burnsinc@outlook.com", "admin@buyshare.co"];

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function geocodeAddress(address: string | null, city: string, state: string, zip: string | null): Promise<{ lat: number; lng: number } | null> {
  try {
    const parts = [address, city, state, zip, "US"].filter(Boolean);
    const q = encodeURIComponent(parts.join(", "));
    const url = `https://nominatim.openstreetmap.org/search?q=${q}&format=json&limit=1&countrycodes=us`;
    const resp = await fetch(url, {
      headers: { "User-Agent": "Buyshare/1.0 geocoder (admin-import)" },
      signal: AbortSignal.timeout(6000),
    });
    if (!resp.ok) return null;
    const data: any[] = await resp.json();
    if (!Array.isArray(data) || !data[0]) return null;
    const lat = parseFloat(data[0].lat);
    const lng = parseFloat(data[0].lon);
    if (isNaN(lat) || isNaN(lng)) return null;
    return { lat, lng };
  } catch {
    return null;
  }
}

async function sendEmail(to: string | string[], subject: string, html: string) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) { console.log(`[businesses] Email skipped (no RESEND_API_KEY): ${subject}`); return; }
  const from = process.env.RESEND_FROM_EMAIL
    ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
    : "Buyshare <onboarding@resend.dev>";
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to, subject, html }),
    });
    if (!res.ok) console.error(`[businesses] Resend error ${res.status}: ${await res.text()}`);
    else console.log(`[businesses] Email sent: ${subject} → ${Array.isArray(to) ? to.join(", ") : to}`);
  } catch (err) {
    console.error("[businesses] sendEmail error:", err);
  }
}

const router = Router();
export default router;

export async function ensureBusinessTables() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS business_saves (
      user_id TEXT NOT NULL,
      business_id TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (user_id, business_id)
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS businesses (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      business_name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      address TEXT,
      city TEXT,
      state TEXT DEFAULT 'FL',
      zip TEXT,
      phone TEXT,
      website TEXT,
      email TEXT,
      latitude NUMERIC,
      longitude NUMERIC,
      description TEXT,
      logo_url TEXT,
      photos TEXT[] DEFAULT '{}',
      hours TEXT,
      social_links TEXT,
      claim_status TEXT NOT NULL DEFAULT 'unclaimed',
      verified_status TEXT NOT NULL DEFAULT 'unverified',
      owner_user_id TEXT,
      featured BOOLEAN NOT NULL DEFAULT FALSE,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      views INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`CREATE INDEX IF NOT EXISTS businesses_category_idx ON businesses (category)`).catch(() => {});
  await db.execute(sql`CREATE INDEX IF NOT EXISTS businesses_city_idx ON businesses (city)`).catch(() => {});
  await db.execute(sql`CREATE INDEX IF NOT EXISTS businesses_phone_idx ON businesses (phone)`).catch(() => {});
  await db.execute(sql`CREATE INDEX IF NOT EXISTS businesses_latlon_idx ON businesses (latitude, longitude)`).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS business_claims (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      user_email TEXT NOT NULL,
      user_name TEXT,
      business_email TEXT,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
}

let ready = false;
async function withDB(fn: () => Promise<void>, res: any) {
  try {
    if (!ready) { await ensureBusinessTables(); ready = true; }
    await fn();
  } catch (err: any) {
    console.error("[businesses]", err);
    res.status(500).json({ error: err.message || "Server error" });
  }
}

function makeSlug(name: string, city: string, suffix: string): string {
  const base = `${name} ${city}`.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
  return `${base}-${suffix}`;
}

export const BUSINESS_CATEGORIES = [
  "HVAC & Air Conditioning",
  "Plumbing",
  "Electrical",
  "Roofing",
  "General Contractors",
  "Handyman & Repairs",
  "Painting",
  "Flooring",
  "Remodeling & Renovation",
  "Lawn Care & Landscaping",
  "Pool Care & Cleaning",
  "Pressure Washing",
  "Pest Control",
  "Cleaning Services",
  "Tree Service",
  "Fence & Gate",
  "Drywall & Stucco",
  "Concrete & Masonry",
  "Gutters",
  "Windows & Doors",
  "Garage Doors",
  "Appliance Repair",
  "Moving & Hauling",
  "Junk Removal",
  "Irrigation & Sprinklers",
  "Landscaping Design",
  "Real Estate & Realtors",
  "Insurance",
  "Legal Services",
  "Mortgage & Lending",
  "Other",
];

// ── Categories list ────────────────────────────────────────────────────────────
router.get("/businesses/categories", (_req, res) => {
  res.json({ categories: BUSINESS_CATEGORIES });
});

// ── Cities list ───────────────────────────────────────────────────────────────
router.get("/businesses/cities", async (_req, res) => {
  await withDB(async () => {
    const result = await pool.query(
      `SELECT DISTINCT city FROM businesses WHERE is_active = TRUE AND city IS NOT NULL ORDER BY city`
    );
    res.json(result.rows.map((r: any) => r.city));
  }, res);
});

// ── Map pins ──────────────────────────────────────────────────────────────────
// Bounds: [latMin, lngMin, latMax, lngMax]
const REGION_BOUNDS: Record<string, [number, number, number, number]> = {
  // Broad Florida regions
  swfl:      [24.8, -83.2, 27.5, -80.8],
  tampa:     [27.4, -83.5, 29.0, -81.5],
  southeast: [25.0, -81.2, 27.3, -79.8],
  northeast: [28.5, -82.5, 31.0, -80.0],
  central:   [27.8, -82.5, 29.5, -80.5],
  // SWFL sub-regions
  "sarasota":       [27.20, -82.70, 27.50, -82.35],
  "venice":         [26.85, -82.60, 27.15, -82.25],  // Venice / North Port / Englewood
  "port-charlotte": [26.85, -82.40, 27.10, -81.90],  // Port Charlotte / Punta Gorda
  "cape-coral":     [26.48, -82.20, 26.85, -81.80],  // Cape Coral / Fort Myers
  "naples":         [25.90, -81.90, 26.50, -81.55],  // Naples / Bonita Springs / Estero
};

async function geocodeZip(zip: string): Promise<{ lat: number; lng: number } | null> {
  const key = process.env.GOOGLE_API_KEY;
  if (!key) return null;
  try {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(zip + " FL USA")}&key=${key}`;
    const r = await fetch(url);
    const d = await r.json() as any;
    if (d.status !== "OK" || !d.results?.[0]) return null;
    const loc = d.results[0].geometry.location;
    return { lat: loc.lat, lng: loc.lng };
  } catch { return null; }
}

router.get("/businesses/map", async (req, res) => {
  await withDB(async () => {
    const { category, city, region } = req.query as Record<string, string>;
    const conditions = ["is_active = TRUE", "latitude IS NOT NULL", "longitude IS NOT NULL"];
    const params: any[] = [];
    if (category && category !== "all") { params.push(category); conditions.push(`category = $${params.length}`); }
    if (city) { params.push(`%${city}%`); conditions.push(`city ILIKE $${params.length}`); }
    if (region && region !== "all" && REGION_BOUNDS[region]) {
      const [latMin, lngMin, latMax, lngMax] = REGION_BOUNDS[region];
      params.push(latMin); conditions.push(`latitude::float >= $${params.length}`);
      params.push(latMax); conditions.push(`latitude::float <= $${params.length}`);
      params.push(lngMin); conditions.push(`longitude::float >= $${params.length}`);
      params.push(lngMax); conditions.push(`longitude::float <= $${params.length}`);
    }
    const result = await pool.query(
      `SELECT id, slug, business_name, category, city, phone,
              latitude::float AS lat, longitude::float AS lng, claim_status
       FROM businesses WHERE ${conditions.join(" AND ")}
       ORDER BY featured DESC, business_name ASC LIMIT 2000`,
      params
    );
    res.json(result.rows);
  }, res);
});

// ── Claim list (admin) ────────────────────────────────────────────────────────
router.get("/businesses/claims", requireMasterAdmin, async (_req, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`
      SELECT bc.*, b.business_name, b.city, b.category, b.claim_status
      FROM business_claims bc
      JOIN businesses b ON b.id = bc.business_id
      ORDER BY bc.created_at DESC
    `);
    res.json(result.rows);
  }, res);
});

// ── By slug ───────────────────────────────────────────────────────────────────
router.get("/businesses/slug/:slug", async (req, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`SELECT * FROM businesses WHERE slug = ${req.params.slug} AND is_active = TRUE LIMIT 1`);
    if (!result.rows.length) return (res as any).status(404).json({ error: "Not found" });
    await db.execute(sql`UPDATE businesses SET views = COALESCE(views,0)+1 WHERE slug = ${req.params.slug}`).catch(() => {});
    res.json(result.rows[0]);
  }, res);
});

// ── List / search ─────────────────────────────────────────────────────────────
router.get("/businesses", async (req, res) => {
  await withDB(async () => {
    const { q: search, category, city, zip, region, radius, page = "1", limit = "24" } = req.query as Record<string, string>;
    const pageNum = Math.max(1, parseInt(page) || 1);
    const limitNum = Math.min(48, parseInt(limit) || 24);
    const offset = (pageNum - 1) * limitNum;

    const conditions: string[] = ["is_active = TRUE"];
    const params: any[] = [];

    if (search) {
      params.push(`%${search}%`);
      conditions.push(`(business_name ILIKE $${params.length} OR description ILIKE $${params.length} OR city ILIKE $${params.length})`);
    }
    if (category && category !== "all") {
      params.push(category);
      conditions.push(`category = $${params.length}`);
    }
    if (city) {
      params.push(`%${city}%`);
      conditions.push(`city ILIKE $${params.length}`);
    }

    // Region bounding box filter (replaces/supplements city filter)
    if (region && region !== "all" && REGION_BOUNDS[region]) {
      const [latMin, lngMin, latMax, lngMax] = REGION_BOUNDS[region];
      conditions.push("latitude IS NOT NULL AND longitude IS NOT NULL");
      params.push(latMin); conditions.push(`latitude::float >= $${params.length}`);
      params.push(latMax); conditions.push(`latitude::float <= $${params.length}`);
      params.push(lngMin); conditions.push(`longitude::float >= $${params.length}`);
      params.push(lngMax); conditions.push(`longitude::float <= $${params.length}`);
    }

    // ZIP + radius search (Haversine)
    if (zip && radius) {
      const radiusMiles = Math.min(100, parseFloat(radius) || 25);
      const center = await geocodeZip(zip);
      if (center) {
        params.push(center.lat);
        const latIdx = params.length;
        params.push(center.lng);
        const lngIdx = params.length;
        params.push(radiusMiles);
        const radIdx = params.length;
        conditions.push(`latitude IS NOT NULL AND longitude IS NOT NULL`);
        conditions.push(
          `(3959 * acos(LEAST(1.0, ` +
          `cos(radians($${latIdx})) * cos(radians(latitude::float)) * cos(radians(longitude::float) - radians($${lngIdx})) ` +
          `+ sin(radians($${latIdx})) * sin(radians(latitude::float))))) <= $${radIdx}`
        );
      } else {
        // Fallback: exact zip match if geocoding unavailable
        params.push(zip);
        conditions.push(`zip = $${params.length}`);
      }
    } else if (zip && !radius) {
      params.push(zip);
      conditions.push(`zip = $${params.length}`);
    }

    const where = conditions.join(" AND ");
    const countResult = await pool.query(`SELECT COUNT(*) as cnt FROM businesses WHERE ${where}`, params);
    const total = parseInt(countResult.rows[0].cnt, 10);

    const dataParams = [...params, limitNum, offset];
    const result = await pool.query(
      `SELECT id, slug, business_name, category, address, city, state, zip, phone, website,
              logo_url, description, claim_status, verified_status, featured, views
       FROM businesses WHERE ${where}
       ORDER BY featured DESC, business_name ASC
       LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
      dataParams
    );

    res.json({ businesses: result.rows, total, page: pageNum, pages: Math.ceil(total / limitNum) });
  }, res);
});

// ── Owner: get my business ────────────────────────────────────────────────────
router.get("/businesses/my", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`SELECT * FROM businesses WHERE owner_user_id = ${req.user!.id} AND is_active = TRUE LIMIT 1`);
    if (!result.rows.length) return (res as any).status(404).json({ error: "No claimed business found for your account" });
    res.json(result.rows[0]);
  }, res);
});

// ── Single by id ──────────────────────────────────────────────────────────────
router.get("/businesses/:id", async (req, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`SELECT * FROM businesses WHERE id = ${req.params.id} AND is_active = TRUE LIMIT 1`);
    if (!result.rows.length) return (res as any).status(404).json({ error: "Not found" });
    res.json(result.rows[0]);
  }, res);
});

// ── Submit claim ──────────────────────────────────────────────────────────────
router.post("/businesses/:id/claim", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const user = req.user!;
    const biz = await db.execute(sql`SELECT id, claim_status, business_name FROM businesses WHERE id = ${req.params.id} AND is_active = TRUE`);
    if (!biz.rows.length) return (res as any).status(404).json({ error: "Business not found" });
    if ((biz.rows[0] as any).claim_status === "claimed") return (res as any).status(400).json({ error: "This business has already been claimed" });
    const existing = await db.execute(sql`SELECT id FROM business_claims WHERE business_id = ${req.params.id} AND user_id = ${user.id} AND status = 'pending'`);
    if ((existing.rows as any[]).length) return (res as any).status(400).json({ error: "You already have a pending claim for this business" });
    const { business_email, notes } = req.body;
    const bizName = (biz.rows[0] as any).business_name || req.params.id;
    await db.execute(sql`
      INSERT INTO business_claims (id, business_id, user_id, user_email, user_name, business_email, notes)
      VALUES (gen_random_uuid()::text, ${req.params.id}, ${user.id}, ${user.email}, ${user.name || ""}, ${business_email || null}, ${notes || null})
    `);
    sendEmail(ADMIN_EMAILS, `[Buyshare] New Business Claim — ${bizName}`, `
      <h2>New Business Ownership Claim</h2>
      <p><strong>Business:</strong> ${bizName}</p>
      <p><strong>Claimed by:</strong> ${user.name || "Unknown"} (${user.email})</p>
      ${business_email ? `<p><strong>Business email provided:</strong> ${business_email}</p>` : ""}
      ${notes ? `<p><strong>Notes:</strong> ${notes}</p>` : ""}
      <p><a href="https://buyshare.co/admin/businesses">Review in Admin Panel →</a></p>
    `);
    res.json({ success: true, message: "Claim submitted — our team will review within 1–2 business days." });
  }, res);
});

// ── Admin: bulk CSV import ────────────────────────────────────────────────────
router.post("/businesses/import", requireMasterAdmin, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const rows: any[] = req.body?.rows;
    if (!Array.isArray(rows) || rows.length === 0) {
      return (res as any).status(400).json({ error: "rows array is required" });
    }
    if (rows.length > 5000) {
      return (res as any).status(400).json({ error: "Maximum 5,000 rows per import" });
    }

    // Load existing phones + coords for dedup
    const existingPhones = new Set<string>();
    const existingCoords: Array<[number, number]> = [];
    const phoneRows = await pool.query(`SELECT phone FROM businesses WHERE phone IS NOT NULL`);
    phoneRows.rows.forEach((r: any) => existingPhones.add(r.phone.replace(/\D/g, "")));
    const coordRows = await pool.query(`SELECT latitude::float AS lat, longitude::float AS lng FROM businesses WHERE latitude IS NOT NULL AND longitude IS NOT NULL`);
    coordRows.rows.forEach((r: any) => existingCoords.push([r.lat, r.lng]));

    let inserted = 0;
    let skipped = 0;
    let geocoded = 0;
    let geocodeAttempts = 0;
    const GEOCODE_CAP = 50; // max geocode calls per import (~55s at 1.1s delay)
    const errors: Array<{ row: number; reason: string }> = [];
    const insertedPhones = new Set<string>();
    const insertedCoords: Array<[number, number]> = [...existingCoords];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNum = i + 1;

      const name = (row.business_name || "").trim();
      const category = (row.category || "").trim();
      const city = (row.city || "").trim();

      if (!name) { errors.push({ row: rowNum, reason: "Missing business_name" }); skipped++; continue; }
      if (!category) { errors.push({ row: rowNum, reason: "Missing category" }); skipped++; continue; }
      if (!city) { errors.push({ row: rowNum, reason: "Missing city" }); skipped++; continue; }

      const phoneRaw = (row.phone || "").trim();
      const phoneDigits = phoneRaw.replace(/\D/g, "");

      if (phoneDigits && (existingPhones.has(phoneDigits) || insertedPhones.has(phoneDigits))) {
        errors.push({ row: rowNum, reason: `Duplicate phone: ${phoneRaw}` });
        skipped++;
        continue;
      }

      let lat: number | null = row.latitude ? parseFloat(row.latitude) : null;
      let lng: number | null = row.longitude ? parseFloat(row.longitude) : null;
      if (lat !== null && isNaN(lat)) lat = null;
      if (lng !== null && isNaN(lng)) lng = null;

      const state = (row.state || "FL").trim();
      const zip = (row.zip || row.zip_code || "").trim() || null;
      const address = (row.address || "").trim() || null;

      // Auto-geocode if coordinates missing and under cap
      if ((lat === null || lng === null) && geocodeAttempts < GEOCODE_CAP) {
        geocodeAttempts++;
        if (geocodeAttempts > 1) await sleep(1100); // Nominatim rate limit: 1 req/s
        const coords = await geocodeAddress(address, city, state, zip);
        if (coords) {
          lat = coords.lat;
          lng = coords.lng;
          geocoded++;
        }
      }

      if (lat !== null && lng !== null) {
        const dupe = insertedCoords.find(([elat, elng]) => Math.abs(elat - lat!) < 0.0005 && Math.abs(elng - lng!) < 0.0005);
        if (dupe) {
          errors.push({ row: rowNum, reason: `Duplicate coordinates for "${name}"` });
          skipped++;
          continue;
        }
      }

      const id = `imp-${Date.now()}-${i}`;
      const slug = makeSlug(name, city, `${Date.now()}-${i}`);
      const website = (row.website || "").trim() || null;
      const email = (row.email || "").trim() || null;
      const description = (row.description || "").trim() || null;

      try {
        await pool.query(
          `INSERT INTO businesses (id, business_name, slug, category, address, city, state, zip, phone, website, email, latitude, longitude, description, is_active, claim_status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,TRUE,'unclaimed')
           ON CONFLICT (slug) DO NOTHING`,
          [id, name, slug, category, address, city, state, zip, phoneRaw || null, website, email,
           lat, lng, description]
        );
        if (phoneDigits) insertedPhones.add(phoneDigits);
        if (lat !== null && lng !== null) insertedCoords.push([lat, lng]);
        inserted++;
      } catch (e: any) {
        errors.push({ row: rowNum, reason: e.message?.slice(0, 80) || "Insert failed" });
        skipped++;
      }
    }

    console.log(`[businesses] Import complete: ${inserted} inserted, ${skipped} skipped, ${geocoded} geocoded`);
    res.json({ inserted, skipped, geocoded, errors: errors.slice(0, 100) });
  }, res);
});

// ── Admin: geocode businesses missing coordinates ─────────────────────────────
router.post("/businesses/geocode-missing", requireMasterAdmin, async (_req, res) => {
  await withDB(async () => {
    const missing = await pool.query(
      `SELECT id, address, city, state, zip FROM businesses WHERE (latitude IS NULL OR longitude IS NULL) AND is_active = TRUE ORDER BY created_at DESC LIMIT 200`
    );
    if (!missing.rows.length) return res.json({ geocoded: 0, failed: 0, message: "No businesses need geocoding" });

    let geocodedCount = 0;
    let failedCount = 0;

    for (let i = 0; i < missing.rows.length; i++) {
      const row = missing.rows[i] as any;
      if (i > 0) await sleep(1100);
      const coords = await geocodeAddress(row.address, row.city || "", row.state || "FL", row.zip);
      if (coords) {
        await pool.query(
          `UPDATE businesses SET latitude = $1, longitude = $2 WHERE id = $3`,
          [coords.lat, coords.lng, row.id]
        );
        geocodedCount++;
      } else {
        failedCount++;
      }
    }

    console.log(`[businesses] Geocode-missing: ${geocodedCount} geocoded, ${failedCount} failed`);
    const remaining = await pool.query(`SELECT COUNT(*) FROM businesses WHERE (latitude IS NULL OR longitude IS NULL) AND is_active = TRUE`);
    res.json({ geocoded: geocodedCount, failed: failedCount, remaining: parseInt(remaining.rows[0].count) });
  }, res);
});

// ── Admin: fetch real businesses from Google Places ───────────────────────────
const KEYWORD_TO_CATEGORY: Record<string, string> = {
  "hvac": "HVAC & Air Conditioning", "air conditioning": "HVAC & Air Conditioning", "cooling": "HVAC & Air Conditioning",
  "plumb": "Plumbing",
  "electri": "Electrical",
  "roof": "Roofing",
  "general contractor": "General Contractors",
  "handyman": "Handyman & Repairs",
  "paint": "Painting",
  "floor": "Flooring",
  "remodel": "Remodeling & Renovation",
  "lawn": "Lawn Care & Landscaping", "landscap": "Lawn Care & Landscaping", "mow": "Lawn Care & Landscaping",
  "pool": "Pool Care & Cleaning",
  "pressure wash": "Pressure Washing", "power wash": "Pressure Washing",
  "pest": "Pest Control", "exterminat": "Pest Control",
  "clean": "Cleaning Services",
  "tree": "Tree Service",
  "fence": "Fence & Gate",
  "drywall": "Drywall & Stucco", "stucco": "Drywall & Stucco",
  "concrete": "Concrete & Masonry", "mason": "Concrete & Masonry",
  "gutter": "Gutters",
  "window": "Windows & Doors", "door replacement": "Windows & Doors",
  "garage door": "Garage Doors",
  "appliance": "Appliance Repair",
  "mov": "Moving & Hauling", "haul": "Moving & Hauling", "mover": "Moving & Hauling",
  "junk": "Junk Removal",
  "irrigat": "Irrigation & Sprinklers", "sprinkler": "Irrigation & Sprinklers",
  "real estate": "Real Estate & Realtors", "realtor": "Real Estate & Realtors",
  "insurance": "Insurance",
  "legal": "Legal Services", "attorney": "Legal Services", "lawyer": "Legal Services",
  "mortgage": "Mortgage & Lending", "lending": "Mortgage & Lending",
};

function resolveCategory(keyword: string): string {
  const k = keyword.toLowerCase();
  for (const [pattern, cat] of Object.entries(KEYWORD_TO_CATEGORY)) {
    if (k.includes(pattern)) return cat;
  }
  return "Other";
}

function parseGoogleAddress(formatted: string): { address: string; zip: string } {
  const parts = formatted.split(",").map((s: string) => s.trim());
  const address = parts[0] || "";
  const stateZip = parts[2] || "";
  const zipMatch = stateZip.match(/\d{5}/);
  return { address, zip: zipMatch ? zipMatch[0] : "" };
}

// ── GET /fetch-businesses?category=HVAC+air+conditioning&city=Port+Charlotte ──
router.get("/fetch-businesses", requireMasterAdmin, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const category = (req.query.category as string || "").trim();
    const city = (req.query.city as string || "").trim();
    if (!category || !city) return (res as any).status(400).json({ error: "category and city are required" });

    let places: any[];
    try {
      places = await fetchPlaces(city, category);
    } catch (e: any) {
      return (res as any).status(400).json({ error: e.message });
    }
    if (!places.length) return res.json({ fetched: 0, inserted: 0, skipped: 0, message: "No results found" });

    const resolvedCategory = resolveCategory(category);
    const key = process.env.GOOGLE_API_KEY || process.env.GOOGLE_PLACES_API_KEY || "";

    const existingPhones = new Set<string>();
    const existingCoords: Array<[number, number]> = [];
    const phoneRows = await pool.query(`SELECT phone FROM businesses WHERE phone IS NOT NULL`);
    phoneRows.rows.forEach((r: any) => existingPhones.add(r.phone.replace(/\D/g, "")));
    const coordRows = await pool.query(`SELECT latitude::float AS lat, longitude::float AS lng FROM businesses WHERE latitude IS NOT NULL AND longitude IS NOT NULL`);
    coordRows.rows.forEach((r: any) => existingCoords.push([r.lat, r.lng]));
    const insertedCoords: Array<[number, number]> = [...existingCoords];
    const insertedPhones = new Set<string>();

    let inserted = 0, skipped = 0;
    const skippedReasons: string[] = [];

    for (let i = 0; i < places.length; i++) {
      const place = places[i];
      await sleep(120);

      const detailUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&fields=name,formatted_phone_number,website,formatted_address,geometry,business_status&key=${key}`;
      const detailResp = await fetch(detailUrl, { signal: AbortSignal.timeout(8000) });
      const detailData: any = await detailResp.json();
      const detail = detailData.result || {};

      if (detail.business_status === "PERMANENTLY_CLOSED" || place.permanently_closed) {
        skipped++; skippedReasons.push(`${place.name}: permanently closed`); continue;
      }

      const name = (detail.name || place.name || "").trim();
      if (!name) { skipped++; continue; }

      const phoneRaw = (detail.formatted_phone_number || "").trim();
      const phoneDigits = phoneRaw.replace(/\D/g, "");
      if (phoneDigits && (existingPhones.has(phoneDigits) || insertedPhones.has(phoneDigits))) {
        skipped++; skippedReasons.push(`${name}: duplicate phone`); continue;
      }

      const lat: number | null = place.lat ?? detail.geometry?.location?.lat ?? null;
      const lng: number | null = place.lng ?? detail.geometry?.location?.lng ?? null;
      if (lat !== null && lng !== null) {
        const dupe = insertedCoords.find(([elat, elng]) => Math.abs(elat - lat) < 0.0005 && Math.abs(elng - lng) < 0.0005);
        if (dupe) { skipped++; skippedReasons.push(`${name}: duplicate location`); continue; }
      }

      const { address, zip } = parseGoogleAddress(detail.formatted_address || place.address || "");
      const website = (detail.website || place.website || "").trim() || null;
      const rating = place.rating ?? null;
      const reviewCount = place.review_count ?? null;
      const id = `gpl-${Date.now()}-${i}`;
      const slug = makeSlug(name, city, `${Date.now()}-${i}`);

      try {
        await pool.query(
          `INSERT INTO businesses (id, business_name, slug, category, address, city, state, zip, phone, website, latitude, longitude, rating, review_count, is_active, claim_status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,TRUE,'unclaimed')
           ON CONFLICT (slug) DO NOTHING`,
          [id, name, slug, resolvedCategory, address || null, city, "FL", zip || null, phoneRaw || null, website, lat, lng, rating, reviewCount]
        );
        if (phoneDigits) insertedPhones.add(phoneDigits);
        if (lat !== null && lng !== null) insertedCoords.push([lat, lng]);
        inserted++;
      } catch (e: any) {
        skipped++; skippedReasons.push(`${name}: ${e.message?.slice(0, 60)}`);
      }
    }

    console.log(`[businesses] GET fetch-businesses "${category}" in ${city}: ${places.length} found, ${inserted} inserted, ${skipped} skipped`);
    res.json({ fetched: places.length, inserted, skipped, category: resolvedCategory, skippedReasons: skippedReasons.slice(0, 20) });
  }, res);
});

router.post("/businesses/fetch-google", requireMasterAdmin, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const { apiKey, keyword, city, state = "FL", max_results = 20 } = req.body;
    const key = apiKey || process.env.GOOGLE_API_KEY || process.env.GOOGLE_PLACES_API_KEY;
    if (!key) return (res as any).status(400).json({ error: "Google Maps API key required" });
    if (!keyword || !city) return (res as any).status(400).json({ error: "keyword and city are required" });

    const cap = Math.min(parseInt(max_results) || 20, 60);
    const category = resolveCategory(keyword);

    // Text Search
    const query = `${keyword} in ${city} ${state}`;
    const searchUrl = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(query)}&key=${key}`;
    const searchResp = await fetch(searchUrl, { signal: AbortSignal.timeout(10000) });
    const searchData: any = await searchResp.json();

    if (searchData.status === "REQUEST_DENIED" || searchData.status === "INVALID_REQUEST") {
      return (res as any).status(400).json({ error: `Google API: ${searchData.status} — ${searchData.error_message || "Check your API key"}` });
    }
    if (searchData.status === "ZERO_RESULTS") {
      return res.json({ fetched: 0, inserted: 0, skipped: 0, message: "No results found for that search" });
    }

    const places: any[] = (searchData.results || []).slice(0, cap);

    // Load existing phones + coords for dedup
    const existingPhones = new Set<string>();
    const existingCoords: Array<[number, number]> = [];
    const phoneRows = await pool.query(`SELECT phone FROM businesses WHERE phone IS NOT NULL`);
    phoneRows.rows.forEach((r: any) => existingPhones.add(r.phone.replace(/\D/g, "")));
    const coordRows = await pool.query(`SELECT latitude::float AS lat, longitude::float AS lng FROM businesses WHERE latitude IS NOT NULL AND longitude IS NOT NULL`);
    coordRows.rows.forEach((r: any) => existingCoords.push([r.lat, r.lng]));
    const insertedCoords: Array<[number, number]> = [...existingCoords];
    const insertedPhones = new Set<string>();

    let inserted = 0, skipped = 0;
    const skippedReasons: string[] = [];

    for (let i = 0; i < places.length; i++) {
      const place = places[i];
      await sleep(120); // ~8 req/s, well within Places API limits

      // Fetch place details for phone + website
      const detailUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&fields=name,formatted_phone_number,website,formatted_address,geometry,business_status&key=${key}`;
      const detailResp = await fetch(detailUrl, { signal: AbortSignal.timeout(8000) });
      const detailData: any = await detailResp.json();
      const detail = detailData.result || {};

      // Skip permanently closed
      if (detail.business_status === "PERMANENTLY_CLOSED" || place.permanently_closed) {
        skipped++; skippedReasons.push(`${place.name}: permanently closed`); continue;
      }

      const name = (detail.name || place.name || "").trim();
      if (!name) { skipped++; continue; }

      const phoneRaw = (detail.formatted_phone_number || "").trim();
      const phoneDigits = phoneRaw.replace(/\D/g, "");

      if (phoneDigits && (existingPhones.has(phoneDigits) || insertedPhones.has(phoneDigits))) {
        skipped++; skippedReasons.push(`${name}: duplicate phone`); continue;
      }

      const lat: number | null = place.geometry?.location?.lat ?? detail.geometry?.location?.lat ?? null;
      const lng: number | null = place.geometry?.location?.lng ?? detail.geometry?.location?.lng ?? null;

      if (lat !== null && lng !== null) {
        const dupe = insertedCoords.find(([elat, elng]) => Math.abs(elat - lat) < 0.0005 && Math.abs(elng - lng) < 0.0005);
        if (dupe) { skipped++; skippedReasons.push(`${name}: duplicate location`); continue; }
      }

      const { address, zip } = parseGoogleAddress(detail.formatted_address || place.formatted_address || "");
      const website = (detail.website || "").trim() || null;
      const rating = (place as any).rating ?? null;
      const reviewCount = (place as any).user_ratings_total ?? null;
      const id = `gpl-${Date.now()}-${i}`;
      const slug = makeSlug(name, city, `${Date.now()}-${i}`);

      try {
        await pool.query(
          `INSERT INTO businesses (id, business_name, slug, category, address, city, state, zip, phone, website, latitude, longitude, rating, review_count, is_active, claim_status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,TRUE,'unclaimed')
           ON CONFLICT (slug) DO NOTHING`,
          [id, name, slug, category, address || null, city, state, zip || null, phoneRaw || null, website, lat, lng, rating, reviewCount]
        );
        if (phoneDigits) insertedPhones.add(phoneDigits);
        if (lat !== null && lng !== null) insertedCoords.push([lat, lng]);
        inserted++;
      } catch (e: any) {
        skipped++; skippedReasons.push(`${name}: ${e.message?.slice(0, 60)}`);
      }
    }

    console.log(`[businesses] Google fetch "${query}": ${places.length} found, ${inserted} inserted, ${skipped} skipped`);
    res.json({ fetched: places.length, inserted, skipped, category, skippedReasons: skippedReasons.slice(0, 20) });
  }, res);
});

// ── Admin: create single business ─────────────────────────────────────────────
router.post("/businesses", requireMasterAdmin, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const { business_name, category, address, city, state, zip, phone, website, email, latitude, longitude, description, logo_url, hours, social_links, featured } = req.body;
    if (!business_name || !category) return (res as any).status(400).json({ error: "business_name and category required" });
    const id = `biz-${Date.now()}`;
    const slug = makeSlug(business_name, city || "", `${Date.now()}`);
    const conflict = await db.execute(sql`SELECT id FROM businesses WHERE slug = ${slug}`);
    const finalSlug = (conflict.rows as any[]).length ? `${slug}-${Date.now()}` : slug;
    await db.execute(sql`
      INSERT INTO businesses (id, business_name, slug, category, address, city, state, zip, phone, website, email, latitude, longitude, description, logo_url, hours, social_links, featured)
      VALUES (${id}, ${business_name}, ${finalSlug}, ${category}, ${address||null}, ${city||null}, ${state||"FL"}, ${zip||null}, ${phone||null}, ${website||null}, ${email||null}, ${latitude||null}, ${longitude||null}, ${description||null}, ${logo_url||null}, ${hours||null}, ${social_links||null}, ${Boolean(featured)})
    `);
    const result = await db.execute(sql`SELECT * FROM businesses WHERE id = ${id}`);
    res.json(result.rows[0]);
  }, res);
});

// ── Admin: approve / reject claim ─────────────────────────────────────────────
router.patch("/businesses/claims/:id", requireMasterAdmin, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const { status, admin_notes } = req.body;
    if (!["approved", "rejected"].includes(status)) return (res as any).status(400).json({ error: "status must be approved or rejected" });
    const claim = await db.execute(sql`
      SELECT bc.*, b.business_name FROM business_claims bc
      JOIN businesses b ON b.id = bc.business_id
      WHERE bc.id = ${req.params.id}
    `);
    if (!claim.rows.length) return (res as any).status(404).json({ error: "Claim not found" });
    const row = claim.rows[0] as any;
    await db.execute(sql`UPDATE business_claims SET status = ${status}, admin_notes = ${admin_notes||null}, updated_at = NOW() WHERE id = ${req.params.id}`);
    if (status === "approved") {
      await db.execute(sql`
        UPDATE businesses SET claim_status = 'claimed', verified_status = 'verified', owner_user_id = ${row.user_id}, updated_at = NOW()
        WHERE id = ${row.business_id}
      `);
      await db.execute(sql`
        INSERT INTO notifications (id, user_id, type, message, link)
        VALUES (gen_random_uuid()::text, ${row.user_id}, 'business', ${'Your business claim was approved! You can now manage your profile.'}, ${'/my-business'})
      `).catch(() => {});
      sendEmail(row.user_email, `Your Buyshare Business Claim Was Approved! 🎉`, `
        <h2>Great news, ${row.user_name || "there"}!</h2>
        <p>Your ownership claim for <strong>${row.business_name}</strong> has been <strong>approved</strong> by the Buyshare team.</p>
        <p>You can now manage your business profile, update hours, add photos, and more.</p>
        <p><a href="https://buyshare.co/my-business" style="background:#16a34a;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;">Manage My Business →</a></p>
        ${admin_notes ? `<p><em>Admin note: ${admin_notes}</em></p>` : ""}
        <hr/><p style="font-size:12px;color:#888">Buyshare.co — Southwest Florida's Sharing Platform</p>
      `);
    } else {
      sendEmail(row.user_email, `Update on Your Buyshare Business Claim`, `
        <h2>Hi ${row.user_name || "there"},</h2>
        <p>We reviewed your ownership claim for <strong>${row.business_name}</strong> and were unable to approve it at this time.</p>
        ${admin_notes ? `<p><strong>Reason:</strong> ${admin_notes}</p>` : ""}
        <p>If you have questions, please reply to this email.</p>
        <hr/><p style="font-size:12px;color:#888">Buyshare.co — Southwest Florida's Sharing Platform</p>
      `);
    }
    res.json({ success: true });
  }, res);
});

// ── Admin or owner: update business ──────────────────────────────────────────
router.patch("/businesses/:id", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const user = req.user!;
    const biz = await db.execute(sql`SELECT * FROM businesses WHERE id = ${req.params.id}`);
    if (!biz.rows.length) return (res as any).status(404).json({ error: "Not found" });
    const row = biz.rows[0] as any;
    if (!user.is_admin && row.owner_user_id !== user.id) return (res as any).status(403).json({ error: "Not authorized" });
    const ownerFields = ["business_name", "address", "city", "state", "zip", "phone", "website", "email", "description", "logo_url", "hours", "social_links"];
    const adminFields = [...ownerFields, "category", "latitude", "longitude", "claim_status", "verified_status", "owner_user_id", "featured", "is_active"];
    const allowed = user.is_admin ? adminFields : ownerFields;
    const updates: string[] = [];
    const params: any[] = [];
    for (const f of allowed) {
      if (req.body[f] !== undefined) { params.push(req.body[f]); updates.push(`${f} = $${params.length}`); }
    }
    if (!updates.length) return (res as any).status(400).json({ error: "No valid fields to update" });
    params.push(new Date().toISOString()); updates.push(`updated_at = $${params.length}`);
    params.push(req.params.id);
    await pool.query(`UPDATE businesses SET ${updates.join(", ")} WHERE id = $${params.length}`, params);

    // Re-geocode when address fields change (owners only — admins set lat/lng directly)
    const addressTouched = ["address", "city", "state", "zip"].some(f => req.body[f] !== undefined);
    if (!user.is_admin && addressTouched) {
      const fresh = await pool.query(`SELECT address, city, state, zip FROM businesses WHERE id = $1`, [req.params.id]);
      const b = fresh.rows[0] as any;
      if (b) {
        geocodeAddress(b.address || null, b.city || "", b.state || "FL", b.zip || null)
          .then(async coords => {
            if (coords) {
              await pool.query(`UPDATE businesses SET latitude = $1, longitude = $2 WHERE id = $3`, [coords.lat, coords.lng, req.params.id]);
            }
          }).catch(() => {});
      }
    }

    res.json({ success: true });
  }, res);
});

// ── Save / unsave toggle ──────────────────────────────────────────────────────
router.get("/businesses/:id/save-status", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const r = await db.execute(sql`SELECT 1 FROM business_saves WHERE user_id = ${req.user!.id} AND business_id = ${req.params.id}`);
    res.json({ saved: r.rows.length > 0 });
  }, res);
});

router.post("/businesses/:id/save", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const existing = await db.execute(sql`SELECT 1 FROM business_saves WHERE user_id = ${req.user!.id} AND business_id = ${req.params.id}`);
    if (existing.rows.length) {
      await db.execute(sql`DELETE FROM business_saves WHERE user_id = ${req.user!.id} AND business_id = ${req.params.id}`);
      res.json({ saved: false });
    } else {
      await db.execute(sql`INSERT INTO business_saves (user_id, business_id) VALUES (${req.user!.id}, ${req.params.id}) ON CONFLICT DO NOTHING`);
      res.json({ saved: true });
    }
  }, res);
});

router.get("/user/saved-businesses", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`
      SELECT b.id, b.slug, b.business_name, b.category, b.city, b.state, b.phone, b.logo_url, b.description, b.claim_status, bs.created_at as saved_at
      FROM business_saves bs
      JOIN businesses b ON b.id = bs.business_id
      WHERE bs.user_id = ${req.user!.id} AND b.is_active = TRUE
      ORDER BY bs.created_at DESC
    `);
    res.json(result.rows);
  }, res);
});

// ── Contact business ──────────────────────────────────────────────────────────
router.post("/businesses/:id/contact", async (req: AuthRequest, res) => {
  await withDB(async () => {
    const { name, email, phone, message } = req.body;
    if (!name || !message) return (res as any).status(400).json({ error: "name and message are required" });
    const biz = await db.execute(sql`SELECT id, business_name, email, owner_user_id FROM businesses WHERE id = ${req.params.id} AND is_active = TRUE`);
    if (!biz.rows.length) return (res as any).status(404).json({ error: "Business not found" });
    const b = biz.rows[0] as any;
    if (b.owner_user_id) {
      const msg = `New inquiry for ${b.business_name} from ${name}${email ? ` (${email})` : ""}${phone ? `, ${phone}` : ""}: "${message}"`;
      await db.execute(sql`
        INSERT INTO notifications (id, user_id, type, message, link)
        VALUES (gen_random_uuid()::text, ${b.owner_user_id}, 'contact', ${msg}, ${'/my-business'})
      `).catch(() => {});
    }
    if (b.email) {
      sendEmail(b.email, `New Customer Inquiry — ${b.business_name}`, `
        <h2>You have a new message via Buyshare.co</h2>
        <table style="border-collapse:collapse;width:100%">
          <tr><td style="padding:6px 0"><strong>From:</strong></td><td>${name}</td></tr>
          ${email ? `<tr><td style="padding:6px 0"><strong>Email:</strong></td><td><a href="mailto:${email}">${email}</a></td></tr>` : ""}
          ${phone ? `<tr><td style="padding:6px 0"><strong>Phone:</strong></td><td>${phone}</td></tr>` : ""}
          <tr><td style="padding:6px 0;vertical-align:top"><strong>Message:</strong></td><td>${message}</td></tr>
        </table>
        <p style="margin-top:16px"><a href="https://buyshare.co/my-business" style="background:#16a34a;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;">View My Dashboard →</a></p>
        <hr/><p style="font-size:12px;color:#888">Buyshare.co — Southwest Florida's Sharing Platform</p>
      `);
    }
    res.json({ success: true, message: "Your message has been sent to the business owner." });
  }, res);
});
