import { Router } from "express";
import { db, pool } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

async function sendServiceRequestEmail(data: Record<string, string>) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) { console.log("[bluetruck] No RESEND_API_KEY — skipping email"); return; }
  const from = process.env.RESEND_FROM_EMAIL
    ? `BlueTruck <${process.env.RESEND_FROM_EMAIL}>`
    : "BlueTruck <onboarding@resend.dev>";
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: ["burnsinc@outlook.com"],
        subject: `[BlueTruck] New Service Request — ${data.serviceType || "General"} from ${data.fullName || "Unknown"}`,
        html: `
          <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:32px 24px;color:#1a1a1a;">
            <div style="background:#002a6e;padding:16px 24px;border-radius:12px 12px 0 0;margin-bottom:0;">
              <h2 style="color:white;margin:0;font-size:20px;">New Service Request</h2>
              <p style="color:#93c5fd;margin:4px 0 0;font-size:13px;">BlueTruck.co — Buyshare.co</p>
            </div>
            <div style="border:1px solid #e5e7eb;border-top:none;border-radius:0 0 12px 12px;padding:24px;">
              <table style="width:100%;border-collapse:collapse;font-size:14px;">
                <tr><td style="padding:8px 0;color:#6b7280;width:140px;">Name</td><td style="padding:8px 0;font-weight:600;">${data.fullName || "—"}</td></tr>
                <tr style="background:#f9fafb;"><td style="padding:8px 6px;color:#6b7280;">Phone</td><td style="padding:8px 6px;font-weight:600;"><a href="tel:${data.phone}" style="color:#002a6e;">${data.phone || "—"}</a></td></tr>
                <tr><td style="padding:8px 0;color:#6b7280;">Email</td><td style="padding:8px 0;font-weight:600;">${data.email || "—"}</td></tr>
                <tr style="background:#f9fafb;"><td style="padding:8px 6px;color:#6b7280;">Service</td><td style="padding:8px 6px;font-weight:600;color:#002a6e;">${data.serviceType || "—"}</td></tr>
                <tr><td style="padding:8px 0;color:#6b7280;">Zip Code</td><td style="padding:8px 0;">${data.zip || "—"}</td></tr>
                <tr style="background:#f9fafb;"><td style="padding:8px 6px;color:#6b7280;">Address</td><td style="padding:8px 6px;">${data.address || "—"}</td></tr>
                <tr><td style="padding:8px 0;color:#6b7280;">Notes</td><td style="padding:8px 0;">${data.specialInstructions || "—"}</td></tr>
              </table>
              <div style="margin-top:20px;padding:16px;background:#f0f7ff;border-radius:8px;border-left:4px solid #1fbe4b;">
                <p style="margin:0;font-size:13px;color:#374151;">📞 Call back within 24 hours: <a href="tel:${data.phone}" style="color:#002a6e;font-weight:600;">${data.phone}</a></p>
              </div>
            </div>
          </div>
        `,
      }),
    });
  } catch (e) {
    console.error("[bluetruck] Email send error:", e);
  }
}

// ── Ensure service_requests table exists ──────────────────────────────────────
async function ensureTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bluetruck_service_requests (
      id SERIAL PRIMARY KEY,
      full_name TEXT,
      email TEXT,
      phone TEXT,
      zip TEXT,
      service_type TEXT,
      address TEXT,
      special_instructions TEXT,
      status TEXT DEFAULT 'new',
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `).catch(() => {});
}
ensureTable();

// ── POST /api/bluetruck/service-request ───────────────────────────────────────
router.post("/bluetruck/service-request", async (req, res) => {
  const { fullName, email, phone, zip, serviceType, address, specialInstructions } = req.body;
  if (!fullName || !phone) return (res as any).status(400).json({ error: "Name and phone are required" });

  await pool.query(
    `INSERT INTO bluetruck_service_requests (full_name, email, phone, zip, service_type, address, special_instructions)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [fullName, email || null, phone, zip || null, serviceType || null, address || null, specialInstructions || null]
  ).catch(e => console.error("[bluetruck] DB insert error:", e));

  await sendServiceRequestEmail({ fullName, email, phone, zip, serviceType, address, specialInstructions });

  res.json({ success: true, message: "Request received — we'll call you within 24 hours." });
});

// ── GET /api/bluetruck/service-requests (admin) ───────────────────────────────
router.get("/bluetruck/service-requests", async (req, res) => {
  const adminEmails = ["burnsinc@outlook.com", "admin@buyshare.co"];
  const authHeader = req.headers.authorization || "";
  const token = authHeader.replace("Bearer ", "");

  if (!token) return (res as any).status(401).json({ error: "Unauthorized" });

  const rows = await pool.query(
    `SELECT * FROM bluetruck_service_requests ORDER BY created_at DESC LIMIT 200`
  ).catch(() => ({ rows: [] }));

  res.json({ requests: rows.rows });
});

export default router;
