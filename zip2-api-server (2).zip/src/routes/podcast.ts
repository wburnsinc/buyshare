import { Router } from "express";
import { pool } from "@workspace/db";
import { requireAuth } from "../middleware/auth.js";
import crypto from "crypto";

const router = Router();

export async function ensurePodcastTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS podcast_channels (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      tagline TEXT,
      description TEXT,
      category TEXT,
      photo_url TEXT,
      banner_url TEXT,
      youtube_url TEXT,
      facebook_url TEXT,
      tiktok_url TEXT,
      instagram_url TEXT,
      website_url TEXT,
      email TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS podcast_episodes (
      id TEXT PRIMARY KEY,
      channel_id TEXT NOT NULL REFERENCES podcast_channels(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      video_type TEXT NOT NULL DEFAULT 'youtube',
      video_url TEXT,
      youtube_url TEXT,
      facebook_url TEXT,
      tiktok_url TEXT,
      thumbnail_url TEXT,
      tags TEXT,
      duration_mins INTEGER,
      episode_number INTEGER,
      season_number INTEGER,
      views INTEGER NOT NULL DEFAULT 0,
      likes INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'published',
      published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS podcast_likes (
      episode_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      PRIMARY KEY(episode_id, user_id)
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS podcast_comments (
      id TEXT PRIMARY KEY,
      episode_id TEXT NOT NULL REFERENCES podcast_episodes(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      author_name TEXT NOT NULL,
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
}

ensurePodcastTables();

// ── CHANNELS ──────────────────────────────────────────────────────────────────

router.get("/api/podcast/channels", async (req, res) => {
  try {
    const { q, category, limit = 50, offset = 0 } = req.query as Record<string, string>;
    const params: unknown[] = [];
    let pi = 1;
    const where: string[] = ["c.status = 'active'"];

    if (q) {
      where.push(`(LOWER(c.name) LIKE LOWER($${pi}) OR LOWER(c.description) LIKE LOWER($${pi}))`);
      params.push(`%${q}%`); pi++;
    }
    if (category) { where.push(`c.category = $${pi++}`); params.push(category); }

    params.push(Number(limit), Number(offset));
    const result = await pool.query(`
      SELECT c.*,
        (SELECT COUNT(*)::int FROM podcast_episodes WHERE channel_id = c.id AND status = 'published') AS episode_count,
        (SELECT SUM(views)::int FROM podcast_episodes WHERE channel_id = c.id) AS total_views
      FROM podcast_channels c
      WHERE ${where.join(" AND ")}
      ORDER BY c.created_at DESC
      LIMIT $${pi++} OFFSET $${pi}
    `, params);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/podcast/channels/me", requireAuth, async (req: any, res) => {
  try {
    const result = await pool.query(`
      SELECT c.*,
        (SELECT COUNT(*)::int FROM podcast_episodes WHERE channel_id = c.id AND status = 'published') AS episode_count
      FROM podcast_channels c WHERE c.user_id = $1
    `, [req.user.id]);
    res.json(result.rows[0] || null);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/podcast/channels/:id", async (req, res) => {
  try {
    const ch = await pool.query(`
      SELECT c.*,
        (SELECT COUNT(*)::int FROM podcast_episodes WHERE channel_id = c.id AND status = 'published') AS episode_count,
        (SELECT SUM(views)::int FROM podcast_episodes WHERE channel_id = c.id) AS total_views
      FROM podcast_channels c WHERE c.id = $1
    `, [req.params.id]);
    if (!ch.rows.length) return res.status(404).json({ error: "Not found" });

    const eps = await pool.query(
      "SELECT * FROM podcast_episodes WHERE channel_id = $1 AND status = 'published' ORDER BY published_at DESC",
      [req.params.id]
    );
    res.json({ ...ch.rows[0], episodes: eps.rows });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/podcast/channels", requireAuth, async (req: any, res) => {
  try {
    const existing = await pool.query("SELECT id FROM podcast_channels WHERE user_id=$1", [req.user.id]);
    if (existing.rows.length) return res.status(409).json({ error: "Channel exists", id: existing.rows[0].id });

    const { name, tagline, description, category, photo_url, banner_url,
            youtube_url, facebook_url, tiktok_url, instagram_url, website_url, email } = req.body;
    if (!name) return res.status(400).json({ error: "name required" });

    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO podcast_channels(id,user_id,name,tagline,description,category,photo_url,banner_url,youtube_url,facebook_url,tiktok_url,instagram_url,website_url,email,status,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,'active',NOW())
    `, [id, req.user.id, name, tagline || null, description || null, category || null,
       photo_url || null, banner_url || null, youtube_url || null, facebook_url || null,
       tiktok_url || null, instagram_url || null, website_url || null,
       email || req.user.email]);
    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.patch("/api/podcast/channels/:id", requireAuth, async (req: any, res) => {
  try {
    const own = await pool.query("SELECT id FROM podcast_channels WHERE id=$1 AND user_id=$2", [req.params.id, req.user.id]);
    if (!own.rows.length) return res.status(403).json({ error: "Not authorized" });
    const { name, tagline, description, category, photo_url, banner_url,
            youtube_url, facebook_url, tiktok_url, instagram_url, website_url, email } = req.body;
    await pool.query(`
      UPDATE podcast_channels SET
        name=COALESCE($2,name), tagline=COALESCE($3,tagline), description=COALESCE($4,description),
        category=COALESCE($5,category), photo_url=COALESCE($6,photo_url), banner_url=COALESCE($7,banner_url),
        youtube_url=COALESCE($8,youtube_url), facebook_url=COALESCE($9,facebook_url),
        tiktok_url=COALESCE($10,tiktok_url), instagram_url=COALESCE($11,instagram_url),
        website_url=COALESCE($12,website_url), email=COALESCE($13,email), updated_at=NOW()
      WHERE id=$1
    `, [req.params.id, name, tagline, description, category, photo_url, banner_url,
       youtube_url, facebook_url, tiktok_url, instagram_url, website_url, email]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// ── EPISODES ──────────────────────────────────────────────────────────────────

router.get("/api/podcast/episodes", async (req, res) => {
  try {
    const { video_type, q, limit = 60, offset = 0 } = req.query as Record<string, string>;
    const params: unknown[] = [];
    let pi = 1;
    const where: string[] = ["e.status = 'published'"];

    if (video_type) { where.push(`e.video_type = $${pi++}`); params.push(video_type); }
    if (q) {
      where.push(`(LOWER(e.title) LIKE LOWER($${pi}) OR LOWER(e.description) LIKE LOWER($${pi}) OR LOWER(e.tags) LIKE LOWER($${pi}))`);
      params.push(`%${q}%`); pi++;
    }

    params.push(Number(limit), Number(offset));
    const result = await pool.query(`
      SELECT e.*, c.name AS channel_name, c.photo_url AS channel_photo, c.id AS channel_id
      FROM podcast_episodes e
      JOIN podcast_channels c ON c.id = e.channel_id
      WHERE ${where.join(" AND ")}
      ORDER BY e.published_at DESC
      LIMIT $${pi++} OFFSET $${pi}
    `, params);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/podcast/episodes/:id", async (req, res) => {
  try {
    const ep = await pool.query(`
      SELECT e.*, c.name AS channel_name, c.photo_url AS channel_photo,
        c.youtube_url AS channel_youtube, c.facebook_url AS channel_facebook,
        c.tiktok_url AS channel_tiktok, c.id AS channel_id
      FROM podcast_episodes e
      JOIN podcast_channels c ON c.id = e.channel_id
      WHERE e.id = $1
    `, [req.params.id]);
    if (!ep.rows.length) return res.status(404).json({ error: "Not found" });
    await pool.query("UPDATE podcast_episodes SET views = views + 1 WHERE id=$1", [req.params.id]);
    const comments = await pool.query(
      "SELECT * FROM podcast_comments WHERE episode_id=$1 ORDER BY created_at DESC",
      [req.params.id]
    );
    res.json({ ...ep.rows[0], views: ep.rows[0].views + 1, comments: comments.rows });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/podcast/episodes", requireAuth, async (req: any, res) => {
  try {
    const channel = await pool.query("SELECT id FROM podcast_channels WHERE user_id=$1", [req.user.id]);
    if (!channel.rows.length) return res.status(400).json({ error: "Create a channel first" });

    const { title, description, video_type = "youtube", video_url, youtube_url,
            facebook_url, tiktok_url, thumbnail_url, tags, duration_mins,
            episode_number, season_number } = req.body;

    if (!title) return res.status(400).json({ error: "title required" });
    if (!youtube_url && !facebook_url && !tiktok_url && !video_url) {
      return res.status(400).json({ error: "At least one video URL required" });
    }

    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO podcast_episodes(id,channel_id,user_id,title,description,video_type,video_url,youtube_url,facebook_url,tiktok_url,thumbnail_url,tags,duration_mins,episode_number,season_number,views,likes,status,published_at,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,0,0,'published',NOW(),NOW())
    `, [id, channel.rows[0].id, req.user.id, title, description || null,
       video_type, video_url || null, youtube_url || null, facebook_url || null,
       tiktok_url || null, thumbnail_url || null, tags || null,
       duration_mins || null, episode_number || null, season_number || null]);
    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/podcast/episodes/:id", requireAuth, async (req: any, res) => {
  try {
    await pool.query("DELETE FROM podcast_episodes WHERE id=$1 AND user_id=$2", [req.params.id, (req as any).user.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/podcast/episodes/:id/like", requireAuth, async (req: any, res) => {
  try {
    const existing = await pool.query(
      "SELECT 1 FROM podcast_likes WHERE episode_id=$1 AND user_id=$2",
      [req.params.id, req.user.id]
    );
    if (existing.rows.length) {
      await pool.query("DELETE FROM podcast_likes WHERE episode_id=$1 AND user_id=$2", [req.params.id, req.user.id]);
      await pool.query("UPDATE podcast_episodes SET likes = GREATEST(0, likes - 1) WHERE id=$1", [req.params.id]);
      return res.json({ liked: false });
    }
    await pool.query("INSERT INTO podcast_likes VALUES($1,$2) ON CONFLICT DO NOTHING", [req.params.id, req.user.id]);
    await pool.query("UPDATE podcast_episodes SET likes = likes + 1 WHERE id=$1", [req.params.id]);
    res.json({ liked: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.post("/api/podcast/episodes/:id/comments", requireAuth, async (req: any, res) => {
  try {
    const { body } = req.body;
    if (!body?.trim()) return res.status(400).json({ error: "body required" });
    const id = crypto.randomUUID();
    await pool.query(`
      INSERT INTO podcast_comments(id,episode_id,user_id,author_name,body,created_at)
      VALUES($1,$2,$3,$4,$5,NOW())
    `, [id, req.params.id, req.user.id, req.user.full_name || req.user.email, body]);
    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// ── ADMIN ─────────────────────────────────────────────────────────────────────

router.get("/api/admin/podcast/channels", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const result = await pool.query(`
      SELECT c.*,
        (SELECT COUNT(*)::int FROM podcast_episodes WHERE channel_id = c.id) AS episode_count,
        (SELECT SUM(views)::int FROM podcast_episodes WHERE channel_id = c.id) AS total_views
      FROM podcast_channels c
      ORDER BY c.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/admin/podcast/channels/:id", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    await pool.query("DELETE FROM podcast_channels WHERE id=$1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/admin/podcast/episodes", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const result = await pool.query(`
      SELECT e.*, c.name AS channel_name
      FROM podcast_episodes e
      JOIN podcast_channels c ON c.id = e.channel_id
      ORDER BY e.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/admin/podcast/episodes/:id", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    await pool.query("DELETE FROM podcast_episodes WHERE id=$1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.patch("/api/admin/podcast/channels/:id/status", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const { status } = req.body;
    await pool.query("UPDATE podcast_channels SET status=$2 WHERE id=$1", [req.params.id, status]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// ── ADMIN: BlueCertified ──────────────────────────────────────────────────────

router.get("/api/admin/bluecertified/profiles", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const result = await pool.query(`
      SELECT p.*,
        (SELECT COUNT(*)::int FROM blc_contractor_reviews WHERE contractor_id = p.id) AS review_count,
        COALESCE((SELECT ROUND(AVG(rating)::numeric,1) FROM blc_contractor_reviews WHERE contractor_id = p.id), 0) AS avg_rating
      FROM blc_contractor_profiles p
      ORDER BY p.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/admin/bluecertified/profiles/:id", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    await pool.query("DELETE FROM blc_contractor_profiles WHERE id=$1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.patch("/api/admin/bluecertified/profiles/:id/status", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const { status } = req.body;
    await pool.query("UPDATE blc_contractor_profiles SET status=$2 WHERE id=$1", [req.params.id, status]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/admin/bluecertified/jobs", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const result = await pool.query("SELECT * FROM blc_job_postings ORDER BY created_at DESC");
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/admin/bluecertified/jobs/:id", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    await pool.query("DELETE FROM blc_job_postings WHERE id=$1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// ── ADMIN: PropConnect ────────────────────────────────────────────────────────

router.get("/api/admin/propconnect/profiles", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const result = await pool.query(`
      SELECT p.*,
        (SELECT COUNT(*)::int FROM re_reviews WHERE profile_id = p.id) AS review_count
      FROM re_profiles p ORDER BY p.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/admin/propconnect/profiles/:id", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    await pool.query("DELETE FROM re_profiles WHERE id=$1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.patch("/api/admin/propconnect/profiles/:id/status", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const { status } = req.body;
    await pool.query("UPDATE re_profiles SET status=$2 WHERE id=$1", [req.params.id, status]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/admin/propconnect/listings", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const result = await pool.query(`
      SELECT l.*, p.full_name AS agent_name FROM re_listings l
      JOIN re_profiles p ON p.id = l.profile_id
      ORDER BY l.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/admin/propconnect/listings/:id", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    await pool.query("DELETE FROM re_listings WHERE id=$1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.get("/api/admin/propconnect/forum", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const result = await pool.query("SELECT * FROM re_forum_posts ORDER BY created_at DESC");
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/api/admin/propconnect/forum/:id", requireAuth, async (req: any, res) => {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    await pool.query("DELETE FROM re_forum_posts WHERE id=$1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

export default router;
