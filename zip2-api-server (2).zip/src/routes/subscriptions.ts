import { Router } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { stripe } from "../lib/stripe.js";
import { requireAuth, AuthRequest } from "../middleware/auth.js";
import { logAudit } from "./admin.js";
import { checkAndAlertChurn } from "./admin.js";

const router = Router();

const TIER_LABELS: Record<string, string> = {
  pro: "Buyshare Pro",
  contractor: "Buyshare Contractor Pro",
  thrift: "THRIFTgirl Membership",
};

async function sendCancellationEmail(email: string, tier: string, currentPeriodEnd: Date | string | null) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.log(`[cancel-email] Skipped (no RESEND_API_KEY). To: ${email}`);
    return;
  }

  const from = process.env.RESEND_FROM_EMAIL
    ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
    : "Buyshare <onboarding@resend.dev>";

  const tierLabel = TIER_LABELS[tier] || tier;
  const domain = process.env.PUBLIC_DOMAIN || "buyshare.co";
  const resubscribeUrl = `https://${domain}/pricing`;

  const accessEndsText = currentPeriodEnd
    ? new Date(currentPeriodEnd).toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })
    : "the end of your current billing period";

  const html = `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:32px 24px;color:#1a1a1a;">
      <img src="https://bluetruck.co/assets/share-logo.png" alt="SHARE" style="height:40px;margin-bottom:24px;" />
      <h1 style="font-size:22px;font-weight:700;margin:0 0 8px;">Your subscription has been cancelled</h1>
      <p style="color:#555;margin:0 0 24px;">We've received your cancellation request. Here's a summary:</p>

      <div style="background:#f9f9f9;border-radius:8px;padding:20px 24px;margin-bottom:24px;">
        <p style="margin:0 0 8px;"><strong>Plan:</strong> ${tierLabel}</p>
        <p style="margin:0;"><strong>Access ends:</strong> ${accessEndsText}</p>
      </div>

      <p style="color:#555;margin:0 0 24px;">
        You'll continue to have full access to all ${tierLabel} features until that date.
        After that, your account will revert to the free plan.
      </p>

      <a href="${resubscribeUrl}"
         style="display:inline-block;background:#1a1a1a;color:#fff;text-decoration:none;padding:12px 24px;border-radius:6px;font-weight:600;font-size:15px;">
        Resubscribe
      </a>

      <p style="color:#aaa;font-size:12px;margin-top:32px;">
        If you didn't request this cancellation, please contact us immediately at
        <a href="mailto:support@buyshare.co" style="color:#aaa;">support@buyshare.co</a>.
      </p>
    </div>
  `;

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: email, subject: `Your ${tierLabel} cancellation confirmation`, html }),
    });
    if (!response.ok) {
      const body = await response.text();
      console.error(`[cancel-email] Resend error ${response.status}: ${body}`);
    } else {
      console.log(`[cancel-email] Cancellation confirmation sent to ${email} (tier: ${tier})`);
    }
  } catch (err) {
    console.error("[cancel-email] Failed to send cancellation email:", err);
  }
}

let priceIds: { pro: string; contractor: string; thrift: string } | null = null;

async function ensurePrices() {
  if (priceIds) return priceIds;

  const list = await stripe.prices.list({ active: true, limit: 100 });

  let proPrice = list.data.find(p => p.metadata?.buyshare_product === "pro" && p.recurring?.interval === "month");
  let contractorPrice = list.data.find(p => p.metadata?.buyshare_product === "contractor" && p.recurring?.interval === "month");
  let thriftPrice = list.data.find(p => p.metadata?.buyshare_product === "thrift" && p.recurring?.interval === "month");

  if (!proPrice) {
    const product = await stripe.products.create({
      name: "Buyshare Pro",
      description: "Unlimited listings, priority map placement, PLAYDATE Verified badge, advanced dashboard.",
      metadata: { buyshare_product: "pro" },
    });
    proPrice = await stripe.prices.create({
      product: product.id,
      unit_amount: 500,
      currency: "usd",
      recurring: { interval: "month" },
      metadata: { buyshare_product: "pro" },
    });
  }

  if (!contractorPrice) {
    const product = await stripe.products.create({
      name: "Buyshare Contractor Pro",
      description: "Full contractor portal, BlueTruck job matching, project manager tools, and all Pro features.",
      metadata: { buyshare_product: "contractor" },
    });
    contractorPrice = await stripe.prices.create({
      product: product.id,
      unit_amount: 1500,
      currency: "usd",
      recurring: { interval: "month" },
      metadata: { buyshare_product: "contractor" },
    });
  }

  if (!thriftPrice) {
    const product = await stripe.products.create({
      name: "Thrift Girl Membership",
      description: "Full access to Thrift Girl marketplace — buy, sell, trade, and give away items. 3-day free trial.",
      metadata: { buyshare_product: "thrift" },
    });
    thriftPrice = await stripe.prices.create({
      product: product.id,
      unit_amount: 500,
      currency: "usd",
      recurring: { interval: "month" },
      metadata: { buyshare_product: "thrift" },
    });
  }

  priceIds = { pro: proPrice.id, contractor: contractorPrice.id, thrift: thriftPrice.id };
  return priceIds;
}

async function ensureSubTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS subscriptions (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      name TEXT,
      tier TEXT NOT NULL,
      stripe_customer_id TEXT,
      stripe_subscription_id TEXT,
      stripe_session_id TEXT,
      status TEXT DEFAULT 'pending',
      current_period_end TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
}

let dbReady = false;
async function withDB(fn: () => Promise<void>, res: any) {
  try {
    if (!dbReady) { await ensureSubTable(); dbReady = true; }
    await fn();
  } catch (err: any) {
    console.error("subscription error:", err);
    res.status(500).json({ error: err.message || "Server error" });
  }
}

router.post("/subscribe/checkout", async (req, res) => {
  await withDB(async () => {
    const { email, name, tier } = req.body;
    if (!email || !["pro", "contractor", "thrift"].includes(tier)) {
      res.status(400).json({ error: "email and valid tier (pro | contractor | thrift) required" });
      return;
    }

    const prices = await ensurePrices();
    const priceId = tier === "contractor" ? prices.contractor : tier === "thrift" ? prices.thrift : prices.pro;

    const origin = req.headers.origin || req.headers.referer?.replace(/\/[^/]*$/, "") || "";
    const baseUrl = origin.includes("localhost") ? `http://localhost:${process.env.PORT || 3000}` : origin;

    const successPath = tier === "thrift" ? "/thrift" : "/pricing";
    const cancelPath = tier === "thrift" ? "/thrift/join" : "/pricing";

    const sessionParams: any = {
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [{ price: priceId, quantity: 1 }],
      customer_email: email,
      metadata: { tier, name: name || "", email },
      success_url: `${baseUrl}${successPath}?subscribed=1&tier=${tier}&session_id={CHECKOUT_SESSION_ID}&email=${encodeURIComponent(email)}`,
      cancel_url: `${baseUrl}${cancelPath}`,
    };

    if (tier === "thrift") {
      sessionParams.subscription_data = { trial_period_days: 30 };
    }

    const session = await stripe.checkout.sessions.create(sessionParams);

    const id = `sub-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    await db.execute(sql`
      INSERT INTO subscriptions (id, email, name, tier, stripe_session_id, status)
      VALUES (${id}, ${email.toLowerCase()}, ${name || null}, ${tier}, ${session.id}, 'pending')
      ON CONFLICT DO NOTHING
    `);

    res.json({ url: session.url, sessionId: session.id });

    // Fire-and-forget: admin alert for new subscription checkout
    const _apiKey = process.env.RESEND_API_KEY;
    if (_apiKey) {
      const _from = process.env.RESEND_FROM_EMAIL
        ? `Buyshare <${process.env.RESEND_FROM_EMAIL}>`
        : "Buyshare <onboarding@resend.dev>";
      const tierLabel = tier === "contractor" ? "Contractor Pro ($15/mo)" : tier === "thrift" ? "Thrift Club ($3/mo)" : "Pro ($5/mo)";
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${_apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: _from,
          to: ["burnsinc@outlook.com", "admin@buyshare.co"],
          subject: `💳 New subscription checkout — ${tierLabel}`,
          html: `<div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px">
            <h2 style="color:#7c3aed">New Subscription Started</h2>
            <table style="border-collapse:collapse;width:100%">
              <tr><td style="padding:6px 0;font-weight:600;width:120px">Name</td><td>${name || "—"}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Email</td><td>${email.toLowerCase()}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Plan</td><td>${tierLabel}</td></tr>
              <tr><td style="padding:6px 0;font-weight:600">Session</td><td style="font-size:12px;color:#6b7280">${session.id}</td></tr>
            </table>
            <a href="https://buyshare.co/admin/subscriptions" style="display:inline-block;background:#7c3aed;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;margin-top:16px">View Subscriptions</a>
          </div>`,
        }),
      }).catch(() => {});
    }
  }, res);
});

router.get("/subscribe/status", async (req, res) => {
  await withDB(async () => {
    const { email, session_id } = req.query as { email?: string; session_id?: string };
    if (!email && !session_id) {
      res.status(400).json({ error: "email or session_id required" });
      return;
    }

    if (session_id) {
      try {
        const session = await stripe.checkout.sessions.retrieve(session_id as string, { expand: ["subscription"] });
        const sub = session.subscription as any;
        const validStatuses = ["active", "trialing"];
        if (sub && validStatuses.includes(sub.status)) {
          const tier = session.metadata?.tier || "pro";
          await db.execute(sql`
            UPDATE subscriptions
            SET status = ${sub.status},
                stripe_subscription_id = ${sub.id},
                stripe_customer_id = ${sub.customer as string},
                current_period_end = to_timestamp(${sub.current_period_end})
            WHERE stripe_session_id = ${session_id}
          `);
          res.json({ subscribed: true, tier, status: sub.status });
          return;
        }
      } catch (e) { console.error("session retrieve error", e); }
    }

    if (email) {
      const row = await db.execute(sql`
        SELECT * FROM subscriptions WHERE email = ${email.toLowerCase()}
        AND status IN ('active', 'trialing')
        ORDER BY created_at DESC LIMIT 1
      `);
      const sub = (row.rows as any[])[0];
      if (sub) {
        res.json({ subscribed: true, tier: sub.tier, status: sub.status, current_period_end: sub.current_period_end, cancel_at_period_end: sub.cancel_at_period_end ?? false });
        return;
      }
    }

    res.json({ subscribed: false, tier: "free", status: "none" });
  }, res);
});

router.get("/subscribe/all", async (req, res) => {
  await withDB(async () => {
    const result = await db.execute(sql`SELECT * FROM subscriptions ORDER BY created_at DESC`);
    res.json({ subscriptions: result.rows });
  }, res);
});

router.post("/subscribe/cancel", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const userEmail = req.user?.email;
    if (!userEmail) {
      res.status(401).json({ error: "Not authenticated" });
      return;
    }

    await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS cancel_at_period_end BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
    await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS canceled_at TIMESTAMPTZ`).catch(() => {});

    const row = await db.execute(sql`
      SELECT * FROM subscriptions
      WHERE email = ${userEmail.toLowerCase()}
        AND status IN ('active', 'trialing')
        AND (cancel_at_period_end IS NULL OR cancel_at_period_end = FALSE)
      ORDER BY created_at DESC LIMIT 1
    `);
    const sub = (row.rows as any[])[0];

    if (!sub) {
      res.status(404).json({ error: "No active subscription found" });
      return;
    }
    if (!sub.stripe_subscription_id) {
      res.status(400).json({ error: "No Stripe subscription ID on this record" });
      return;
    }

    await stripe.subscriptions.update(sub.stripe_subscription_id, { cancel_at_period_end: true });
    await db.execute(sql`
      UPDATE subscriptions
      SET cancel_at_period_end = TRUE, canceled_at = NOW()
      WHERE id = ${sub.id}
    `);

    await logAudit(userEmail, "cancel", "subscription", sub.id, `Self-service cancel: Stripe sub ${sub.stripe_subscription_id} set cancel_at_period_end=true; access retained until period end`);

    res.json({ ok: true, current_period_end: sub.current_period_end });
    sendCancellationEmail(userEmail, sub.tier, sub.current_period_end).catch(err => console.error("[cancel-email] post-cancel email failed:", err));
    checkAndAlertChurn().catch(err => console.error("[churn-alert] post-cancel check failed:", err));
  }, res);
});

router.post("/subscribe/reactivate", requireAuth, async (req: AuthRequest, res) => {
  await withDB(async () => {
    const userEmail = req.user?.email;
    if (!userEmail) {
      res.status(401).json({ error: "Not authenticated" });
      return;
    }

    await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS cancel_at_period_end BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
    await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS canceled_at TIMESTAMPTZ`).catch(() => {});

    const row = await db.execute(sql`
      SELECT * FROM subscriptions
      WHERE email = ${userEmail.toLowerCase()}
        AND status IN ('active', 'trialing')
        AND cancel_at_period_end = TRUE
      ORDER BY created_at DESC LIMIT 1
    `);
    const sub = (row.rows as any[])[0];

    if (!sub) {
      res.status(404).json({ error: "No subscription scheduled for cancellation found" });
      return;
    }
    if (!sub.stripe_subscription_id) {
      res.status(400).json({ error: "No Stripe subscription ID on this record" });
      return;
    }

    await stripe.subscriptions.update(sub.stripe_subscription_id, { cancel_at_period_end: false });
    await db.execute(sql`
      UPDATE subscriptions
      SET cancel_at_period_end = FALSE, canceled_at = NULL
      WHERE id = ${sub.id}
    `);

    await logAudit(userEmail, "reactivate", "subscription", sub.id, `Self-service reactivate: Stripe sub ${sub.stripe_subscription_id} set cancel_at_period_end=false`);

    res.json({ ok: true, current_period_end: sub.current_period_end });
  }, res);
});

export default router;
