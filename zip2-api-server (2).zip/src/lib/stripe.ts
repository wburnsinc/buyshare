import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY environment variable is required");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-05-28.basil",
});

/**
 * Buyshare split calculator — all math in cents to avoid floating-point errors.
 * - 10% platform commission on rental price only
 * - Stripe fee (2.9% + $0.30) passed to renter when passFeesToRenter=true
 * - Security deposit held separately in platform escrow
 * - Optional $3.99 Buyshare Protection
 */
export function calculateSplit(opts: {
  rentalCents: number;
  depositCents: number;
  addProtection: boolean;
  passFeesToRenter: boolean;
  deliveryFeeCents?: number;
}) {
  const { rentalCents, depositCents, addProtection, passFeesToRenter, deliveryFeeCents = 0 } = opts;

  const platformCommission = Math.round(rentalCents * 0.10);
  const protectionFee = addProtection ? 399 : 0;

  let stripeFees = 0;
  let totalCharge: number;

  if (passFeesToRenter) {
    const subtotal = rentalCents + depositCents + protectionFee + deliveryFeeCents;
    stripeFees = Math.round(subtotal * 0.029) + 30;
    totalCharge = subtotal + stripeFees;
  } else {
    totalCharge = rentalCents + depositCents + protectionFee + deliveryFeeCents;
  }

  const ownerPayout = rentalCents - platformCommission;

  return {
    rentalCents,
    depositCents,
    platformFeeCents: platformCommission,
    stripeFeesCents: stripeFees,
    protectionFeeCents: protectionFee,
    deliveryFeeCents,
    totalChargeCents: totalCharge,
    ownerPayoutCents: ownerPayout,
  };
}

export function getRentalDays(start: Date, end: Date): number {
  const ms = end.getTime() - start.getTime();
  return Math.max(1, Math.ceil(ms / (1000 * 60 * 60 * 24)));
}
