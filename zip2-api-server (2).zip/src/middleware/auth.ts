import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";

const JWT_SECRET = process.env.JWT_SECRET || "buyshare-jwt-secret-2026";

let lastActiveColumnEnsured = false;
async function ensureLastActiveColumn() {
  if (lastActiveColumnEnsured) return;
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMPTZ`).catch(() => {});
  lastActiveColumnEnsured = true;
}

export interface AuthRequest extends Request {
  user?: any;
}

export async function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const token = header.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET) as { userId: string };
    await ensureLastActiveColumn();
    const result = await db.execute(sql`
      SELECT id, email, name, phone, role, avatar_url, stripe_account_id,
             is_admin, is_verified, is_banned, created_at, last_active_at
      FROM users WHERE id = ${payload.userId} LIMIT 1
    `);
    const user = (result.rows as any[])[0];
    if (!user) { res.status(401).json({ error: "User not found" }); return; }
    req.user = user;
    db.execute(sql`UPDATE users SET last_active_at = NOW() WHERE id = ${payload.userId}`).catch(() => {});
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

export async function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  await requireAuth(req, res, async () => {
    if (!req.user?.is_admin) {
      res.status(403).json({ error: "Admin access required" });
      return;
    }
    next();
  });
}

const MASTER_ADMIN_EMAILS = ["burnsinc@outlook.com", "admin@buyshare.co"];

export async function requireMasterAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  await requireAuth(req, res, async () => {
    const email = req.user?.email?.toLowerCase();
    // Email whitelist is the security gate — is_admin DB flag is a bonus,
    // not a hard requirement, since the hardcoded email list + valid JWT is sufficient.
    if (!MASTER_ADMIN_EMAILS.includes(email)) {
      res.status(403).json({ error: "Master admin access required" });
      return;
    }
    // Ensure is_admin is set in the DB so other checks (requireAdmin) also work
    if (!req.user?.is_admin) {
      db.execute(sql`UPDATE users SET is_admin = TRUE, is_verified = TRUE WHERE id = ${req.user.id}`).catch(() => {});
    }
    next();
  });
}

export { JWT_SECRET };
