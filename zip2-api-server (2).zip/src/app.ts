import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "path";
import { fileURLToPath } from "url";
import router from "./routes/index.js";
import webhookRouter from "./routes/webhooks.js";
import { logger } from "./lib/logger.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app: Express = express();

// ── Security headers ──────────────────────────────────────────────────────────
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "geolocation=(), camera=(), microphone=()");
  res.removeHeader("X-Powered-By");
  next();
});

// ── In-memory rate limiter (no external dep) ──────────────────────────────────
const rlWindows = new Map<string, number[]>();
setInterval(() => rlWindows.clear(), 60_000); // flush every minute

function rateLimit(maxReqs: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = (req.headers["x-forwarded-for"] as string)?.split(",")[0].trim() || req.ip || "unknown";
    const now = Date.now();
    const cutoff = now - windowMs;
    const hits = (rlWindows.get(ip) ?? []).filter((t) => t > cutoff);
    hits.push(now);
    rlWindows.set(ip, hits);
    if (hits.length > maxReqs) {
      res.status(429).json({ error: "Too many requests — please slow down." });
      return;
    }
    next();
  };
}

// ── CORS ──────────────────────────────────────────────────────────────────────
const ALLOWED_ORIGINS = [
  "https://buyshare.co",
  "https://www.buyshare.co",
  "https://buyshare.app",
  "https://www.buyshare.app",
  "https://buyshare.site",
  "https://www.buyshare.site",
];

app.use(
  cors({
    origin: (origin, cb) => {
      if (!origin) return cb(null, true); // server-to-server / curl
      const o = origin.toLowerCase();
      const ok =
        ALLOWED_ORIGINS.includes(o) ||
        /^https?:\/\/[^.]+\.replit\.(dev|app)$/.test(o) ||
        /^https?:\/\/localhost(:\d+)?$/.test(o);
      cb(ok ? null : new Error("CORS: origin not allowed"), ok);
    },
    credentials: true,
  }),
);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
      },
      res(res) {
        return { statusCode: res.statusCode };
      },
    },
  }),
);

// ── Stripe webhooks need raw body — must come BEFORE express.json() ───────────
app.use(
  "/api/webhooks/stripe",
  express.raw({ type: "application/json" }),
  webhookRouter,
);

// Body limits — prevent oversized payloads
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));

// ── Global rate limits ────────────────────────────────────────────────────────
app.use("/api/auth", rateLimit(20, 60_000));            // 20 auth attempts/min
app.use("/api/share-listings", rateLimit(30, 60_000));  // 30 listing ops/min
app.use("/api/share-bookings", rateLimit(20, 60_000));  // 20 booking ops/min
app.use("/api", rateLimit(200, 60_000));                 // 200 general/min

// ── Serve uploaded files statically ──────────────────────────────────────────
app.use("/uploads", express.static(path.join(process.cwd(), "public/uploads")));

app.use("/api", router);

export default app;
