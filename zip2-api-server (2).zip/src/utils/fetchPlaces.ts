export interface PlaceResult {
  place_id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  rating: number | null;
  review_count: number | null;
  website: string | null;
  phone: string | null;
}

export async function fetchPlaces(city: string, type: string): Promise<PlaceResult[]> {
  const apiKey = process.env.GOOGLE_API_KEY || process.env.GOOGLE_PLACES_API_KEY;
  if (!apiKey) throw new Error("GOOGLE_API_KEY not configured in environment");

  const query = `${type} in ${city} FL`;
  const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(query)}&key=${apiKey}`;
  const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
  const data: any = await response.json();

  if (data.status === "REQUEST_DENIED" || data.status === "INVALID_REQUEST") {
    throw new Error(`Google API: ${data.status} — ${data.error_message || "Check your API key and ensure Places API is enabled"}`);
  }
  if (data.status === "ZERO_RESULTS") return [];

  return (data.results || []).map((b: any) => ({
    place_id: b.place_id,
    name: b.name,
    address: b.formatted_address || "",
    lat: b.geometry?.location?.lat ?? null,
    lng: b.geometry?.location?.lng ?? null,
    rating: b.rating ?? null,
    review_count: b.user_ratings_total ?? null,
    website: b.website ?? null,
    phone: b.formatted_phone_number ?? null,
  }));
}
