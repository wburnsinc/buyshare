import app from "./app";
import { logger } from "./lib/logger";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { startReminderScheduler } from "./routes/playdate.js";
import { startChurnAlertScheduler, startWeeklyDigestScheduler } from "./routes/admin.js";

const ADMIN_ACCOUNTS = [
  { id: "master-admin-001", email: "burnsinc@outlook.com", name: "Burns Inc. Admin", phone: "2232548299" },
  { id: "master-admin-002", email: "admin@buyshare.co",    name: "Buyshare Admin",   phone: "" },
];

async function ensureAllTables() {
  // Users extra columns (Drizzle schema additions)
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS is_verified BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_initials TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS address TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS hide_address BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS subscription_tier TEXT`).catch(() => {});

  // Self-init tables — created here so both dev and prod have them, preventing
  // Replit's publisher from generating DROP TABLE / CREATE TABLE conflicts.
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS audit_log (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      admin_email TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS notifications (
      id SERIAL PRIMARY KEY,
      user_id TEXT,
      type TEXT NOT NULL DEFAULT 'info',
      message TEXT NOT NULL,
      read BOOLEAN NOT NULL DEFAULT FALSE,
      link TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `).catch(() => {});

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS subscriptions (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      name TEXT,
      tier TEXT NOT NULL,
      stripe_customer_id TEXT,
      stripe_subscription_id TEXT,
      stripe_session_id TEXT,
      status TEXT DEFAULT 'pending',
      current_period_end TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS share_listings (
      id SERIAL PRIMARY KEY,
      share_type TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      address TEXT,
      city TEXT DEFAULT 'Punta Gorda',
      price_per_hour NUMERIC(10,2),
      price_per_day NUMERIC(10,2),
      max_guests INTEGER,
      amenities TEXT[],
      rules TEXT,
      host_name TEXT,
      host_email TEXT,
      photo_urls TEXT[],
      status TEXT NOT NULL DEFAULT 'active',
      average_rating NUMERIC(3,2),
      review_count INTEGER DEFAULT 0,
      stripe_account_id TEXT,
      onboard_token TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `).catch(() => {});

  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS host_email TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS photo_urls TEXT[]`).catch(() => {});
  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS stripe_account_id TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE share_listings ADD COLUMN IF NOT EXISTS onboard_token TEXT`).catch(() => {});

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS share_bookings (
      id SERIAL PRIMARY KEY,
      listing_id INTEGER REFERENCES share_listings(id),
      share_type TEXT NOT NULL,
      guest_name TEXT NOT NULL,
      guest_email TEXT,
      guest_phone TEXT,
      start_date TIMESTAMPTZ,
      end_date TIMESTAMPTZ,
      guest_count INTEGER DEFAULT 1,
      message TEXT,
      amount_cents INTEGER DEFAULT 0,
      stripe_session_id TEXT,
      stripe_payment_status TEXT DEFAULT 'pending',
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `).catch(() => {});

  await db.execute(sql`ALTER TABLE share_bookings ADD COLUMN IF NOT EXISTS amount_cents INTEGER DEFAULT 0`).catch(() => {});
  await db.execute(sql`ALTER TABLE share_bookings ADD COLUMN IF NOT EXISTS stripe_session_id TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE share_bookings ADD COLUMN IF NOT EXISTS stripe_payment_status TEXT DEFAULT 'pending'`).catch(() => {});

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS map_pins (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      label TEXT NOT NULL,
      lat DOUBLE PRECISION NOT NULL,
      lng DOUBLE PRECISION NOT NULL,
      category TEXT NOT NULL DEFAULT 'Other',
      phone TEXT,
      description TEXT,
      icon_color TEXT NOT NULL DEFAULT 'blue',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // ── laytons_bookings ────────────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS laytons_bookings (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      service TEXT NOT NULL,
      address TEXT NOT NULL,
      preferred_date TEXT NOT NULL,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE laytons_bookings ADD COLUMN IF NOT EXISTS stripe_session_id TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE laytons_bookings ADD COLUMN IF NOT EXISTS stripe_payment_status TEXT DEFAULT 'pending'`).catch(() => {});
  await db.execute(sql`ALTER TABLE laytons_bookings ADD COLUMN IF NOT EXISTS amount_cents INTEGER DEFAULT 0`).catch(() => {});

  // ── contractors ─────────────────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractors (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      business_name TEXT,
      services TEXT,
      zip_code TEXT,
      bio TEXT,
      license_number TEXT,
      years_experience INTEGER,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS photo_url TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS hourly_rate NUMERIC`).catch(() => {});
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT 'none'`).catch(() => {});
  await db.execute(sql`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()`).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractor_jobs (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      location TEXT NOT NULL,
      address TEXT,
      pay TEXT NOT NULL,
      pay_amount NUMERIC DEFAULT 0,
      description TEXT,
      client_name TEXT,
      client_phone TEXT,
      scheduled_date TEXT,
      scheduled_time TEXT,
      tags TEXT,
      status TEXT DEFAULT 'open',
      posted_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractor_claims (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      contractor_email TEXT NOT NULL,
      status TEXT DEFAULT 'claimed',
      notes TEXT,
      claimed_at TIMESTAMP DEFAULT NOW(),
      completed_at TIMESTAMP,
      UNIQUE(job_id, contractor_email)
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contractor_ratings (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      contractor_email TEXT NOT NULL,
      client_name TEXT,
      rating INTEGER DEFAULT 5,
      review TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});

  // ── thrift tables ────────────────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_listings (
      id TEXT PRIMARY KEY,
      seller_email TEXT NOT NULL,
      seller_name TEXT,
      title TEXT NOT NULL,
      description TEXT,
      category TEXT NOT NULL,
      condition TEXT NOT NULL,
      price_type TEXT NOT NULL DEFAULT 'asking',
      price INTEGER DEFAULT 0,
      photo1_url TEXT,
      photo2_url TEXT,
      location_text TEXT,
      lat NUMERIC,
      lng NUMERIC,
      status TEXT DEFAULT 'available',
      pickup_date TEXT,
      views INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE thrift_listings ADD COLUMN IF NOT EXISTS flagged BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE thrift_listings ADD COLUMN IF NOT EXISTS featured BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_comments (
      id TEXT PRIMARY KEY,
      listing_id TEXT NOT NULL,
      commenter_email TEXT NOT NULL,
      commenter_name TEXT,
      parent_id TEXT,
      body TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_messages (
      id TEXT PRIMARY KEY,
      from_email TEXT NOT NULL,
      from_name TEXT,
      to_email TEXT NOT NULL,
      listing_id TEXT,
      listing_title TEXT,
      body TEXT NOT NULL,
      is_read BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_reviews (
      id TEXT PRIMARY KEY,
      reviewer_email TEXT NOT NULL,
      reviewer_name TEXT,
      reviewee_email TEXT NOT NULL,
      listing_id TEXT,
      stars INTEGER NOT NULL,
      body TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_blocks (
      blocker_email TEXT NOT NULL,
      blocked_email TEXT NOT NULL,
      PRIMARY KEY (blocker_email, blocked_email)
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_delivery_requests (
      id TEXT PRIMARY KEY,
      listing_id TEXT,
      listing_title TEXT,
      seller_email TEXT,
      buyer_email TEXT NOT NULL,
      buyer_name TEXT,
      delivery_address TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS thrift_reports (
      id TEXT PRIMARY KEY,
      listing_id TEXT NOT NULL,
      reporter_email TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});

  // ── pro_requests / vetted_pros / pro_reviews ──────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS pro_requests (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      business_name TEXT NOT NULL,
      contact_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      title TEXT,
      location TEXT,
      website TEXT,
      photo_url TEXT,
      service_areas TEXT,
      years_experience TEXT,
      license_number TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS title TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS location TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS claim_code TEXT DEFAULT gen_random_uuid()::text`).catch(() => {});
  await db.execute(sql`ALTER TABLE pro_requests ADD COLUMN IF NOT EXISTS claimed_by_user_id TEXT`).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS vetted_pros (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      business_name TEXT NOT NULL,
      contact_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      title TEXT,
      location TEXT,
      website TEXT,
      photo_url TEXT,
      lat NUMERIC,
      lng NUMERIC,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE vetted_pros ADD COLUMN IF NOT EXISTS request_id TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE vetted_pros ADD COLUMN IF NOT EXISTS email TEXT`).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS pro_reviews (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      pro_id TEXT NOT NULL,
      reviewer_name TEXT NOT NULL,
      stars INTEGER NOT NULL CHECK (stars >= 1 AND stars <= 5),
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // ── meetups / meetup_rsvps ────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS meetups (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      location TEXT NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      description TEXT,
      host_name TEXT NOT NULL,
      contact TEXT,
      category TEXT DEFAULT 'general',
      max_attendees INTEGER DEFAULT 20,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE meetups ADD COLUMN IF NOT EXISTS host_code TEXT`).catch(() => {});
  await db.execute(sql`ALTER TABLE meetups ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active'`).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS meetup_rsvps (
      id TEXT PRIMARY KEY,
      meetup_id TEXT NOT NULL REFERENCES meetups(id) ON DELETE CASCADE,
      first_name TEXT NOT NULL,
      last_initial TEXT NOT NULL,
      contact TEXT NOT NULL,
      num_children INTEGER NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE meetup_rsvps ADD COLUMN IF NOT EXISTS reminded_at TIMESTAMP`).catch(() => {});
  await db.execute(sql`ALTER TABLE meetup_rsvps ADD COLUMN IF NOT EXISTS emailed_at TIMESTAMP`).catch(() => {});
  await db.execute(sql`ALTER TABLE meetup_rsvps ADD COLUMN IF NOT EXISTS emailed_type TEXT`).catch(() => {});

  // ── investors ─────────────────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS investors (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      amount INTEGER NOT NULL,
      tier TEXT NOT NULL,
      annual_return_pct NUMERIC NOT NULL,
      stripe_session_id TEXT,
      stripe_payment_status TEXT DEFAULT 'pending',
      status TEXT DEFAULT 'pending',
      notes TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});

  // ── services ──────────────────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS services (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      provider TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      price INTEGER NOT NULL DEFAULT 0,
      unit TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    )
  `).catch(() => {});

  // ── platform_settings ─────────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS platform_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT '',
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // ── business_saves ────────────────────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS business_saves (
      user_id TEXT NOT NULL,
      business_id TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (user_id, business_id)
    )
  `).catch(() => {});

  // ── businesses / business_claims ──────────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS businesses (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      business_name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      address TEXT,
      city TEXT,
      state TEXT DEFAULT 'FL',
      zip TEXT,
      phone TEXT,
      website TEXT,
      email TEXT,
      latitude NUMERIC,
      longitude NUMERIC,
      description TEXT,
      logo_url TEXT,
      photos TEXT[] DEFAULT '{}',
      hours TEXT,
      social_links TEXT,
      claim_status TEXT NOT NULL DEFAULT 'unclaimed',
      verified_status TEXT NOT NULL DEFAULT 'unverified',
      owner_user_id TEXT,
      featured BOOLEAN NOT NULL DEFAULT FALSE,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      views INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`ALTER TABLE businesses ADD COLUMN IF NOT EXISTS rating NUMERIC(3,1)`).catch(() => {});
  await db.execute(sql`ALTER TABLE businesses ADD COLUMN IF NOT EXISTS review_count INTEGER`).catch(() => {});
  await db.execute(sql`CREATE INDEX IF NOT EXISTS businesses_category_idx ON businesses (category)`).catch(() => {});
  await db.execute(sql`CREATE INDEX IF NOT EXISTS businesses_city_idx ON businesses (city)`).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS business_claims (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL,
      user_email TEXT NOT NULL,
      user_name TEXT,
      business_email TEXT,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // ── Extra column guards for schema-managed columns ────────────────────────
  await db.execute(sql`ALTER TABLE listings ADD COLUMN IF NOT EXISTS pinned BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE listings ADD COLUMN IF NOT EXISTS featured BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS cancel_at_period_end BOOLEAN NOT NULL DEFAULT FALSE`).catch(() => {});
  await db.execute(sql`ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS canceled_at TIMESTAMPTZ`).catch(() => {});

  // ── quick_earn_jobs / quick_earn_bids ─────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS quick_earn_jobs (
      id TEXT PRIMARY KEY,
      poster_user_id TEXT NOT NULL,
      poster_name TEXT NOT NULL,
      poster_email TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL,
      rate TEXT NOT NULL,
      location_text TEXT,
      zip_code TEXT,
      deadline TEXT,
      status TEXT DEFAULT 'open',
      approved_bid_id TEXT,
      views INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS quick_earn_bids (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      bidder_user_id TEXT NOT NULL,
      bidder_name TEXT NOT NULL,
      bidder_email TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT NOW(),
      CONSTRAINT quick_earn_bids_unique UNIQUE(job_id, bidder_user_id)
    )
  `).catch(() => {});

  // ── BlueCertified contractor network ──────────────────────────────────────
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS blc_contractor_profiles (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      company_name TEXT,
      address TEXT,
      city TEXT NOT NULL,
      state TEXT NOT NULL DEFAULT 'FL',
      zip TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT,
      website TEXT,
      bio TEXT,
      years_experience INTEGER,
      license_number TEXT,
      insured BOOLEAN NOT NULL DEFAULT FALSE,
      photo_url TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      is_featured BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS blc_contractor_categories (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL REFERENCES blc_contractor_profiles(id) ON DELETE CASCADE,
      category TEXT NOT NULL,
      UNIQUE(profile_id, category)
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS blc_contractor_reviews (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL REFERENCES blc_contractor_profiles(id) ON DELETE CASCADE,
      reviewer_user_id TEXT NOT NULL,
      reviewer_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
      comment TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(profile_id, reviewer_user_id)
    )
  `).catch(() => {});
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS blc_job_postings (
      id TEXT PRIMARY KEY,
      posted_by_user_id TEXT NOT NULL,
      poster_name TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      category TEXT NOT NULL,
      city TEXT NOT NULL,
      zip TEXT,
      budget_min INTEGER,
      budget_max INTEGER,
      contact_email TEXT,
      contact_phone TEXT,
      job_type TEXT NOT NULL DEFAULT 'subcontract',
      status TEXT NOT NULL DEFAULT 'open',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
}

async function bootstrapMasterAdmin() {
  try {
    await ensureAllTables();

    const masterPass = process.env.MASTER_ADMIN_PASSWORD;
    if (!masterPass) {
      logger.warn("MASTER_ADMIN_PASSWORD not set — upserting is_admin flag on known admin emails");
      for (const acct of ADMIN_ACCOUNTS) {
        // UPDATE any existing user row with this email
        await db.execute(sql`UPDATE users SET is_admin = TRUE, is_verified = TRUE WHERE LOWER(email) = ${acct.email}`).catch(() => {});
      }
      return;
    }

    for (const acct of ADMIN_ACCOUNTS) {
      const hash = await bcrypt.hash(masterPass, 12);
      await db.execute(sql`
        INSERT INTO users (id, email, name, phone, role, is_admin, is_verified, password_hash)
        VALUES (${acct.id}, ${acct.email}, ${acct.name}, ${acct.phone}, 'both', TRUE, TRUE, ${hash})
        ON CONFLICT (id) DO UPDATE SET is_admin = TRUE, is_verified = TRUE, password_hash = EXCLUDED.password_hash
      `);
      const existing = await db.execute(sql`SELECT id FROM users WHERE LOWER(email) = ${acct.email} AND id != ${acct.id} LIMIT 1`);
      if ((existing.rows as any[]).length > 0) {
        await db.execute(sql`
          UPDATE users SET is_admin = TRUE, is_verified = TRUE, password_hash = ${hash}
          WHERE LOWER(email) = ${acct.email}
        `);
      }
      logger.info(`Master admin credentials set for ${acct.email}`);
    }
  } catch (err) {
    logger.warn({ err }, "Master admin bootstrap warning (non-fatal)");
  }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

bootstrapMasterAdmin().then(() => {
  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }
    logger.info({ port }, "Server listening");
    startReminderScheduler();
    startChurnAlertScheduler();
    startWeeklyDigestScheduler();
  });
}).catch((err) => {
  logger.error({ err }, "Fatal error during startup");
  process.exit(1);
});
