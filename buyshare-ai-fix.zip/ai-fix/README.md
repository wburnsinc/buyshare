# AI Fix — Buyshare.co
## What was broken & what this package fixes

### Root Cause
The platform was built on Replit's AI proxy which:
1. Used a **fake model name** `"gpt-5.4"` — doesn't exist outside Replit
2. Imported `@workspace/integrations-openai-ai-server` — a **Replit-only package** that fails everywhere else
3. Used Replit's `AI_INTEGRATIONS_OPENAI_BASE_URL` / `AI_INTEGRATIONS_OPENAI_API_KEY` env vars — auto-injected by Replit, not present on any other platform

When Replit shut down due to overcharging, all AI features silently broke.

### What's fixed in this package

| File | Fix |
|------|-----|
| `src/lib/ai.ts` | Universal AI client — works with any OpenAI-compatible API. Drop-in replacement for the Replit package. Includes smart model routing (cheap → expensive). |
| `src/routes/modules/burncall.ts` | Fixed import + replaced `"gpt-5.4"` with `"gpt-4o-mini"`. All 4 AI endpoints now work. |
| `src/routes/modules/earntree.ts` | No AI in this module — verified working as-is. |
| `src/routes/modules/pocketcash.ts` | No AI in this module — verified working as-is. |
| `src/routes/bluecertified.ts` | Replaced manual `fetch()` OpenAI call with `ai.ts` client. Graceful fallback if no key. |
| `src/routes/admin-ai.ts` | **NEW** — Admin AI dashboard: usage logs, cost per module, per-module on/off toggle, daily budget caps. |

---

## Installation (3 steps)

### Step 1 — Copy files into your project

```
your-project/
  artifacts/api-server/src/
    lib/
      ai.ts          ← copy from this package
    routes/
      modules/
        burncall.ts  ← replace with patched version
      bluecertified.ts  ← replace with patched version
      admin-ai.ts    ← new file, copy in
```

### Step 2 — Set your .env

```bash
# Required — get from https://platform.openai.com/api-keys
OPENAI_API_KEY=sk-proj-...

# Optional — override which models are used
AI_MODEL_FAST=gpt-4o-mini    # for lead qualify, matching, short tasks
AI_MODEL_SMART=gpt-4o        # for complex analysis (used sparingly)
```

**Cost comparison:**
- `gpt-4o-mini`: ~$0.15 per 1M tokens — use for everything simple
- `gpt-4o`: ~$2.50 per 1M tokens — only for complex tasks
- A typical BurnCall lead qualification = ~300 tokens = **$0.000045** (less than 1/100th of a cent)

### Step 3 — Register the admin-ai router

In `src/routes/index.ts`, add:

```typescript
import aiAdminRouter from "./admin-ai.js";
// ...
router.use(aiAdminRouter);
```

Then access the AI dashboard at `/admin` → add the AI Usage tab in your admin frontend.

---

## Cost control strategy

### Model routing (automatic)
The `ai.ts` client maps task types to models:
- All BurnCall AI (lead qualify, chat, campaigns) → `gpt-4o-mini` 
- BlueCertified contractor matching → `gpt-4o-mini`
- Only use `gpt-4o` when explicitly requested via `AI_MODEL_SMART` env var

### Per-module budget caps (admin panel)
The new `/api/admin/ai/settings/:module` endpoint lets you:
- Disable AI for any module without code changes
- Set a daily token budget per module
- Switch a module to a different model

### Typical monthly cost estimate
Assuming 1,000 AI calls/month (realistic for a growing platform):
- 800 simple tasks × 300 tokens × $0.15/1M = **$0.036**
- 200 complex tasks × 800 tokens × $2.50/1M = **$0.40**
- **Total: ~$0.44/month** for 1,000 AI calls

You were being charged many times more because `gpt-5.4` on Replit's proxy was routed to GPT-4o with a markup.

---

## Free hosting recommendation (your domain, $0/month)

| Service | What it hosts | Free tier |
|---------|--------------|-----------|
| **Vercel** | React frontend | Unlimited static, custom domain |
| **Railway** | Node/Express API | $5/mo credit (covers small API easily) |
| **Neon.tech** | PostgreSQL | 0.5GB storage, serverless |
| **Cloudflare** | DNS + SSL + CDN | Free forever |
| **Cloudflare R2** | File storage | 10GB free (replaces Replit Object Storage) |
| **Resend** | Email | 3,000/month free |

**Stripe** — required for payments, but no monthly fee. You only pay per transaction (2.9% + 30¢).

---

## AI Admin Dashboard API

```
GET  /api/admin/ai/status              — check if API key is configured
GET  /api/admin/ai/usage               — usage stats by module (30 days)
GET  /api/admin/ai/log?module=burncall — recent AI call log
PATCH /api/admin/ai/settings/burncall  — { enabled, daily_token_budget, preferred_model }
DELETE /api/admin/ai/log?days=30       — clear old log entries
```
