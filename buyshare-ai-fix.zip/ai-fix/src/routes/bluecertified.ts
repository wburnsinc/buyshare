import { Router } from "express";
import { pool } from "@workspace/db";
import { requireAuth } from "../middleware/auth.js";
import crypto from "crypto";

const router = Router();

export const BLC_CATEGORIES = [
  "Lawn Care & Landscaping", "Pool Services & Maintenance", "HVAC Services",
  "Plumbing Services", "Electrical Services", "Roofing Services", "Painting Services",
  "Cleaning Services", "Construction & Remodeling", "Handyman Services",
  "Pressure Washing", "Tree Services", "Flooring", "Pest Control", "Moving Services",
  "Concrete & Driveways", "Fencing", "Irrigation", "Appliance Repair", "General Contractor",
  "Delivery Services", "Landscaping Design", "Gutters", "Drywall & Plaster",
  "Garage Doors", "Window & Door", "Waterproofing", "Insulation", "Security Systems",
];

async function ensureBLCTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS blc_contractor_profiles (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      company_name TEXT,
      address TEXT,
      city TEXT NOT NULL,
      state TEXT NOT NULL DEFAULT 'FL',
      zip TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT,
      website TEXT,
      bio TEXT,
      years_experience INTEGER,
      license_number TEXT,
      insured BOOLEAN NOT NULL DEFAULT FALSE,
      photo_url TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      is_featured BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS blc_contractor_categories (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL REFERENCES blc_contractor_profiles(id) ON DELETE CASCADE,
      category TEXT NOT NULL,
      UNIQUE(profile_id, category)
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS blc_contractor_reviews (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL REFERENCES blc_contractor_profiles(id) ON DELETE CASCADE,
      reviewer_user_id TEXT NOT NULL,
      reviewer_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
      comment TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(profile_id, reviewer_user_id)
    )
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS blc_job_postings (
      id TEXT PRIMARY KEY,
      posted_by_user_id TEXT NOT NULL,
      poster_name TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      category TEXT NOT NULL,
      city TEXT NOT NULL,
      zip TEXT,
      budget_min INTEGER,
      budget_max INTEGER,
      contact_email TEXT,
      contact_phone TEXT,
      job_type TEXT NOT NULL DEFAULT 'subcontract',
      status TEXT NOT NULL DEFAULT 'open',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});
}

ensureBLCTables();

function withCategories(alias = "cp") {
  return `
    COALESCE(
      (SELECT json_agg(category ORDER BY category)
       FROM blc_contractor_categories WHERE profile_id = ${alias}.id),
      '[]'::json
    ) AS categories,
    COALESCE(
      (SELECT ROUND(AVG(rating)::numeric, 1)
       FROM blc_contractor_reviews WHERE profile_id = ${alias}.id),
      0
    ) AS avg_rating,
    (SELECT COUNT(*)::int FROM blc_contractor_reviews WHERE profile_id = ${alias}.id) AS review_count
  `;
}

// ── CONTRACTORS ───────────────────────────────────────────────────────────────

router.get("/api/bluecertified/contractors", async (req, res) => {
  try {
    const { category, city, zip, q, limit = 60, offset = 0 } = req.query as Record<string, string>;
    const params: unknown[] = [];
    let pi = 1;
    const where: string[] = ["cp.status = 'active'"];

    if (category) {
      where.push(`EXISTS (SELECT 1 FROM blc_contractor_categories WHERE profile_id = cp.id AND category = $${pi++})`);
      params.push(category);
    }
    if (city) {
      where.push(`LOWER(cp.city) LIKE LOWER($${pi++})`);
      params.push(`%${city}%`);
    }
    if (zip) {
      where.push(`cp.zip = $${pi++}`);
      params.push(zip);
    }
    if (q) {
      where.push(`(LOWER(cp.company_name) LIKE LOWER($${pi}) OR LOWER(cp.full_name) LIKE LOWER($${pi}) OR LOWER(cp.bio) LIKE LOWER($${pi}))`);
      params.push(`%${q}%`);
      pi++;
    }

    const whereClause = where.join(" AND ");
    params.push(Number(limit), Number(offset));
    const query = `
      SELECT cp.*, ${withCategories()}
      FROM blc_contractor_profiles cp
      WHERE ${whereClause}
      ORDER BY cp.is_featured DESC, avg_rating DESC, cp.created_at DESC
      LIMIT $${pi++} OFFSET $${pi}
    `;
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/api/bluecertified/contractors/me", requireAuth, async (req: any, res) => {
  try {
    const result = await pool.query(
      `SELECT cp.*, ${withCategories()} FROM blc_contractor_profiles cp WHERE cp.user_id = $1`,
      [req.user.id]
    );
    res.json(result.rows[0] || null);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/api/bluecertified/contractors/:id", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT cp.*, ${withCategories()},
        COALESCE(
          (SELECT json_agg(json_build_object(
            'id', r.id, 'reviewer_name', r.reviewer_name,
            'rating', r.rating, 'comment', r.comment, 'created_at', r.created_at
          ) ORDER BY r.created_at DESC)
          FROM blc_contractor_reviews r WHERE r.profile_id = cp.id),
          '[]'::json
        ) AS reviews
       FROM blc_contractor_profiles cp WHERE cp.id = $1`,
      [req.params.id]
    );
    if (!result.rows.length) return res.status(404).json({ error: "Not found" });
    res.json(result.rows[0]);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/api/bluecertified/contractors", requireAuth, async (req: any, res) => {
  try {
    const {
      full_name, company_name, address, city, state = "FL", zip,
      phone, email, website, bio, years_experience,
      license_number, insured = false, photo_url, categories = [],
    } = req.body;

    if (!full_name || !phone || !city || !zip) {
      return res.status(400).json({ error: "full_name, phone, city, zip are required" });
    }

    const existing = await pool.query(
      "SELECT id FROM blc_contractor_profiles WHERE user_id = $1", [req.user.id]
    );
    if (existing.rows.length) {
      return res.status(409).json({ error: "Profile already exists", profile_id: existing.rows[0].id });
    }

    const id = crypto.randomUUID();
    await pool.query(
      `INSERT INTO blc_contractor_profiles
         (id,user_id,full_name,company_name,address,city,state,zip,phone,email,website,bio,years_experience,license_number,insured,photo_url,status,created_at)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,'active',NOW())`,
      [id, req.user.id, full_name, company_name || null, address || null,
       city, state, zip, phone, email || req.user.email, website || null,
       bio || null, years_experience || null, license_number || null, insured, photo_url || null]
    );

    for (const cat of categories) {
      await pool.query(
        "INSERT INTO blc_contractor_categories(id,profile_id,category) VALUES($1,$2,$3) ON CONFLICT DO NOTHING",
        [crypto.randomUUID(), id, cat]
      ).catch(() => {});
    }

    res.status(201).json({ id });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.patch("/api/bluecertified/contractors/:id", requireAuth, async (req: any, res) => {
  try {
    const own = await pool.query(
      "SELECT id FROM blc_contractor_profiles WHERE id=$1 AND user_id=$2",
      [req.params.id, req.user.id]
    );
    if (!own.rows.length) return res.status(403).json({ error: "Not authorized" });

    const {
      full_name, company_name, address, city, state, zip, phone, email,
      website, bio, years_experience, license_number, insured, photo_url, categories,
    } = req.body;

    await pool.query(
      `UPDATE blc_contractor_profiles SET
        full_name=COALESCE($2,full_name), company_name=COALESCE($3,company_name),
        address=COALESCE($4,address), city=COALESCE($5,city), state=COALESCE($6,state),
        zip=COALESCE($7,zip), phone=COALESCE($8,phone), email=COALESCE($9,email),
        website=COALESCE($10,website), bio=COALESCE($11,bio),
        years_experience=COALESCE($12,years_experience), license_number=COALESCE($13,license_number),
        insured=COALESCE($14,insured), photo_url=COALESCE($15,photo_url), updated_at=NOW()
       WHERE id=$1`,
      [req.params.id, full_name, company_name, address, city, state, zip, phone,
       email, website, bio, years_experience, license_number, insured, photo_url]
    );

    if (Array.isArray(categories)) {
      await pool.query("DELETE FROM blc_contractor_categories WHERE profile_id=$1", [req.params.id]);
      for (const cat of categories) {
        await pool.query(
          "INSERT INTO blc_contractor_categories(id,profile_id,category) VALUES($1,$2,$3) ON CONFLICT DO NOTHING",
          [crypto.randomUUID(), req.params.id, cat]
        ).catch(() => {});
      }
    }

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/api/bluecertified/contractors/:id/reviews", requireAuth, async (req: any, res) => {
  try {
    const { rating, comment } = req.body;
    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: "rating 1–5 required" });
    }
    const id = crypto.randomUUID();
    await pool.query(
      `INSERT INTO blc_contractor_reviews(id,profile_id,reviewer_user_id,reviewer_name,rating,comment,created_at)
       VALUES($1,$2,$3,$4,$5,$6,NOW())
       ON CONFLICT(profile_id,reviewer_user_id) DO UPDATE SET rating=$5, comment=$6`,
      [id, req.params.id, req.user.id, req.user.full_name || req.user.email, rating, comment || null]
    );
    res.status(201).json({ id });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// ── JOB POSTINGS ─────────────────────────────────────────────────────────────

router.get("/api/bluecertified/jobs", async (req, res) => {
  try {
    const { category, city, status = "open" } = req.query as Record<string, string>;
    const params: unknown[] = [status];
    let pi = 2;
    const where = ["status = $1"];

    if (category) { where.push(`category = $${pi++}`); params.push(category); }
    if (city) { where.push(`LOWER(city) LIKE LOWER($${pi++})`); params.push(`%${city}%`); }

    const result = await pool.query(
      `SELECT * FROM blc_job_postings WHERE ${where.join(" AND ")} ORDER BY created_at DESC LIMIT 100`,
      params
    );
    res.json(result.rows);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/api/bluecertified/jobs", requireAuth, async (req: any, res) => {
  try {
    const { title, description, category, city, zip, budget_min, budget_max,
            contact_email, contact_phone, job_type = "subcontract" } = req.body;
    if (!title || !category || !city) {
      return res.status(400).json({ error: "title, category, city required" });
    }
    const id = crypto.randomUUID();
    await pool.query(
      `INSERT INTO blc_job_postings(id,posted_by_user_id,poster_name,title,description,category,city,zip,budget_min,budget_max,contact_email,contact_phone,job_type,status,created_at)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'open',NOW())`,
      [id, req.user.id, req.user.full_name || req.user.email, title, description || null,
       category, city, zip || null, budget_min || null, budget_max || null,
       contact_email || req.user.email, contact_phone || null, job_type]
    );
    res.status(201).json({ id });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.patch("/api/bluecertified/jobs/:id", requireAuth, async (req: any, res) => {
  try {
    const own = await pool.query(
      "SELECT id FROM blc_job_postings WHERE id=$1 AND posted_by_user_id=$2",
      [req.params.id, req.user.id]
    );
    if (!own.rows.length) return res.status(403).json({ error: "Not authorized" });
    const { status, title, description } = req.body;
    await pool.query(
      "UPDATE blc_job_postings SET status=COALESCE($2,status),title=COALESCE($3,title),description=COALESCE($4,description) WHERE id=$1",
      [req.params.id, status, title, description]
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.delete("/api/bluecertified/jobs/:id", requireAuth, async (req: any, res) => {
  try {
    await pool.query(
      "DELETE FROM blc_job_postings WHERE id=$1 AND posted_by_user_id=$2",
      [req.params.id, (req as any).user.id]
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// ── AI MATCH ─────────────────────────────────────────────────────────────────

router.post("/api/bluecertified/ai-match", async (req, res) => {
  try {
    const { description, category, zip, city } = req.body;
    if (!description) return res.status(400).json({ error: "description required" });

    const contractorsResult = await pool.query(
      `SELECT cp.id, cp.full_name, cp.company_name, cp.city, cp.zip, cp.bio,
         cp.years_experience, cp.insured, cp.phone, cp.email, cp.website,
         ${withCategories()},
         COALESCE((SELECT json_agg(json_build_object(
           'reviewer_name', r.reviewer_name, 'rating', r.rating, 'comment', r.comment
         ) ORDER BY r.created_at DESC LIMIT 3) FROM blc_contractor_reviews r WHERE r.profile_id = cp.id), '[]'::json) as reviews
       FROM blc_contractor_profiles cp
       WHERE cp.status = 'active'
       ORDER BY cp.is_featured DESC, avg_rating DESC
       LIMIT 200`
    );

    const contractors = contractorsResult.rows;
    if (!contractors.length) {
      return res.json({ matches: [], reasoning: "No active contractors yet — be the first to join BlueCertified!" });
    }

    const contractorList = contractors.map(c =>
      `ID:${c.id}|${c.company_name || c.full_name}|${(c.categories as string[]).join(",")}|${c.city}|Rating:${c.avg_rating}|Exp:${c.years_experience || "?"}yr|Insured:${c.insured}|${(c.bio || "").substring(0, 80)}`
    ).join("
");

    let parsed: any = { matches: [], reasoning: "" };
    try {
      const { complete, parseJSON, isAIConfigured } = await import("../lib/ai.js");
      if (!isAIConfigured()) throw new Error("no key");
      const aiText = await complete({
        model: "gpt-4o-mini",
        max_tokens: 600,
        messages: [
          { role: "system", content: "You are BlueCertified AI, a contractor matching assistant for Southwest Florida. Match homeowners to the best-fit contractors from the provided list. Consider: service category match, location (SWFL cities), experience, insurance, and rating. Return ONLY valid JSON." },
          { role: "user", content: `Homeowner request: "${description}"
Preferred category: ${category || "any"}
Location: ${city || "SWFL"} ${zip || ""}

Contractors:
${contractorList}

Respond with: {"matches":["id1","id2","id3"],"reasoning":"2 sentence explanation of why these pros are the best fit"}` },
        ],
      });
      parsed = parseJSON(aiText, { matches: [], reasoning: "" });
    } catch {
      const lowerDesc = description.toLowerCase();
      const filtered = contractors
        .filter(c => {
          if (category) return (c.categories as string[]).includes(category);
          return (c.categories as string[]).some(cat =>
            lowerDesc.includes(cat.toLowerCase().split(" ")[0])
          );
        })
        .slice(0, 5);
      const fallback = filtered.length ? filtered : contractors.slice(0, 5);
      return res.json({ matches: fallback, reasoning: "Top-rated contractors matched to your service needs." });
    }

    const matchedContractors = ((parsed.matches as string[]) || [])
      .map(id => contractors.find(c => c.id === id))
      .filter(Boolean)
      .slice(0, 5);

    if (!matchedContractors.length) {
      const fallback = contractors.filter(c =>
        !category || (c.categories as string[]).includes(category)
      ).slice(0, 5);
      return res.json({ matches: fallback, reasoning: "Top-rated contractors in your area." });
    }

    res.json({ matches: matchedContractors, reasoning: parsed.reasoning || "Best matches found for your project." });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
