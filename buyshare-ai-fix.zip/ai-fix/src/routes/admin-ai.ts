/**
 * admin-ai.ts — AI Usage Dashboard for Master Admin
 *
 * Tracks per-module AI usage, estimated cost, and lets admin control:
 *   - Toggle AI on/off per module
 *   - Set daily token budget per module
 *   - View live usage log
 *
 * Mount in routes/index.ts: import aiAdminRouter from "./admin-ai.js"
 */

import { Router } from "express";
import { pool } from "@workspace/db";
import { requireMasterAdmin } from "../middleware/auth.js";
import { isAIConfigured } from "../lib/ai.js";

const router = Router();

// ── Ensure AI log table exists ────────────────────────────────────────────────
async function ensureAITables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_usage_log (
      id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
      module TEXT NOT NULL,
      endpoint TEXT NOT NULL,
      model TEXT NOT NULL,
      prompt_tokens INTEGER DEFAULT 0,
      completion_tokens INTEGER DEFAULT 0,
      total_tokens INTEGER DEFAULT 0,
      estimated_cost_cents NUMERIC(10,4) DEFAULT 0,
      user_id TEXT,
      success BOOLEAN DEFAULT TRUE,
      error_message TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  await pool.query(`
    CREATE INDEX IF NOT EXISTS ai_usage_module_idx ON ai_usage_log (module, created_at DESC)
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_module_settings (
      module TEXT PRIMARY KEY,
      enabled BOOLEAN NOT NULL DEFAULT TRUE,
      daily_token_budget INTEGER DEFAULT 100000,
      preferred_model TEXT DEFAULT 'gpt-4o-mini',
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `).catch(() => {});

  // Seed default module settings
  const modules = [
    "burncall", "bluecertified", "propconnect", "playdate",
    "podcast", "pocketcash", "earntree", "bluetruck"
  ];
  for (const mod of modules) {
    await pool.query(`
      INSERT INTO ai_module_settings (module) VALUES ($1)
      ON CONFLICT (module) DO NOTHING
    `, [mod]).catch(() => {});
  }
}
ensureAITables();

// ── Cost per 1M tokens (USD cents) ───────────────────────────────────────────
const MODEL_COSTS: Record<string, { input: number; output: number }> = {
  "gpt-4o-mini": { input: 15, output: 60 },    // $0.15/$0.60 per 1M
  "gpt-4o":      { input: 250, output: 1000 }, // $2.50/$10 per 1M
  "gpt-4":       { input: 3000, output: 6000 },
};

export function estimateCostCents(model: string, promptTokens: number, completionTokens: number): number {
  const costs = MODEL_COSTS[model] || MODEL_COSTS["gpt-4o-mini"];
  return (
    (promptTokens / 1_000_000) * costs.input +
    (completionTokens / 1_000_000) * costs.output
  );
}

/** Log an AI call — call this from any route after a successful AI response */
export async function logAIUsage(opts: {
  module: string;
  endpoint: string;
  model: string;
  promptTokens?: number;
  completionTokens?: number;
  userId?: string;
  success?: boolean;
  errorMessage?: string;
}) {
  try {
    const prompt = opts.promptTokens || 0;
    const completion = opts.completionTokens || 0;
    const total = prompt + completion;
    const cost = estimateCostCents(opts.model, prompt, completion);
    await pool.query(
      `INSERT INTO ai_usage_log
        (module, endpoint, model, prompt_tokens, completion_tokens, total_tokens, estimated_cost_cents, user_id, success, error_message)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [
        opts.module, opts.endpoint, opts.model,
        prompt, completion, total, cost,
        opts.userId || null,
        opts.success !== false,
        opts.errorMessage || null,
      ]
    );
  } catch { /* non-critical — never crash the main request */ }
}

/** Check if a module's AI is enabled and within budget */
export async function isModuleAIEnabled(module: string): Promise<{ enabled: boolean; model: string }> {
  try {
    const { rows } = await pool.query(
      `SELECT enabled, preferred_model, daily_token_budget FROM ai_module_settings WHERE module = $1`,
      [module]
    );
    if (!rows[0]?.enabled) return { enabled: false, model: "gpt-4o-mini" };

    // Check daily budget
    const budget = rows[0].daily_token_budget || 100000;
    const { rows: usage } = await pool.query(
      `SELECT COALESCE(SUM(total_tokens),0) as used
       FROM ai_usage_log
       WHERE module = $1 AND created_at > NOW() - INTERVAL '1 day'`,
      [module]
    );
    const used = Number((usage[0] as any)?.used || 0);
    if (used >= budget) return { enabled: false, model: rows[0].preferred_model };

    return { enabled: true, model: rows[0].preferred_model || "gpt-4o-mini" };
  } catch {
    return { enabled: true, model: "gpt-4o-mini" };
  }
}

// ── ADMIN ROUTES ──────────────────────────────────────────────────────────────

/** GET /api/admin/ai/status — quick health check */
router.get("/admin/ai/status", requireMasterAdmin, (_req, res) => {
  res.json({
    configured: isAIConfigured(),
    message: isAIConfigured()
      ? "OpenAI API key is set and ready"
      : "OPENAI_API_KEY is missing — add it to .env",
  });
});

/** GET /api/admin/ai/usage — aggregate stats by module */
router.get("/admin/ai/usage", requireMasterAdmin, async (_req, res) => {
  try {
    await ensureAITables();
    const { rows: byModule } = await pool.query(`
      SELECT
        module,
        COUNT(*) as calls,
        COALESCE(SUM(total_tokens),0) as total_tokens,
        COALESCE(SUM(estimated_cost_cents),0) as cost_cents,
        MAX(created_at) as last_call,
        COUNT(*) FILTER (WHERE success = FALSE) as errors,
        AVG(total_tokens) as avg_tokens_per_call
      FROM ai_usage_log
      WHERE created_at > NOW() - INTERVAL '30 days'
      GROUP BY module
      ORDER BY cost_cents DESC
    `);

    const { rows: today } = await pool.query(`
      SELECT
        COALESCE(SUM(total_tokens),0) as tokens_today,
        COALESCE(SUM(estimated_cost_cents),0) as cost_today,
        COUNT(*) as calls_today
      FROM ai_usage_log
      WHERE created_at > NOW() - INTERVAL '1 day'
    `);

    const { rows: models } = await pool.query(`
      SELECT model, COUNT(*) as calls, COALESCE(SUM(total_tokens),0) as tokens
      FROM ai_usage_log
      WHERE created_at > NOW() - INTERVAL '30 days'
      GROUP BY model ORDER BY calls DESC
    `);

    const { rows: settings } = await pool.query(
      `SELECT * FROM ai_module_settings ORDER BY module`
    );

    res.json({
      byModule,
      today: today[0],
      byModel: models,
      settings,
      configured: isAIConfigured(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/** GET /api/admin/ai/log — recent AI calls */
router.get("/admin/ai/log", requireMasterAdmin, async (req, res) => {
  const limit = Math.min(200, parseInt((req.query.limit as string) || "50"));
  const module = req.query.module as string | undefined;
  try {
    const { rows } = await pool.query(
      `SELECT * FROM ai_usage_log
       ${module ? "WHERE module = $2" : ""}
       ORDER BY created_at DESC
       LIMIT $1`,
      module ? [limit, module] : [limit]
    );
    res.json({ log: rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/** PATCH /api/admin/ai/settings/:module — update module AI settings */
router.patch("/admin/ai/settings/:module", requireMasterAdmin, async (req, res) => {
  const { module } = req.params;
  const { enabled, daily_token_budget, preferred_model } = req.body;
  try {
    await ensureAITables();
    await pool.query(
      `INSERT INTO ai_module_settings (module, enabled, daily_token_budget, preferred_model, updated_at)
       VALUES ($1, $2, $3, $4, NOW())
       ON CONFLICT (module) DO UPDATE
         SET enabled = COALESCE($2, ai_module_settings.enabled),
             daily_token_budget = COALESCE($3, ai_module_settings.daily_token_budget),
             preferred_model = COALESCE($4, ai_module_settings.preferred_model),
             updated_at = NOW()`,
      [module, enabled ?? null, daily_token_budget ?? null, preferred_model ?? null]
    );
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/** DELETE /api/admin/ai/log — clear old log entries */
router.delete("/admin/ai/log", requireMasterAdmin, async (req, res) => {
  const days = parseInt((req.query.days as string) || "30");
  try {
    const { rowCount } = await pool.query(
      `DELETE FROM ai_usage_log WHERE created_at < NOW() - INTERVAL '${days} days'`
    );
    res.json({ deleted: rowCount });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
