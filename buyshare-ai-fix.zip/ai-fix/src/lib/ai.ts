/**
 * ai.ts — Universal AI client for Buyshare.co
 *
 * Drop-in replacement for @workspace/integrations-openai-ai-server (Replit-only).
 * Works with any OpenAI-compatible API: OpenAI, Anthropic (via proxy), etc.
 *
 * COST-SAVING MODEL ROUTER:
 *   "fast"    → gpt-4o-mini  (lead qualify, matching, short tasks) ~$0.15/1M tokens
 *   "smart"   → gpt-4o       (complex analysis, campaigns)          ~$2.50/1M tokens
 *   "stream"  → gpt-4o-mini  (streaming chat)                       cheapest streamer
 *
 * Set env vars:
 *   OPENAI_API_KEY=sk-...          (required)
 *   OPENAI_BASE_URL=               (optional, default: https://api.openai.com/v1)
 *   AI_MODEL_FAST=gpt-4o-mini      (optional override)
 *   AI_MODEL_SMART=gpt-4o          (optional override)
 */

const BASE_URL = (
  process.env.OPENAI_BASE_URL ||
  process.env.AI_INTEGRATIONS_OPENAI_BASE_URL ||
  "https://api.openai.com/v1"
).replace(/\/$/, "");

const API_KEY =
  process.env.OPENAI_API_KEY ||
  process.env.AI_INTEGRATIONS_OPENAI_API_KEY ||
  "";

const MODEL_FAST  = process.env.AI_MODEL_FAST  || "gpt-4o-mini";
const MODEL_SMART = process.env.AI_MODEL_SMART || "gpt-4o";
// "gpt-5.4" was a Replit proxy alias — map it back to a real model
const MODEL_ALIASES: Record<string, string> = {
  "gpt-5.4": MODEL_FAST,
  "gpt-4o-mini": MODEL_FAST,
  "gpt-4o": MODEL_SMART,
};

function resolveModel(requested?: string): string {
  if (!requested) return MODEL_FAST;
  return MODEL_ALIASES[requested] || requested;
}

export type Message = { role: "system" | "user" | "assistant"; content: string };

export interface CompletionOptions {
  model?: string;
  max_tokens?: number;
  /** @deprecated use max_tokens */ max_completion_tokens?: number;
  temperature?: number;
  messages: Message[];
  stream?: boolean;
}

async function callAPI(body: Record<string, unknown>): Promise<Response> {
  if (!API_KEY) {
    throw new Error(
      "OPENAI_API_KEY is not set. Add it to your .env file. Get a key at https://platform.openai.com/api-keys"
    );
  }
  const res = await fetch(`${BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`OpenAI API error ${res.status}: ${text}`);
  }
  return res;
}

/** Non-streaming completion — returns the full text response */
export async function complete(opts: CompletionOptions): Promise<string> {
  const model = resolveModel(opts.model);
  const max_tokens = opts.max_tokens || opts.max_completion_tokens || 1000;
  const res = await callAPI({
    model,
    max_tokens,
    temperature: opts.temperature ?? 0.7,
    messages: opts.messages,
    stream: false,
  });
  const data = (await res.json()) as any;
  return data.choices?.[0]?.message?.content || "";
}

/** Streaming completion — yields text chunks, for use with SSE endpoints */
export async function* stream(opts: CompletionOptions): AsyncGenerator<string> {
  const model = resolveModel(opts.model);
  const max_tokens = opts.max_tokens || opts.max_completion_tokens || 2000;
  const res = await callAPI({
    model,
    max_tokens,
    temperature: opts.temperature ?? 0.7,
    messages: opts.messages,
    stream: true,
  });

  const reader = res.body!.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed === "data: [DONE]") continue;
      if (trimmed.startsWith("data: ")) {
        try {
          const json = JSON.parse(trimmed.slice(6));
          const chunk = json.choices?.[0]?.delta?.content;
          if (chunk) yield chunk;
        } catch {}
      }
    }
  }
}

/**
 * OpenAI SDK-compatible shim used by existing code that calls:
 *   openai.chat.completions.create({ model, messages, stream })
 *
 * Usage: import { openai } from "./lib/ai.js"
 */
export const openai = {
  chat: {
    completions: {
      create: async (opts: CompletionOptions & { stream?: boolean }) => {
        if (opts.stream) {
          // Return an async iterable that mimics the SDK's stream interface
          const gen = stream(opts);
          return {
            [Symbol.asyncIterator]: () => ({
              next: async () => {
                const { value, done } = await gen.next();
                if (done) return { value: undefined, done: true };
                return {
                  value: { choices: [{ delta: { content: value } }] },
                  done: false,
                };
              },
            }),
          };
        }
        // Non-streaming — return SDK-compatible object
        const text = await complete(opts);
        return {
          choices: [{ message: { content: text }, finish_reason: "stop" }],
        };
      },
    },
  },
};

/**
 * Parse JSON from an AI response safely.
 * Strips markdown code fences before parsing.
 */
export function parseJSON<T = Record<string, unknown>>(
  text: string,
  fallback: T
): T {
  try {
    const cleaned = text.replace(/```json\n?|\n?```/g, "").trim();
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]) as T;
  } catch {}
  return fallback;
}

/** Check if AI is configured — use for health checks */
export function isAIConfigured(): boolean {
  return !!API_KEY;
}
