import { pgTable, text, serial, timestamp, numeric, integer, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const campaignsTable = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("pending"), // draft | pending | active | paused | ended | rejected
  rewardAmount: numeric("reward_amount", { precision: 10, scale: 2 }).notNull().default("0.25"),
  category: text("category").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zip: text("zip"),
  serviceRadius: numeric("service_radius", { precision: 8, scale: 2 }),
  landingPageUrl: text("landing_page_url"),
  ctaText: text("cta_text"),
  imageUrl: text("image_url"),
  weeklyBudget: numeric("weekly_budget", { precision: 10, scale: 2 }).notNull().default("50"),
  budgetSpent: numeric("budget_spent", { precision: 10, scale: 2 }).notNull().default("0"),
  estimatedVerificationHours: integer("estimated_verification_hours").notNull().default(24),
  startDate: date("start_date", { mode: "string" }).notNull(),
  endDate: date("end_date", { mode: "string" }).notNull(),
  targetAudience: text("target_audience"),
  rejectionReason: text("rejection_reason"),
  shareCount: integer("share_count").notNull().default(0),
  clickCount: integer("click_count").notNull().default(0),
  conversionCount: integer("conversion_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertCampaignSchema = createInsertSchema(campaignsTable).omit({ id: true, createdAt: true, updatedAt: true, shareCount: true, clickCount: true, conversionCount: true, budgetSpent: true });
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaignsTable.$inferSelect;
