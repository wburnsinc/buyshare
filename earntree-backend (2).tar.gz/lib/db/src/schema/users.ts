import { pgTable, text, serial, timestamp, boolean, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  clerkId: text("clerk_id").unique().notNull(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  avatarUrl: text("avatar_url"),
  role: text("role").notNull().default("user"), // user | business | admin
  referralCode: text("referral_code").unique().notNull(),
  city: text("city"),
  state: text("state"),
  zip: text("zip"),
  lat: numeric("lat", { precision: 10, scale: 6 }),
  lng: numeric("lng", { precision: 10, scale: 6 }),
  referredByUserId: integer("referred_by_user_id"),
  referralBonusCount: integer("referral_bonus_count").notNull().default(0),
  networkActivated: boolean("network_activated").notNull().default(false),
  isFrozen: boolean("is_frozen").notNull().default(false),
  freezeReason: text("freeze_reason"),
  availableBalance: numeric("available_balance", { precision: 10, scale: 2 }).notNull().default("0"),
  pendingBalance: numeric("pending_balance", { precision: 10, scale: 2 }).notNull().default("0"),
  lifetimeEarnings: numeric("lifetime_earnings", { precision: 10, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
