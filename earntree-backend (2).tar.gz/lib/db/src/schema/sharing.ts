import { pgTable, text, serial, timestamp, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const trackingLinksTable = pgTable("tracking_links", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  campaignId: integer("campaign_id"),
  networkTaskId: integer("network_task_id"),
  code: text("code").unique().notNull(),
  destinationUrl: text("destination_url").notNull(),
  clickCount: integer("click_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const shareEventsTable = pgTable("share_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  campaignId: integer("campaign_id"),
  networkTaskId: integer("network_task_id"),
  trackingLinkId: integer("tracking_link_id"),
  shareChannel: text("share_channel").notNull(), // copy | sms | email | facebook | twitter | linkedin | whatsapp | messenger | native
  status: text("status").notNull().default("recorded"), // recorded | pending_verification | verified | rejected
  rewardStatus: text("reward_status"), // pending | approved | rejected | paid
  fraudScore: numeric("fraud_score", { precision: 5, scale: 2 }).default("0"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
});

export const clickEventsTable = pgTable("click_events", {
  id: serial("id").primaryKey(),
  trackingLinkId: integer("tracking_link_id").notNull(),
  userId: integer("user_id"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  referrer: text("referrer"),
  isSelfClick: text("is_self_click").notNull().default("false"),
  isDuplicate: text("is_duplicate").notNull().default("false"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertShareEventSchema = createInsertSchema(shareEventsTable).omit({ id: true, createdAt: true, verifiedAt: true });
export type InsertShareEvent = z.infer<typeof insertShareEventSchema>;
export type ShareEvent = typeof shareEventsTable.$inferSelect;
export type TrackingLink = typeof trackingLinksTable.$inferSelect;
