import { type Request, type Response, type NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";

export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

export async function getOrCreateUser(clerkId: string, clerkUser?: { email: string; name: string; avatarUrl?: string }) {
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (existing) return existing;

  if (!clerkUser) return null;

  const referralCode = nanoid(8).toUpperCase();
  const [created] = await db.insert(usersTable).values({
    clerkId,
    email: clerkUser.email,
    name: clerkUser.name,
    avatarUrl: clerkUser.avatarUrl,
    referralCode,
    role: "user",
  }).returning();
  return created;
}

export async function getCurrentUser(req: Request) {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) return null;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  return user ?? null;
}
