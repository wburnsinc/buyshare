import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import dashboardRouter from "./dashboard";
import campaignsRouter from "./campaigns";
import rewardsRouter from "./rewards";
import businessesRouter from "./businesses";
import networkRouter from "./network";
import adminRouter from "./admin";
import categoriesRouter from "./categories";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(dashboardRouter);
router.use(campaignsRouter);
router.use(rewardsRouter);
router.use(businessesRouter);
router.use(networkRouter);
router.use(adminRouter);
router.use(categoriesRouter);

export default router;
