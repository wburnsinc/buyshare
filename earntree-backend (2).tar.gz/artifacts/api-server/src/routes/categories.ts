import { Router } from "express";
import { db, categoriesTable } from "@workspace/db";
import { asc } from "drizzle-orm";

const router = Router();

router.get("/categories", async (_req, res): Promise<void> => {
  const categories = await db.select().from(categoriesTable).orderBy(asc(categoriesTable.sortOrder));
  res.json(categories.map(c => ({
    id: c.id,
    name: c.name,
    slug: c.slug,
    iconName: c.iconName ?? null,
  })));
});

export default router;
