import { Router } from "express";
import { getAuth, clerkClient } from "@clerk/express";
import { db, usersTable, rewardsTable, rewardLedgerTable, platformSettingsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { nanoid } from "nanoid";
import { logger } from "../lib/logger";

const router = Router();

router.get("/auth/me", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  let [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));

  if (!user) {
    // Auto-create user from Clerk
    try {
      const clerkUser = await clerkClient.users.getUser(clerkId);
      const email = clerkUser.emailAddresses[0]?.emailAddress ?? "";
      const name = `${clerkUser.firstName ?? ""} ${clerkUser.lastName ?? ""}`.trim() || email;
      const avatarUrl = clerkUser.imageUrl;
      const referralCode = nanoid(8).toUpperCase();

      const [created] = await db.insert(usersTable).values({
        clerkId,
        email,
        name,
        avatarUrl,
        referralCode,
        role: "user",
      }).returning();
      user = created;
    } catch (err) {
      req.log.error({ err }, "Failed to create user from Clerk");
      res.status(500).json({ error: "Failed to create user" });
      return;
    }
  }

  res.json({
    id: user.id,
    clerkId: user.clerkId,
    email: user.email,
    name: user.name,
    avatarUrl: user.avatarUrl,
    referralCode: user.referralCode,
    role: user.role,
    city: user.city,
    state: user.state,
    zip: user.zip,
    lat: user.lat ? Number(user.lat) : null,
    lng: user.lng ? Number(user.lng) : null,
    networkActivated: user.networkActivated,
    isFrozen: user.isFrozen,
    createdAt: user.createdAt.toISOString(),
  });
});

router.put("/auth/profile", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { name, city, state, zip, lat, lng } = req.body;

  const [user] = await db.update(usersTable)
    .set({ name, city, state, zip, lat, lng })
    .where(eq(usersTable.clerkId, clerkId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json({
    id: user.id,
    clerkId: user.clerkId,
    email: user.email,
    name: user.name,
    avatarUrl: user.avatarUrl,
    referralCode: user.referralCode,
    role: user.role,
    city: user.city,
    state: user.state,
    zip: user.zip,
    lat: user.lat ? Number(user.lat) : null,
    lng: user.lng ? Number(user.lng) : null,
    networkActivated: user.networkActivated,
    isFrozen: user.isFrozen,
    createdAt: user.createdAt.toISOString(),
  });
});

// POST /auth/referral — link a referral code to the current user (call once after sign-up)
router.post("/auth/referral", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const { referralCode } = req.body as { referralCode?: string };
  if (!referralCode || typeof referralCode !== "string") {
    res.status(400).json({ error: "referralCode is required" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  if (user.referredByUserId) {
    res.status(409).json({ error: "Referral already linked" });
    return;
  }

  const [referrer] = await db.select().from(usersTable).where(eq(usersTable.referralCode, referralCode.toUpperCase().trim()));
  if (!referrer) { res.status(404).json({ error: "Referral code not found" }); return; }
  if (referrer.id === user.id) { res.status(400).json({ error: "Cannot refer yourself" }); return; }

  await db.update(usersTable).set({ referredByUserId: referrer.id }).where(eq(usersTable.id, user.id));

  res.json({ success: true, referrerName: referrer.name });
});

export default router;
