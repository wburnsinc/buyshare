import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, rewardsTable, shareEventsTable, campaignsTable, businessesTable, rewardLedgerTable } from "@workspace/db";
import { eq, and, gte, sql, desc, count, sum } from "drizzle-orm";
import { platformSettingsTable } from "@workspace/db";

const router = Router();

async function getSetting(key: string, fallback: string) {
  const [row] = await db.select().from(platformSettingsTable).where(eq(platformSettingsTable.key, key));
  return row?.value ?? fallback;
}

router.get("/users/dashboard", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const payoutThreshold = Number(await getSetting("payoutThreshold", "100"));

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [sharesTodayRow] = await db.select({ count: count() }).from(shareEventsTable)
    .where(and(eq(shareEventsTable.userId, user.id), gte(shareEventsTable.createdAt, today)));

  // Referral stats
  const [referralCountRow] = await db.select({ count: count() }).from(usersTable)
    .where(eq(usersTable.referredByUserId, user.id));
  const [referralBonusRow] = await db.select({ total: sum(rewardsTable.amount) }).from(rewardsTable)
    .where(and(eq(rewardsTable.userId, user.id), sql`${rewardsTable.campaignId} IS NULL`));

  const [campaignsAvailRow] = await db.select({ count: count() }).from(campaignsTable)
    .where(eq(campaignsTable.status, "active"));

  const recentRewards = await db.select({
    id: rewardsTable.id,
    amount: rewardsTable.amount,
    status: rewardsTable.status,
    createdAt: rewardsTable.createdAt,
    campaignId: rewardsTable.campaignId,
  }).from(rewardsTable)
    .where(eq(rewardsTable.userId, user.id))
    .orderBy(desc(rewardsTable.createdAt))
    .limit(10);

  const recentActivity = recentRewards.map(r => ({
    id: r.id,
    type: "reward",
    description: `Reward for campaign #${r.campaignId}`,
    amount: Number(r.amount),
    status: r.status,
    createdAt: r.createdAt.toISOString(),
  }));

  res.json({
    availableBalance: Number(user.availableBalance),
    pendingBalance: Number(user.pendingBalance),
    lifetimeEarnings: Number(user.lifetimeEarnings),
    payoutThreshold,
    nextPayoutAt: payoutThreshold,
    campaignsAvailable: campaignsAvailRow.count,
    sharesToday: sharesTodayRow.count,
    clicksToday: 0,
    referralCount: referralCountRow.count,
    referralBonusEarned: Number(referralBonusRow.total ?? 0),
    referralCode: user.referralCode,
    recentActivity,
  });
});

router.get("/business/dashboard", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const campaigns = await db.select().from(campaignsTable).where(eq(campaignsTable.businessId, biz.id));
  const activeCampaigns = campaigns.filter(c => c.status === "active").length;
  const totalShares = campaigns.reduce((s, c) => s + c.shareCount, 0);
  const totalClicks = campaigns.reduce((s, c) => s + c.clickCount, 0);
  const totalConversions = campaigns.reduce((s, c) => s + c.conversionCount, 0);
  const totalSpend = campaigns.reduce((s, c) => s + Number(c.budgetSpent), 0);
  const weeklyBudget = campaigns.filter(c => c.status === "active").reduce((s, c) => s + Number(c.weeklyBudget), 0);

  res.json({
    activeCampaigns,
    totalShares,
    totalClicks,
    totalConversions,
    totalSpend,
    remainingBudget: weeklyBudget - totalSpend,
    costPerShare: totalShares > 0 ? totalSpend / totalShares : 0,
    costPerClick: totalClicks > 0 ? totalSpend / totalClicks : 0,
    recentEvents: [],
  });
});

export default router;
