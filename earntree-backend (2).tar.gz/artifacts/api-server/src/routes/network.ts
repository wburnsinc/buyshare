import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, networkPropertiesTable, networkTasksTable, platformSettingsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { nanoid } from "nanoid";

const router = Router();

async function getSetting(key: string, fallback: string) {
  const [row] = await db.select().from(platformSettingsTable).where(eq(platformSettingsTable.key, key));
  return row?.value ?? fallback;
}

// GET /users/activate-network
router.get("/users/activate-network", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const isRequired = (await getSetting("networkActivationRequired", "true")) === "true";
  const properties = await db.select().from(networkPropertiesTable)
    .where(eq(networkPropertiesTable.isActive, true))
    .orderBy(networkPropertiesTable.sortOrder);

  const userTasks = await db.select().from(networkTasksTable).where(eq(networkTasksTable.userId, user.id));
  const tasksByProperty = new Map(userTasks.map(t => [t.propertyId, t]));

  const baseUrl = process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}` : "http://localhost";

  const tasks = await Promise.all(properties.map(async (prop) => {
    let task = tasksByProperty.get(prop.id);
    if (!task) {
      const code = nanoid(10);
      const [created] = await db.insert(networkTasksTable).values({
        userId: user.id,
        propertyId: prop.id,
        trackingCode: code,
        isCompleted: false,
      }).returning();
      task = created;
    }

    return {
      id: prop.id,
      propertyName: prop.propertyName,
      propertyUrl: prop.propertyUrl,
      description: prop.description,
      logoUrl: prop.logoUrl ?? null,
      trackingLink: `${baseUrl}/api/t/${task.trackingCode}`,
      isCompleted: task.isCompleted,
      completedAt: task.completedAt?.toISOString() ?? null,
    };
  }));

  const completedCount = tasks.filter(t => t.isCompleted).length;
  const totalCount = tasks.length;
  const isComplete = completedCount >= totalCount;

  // Update user networkActivated if all done
  if (isComplete && !user.networkActivated) {
    await db.update(usersTable).set({ networkActivated: true }).where(eq(usersTable.id, user.id));
  }

  res.json({
    isComplete,
    isRequired,
    completedCount,
    totalCount,
    tasks,
  });
});

// POST /users/activate-network/share
router.post("/users/activate-network/share", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const { taskId, shareChannel } = req.body;

  // Get the task for this user and property
  const [task] = await db.select().from(networkTasksTable)
    .where(and(eq(networkTasksTable.userId, user.id), eq(networkTasksTable.propertyId, taskId)));

  if (!task) { res.status(404).json({ error: "Task not found" }); return; }

  // Mark as completed after recording share attempt
  const [updated] = await db.update(networkTasksTable).set({
    shareChannel,
    isCompleted: true,
    completedAt: new Date(),
  }).where(eq(networkTasksTable.id, task.id)).returning();

  // Check if all tasks done
  const allTasks = await db.select().from(networkTasksTable).where(eq(networkTasksTable.userId, user.id));
  const allDone = allTasks.every(t => t.isCompleted);
  if (allDone) {
    await db.update(usersTable).set({ networkActivated: true }).where(eq(usersTable.id, user.id));
  }

  res.status(201).json({
    taskId,
    shareChannel,
    trackingCode: updated?.trackingCode ?? task.trackingCode,
    isCompleted: true,
  });
});

export default router;
