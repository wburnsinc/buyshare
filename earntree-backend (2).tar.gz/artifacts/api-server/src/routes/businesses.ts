import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, businessesTable, subscriptionsTable, platformSettingsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

async function getSetting(key: string, fallback: string) {
  const [row] = await db.select().from(platformSettingsTable).where(eq(platformSettingsTable.key, key));
  return row?.value ?? fallback;
}

function bizToJson(biz: typeof businessesTable.$inferSelect, subStatus?: string) {
  return {
    id: biz.id,
    name: biz.name,
    ownerName: biz.ownerName,
    email: biz.email,
    phone: biz.phone ?? null,
    website: biz.website ?? null,
    address: biz.address ?? null,
    city: biz.city ?? null,
    state: biz.state ?? null,
    zip: biz.zip ?? null,
    category: biz.category ?? null,
    bio: biz.bio ?? null,
    logoUrl: biz.logoUrl ?? null,
    serviceRadius: biz.serviceRadius ? Number(biz.serviceRadius) : null,
    status: biz.status,
    subscriptionStatus: subStatus ?? "none",
    createdAt: biz.createdAt.toISOString(),
  };
}

// GET /business/me
router.get("/business/me", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "No business found" }); return; }

  const [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.businessId, biz.id));
  res.json(bizToJson(biz, sub?.status));
});

// POST /business/me
router.post("/business/me", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const existing = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (existing.length > 0) {
    res.status(409).json({ error: "Business already exists for this user" });
    return;
  }

  const { name, ownerName, email, phone, website, address, city, state, zip, category, bio, serviceRadius, logoUrl } = req.body;

  const [biz] = await db.insert(businessesTable).values({
    userId: user.id,
    name, ownerName, email, phone, website, address, city, state, zip, category, bio, serviceRadius, logoUrl,
    status: "pending",
  }).returning();

  // Update user role
  await db.update(usersTable).set({ role: "business" }).where(eq(usersTable.id, user.id));

  res.status(201).json(bizToJson(biz, "none"));
});

// PUT /business/me
router.put("/business/me", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const { name, ownerName, email, phone, website, address, city, state, zip, category, bio, serviceRadius, logoUrl } = req.body;

  const [biz] = await db.update(businessesTable).set({
    name, ownerName, email, phone, website, address, city, state, zip, category, bio, serviceRadius, logoUrl,
  }).where(eq(businessesTable.userId, user.id)).returning();

  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.businessId, biz.id));
  res.json(bizToJson(biz, sub?.status));
});

// GET /business/subscription
router.get("/business/subscription", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.businessId, biz.id));
  const weeklyPrice = Number(await getSetting("subscriptionWeeklyPrice", "10"));

  if (!sub) {
    res.json({ status: "none", stripeSubscriptionId: null, currentPeriodEnd: null, weeklyAmount: weeklyPrice, cancelAtPeriodEnd: false });
    return;
  }

  res.json({
    status: sub.status,
    stripeSubscriptionId: sub.stripeSubscriptionId ?? null,
    currentPeriodEnd: sub.currentPeriodEnd?.toISOString() ?? null,
    weeklyAmount: Number(sub.weeklyAmount),
    cancelAtPeriodEnd: sub.cancelAtPeriodEnd === "true",
  });
});

// POST /business/subscription (Stripe checkout session)
router.post("/business/subscription", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const { successUrl, cancelUrl } = req.body;

  // Check if Stripe is configured
  const stripeKey = process.env.STRIPE_SECRET_KEY;
  if (!stripeKey) {
    // Demo mode - return mock checkout URL
    const demoUrl = `${successUrl}?demo=true&session_id=demo_${Date.now()}`;
    res.status(201).json({ url: demoUrl, sessionId: `demo_${Date.now()}` });
    return;
  }

  try {
    const stripe = (await import("stripe")).default;
    const stripeClient = new stripe(stripeKey);

    const session = await stripeClient.checkout.sessions.create({
      mode: "subscription",
      line_items: [{
        price_data: {
          currency: "usd",
          product_data: { name: "ShareTree Business Subscription" },
          unit_amount: 1000,
          recurring: { interval: "week" },
        },
        quantity: 1,
      }],
      success_url: successUrl,
      cancel_url: cancelUrl,
      customer_email: biz.email,
      metadata: { businessId: String(biz.id) },
    });

    res.status(201).json({ url: session.url!, sessionId: session.id });
  } catch (err) {
    req.log.error({ err }, "Stripe checkout failed");
    res.status(500).json({ error: "Failed to create checkout session" });
  }
});

// POST /business/subscription/cancel
router.post("/business/subscription/cancel", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [biz] = await db.select().from(businessesTable).where(eq(businessesTable.userId, user.id));
  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }

  const [sub] = await db.update(subscriptionsTable).set({
    status: "cancelled",
    cancelAtPeriodEnd: "true",
  }).where(eq(subscriptionsTable.businessId, biz.id)).returning();

  res.json({
    status: sub?.status ?? "cancelled",
    stripeSubscriptionId: sub?.stripeSubscriptionId ?? null,
    currentPeriodEnd: sub?.currentPeriodEnd?.toISOString() ?? null,
    weeklyAmount: Number(sub?.weeklyAmount ?? 10),
    cancelAtPeriodEnd: true,
  });
});

export default router;
