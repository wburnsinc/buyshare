import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, rewardsTable, payoutRequestsTable, campaignsTable, platformSettingsTable } from "@workspace/db";
import { eq, and, desc, count, sql, sum } from "drizzle-orm";

const router = Router();

async function getSetting(key: string, fallback: string) {
  const [row] = await db.select().from(platformSettingsTable).where(eq(platformSettingsTable.key, key));
  return row?.value ?? fallback;
}

// GET /rewards
router.get("/rewards", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const statusFilter = req.query.status as string | undefined;

  let query = db.select({
    reward: rewardsTable,
    campaignTitle: campaignsTable.title,
  }).from(rewardsTable)
    .leftJoin(campaignsTable, eq(rewardsTable.campaignId, campaignsTable.id))
    .$dynamic();

  if (statusFilter) {
    query = query.where(and(eq(rewardsTable.userId, user.id)));
  } else {
    query = query.where(eq(rewardsTable.userId, user.id));
  }

  const rewards = await query.orderBy(desc(rewardsTable.createdAt)).limit(limit);
  const [{ total }] = await db.select({ total: count() }).from(rewardsTable).where(eq(rewardsTable.userId, user.id));

  res.json({
    rewards: rewards.map(({ reward: r, campaignTitle }) => ({
      id: r.id,
      campaignId: r.campaignId ?? null,
      campaignTitle: campaignTitle ?? null,
      shareEventId: r.shareEventId ?? null,
      amount: Number(r.amount),
      status: r.status,
      rejectionReason: r.rejectionReason ?? null,
      createdAt: r.createdAt.toISOString(),
      approvedAt: r.approvedAt?.toISOString() ?? null,
    })),
    total,
  });
});

// GET /rewards/summary
router.get("/rewards/summary", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const payoutThreshold = Number(await getSetting("payoutThreshold", "100"));

  const byStatus = await db.select({
    status: rewardsTable.status,
    count: count(),
    total: sum(rewardsTable.amount),
  }).from(rewardsTable)
    .where(eq(rewardsTable.userId, user.id))
    .groupBy(rewardsTable.status);

  res.json({
    availableBalance: Number(user.availableBalance),
    pendingBalance: Number(user.pendingBalance),
    lifetimeEarnings: Number(user.lifetimeEarnings),
    payoutThreshold,
    canRequestPayout: Number(user.availableBalance) >= payoutThreshold,
    rewardsByStatus: byStatus.map(r => ({
      status: r.status,
      count: r.count,
      total: Number(r.total ?? 0),
    })),
  });
});

// GET /payouts
router.get("/payouts", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const payouts = await db.select().from(payoutRequestsTable)
    .where(eq(payoutRequestsTable.userId, user.id))
    .orderBy(desc(payoutRequestsTable.createdAt));

  const [{ total }] = await db.select({ total: count() }).from(payoutRequestsTable).where(eq(payoutRequestsTable.userId, user.id));

  res.json({
    payouts: payouts.map(p => ({
      id: p.id,
      amount: Number(p.amount),
      status: p.status,
      method: p.method,
      notes: p.notes ?? null,
      createdAt: p.createdAt.toISOString(),
      processedAt: p.processedAt?.toISOString() ?? null,
    })),
    total,
  });
});

// POST /payouts
router.post("/payouts", async (req, res): Promise<void> => {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const payoutThreshold = Number(await getSetting("payoutThreshold", "100"));
  const available = Number(user.availableBalance);

  if (available < payoutThreshold) {
    res.status(400).json({ error: `Minimum payout is $${payoutThreshold}. Your available balance is $${available.toFixed(2)}.` });
    return;
  }

  const { amount, method } = req.body;
  const payoutAmount = Math.min(Number(amount), available);

  const [payout] = await db.insert(payoutRequestsTable).values({
    userId: user.id,
    amount: String(payoutAmount),
    method,
    status: "requested",
  }).returning();

  res.status(201).json({
    id: payout.id,
    amount: Number(payout.amount),
    status: payout.status,
    method: payout.method,
    notes: payout.notes ?? null,
    createdAt: payout.createdAt.toISOString(),
    processedAt: null,
  });
});

export default router;
