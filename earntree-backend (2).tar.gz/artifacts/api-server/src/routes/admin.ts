import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, businessesTable, campaignsTable, rewardsTable, payoutRequestsTable, fraudReviewsTable, adminAuditLogsTable, platformSettingsTable } from "@workspace/db";
import { eq, desc, count, sum } from "drizzle-orm";

const router = Router();

async function requireAdmin(req: any, res: any): Promise<{ userId: number } | null> {
  const { userId: clerkId } = getAuth(req);
  if (!clerkId) { res.status(401).json({ error: "Unauthorized" }); return null; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!user || user.role !== "admin") { res.status(403).json({ error: "Forbidden" }); return null; }
  return { userId: user.id };
}

async function logAudit(adminId: number, action: string, entityType: string, entityId: number, notes?: string) {
  await db.insert(adminAuditLogsTable).values({ adminId, action, entityType, entityId, notes });
}

// GET /admin/stats
router.get("/admin/stats", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const [{ totalUsers }] = await db.select({ totalUsers: count() }).from(usersTable);
  const [{ totalBusinesses }] = await db.select({ totalBusinesses: count() }).from(businessesTable);
  const [{ totalCampaigns }] = await db.select({ totalCampaigns: count() }).from(campaignsTable);
  const [{ totalShares }] = await db.select({ totalShares: sum(campaignsTable.shareCount) }).from(campaignsTable);
  const [{ totalRewardsPaid }] = await db.select({ totalRewardsPaid: sum(rewardsTable.amount) }).from(rewardsTable).where(eq(rewardsTable.status, "paid"));
  const [{ pendingRewards }] = await db.select({ pendingRewards: count() }).from(rewardsTable).where(eq(rewardsTable.status, "pending"));
  const [{ pendingPayouts }] = await db.select({ pendingPayouts: count() }).from(payoutRequestsTable).where(eq(payoutRequestsTable.status, "requested"));
  const [{ fraudQueue }] = await db.select({ fraudQueue: count() }).from(fraudReviewsTable).where(eq(fraudReviewsTable.status, "pending"));

  res.json({
    totalUsers,
    totalBusinesses,
    totalCampaigns,
    totalShares: Number(totalShares ?? 0),
    totalRewardsPaid: Number(totalRewardsPaid ?? 0),
    monthlyRevenue: Number(totalBusinesses) * 10 * 4, // estimate
    pendingRewards,
    pendingPayouts,
    fraudQueue,
  });
});

// GET /admin/users
router.get("/admin/users", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const offset = Number(req.query.offset) || 0;
  const search = req.query.search as string | undefined;

  const users = await db.select().from(usersTable)
    .orderBy(desc(usersTable.createdAt))
    .limit(limit).offset(offset);

  const [{ total }] = await db.select({ total: count() }).from(usersTable);

  res.json({
    users: users.map(u => ({
      id: u.id,
      email: u.email,
      name: u.name,
      role: u.role,
      networkActivated: u.networkActivated,
      isFrozen: u.isFrozen,
      lifetimeEarnings: Number(u.lifetimeEarnings),
      shareCount: 0,
      createdAt: u.createdAt.toISOString(),
    })),
    total,
  });
});

// PATCH /admin/users/:id/freeze
router.patch("/admin/users/:id/freeze", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const { frozen, reason } = req.body;

  const [user] = await db.update(usersTable).set({ isFrozen: frozen, freezeReason: reason }).where(eq(usersTable.id, id)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  await logAudit(admin.userId, frozen ? "freeze_user" : "unfreeze_user", "user", id, reason);

  res.json({
    id: user.id, email: user.email, name: user.name, role: user.role,
    networkActivated: user.networkActivated, isFrozen: user.isFrozen,
    lifetimeEarnings: Number(user.lifetimeEarnings), shareCount: 0, createdAt: user.createdAt.toISOString(),
  });
});

// GET /admin/businesses
router.get("/admin/businesses", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const offset = Number(req.query.offset) || 0;
  const statusFilter = req.query.status as string | undefined;

  const businesses = await db.select().from(businessesTable)
    .orderBy(desc(businessesTable.createdAt))
    .limit(limit).offset(offset);

  const [{ total }] = await db.select({ total: count() }).from(businessesTable);

  res.json({
    businesses: businesses.map(b => ({
      id: b.id, name: b.name, ownerName: b.ownerName, email: b.email,
      phone: b.phone ?? null, website: b.website ?? null, address: b.address ?? null,
      city: b.city ?? null, state: b.state ?? null, zip: b.zip ?? null,
      category: b.category ?? null, bio: b.bio ?? null, logoUrl: b.logoUrl ?? null,
      serviceRadius: b.serviceRadius ? Number(b.serviceRadius) : null,
      status: b.status, subscriptionStatus: null, createdAt: b.createdAt.toISOString(),
    })),
    total,
  });
});

// PATCH /admin/businesses/:id/approve
router.patch("/admin/businesses/:id/approve", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const { approved, reason } = req.body;

  const [biz] = await db.update(businessesTable).set({
    status: approved ? "approved" : "rejected",
    rejectionReason: approved ? null : reason,
  }).where(eq(businessesTable.id, id)).returning();

  if (!biz) { res.status(404).json({ error: "Business not found" }); return; }
  await logAudit(admin.userId, approved ? "approve_business" : "reject_business", "business", id, reason);

  res.json({
    id: biz.id, name: biz.name, ownerName: biz.ownerName, email: biz.email,
    phone: biz.phone ?? null, website: biz.website ?? null, address: biz.address ?? null,
    city: biz.city ?? null, state: biz.state ?? null, zip: biz.zip ?? null,
    category: biz.category ?? null, bio: biz.bio ?? null, logoUrl: biz.logoUrl ?? null,
    serviceRadius: biz.serviceRadius ? Number(biz.serviceRadius) : null,
    status: biz.status, subscriptionStatus: null, createdAt: biz.createdAt.toISOString(),
  });
});

// GET /admin/campaigns
router.get("/admin/campaigns", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const campaigns = await db.select({
    campaign: campaignsTable,
    businessName: businessesTable.name,
    businessLogoUrl: businessesTable.logoUrl,
  }).from(campaignsTable)
    .leftJoin(businessesTable, eq(campaignsTable.businessId, businessesTable.id))
    .orderBy(desc(campaignsTable.createdAt))
    .limit(limit);

  const [{ total }] = await db.select({ total: count() }).from(campaignsTable);

  res.json({
    campaigns: campaigns.map(({ campaign: c, businessName, businessLogoUrl }) => ({
      id: c.id, businessId: c.businessId, businessName: businessName ?? "Unknown",
      businessLogoUrl: businessLogoUrl ?? null, title: c.title, description: c.description,
      status: c.status, rewardAmount: Number(c.rewardAmount), category: c.category,
      city: c.city, state: c.state, zip: c.zip ?? null,
      serviceRadius: c.serviceRadius ? Number(c.serviceRadius) : null,
      landingPageUrl: c.landingPageUrl ?? null, ctaText: c.ctaText ?? null, imageUrl: c.imageUrl ?? null,
      weeklyBudget: Number(c.weeklyBudget), budgetRemaining: Number(c.weeklyBudget),
      estimatedVerificationHours: c.estimatedVerificationHours,
      startDate: c.startDate, endDate: c.endDate, createdAt: c.createdAt.toISOString(),
      recommendationReason: null, matchScore: null, shareCount: c.shareCount, clickCount: c.clickCount, userHasShared: false,
    })),
    total,
  });
});

// PATCH /admin/campaigns/:id/approve
router.patch("/admin/campaigns/:id/approve", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const { approved, reason } = req.body;

  const [c] = await db.update(campaignsTable).set({
    status: approved ? "active" : "rejected",
    rejectionReason: approved ? null : reason,
  }).where(eq(campaignsTable.id, id)).returning();

  if (!c) { res.status(404).json({ error: "Campaign not found" }); return; }
  await logAudit(admin.userId, approved ? "approve_campaign" : "reject_campaign", "campaign", id, reason);

  res.json({
    id: c.id, businessId: c.businessId, businessName: null, businessLogoUrl: null,
    title: c.title, description: c.description, status: c.status,
    rewardAmount: Number(c.rewardAmount), category: c.category, city: c.city, state: c.state,
    zip: c.zip ?? null, serviceRadius: c.serviceRadius ? Number(c.serviceRadius) : null,
    landingPageUrl: c.landingPageUrl ?? null, ctaText: c.ctaText ?? null, imageUrl: c.imageUrl ?? null,
    weeklyBudget: Number(c.weeklyBudget), budgetRemaining: Number(c.weeklyBudget),
    estimatedVerificationHours: c.estimatedVerificationHours,
    startDate: c.startDate, endDate: c.endDate, createdAt: c.createdAt.toISOString(),
  });
});

// GET /admin/rewards
router.get("/admin/rewards", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const statusFilter = req.query.status as string | undefined;

  const rewards = await db.select({
    reward: rewardsTable,
    campaignTitle: campaignsTable.title,
  }).from(rewardsTable)
    .leftJoin(campaignsTable, eq(rewardsTable.campaignId, campaignsTable.id))
    .where(statusFilter ? eq(rewardsTable.status, statusFilter) : undefined!)
    .orderBy(desc(rewardsTable.createdAt))
    .limit(limit);

  const [{ total }] = await db.select({ total: count() }).from(rewardsTable);

  res.json({
    rewards: rewards.map(({ reward: r, campaignTitle }) => ({
      id: r.id, campaignId: r.campaignId ?? null, campaignTitle: campaignTitle ?? null,
      shareEventId: r.shareEventId ?? null, amount: Number(r.amount), status: r.status,
      rejectionReason: r.rejectionReason ?? null, createdAt: r.createdAt.toISOString(),
      approvedAt: r.approvedAt?.toISOString() ?? null,
    })),
    total,
  });
});

// PATCH /admin/rewards/:id/review
router.patch("/admin/rewards/:id/review", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const { status, reason } = req.body;

  const [reward] = await db.update(rewardsTable).set({
    status,
    rejectionReason: status === "rejected" ? reason : null,
    reviewedBy: admin.userId,
    approvedAt: status === "approved" ? new Date() : undefined,
  }).where(eq(rewardsTable.id, id)).returning();

  if (!reward) { res.status(404).json({ error: "Reward not found" }); return; }

  // If approved, update user balance
  if (status === "approved") {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, reward.userId));
    if (user) {
      const newAvailable = Number(user.availableBalance) + Number(reward.amount);
      const newLifetime = Number(user.lifetimeEarnings) + Number(reward.amount);
      await db.update(usersTable).set({
        availableBalance: String(newAvailable),
        lifetimeEarnings: String(newLifetime),
        pendingBalance: String(Math.max(0, Number(user.pendingBalance) - Number(reward.amount))),
      }).where(eq(usersTable.id, user.id));
    }
  }

  await logAudit(admin.userId, `${status}_reward`, "reward", id, reason);

  res.json({
    id: reward.id, campaignId: reward.campaignId ?? null, campaignTitle: null,
    shareEventId: reward.shareEventId ?? null, amount: Number(reward.amount), status: reward.status,
    rejectionReason: reward.rejectionReason ?? null, createdAt: reward.createdAt.toISOString(),
    approvedAt: reward.approvedAt?.toISOString() ?? null,
  });
});

// GET /admin/payouts
router.get("/admin/payouts", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const payouts = await db.select().from(payoutRequestsTable)
    .orderBy(desc(payoutRequestsTable.createdAt)).limit(limit);

  const [{ total }] = await db.select({ total: count() }).from(payoutRequestsTable);

  res.json({
    payouts: payouts.map(p => ({
      id: p.id, amount: Number(p.amount), status: p.status, method: p.method,
      notes: p.notes ?? null, createdAt: p.createdAt.toISOString(), processedAt: p.processedAt?.toISOString() ?? null,
    })),
    total,
  });
});

// PATCH /admin/payouts/:id/process
router.patch("/admin/payouts/:id/process", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const { status, notes } = req.body;

  const [payout] = await db.update(payoutRequestsTable).set({
    status,
    notes,
    processedBy: admin.userId,
    processedAt: new Date(),
  }).where(eq(payoutRequestsTable.id, id)).returning();

  if (!payout) { res.status(404).json({ error: "Payout not found" }); return; }

  // Deduct from user balance if processed
  if (status === "processed") {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, payout.userId));
    if (user) {
      await db.update(usersTable).set({
        availableBalance: String(Math.max(0, Number(user.availableBalance) - Number(payout.amount))),
      }).where(eq(usersTable.id, user.id));
    }
  }

  await logAudit(admin.userId, `${status}_payout`, "payout", id, notes);

  res.json({
    id: payout.id, amount: Number(payout.amount), status: payout.status,
    method: payout.method, notes: payout.notes ?? null,
    createdAt: payout.createdAt.toISOString(), processedAt: payout.processedAt?.toISOString() ?? null,
  });
});

// GET /admin/fraud
router.get("/admin/fraud", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const items = await db.select({
    review: fraudReviewsTable,
    userName: usersTable.name,
  }).from(fraudReviewsTable)
    .leftJoin(usersTable, eq(fraudReviewsTable.userId, usersTable.id))
    .where(eq(fraudReviewsTable.status, "pending"))
    .orderBy(desc(fraudReviewsTable.createdAt))
    .limit(50);

  const [{ total }] = await db.select({ total: count() }).from(fraudReviewsTable).where(eq(fraudReviewsTable.status, "pending"));

  res.json({
    items: items.map(({ review: r, userName }) => ({
      id: r.id, userId: r.userId, userName: userName ?? null,
      type: r.type, riskScore: Number(r.riskScore), status: r.status,
      details: r.details ?? null, createdAt: r.createdAt.toISOString(),
    })),
    total,
  });
});

// GET /admin/audit-logs
router.get("/admin/audit-logs", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const offset = Number(req.query.offset) || 0;

  const logs = await db.select({
    log: adminAuditLogsTable,
    adminName: usersTable.name,
  }).from(adminAuditLogsTable)
    .leftJoin(usersTable, eq(adminAuditLogsTable.adminId, usersTable.id))
    .orderBy(desc(adminAuditLogsTable.createdAt))
    .limit(limit).offset(offset);

  const [{ total }] = await db.select({ total: count() }).from(adminAuditLogsTable);

  res.json({
    logs: logs.map(({ log: l, adminName }) => ({
      id: l.id, adminId: l.adminId, adminName: adminName ?? null,
      action: l.action, entityType: l.entityType, entityId: l.entityId,
      notes: l.notes ?? null, createdAt: l.createdAt.toISOString(),
    })),
    total,
  });
});

// GET /admin/settings
router.get("/admin/settings", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const settings = await db.select().from(platformSettingsTable);
  const map: Record<string, string> = {};
  settings.forEach(s => { map[s.key] = s.value; });

  res.json({
    rewardPerShare: Number(map["rewardPerShare"] ?? "0.25"),
    payoutThreshold: Number(map["payoutThreshold"] ?? "100"),
    dailyEarningCap: Number(map["dailyEarningCap"] ?? "25"),
    weeklyEarningCap: Number(map["weeklyEarningCap"] ?? "100"),
    subscriptionWeeklyPrice: Number(map["subscriptionWeeklyPrice"] ?? "10"),
    networkActivationRequired: map["networkActivationRequired"] !== "false",
    networkActivationOptional: map["networkActivationOptional"] === "true",
    fraudReviewThreshold: Number(map["fraudReviewThreshold"] ?? "75"),
  });
});

// PUT /admin/settings
router.put("/admin/settings", async (req, res): Promise<void> => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  const { rewardPerShare, payoutThreshold, dailyEarningCap, weeklyEarningCap,
    subscriptionWeeklyPrice, networkActivationRequired, networkActivationOptional, fraudReviewThreshold } = req.body;

  const updates: Record<string, string> = {
    rewardPerShare: String(rewardPerShare),
    payoutThreshold: String(payoutThreshold),
    dailyEarningCap: String(dailyEarningCap),
    weeklyEarningCap: String(weeklyEarningCap),
    subscriptionWeeklyPrice: String(subscriptionWeeklyPrice),
    networkActivationRequired: String(networkActivationRequired),
    networkActivationOptional: String(networkActivationOptional),
    fraudReviewThreshold: String(fraudReviewThreshold),
  };

  for (const [key, value] of Object.entries(updates)) {
    await db.insert(platformSettingsTable).values({ key, value })
      .onConflictDoUpdate({ target: platformSettingsTable.key, set: { value } });
  }

  await logAudit(admin.userId, "update_settings", "settings", 0);

  res.json({
    rewardPerShare: Number(rewardPerShare),
    payoutThreshold: Number(payoutThreshold),
    dailyEarningCap: Number(dailyEarningCap),
    weeklyEarningCap: Number(weeklyEarningCap),
    subscriptionWeeklyPrice: Number(subscriptionWeeklyPrice),
    networkActivationRequired: Boolean(networkActivationRequired),
    networkActivationOptional: Boolean(networkActivationOptional),
    fraudReviewThreshold: Number(fraudReviewThreshold),
  });
});

export default router;
