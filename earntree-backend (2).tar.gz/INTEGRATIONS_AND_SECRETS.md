# EarnTree.co — Integrations & Secrets Reference

> **Security notice:** This document lists variable *names* and *descriptions* only.
> Real credentials must be stored in environment variables, never in this file or in source control.

---

## 1. PostgreSQL Database

| Field | Value |
|---|---|
| **Purpose** | Primary data store — users, businesses, campaigns, rewards, share events, payouts, fraud reviews, audit logs, platform settings |
| **Provider** | Replit managed PostgreSQL (dev) — migrate to Neon, Supabase, Railway, or self-hosted for production |
| **Env var** | `DATABASE_URL` |
| **Obtain** | Create a new PostgreSQL database on your chosen host; copy the connection string |
| **Rotation** | Update `DATABASE_URL` in Replit Secrets (or host env), restart the API server |
| **Schema tool** | Drizzle ORM — run `pnpm --filter @workspace/db run push` to apply schema |
| **Billing** | Depends on chosen host — Neon free tier covers small workloads |

---

## 2. Clerk — Authentication

| Field | Value |
|---|---|
| **Purpose** | User sign-up, sign-in, session management, JWT verification. Used by both the React frontend and the Express API (middleware) |
| **Provider** | Clerk (https://clerk.com) |
| **Env vars** | `CLERK_SECRET_KEY` (server-only), `VITE_CLERK_PUBLISHABLE_KEY` (frontend) |
| **Obtain** | Create a Clerk application at https://dashboard.clerk.com → API Keys |
| **Rotation** | Generate new API keys in the Clerk dashboard → update both secrets → restart services |
| **Post-migration** | Re-configure allowed redirect URLs and OAuth providers in the Clerk dashboard for the new domain |
| **Account dependency** | Clerk account ownership — transfer the Clerk app to the new owner's account via the Clerk dashboard Team settings |
| **Subscription** | Clerk free tier supports up to 10,000 MAU; paid plans required above that |

### Clerk configuration checklist after migration
- [ ] Update **Allowed redirect URIs** to new domain
- [ ] Update **Sign-in / Sign-up URLs** in Clerk dashboard
- [ ] Re-connect any social OAuth providers (Google, etc.) under the new domain's OAuth app credentials
- [ ] Update **JWT template** if custom claims are used

---

## 3. Stripe — Business Payments ($10/week subscriptions)

| Field | Value |
|---|---|
| **Purpose** | Processes business subscription payments at $10/week per active campaign. Used by the Business Billing page and the `/api/business/stripe/*` endpoints |
| **Provider** | Stripe (https://stripe.com) |
| **Env vars** | `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_ID`, `VITE_STRIPE_PUBLISHABLE_KEY` (optional, for Stripe.js) |
| **Obtain** | Create a Stripe account → Developers → API keys. Create a recurring Price object at $10/week and copy its `price_XXXX` ID |
| **Rotation** | Roll secret key in Stripe dashboard → update `STRIPE_SECRET_KEY` → redeploy. Re-register the webhook endpoint to get a new `STRIPE_WEBHOOK_SECRET` |
| **Webhook** | Register `https://<your-domain>/api/business/stripe/webhook` in the Stripe dashboard. Events: `checkout.session.completed`, `invoice.payment_succeeded`, `customer.subscription.deleted` |
| **Account dependency** | Stripe account ownership — add new owner as admin in Stripe dashboard → Platform → Team |
| **Subscription** | Stripe charges 2.9% + $0.30 per successful payment. No monthly platform fee |

---

## 4. Session Secret

| Field | Value |
|---|---|
| **Purpose** | Signs Express session cookies to prevent tampering |
| **Env var** | `SESSION_SECRET` |
| **Obtain** | Generate with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| **Rotation** | Update the secret → all existing sessions are immediately invalidated (users must re-log-in) |

---

## 5. App Runtime Variables

| Variable | Purpose | Required |
|---|---|---|
| `PORT` | TCP port the API Express server binds to | Yes (default 5000) |
| `NODE_ENV` | Runtime mode (`development`/`production`) | Yes |
| `APP_BASE_URL` | Public base URL used in tracking link generation | Yes (production) |
| `ADMIN_CLERK_USER_IDS` | Comma-separated Clerk user IDs granted admin role on first login | Optional |

---

## 6. Domain & DNS (No env var — manual setup)

| Item | Notes |
|---|---|
| **Custom domain** | Configured in Replit Deployments → Custom Domain. Target the Replit deployment CNAME |
| **DNS record** | Add a CNAME `earntree.co → <replit-deployment-id>.replit.app` at your DNS registrar |
| **SSL** | Automatic via Replit (or your chosen host's TLS termination) |
| **Post-migration** | Update Clerk allowed origins, Stripe webhook URL, and `APP_BASE_URL` env var |

---

## 7. No-email / No-analytics currently configured

The current app has **no** outbound email provider, analytics service, or external object storage. If you add these later:

- **Email** — Add Resend, SendGrid, or Postmark credentials as `RESEND_API_KEY` / `SENDGRID_API_KEY`
- **Analytics** — Add `VITE_POSTHOG_KEY` or `VITE_GA_MEASUREMENT_ID`
- **File storage** — Add `REPLIT_OBJECT_STORAGE_*` or S3-compatible vars

---

## Credential Handover Checklist

- [ ] New Clerk application created and `CLERK_SECRET_KEY` + `VITE_CLERK_PUBLISHABLE_KEY` updated
- [ ] Stripe account access transferred or new account set up; new `STRIPE_SECRET_KEY` + `STRIPE_PRICE_ID` configured
- [ ] Stripe webhook re-registered for new domain
- [ ] New `DATABASE_URL` pointing at migrated database
- [ ] New `SESSION_SECRET` generated
- [ ] `APP_BASE_URL` set to new domain
- [ ] All variables set in new host's secret store (not in code)
