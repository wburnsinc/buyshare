# EarnTree.co — Relaunch Guide

Step-by-step instructions to deploy this project from scratch on a new Replit account, VPS, or any Node.js host.

---

## Prerequisites

- Node.js 20+ (Node 24 preferred — matches the current dev environment)
- pnpm 9+ (`npm install -g pnpm`)
- A PostgreSQL database (Neon free tier works: https://neon.tech)
- A Clerk account and application (https://clerk.com)
- A Stripe account (https://stripe.com) — required only for business billing

---

## Step 1 — Import Source Code

### Option A: New Replit account (recommended)

1. Log in to https://replit.com
2. Click **Create Repl** → **Import from ZIP** (or use the **Import from GitHub** option if you've pushed to a repo)
3. Upload `earntree-handover.zip`
4. Wait for Replit to detect the workspace — it will find `pnpm-workspace.yaml` automatically

### Option B: Any Linux host / VPS

```bash
unzip earntree-handover.zip -d earntree
cd earntree
```

---

## Step 2 — Install Dependencies

```bash
pnpm install
```

This installs all workspace packages using the frozen lockfile. Do **not** use `npm install` — this is a pnpm workspace.

---

## Step 3 — Configure Environment Variables

1. Copy the example file:
   ```bash
   cp .env.example .env
   ```
2. Fill in every value in `.env` — see `INTEGRATIONS_AND_SECRETS.md` for where to obtain each one.

### On Replit
Use **Secrets** (the padlock icon in the sidebar) instead of a `.env` file — paste each variable name and value there. Replit injects them as environment variables automatically.

Required variables:
```
DATABASE_URL
SESSION_SECRET
CLERK_SECRET_KEY
VITE_CLERK_PUBLISHABLE_KEY
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
STRIPE_PRICE_ID
PORT=5000
NODE_ENV=production
APP_BASE_URL=https://your-domain.com
```

---

## Step 4 — Create the Database & Apply Schema

### 4a. Create a PostgreSQL database

- **Neon** (free): https://console.neon.tech → New Project → copy the connection string
- **Supabase**: https://supabase.com → New Project → Settings → Database → Connection string
- **Railway**: https://railway.app → New → PostgreSQL → Variables → `DATABASE_URL`

Set `DATABASE_URL` to the connection string.

### 4b. Push the Drizzle schema (creates all tables)

```bash
pnpm --filter @workspace/db run push
```

Expected output: all tables created with no errors.

### 4c. Seed reference data

```bash
pnpm --filter @workspace/scripts run seed
```

This inserts the 12 business categories, 5 network properties, and default platform settings.

---

## Step 5 — Import Exported Data (if migrating from existing deployment)

The `handover/` folder contains two SQL files:

| File | Contents |
|---|---|
| `handover/schema.sql` | DDL — table definitions (for reference; Drizzle push is the canonical way to apply schema) |
| `handover/seed_data.sql` | All current live data (users, businesses, campaigns, rewards, etc.) |

To restore live data into a fresh database:

```bash
# 1. Apply schema first (creates tables)
pnpm --filter @workspace/db run push

# 2. Restore data
psql "$DATABASE_URL" < handover/seed_data.sql
```

**Verification checklist after import:**
- [ ] `SELECT count(*) FROM users;` — matches source count
- [ ] `SELECT count(*) FROM campaigns;` — matches source count
- [ ] `SELECT count(*) FROM categories;` returns 12 rows
- [ ] `SELECT count(*) FROM network_properties;` returns 5 rows
- [ ] `SELECT count(*) FROM platform_settings;` has expected settings rows
- [ ] Log in as a known user and verify their data appears correctly

---

## Step 6 — Configure Clerk

1. Go to https://dashboard.clerk.com → your application
2. Under **Paths**, set:
   - Sign-in URL: `/sign-in`
   - Sign-up URL: `/sign-up`
   - After sign-in URL: `/app`
   - After sign-up URL: `/app`
3. Under **Domains**, add your new domain
4. Under **API Keys**, copy `CLERK_SECRET_KEY` and `VITE_CLERK_PUBLISHABLE_KEY`

**Note on user accounts:** Clerk stores user identity separately from your database. If you are migrating existing users:
- Existing Clerk accounts are tied to the original Clerk application
- To migrate users, export them from the old Clerk app (Settings → Users → Export) and import into the new app, **or** ask users to re-register (their reward data in PostgreSQL will be preserved if `clerkId` values match)

---

## Step 7 — Configure Stripe

1. Go to https://dashboard.stripe.com → Developers → API Keys → copy `STRIPE_SECRET_KEY`
2. Create a recurring Price: Products → Add Product → "Business Weekly Plan" → $10.00 / week → copy `price_XXXX` ID as `STRIPE_PRICE_ID`
3. Register webhook: Developers → Webhooks → Add endpoint:
   - URL: `https://your-domain.com/api/business/stripe/webhook`
   - Events: `checkout.session.completed`, `invoice.payment_succeeded`, `customer.subscription.deleted`
   - Copy signing secret as `STRIPE_WEBHOOK_SECRET`

---

## Step 8 — Run the Application

### On Replit
The project has two configured workflows:
- **API Server** — runs `pnpm --filter @workspace/api-server run dev`
- **ShareTree (web)** — runs `pnpm --filter @workspace/sharetree run dev`

Click the green **Run** button or start both workflows from the Workflows panel.

### On a Linux server / VPS

```bash
# Terminal 1 — API server
pnpm --filter @workspace/api-server run dev

# Terminal 2 — Frontend dev server
pnpm --filter @workspace/sharetree run dev
```

For production, build the frontend and serve statically:
```bash
pnpm --filter @workspace/sharetree run build
# Serve dist/ with nginx or express static middleware
```

---

## Step 9 — Deploy (Replit)

1. In Replit, click **Deploy** → **Reserved VM** or **Autoscale**
2. Set all environment variables in the Deployments → Secrets section
3. Click **Deploy** — Replit builds and publishes automatically
4. The app is available at `https://<repl-name>.<username>.replit.app`

For other hosts (Railway, Render, Fly.io):
```bash
pnpm run build   # builds all packages
# Then follow your host's deployment instructions for Node.js apps
```

---

## Step 10 — Connect Custom Domain & DNS

### Replit
1. Deployments → Custom Domain → enter `earntree.co`
2. Replit provides a CNAME target (e.g. `abc123.replit.app`)
3. At your DNS registrar (Cloudflare, Route 53, Namecheap, etc.), add:
   ```
   Type: CNAME
   Name: @  (or earntree.co)
   Value: abc123.replit.app
   TTL: Auto
   ```
4. Replit provisions TLS automatically within a few minutes

After changing domain:
- Update `APP_BASE_URL` env var
- Update Clerk allowed domains
- Update Stripe webhook URL

---

## Step 11 — Smoke Test Critical Features

Run through this checklist before going live:

**Public**
- [ ] Landing page loads at `/`
- [ ] "How It Works", "For Businesses", "Pricing", "Legal" pages load
- [ ] Sign-up flow completes and redirects to `/app`

**User Portal**
- [ ] Dashboard loads with stats
- [ ] Browse Campaigns shows campaigns
- [ ] Share a campaign → tracking link generated
- [ ] Share History shows the event
- [ ] Earnings page shows pending reward

**Business Portal**
- [ ] Business onboarding flow completes
- [ ] Create Campaign form submits successfully
- [ ] Campaign appears in admin queue

**Admin Portal**
- [ ] Admin dashboard loads
- [ ] Approve a business → status updates
- [ ] Approve a campaign → campaign becomes active
- [ ] Approve a reward → user's balance updates
- [ ] Process a payout → payout marked processed

**Network Activation Gate**
- [ ] `/app/activate` shows 5 network properties
- [ ] Sharing a property marks task complete

---

## Step 12 — Backup & Restore

### Automated backup (recommended)

Set up a daily cron job:

```bash
# Add to crontab: crontab -e
0 2 * * * pg_dump "$DATABASE_URL" --no-owner --no-acl | gzip > /backups/earntree-$(date +%Y%m%d).sql.gz
```

### Manual backup

```bash
pg_dump "$DATABASE_URL" --no-owner --no-acl > backup-$(date +%Y-%m-%d).sql
```

### Restore

```bash
# Drop and recreate the database, then:
psql "$DATABASE_URL" < backup-2025-01-01.sql
```

### What cannot be backed up via SQL

| Item | Backup method |
|---|---|
| Clerk user accounts & passwords | Clerk dashboard → Users → Export CSV |
| Stripe customers & subscriptions | Stripe dashboard → Customers (cannot be bulk-imported; customers must re-subscribe) |
| Uploaded media files | None currently — no file uploads in v1 |

---

## Common Troubleshooting

| Symptom | Fix |
|---|---|
| API returns 401 on all routes | `CLERK_SECRET_KEY` is missing or incorrect |
| Frontend shows blank page | `VITE_CLERK_PUBLISHABLE_KEY` is missing |
| `DATABASE_URL` error on start | Check connection string format; ensure the DB allows connections from your host IP |
| Stripe webhook 400 errors | `STRIPE_WEBHOOK_SECRET` mismatch — re-copy from Stripe dashboard |
| Schema push fails | Ensure `DATABASE_URL` user has CREATE TABLE privileges |
