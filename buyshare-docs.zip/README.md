# BuyShare.co — Master Marketplace Platform

**A unified home services and sharing marketplace for Southwest Florida.**  
Brands: Blue Truck LLC · SHARE™ · ThriftGirl™ · Playdate™ · RideShare™ · PoolShare™ · EarnTree™ · BurnCall™

---

## Framework & Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19 + Vite 7 (TypeScript) |
| Routing | Wouter 3 |
| UI | shadcn/ui + Radix UI + Tailwind CSS v4 |
| Charts | Recharts |
| Animations | Framer Motion |
| Backend | Express 5 (Node.js 24, TypeScript ESM) |
| Database | PostgreSQL + Drizzle ORM |
| Validation | Zod v4 + drizzle-zod |
| Package manager | pnpm (workspace/monorepo) |
| Build tool | esbuild (server) + Vite (frontend) |

---

## Repository Structure

```
buyshare-co/
├── artifacts/
│   ├── buyshare/          # Frontend — React/Vite SPA
│   │   ├── src/
│   │   │   ├── pages/     # All 20+ page components
│   │   │   ├── components/# Layout, UI components (shadcn)
│   │   │   ├── hooks/     # Custom hooks
│   │   │   ├── lib/       # Utilities
│   │   │   ├── App.tsx    # Router + providers
│   │   │   ├── main.tsx   # Entry point
│   │   │   └── index.css  # Tailwind + global styles
│   │   ├── index.html     # HTML entry point
│   │   └── vite.config.ts # Vite configuration
│   └── api-server/        # Backend — Express 5 API
│       └── src/
│           ├── routes/    # 17 route files (/api/*)
│           ├── app.ts     # Express app setup
│           └── index.ts   # Server entry point
├── lib/
│   ├── db/                # Database — Drizzle ORM + schema
│   │   └── src/schema/    # 15 table schema files
│   ├── api-spec/          # OpenAPI spec
│   ├── api-client-react/  # Generated React Query hooks
│   └── api-zod/           # Generated Zod schemas
├── scripts/
│   └── src/seed.ts        # Database seed script
├── attached_assets/       # Brand logos and uploaded images
├── schema.sql             # Full PostgreSQL schema export
├── seed-data.sql          # Current data export (INSERT statements)
├── pnpm-workspace.yaml    # pnpm workspace config
├── package.json           # Root scripts
├── .env.example           # Required environment variables
├── RELAUNCH_GUIDE.md      # Step-by-step migration guide
├── INTEGRATIONS_AND_SECRETS.md
└── HANDOVER_CHECKLIST.md
```

---

## Running Locally

### Prerequisites
- Node.js 20+ (22 or 24 recommended)
- pnpm 9+ (`npm install -g pnpm`)
- PostgreSQL 14+ (local or cloud — Neon, Supabase, Railway, etc.)

### 1. Install dependencies
```bash
pnpm install
```

### 2. Configure environment variables
```bash
cp .env.example .env
# Edit .env — fill in DATABASE_URL and SESSION_SECRET at minimum
```

### 3. Push the database schema
```bash
pnpm --filter @workspace/db run push
```
*Or restore from the included SQL export:*
```bash
psql "$DATABASE_URL" < schema.sql
psql "$DATABASE_URL" < seed-data.sql
```

### 4. Start the development servers

**Terminal 1 — API server** (runs on port 8080):
```bash
PORT=8080 pnpm --filter @workspace/api-server run dev
```

**Terminal 2 — Frontend** (runs on port 3000):
```bash
PORT=3000 BASE_PATH=/ pnpm --filter @workspace/buyshare run dev
```

Open http://localhost:3000 in your browser.

> The frontend calls `/api/*` relative to its own origin. In dev, configure your frontend  
> to proxy `/api` to `http://localhost:8080`. See **Proxy Setup** below.

### Development Proxy Setup (Vite)
In `artifacts/buyshare/vite.config.ts`, add to the `server` block:
```ts
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:8080',
      changeOrigin: true,
    }
  }
}
```

---

## Building for Production

```bash
# Build both frontend and backend
PORT=3000 BASE_PATH=/ pnpm --filter @workspace/buyshare run build
pnpm --filter @workspace/api-server run build
```

Frontend output: `artifacts/buyshare/dist/public/`  
Backend output: `artifacts/api-server/dist/index.mjs`

### Serving Production Build
```bash
# Start the API server
PORT=8080 NODE_ENV=production node artifacts/api-server/dist/index.mjs

# Serve frontend static files via any static host (Nginx, Caddy, Vercel, etc.)
# Point root to artifacts/buyshare/dist/public/
```

---

## Required Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | **Yes** | Full PostgreSQL connection string |
| `SESSION_SECRET` | **Yes** | Random secret for session signing (32+ chars) |
| `PORT` | **Yes** | Port for the API server (e.g. `8080`) |
| `NODE_ENV` | No | `development` or `production` |
| `BASE_PATH` | Frontend only | URL base path for Vite (default `/`) |

---

## Seeding Demo Data
```bash
pnpm --filter @workspace/scripts run seed
```
Seeds: services, contractors, bookings, payments, share listings, BurnCall leads, investor metrics, messages.

---

## Key Commands Reference

```bash
pnpm install                                    # Install all dependencies
pnpm --filter @workspace/db run push            # Apply schema to DB
pnpm --filter @workspace/scripts run seed       # Seed demo data
pnpm --filter @workspace/api-server run dev     # Start API (dev)
pnpm --filter @workspace/buyshare run dev       # Start frontend (dev)
pnpm --filter @workspace/api-server run build   # Build API (prod)
pnpm --filter @workspace/buyshare run build     # Build frontend (prod)
pnpm run typecheck                              # Full TypeScript check
pnpm --filter @workspace/api-spec run codegen  # Regenerate API client
```

---

## Deployment Options

| Platform | Notes |
|----------|-------|
| **Railway** | Deploy both services, add Postgres plugin |
| **Render** | Web service (API) + Static site (frontend) |
| **Fly.io** | Dockerfile recommended |
| **Vercel** | Frontend only; API needs separate host |
| **Heroku** | Procfile: `web: node artifacts/api-server/dist/index.mjs` |
| **DigitalOcean App Platform** | Two components: static + web service |
| **VPS (Nginx)** | Nginx reverse proxy to Express; serve static from dist |

---

## Contact & Brand
- Phone: 223-254-8299
- Email: BurnsInc@Outlook.com
- Service Area: Southwest Florida (Punta Gorda, Port Charlotte, Charlotte Harbor)
