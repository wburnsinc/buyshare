# Integrations and Secrets — BuyShare.co

This document lists every external service, credential, and integration used by or planned for BuyShare.co.

---

## Currently Active Integrations

### 1. PostgreSQL Database
| Item | Detail |
|------|--------|
| **Purpose** | Primary application database — all tables, relationships, and data |
| **Provider** | Replit managed PostgreSQL (via `DATABASE_URL` secret) |
| **Env var** | `DATABASE_URL` |
| **Where to get** | Neon (neon.tech) · Supabase · Railway · Aiven · self-hosted |
| **Migration steps** | 1. Create new DB. 2. Run `psql "$DATABASE_URL" < schema.sql`. 3. Run `psql "$DATABASE_URL" < seed-data.sql` for existing data. 4. Run `pnpm --filter @workspace/db run push` to sync ORM. |
| **Rotation** | Update `DATABASE_URL` in env, restart server |
| **In ZIP** | ✅ Schema in `schema.sql`, data in `seed-data.sql`, ORM schema in `lib/db/src/schema/` |

### 2. Google Fonts (Inter)
| Item | Detail |
|------|--------|
| **Purpose** | Typography — Inter font family loaded via CDN in `index.html` |
| **Provider** | Google Fonts CDN (public, no API key) |
| **Env var** | None |
| **Migration steps** | No action needed. Works on any host. Optionally self-host via `fontsource` package. |
| **In ZIP** | ✅ Referenced in `artifacts/buyshare/index.html` |

### 3. Unsplash Images (runtime CDN references)
| Item | Detail |
|------|--------|
| **Purpose** | Placeholder images in ThriftGirl, Playdate, PoolShare, Rideshare pages |
| **Provider** | Unsplash CDN (public, no API key for direct image URLs) |
| **Env var** | None |
| **Migration steps** | No action needed for demo. Replace URLs with your own media for production. |
| **In ZIP** | ✅ URLs hardcoded in page components |

---

## Replit-Specific Dependencies (Must Replace on Migration)

### 4. @replit/vite-plugin-runtime-error-modal
| Item | Detail |
|------|--------|
| **Purpose** | Shows runtime errors as overlays during Replit dev |
| **Used in** | `artifacts/buyshare/vite.config.ts` |
| **Action** | Remove from `vite.config.ts` when deploying outside Replit. See `vite.config.portable.ts` |

### 5. @replit/vite-plugin-cartographer
| Item | Detail |
|------|--------|
| **Purpose** | Replit code navigation in dev only |
| **Used in** | `artifacts/buyshare/vite.config.ts` (dev only, guarded by `REPL_ID` check) |
| **Action** | Already guarded — only loads when `REPL_ID` is set. Automatically skipped outside Replit. |

### 6. @replit/vite-plugin-dev-banner
| Item | Detail |
|------|--------|
| **Purpose** | Replit dev banner in preview |
| **Used in** | `artifacts/buyshare/vite.config.ts` (dev only, guarded by `REPL_ID` check) |
| **Action** | Already guarded. Automatically skipped outside Replit. |

### 7. esbuild Platform Overrides (pnpm-workspace.yaml)
| Item | Detail |
|------|--------|
| **Purpose** | Reduces install size by only installing linux-x64 esbuild binaries (Replit is linux-x64) |
| **Action** | Remove the `overrides` block from `pnpm-workspace.yaml` when deploying on macOS, Windows, or ARM hosts. See `pnpm-workspace.portable.yaml` |

---

## Planned / Roadmap Integrations (Not Yet Active)

### Stripe — Payments
| Item | Detail |
|------|--------|
| **Purpose** | Accept card payments for bookings, SHARE™ rentals, ThriftGirl sales |
| **Env vars** | `STRIPE_SECRET_KEY`, `STRIPE_PUBLISHABLE_KEY`, `STRIPE_WEBHOOK_SECRET` |
| **Where to get** | stripe.com — create account, get API keys from dashboard |
| **Notes** | PocketCash payment UI exists in frontend; Stripe backend not yet wired |

### Twilio — BurnCall AI Phone System
| Item | Detail |
|------|--------|
| **Purpose** | AI-powered phone answering system for Blue Truck / SHARE™ calls |
| **Env vars** | `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_PHONE_NUMBER` |
| **Where to get** | twilio.com — create account, purchase a FL phone number |
| **Notes** | BurnCall frontend UI exists; Twilio/AI backend not yet wired |

### OpenAI — BurnCall AI
| Item | Detail |
|------|--------|
| **Purpose** | LLM for AI call answering and lead qualification |
| **Env vars** | `OPENAI_API_KEY` |
| **Where to get** | platform.openai.com |

### Email (SMTP / SendGrid / Postmark)
| Item | Detail |
|------|--------|
| **Purpose** | Booking confirmations, contractor notifications, password reset |
| **Env vars** | `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `FROM_EMAIL` |
| **Where to get** | SendGrid, Postmark, AWS SES, Resend |
| **Notes** | No email sending currently wired in backend |

### File / Media Storage (S3-compatible)
| Item | Detail |
|------|--------|
| **Purpose** | User uploads — profile photos, ThriftGirl listing images, contractor docs |
| **Env vars** | `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_S3_BUCKET`, `AWS_S3_REGION` |
| **Where to get** | AWS S3, Cloudflare R2, Backblaze B2, Supabase Storage |
| **Notes** | File upload not yet implemented in backend |

---

## Authentication Notes

BuyShare.co currently uses **localStorage-based role simulation** for the demo (not a real auth system). The `buyshare_role` and `buyshare_user` localStorage keys control which dashboard a user sees.

**To add real authentication for production**, implement one of:
- **Lucia Auth + Drizzle** — open-source, runs in your own server
- **Better Auth** — open-source auth framework
- **Clerk** — hosted auth service (clerk.com)
- **Supabase Auth** — if using Supabase as DB

The `usersTable` schema (`lib/db/src/schema/users.ts`) is already defined with email, role enum, and avatar fields — ready to connect to an auth system.

---

## Domain / DNS

No custom domain is configured in the project code. To add one:
1. Purchase domain (Namecheap, Cloudflare Registrar, etc.)
2. Point DNS A record to your host's IP
3. Configure your reverse proxy (Nginx / Caddy) or platform (Vercel / Railway) to serve the domain
4. Update any hardcoded contact URLs if present
