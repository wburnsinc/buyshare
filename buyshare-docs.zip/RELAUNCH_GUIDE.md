# BuyShare.co — Relaunch Guide

Step-by-step instructions to relaunch this application from scratch on any host.

---

## Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Node.js | 20+ (22 or 24 recommended) | nodejs.org or `nvm install 22` |
| pnpm | 9+ | `npm install -g pnpm` |
| PostgreSQL client | Any | `brew install postgresql` / `apt install postgresql-client` |
| Git | Any | git-scm.com |

---

## Step 1 — Import Source Code

### Option A: New Replit Account
1. Create a new Replit account at replit.com
2. Click **Create Repl** → **Import from ZIP**
3. Upload `buyshare-co-handover.zip`
4. Replit will detect it as a Node.js project

### Option B: Any Host (Railway, Render, VPS, etc.)
```bash
# Unzip the handover package
unzip buyshare-co-handover.zip
cd buyshare-co

# Initialize git (if not already)
git init
git add .
git commit -m "Initial import"
```

### Option C: GitHub → Deploy Platform
```bash
# Push to GitHub
git remote add origin https://github.com/YOUR_ORG/buyshare-co.git
git push -u origin main
# Then connect your deploy platform to this GitHub repo
```

---

## Step 2 — Install Dependencies

```bash
pnpm install
```

> **macOS/Windows/ARM note:** Before running `pnpm install`, remove or comment out the `overrides` block in `pnpm-workspace.yaml` that pins esbuild to linux-x64 only. Those overrides are Replit-specific and will break installation on other platforms. The file `pnpm-workspace.portable.yaml` contains the clean version — rename it to replace the original if needed.

---

## Step 3 — Create the Database

### Option A: Neon (recommended free tier)
1. Go to neon.tech → Create account → New project
2. Copy the connection string (looks like `postgresql://user:pass@ep-xxx.neon.tech/neondb?sslmode=require`)
3. Paste into `DATABASE_URL` in your `.env`

### Option B: Supabase
1. Go to supabase.com → New project
2. Settings → Database → Connection string (URI mode)
3. Paste into `DATABASE_URL`

### Option C: Railway
1. In your Railway project, add a PostgreSQL plugin
2. Copy `DATABASE_URL` from the plugin's variables tab

### Option D: Self-hosted
```bash
createdb buyshare
# DATABASE_URL=postgresql://localhost:5432/buyshare
```

---

## Step 4 — Configure Environment Variables

```bash
cp .env.example .env
```

Edit `.env` with your actual values:

```env
DATABASE_URL=postgresql://user:password@host:5432/buyshare
SESSION_SECRET=generate-with-openssl-rand-hex-32
PORT=8080
NODE_ENV=production
BASE_PATH=/
```

Generate a secure SESSION_SECRET:
```bash
openssl rand -hex 32
```

---

## Step 5 — Apply Database Schema and Import Data

### Apply schema (creates all tables):
```bash
pnpm --filter @workspace/db run push
```

### Import existing data (from the handover package):
```bash
psql "$DATABASE_URL" < seed-data.sql
```

### Or seed fresh demo data:
```bash
pnpm --filter @workspace/scripts run seed
```

### Verify the database:
```bash
psql "$DATABASE_URL" -c "\dt"
# Should list: users, services, bookings, contractors, messages, payments,
# reviews, share_listings, leads, growth_metrics, conversations,
# invoices, thriftgirl_listings, playdate_events, rideshare_trips,
# earntree_earnings, earntree_goals, audit_logs
```

---

## Step 6 — Fix Replit-Specific Dependencies (for non-Replit hosts)

### vite.config.ts — remove Replit plugins
The current `vite.config.ts` loads three Replit-only Vite plugins. They are already guarded to only load when `REPL_ID` is set, so they **automatically skip** on non-Replit hosts. However, the `@replit/vite-plugin-runtime-error-modal` import is unconditional.

**Quick fix** — replace `artifacts/buyshare/vite.config.ts` with the portable version included in this package:
```bash
cp artifacts/buyshare/vite.config.portable.ts artifacts/buyshare/vite.config.ts
```

### pnpm-workspace.yaml — remove linux-only esbuild overrides
```bash
cp pnpm-workspace.portable.yaml pnpm-workspace.yaml
pnpm install  # reinstall with cross-platform binaries
```

---

## Step 7 — Restore Uploaded Files and Media

The brand images (Blue Truck logo, SHARE logo, ChatGPT-generated images) are stored in `attached_assets/` and are included in the ZIP.

The `vite.config.ts` aliases `@assets` to `../../attached_assets/`. This works as-is if you keep the directory structure. If you move assets:
1. Update the `@assets` alias in `artifacts/buyshare/vite.config.ts`
2. Or copy `attached_assets/` to wherever your static file server serves from

For production user uploads (ThriftGirl listing images, profile photos): Set up S3-compatible storage (AWS S3, Cloudflare R2, Backblaze B2) and add the env vars listed in `.env.example`.

---

## Step 8 — Run Locally

**Terminal 1 — API server:**
```bash
PORT=8080 NODE_ENV=development pnpm --filter @workspace/api-server run dev
```

**Terminal 2 — Frontend:**
```bash
PORT=3000 BASE_PATH=/ pnpm --filter @workspace/buyshare run dev
```

Add the Vite dev proxy to `artifacts/buyshare/vite.config.ts` → `server` block:
```ts
proxy: {
  '/api': { target: 'http://localhost:8080', changeOrigin: true }
}
```

Open: **http://localhost:3000**

---

## Step 9 — Build for Production

```bash
# Frontend (output: artifacts/buyshare/dist/public/)
PORT=3000 BASE_PATH=/ pnpm --filter @workspace/buyshare run build

# Backend (output: artifacts/api-server/dist/index.mjs)
pnpm --filter @workspace/api-server run build
```

---

## Step 10 — Deploy

### Railway (recommended — easiest full-stack)
1. Push code to GitHub
2. Create new Railway project → **Deploy from GitHub repo**
3. Add service: **Web Service** pointing to `artifacts/api-server/`
4. Add service: **Static Site** pointing to `artifacts/buyshare/dist/public/`
5. Add **PostgreSQL** plugin
6. Set env vars: `DATABASE_URL` (from plugin), `SESSION_SECRET`, `PORT`, `NODE_ENV=production`
7. Set build commands:
   - API: `pnpm install && pnpm --filter @workspace/api-server run build`
   - Frontend: `PORT=3000 BASE_PATH=/ pnpm install && pnpm --filter @workspace/buyshare run build`

### Render
1. New **Web Service** → connect GitHub repo
2. Build command: `pnpm install && pnpm --filter @workspace/api-server run build`
3. Start command: `node artifacts/api-server/dist/index.mjs`
4. New **Static Site** → same repo
5. Build command: `PORT=3000 BASE_PATH=/ pnpm install && pnpm --filter @workspace/buyshare run build`
6. Publish dir: `artifacts/buyshare/dist/public`

### Vercel (frontend only + separate API)
1. Import repo to Vercel
2. Root directory: `artifacts/buyshare`
3. Build command: `BASE_PATH=/ vite build`
4. Output dir: `dist/public`
5. Deploy API separately to Railway/Render
6. Set `VITE_API_URL` env var pointing to API URL

### VPS with Nginx
```nginx
# /etc/nginx/sites-available/buyshare
server {
    listen 80;
    server_name buyshare.co www.buyshare.co;

    # Frontend — static files
    root /var/www/buyshare/dist/public;
    index index.html;
    try_files $uri $uri/ /index.html;  # SPA fallback

    # API — proxy to Express
    location /api/ {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Start the API with PM2:
```bash
npm install -g pm2
PORT=8080 pm2 start artifacts/api-server/dist/index.mjs --name buyshare-api
pm2 save && pm2 startup
```

---

## Step 11 — Connect a Custom Domain

1. Purchase domain at Namecheap, Cloudflare, or Google Domains
2. In your DNS provider, add:
   - `A record`: `@` → your server IP
   - `CNAME`: `www` → `@` or your platform's URL
3. In your hosting platform, add the custom domain
4. Enable HTTPS/SSL:
   - Railway/Render/Vercel: automatic
   - VPS: `certbot --nginx -d buyshare.co -d www.buyshare.co`
5. Update `index.html` meta tags with the real domain
6. Update any hardcoded `buyshare.co` references in source code

---

## Step 12 — Pre-Launch Testing Checklist

Test these critical paths after deployment:

```
[ ] GET /api/healthz → returns { status: "ok" }
[ ] Homepage loads at /
[ ] All nav links work (Blue Truck, SHARE, ThriftGirl, Playdate, Rideshare, EarnTree)
[ ] Services page lists services from DB
[ ] Book a service (POST /api/bookings) → booking appears in DB
[ ] Booking tracker shows real-time status
[ ] Contractor portal loads with jobs
[ ] Admin portal loads overview stats
[ ] BurnCall lead form submits (POST /api/burncall/leads)
[ ] Investor dashboard loads metrics
[ ] ThriftGirl listings display
[ ] SHARE™ listings display
[ ] EarnTree earnings summary loads
[ ] Dark mode toggle works
[ ] Mobile nav works on 375px viewport
[ ] 404 page works (visit /nonexistent-route)
```

---

## Step 13 — Backup and Restore

### Backup (run on a schedule via cron):
```bash
# Full backup (schema + data)
pg_dump "$DATABASE_URL" --no-owner --no-acl > backup-$(date +%Y%m%d-%H%M%S).sql

# Compressed backup
pg_dump "$DATABASE_URL" --no-owner --no-acl | gzip > backup-$(date +%Y%m%d).sql.gz
```

### Restore:
```bash
psql "$DATABASE_URL" < backup-20260626.sql
# or
gunzip -c backup-20260626.sql.gz | psql "$DATABASE_URL"
```

### Automated backups:
- **Railway**: Enable automatic daily backups in the PostgreSQL plugin settings
- **Neon**: Enable branching + Point-in-time restore (free tier supports 7 days)
- **Supabase**: Daily backups included on Pro plan

---

## Troubleshooting

| Error | Fix |
|-------|-----|
| `PORT environment variable is required` | Set `PORT` in your `.env` or shell |
| `DATABASE_URL` connection refused | Check DB is running and URL is correct |
| `Cannot find module '@workspace/db'` | Run `pnpm install` first |
| Vite build fails: missing `BASE_PATH` | Set `BASE_PATH=/` in env |
| esbuild platform error | Remove linux-only overrides from `pnpm-workspace.yaml` |
| Frontend shows blank page | Check browser console; confirm `/api/healthz` returns 200 |
| CORS errors | Ensure API server has `cors()` middleware (it does by default) |
| Drizzle schema mismatch | Run `pnpm --filter @workspace/db run push` to sync |
