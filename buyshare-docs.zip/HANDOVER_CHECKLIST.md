# BuyShare.co — Handover & Migration Checklist

**Prepared:** June 26, 2026  
**Platform:** Replit → Any host  
**Prepared by:** BuyShare.co development session

---

## Section 1 — Application Layer Inventory

### 1A. Frontend / Client-Side Application

| Item | Status |
|------|--------|
| **Location** | `artifacts/buyshare/` |
| **Framework** | React 19 + Vite 7 + TypeScript |
| **Entry point** | `artifacts/buyshare/index.html` → `src/main.tsx` → `src/App.tsx` |
| **Router** | Wouter 3 (`src/App.tsx` — Switch/Route) |
| **Start (dev)** | `PORT=3000 BASE_PATH=/ pnpm --filter @workspace/buyshare run dev` |
| **Build** | `PORT=3000 BASE_PATH=/ pnpm --filter @workspace/buyshare run build` |
| **Build output** | `artifacts/buyshare/dist/public/` (static HTML/JS/CSS) |
| **Dependencies** | React, Vite, Tailwind CSS v4, shadcn/ui, Radix UI, Wouter, TanStack Query, Framer Motion, Recharts, Lucide React |
| **Env vars required** | `PORT` (dev server), `BASE_PATH` (Vite base URL) |
| **Included in ZIP** | ✅ Yes — all source files |
| **Post-migration test** | Visit `/`, confirm homepage renders; check browser console for 0 errors |

**Pages included:**

| Page | Route | Status |
|------|-------|--------|
| Home | `/` | ✅ |
| Find Services | `/services` | ✅ |
| Blue Truck LLC | `/blue-truck` | ✅ |
| SHARE™ Marketplace | `/share` | ✅ |
| PoolShare™ | `/poolshare` | ✅ |
| ThriftGirl™ | `/thriftgirl` | ✅ |
| Playdate™ | `/playdate` | ✅ |
| RideShare™ | `/rideshare` | ✅ |
| EarnTree™ | `/earntree` | ✅ |
| Find Contractors | `/contractors` | ✅ |
| Join as Contractor | `/contractors/join` | ✅ |
| Contractor Portal | `/contractor/portal` | ✅ |
| Customer Dashboard | `/dashboard` | ✅ |
| My Bookings | `/dashboard/bookings` | ✅ |
| Messages | `/dashboard/messages` | ✅ |
| Payments / PocketCash | `/dashboard/payments` | ✅ |
| Booking Tracker | `/dashboard/tracker` | ✅ |
| BurnCall™ AI System | `/burncall` | ✅ |
| Investor Portal | `/investor` | ✅ |
| Admin Portal | `/admin` | ✅ |
| Sign Up | `/sign-up` | ✅ |
| Sign In | `/sign-in` | ✅ |
| Help Center | `/help` | ✅ |
| About Us | `/about` | ✅ |
| Settings | `/settings` | ✅ |
| Legal (Privacy/Terms/etc.) | `/legal/:page` | ✅ |
| 404 Not Found | `*` | ✅ |

---

### 1B. Backend / Server-Side Application

| Item | Status |
|------|--------|
| **Location** | `artifacts/api-server/` |
| **Framework** | Express 5 + TypeScript (ESM) |
| **Entry point** | `artifacts/api-server/src/index.ts` |
| **Start (dev)** | `PORT=8080 pnpm --filter @workspace/api-server run dev` |
| **Build** | `pnpm --filter @workspace/api-server run build` |
| **Build output** | `artifacts/api-server/dist/index.mjs` |
| **Start (prod)** | `PORT=8080 NODE_ENV=production node artifacts/api-server/dist/index.mjs` |
| **Dependencies** | Express 5, Drizzle ORM, pg, pino, pino-http, cors, cookie-parser |
| **Env vars required** | `PORT`, `DATABASE_URL` |
| **Included in ZIP** | ✅ Yes — all route files and config |
| **Post-migration test** | `curl http://localhost:8080/api/healthz` → `{ "status": "ok" }` |

**API Routes included:**

| Route file | Endpoints | Purpose |
|-----------|-----------|---------|
| `health.ts` | `GET /api/healthz` | Health check |
| `dashboard.ts` | `GET /api/dashboard/summary` | Dashboard stats |
| `services.ts` | `GET /api/services`, `POST /api/services` | Service catalog |
| `bookings.ts` | `GET/POST /api/bookings`, `GET/PATCH /api/bookings/:id` | Booking management |
| `contractors.ts` | `GET/POST /api/contractors`, `PATCH /api/contractors/:id` | Contractor directory |
| `users.ts` | `GET/POST/PATCH /api/users` | User management |
| `messages.ts` | `GET/POST /api/messages`, `GET /api/conversations` | Messaging |
| `payments.ts` | `GET/POST /api/payments` | Payment records |
| `reviews.ts` | `GET/POST /api/reviews` | Contractor reviews |
| `share.ts` | `GET/POST /api/share/listings`, stats, reviews | SHARE™ platform |
| `burncall.ts` | `GET/POST /api/burncall/leads`, stats | BurnCall lead system |
| `investor.ts` | `GET /api/investor/metrics`, milestones | Investor portal |
| `thriftgirl.ts` | `GET/POST /api/thriftgirl/listings`, stats | ThriftGirl marketplace |
| `playdate.ts` | `GET/POST /api/playdate/events`, RSVP, stats | Playdate platform |
| `rideshare.ts` | `GET/POST /api/rideshare/trips`, status update, stats | RideShare platform |
| `earntree.ts` | `GET /api/earntree/earnings`, summary, goals, referral | EarnTree earnings |
| `admin.ts` | `GET /api/admin/overview`, bookings, contractors, payments, leads, audit logs, PATCH status | Admin portal |

---

### 1C. API / Service Layer

| Item | Status |
|------|--------|
| **Location** | `lib/api-spec/` (OpenAPI spec), `lib/api-client-react/` (generated hooks), `lib/api-zod/` (generated schemas) |
| **Purpose** | Contract-first API: spec drives code generation for both client hooks and server validation |
| **Codegen command** | `pnpm --filter @workspace/api-spec run codegen` |
| **Included in ZIP** | ✅ Yes — spec and generated files included |
| **Post-migration note** | If you add new routes, update the OpenAPI spec and re-run codegen |

---

### 1D. Database / Data Layer

| Item | Status |
|------|--------|
| **Location** | `lib/db/` |
| **ORM** | Drizzle ORM 0.45 |
| **Database** | PostgreSQL 14+ |
| **Schema files** | `lib/db/src/schema/` (15 schema files, 18+ tables) |
| **Migrations** | Schema pushed via `drizzle-kit push` (no migration files — push-based) |
| **Env vars** | `DATABASE_URL` |
| **Included in ZIP** | ✅ Schema source + `schema.sql` export + `seed-data.sql` |

**Tables:**

| Table | Purpose |
|-------|---------|
| `users` | User accounts with role enum |
| `services` | Service catalog (Lawn, Pool, HVAC, etc.) |
| `bookings` | All service bookings with status tracking |
| `contractors` | Contractor profiles and verification |
| `messages` | Platform messaging |
| `conversations` | Message threads |
| `payments` | Payment records |
| `invoices` | Invoice records |
| `reviews` | Contractor reviews |
| `share_listings` | SHARE™ asset listings (pools, boats, etc.) |
| `leads` | BurnCall AI phone leads |
| `growth_metrics` | Investor dashboard metrics |
| `thriftgirl_listings` | ThriftGirl marketplace items |
| `playdate_events` | Playdate/kids activity events |
| `rideshare_trips` | Rideshare trip records |
| `earntree_earnings` | EarnTree passive income tracking |
| `earntree_goals` | User income goals |
| `audit_logs` | Admin action audit trail |

---

### 1E. Background Workers / Scheduled Jobs / Cron

| Item | Status |
|------|--------|
| **Active background jobs** | ❌ None currently implemented |
| **Planned** | Booking reminder emails, contractor payout processing, BurnCall AI call handling |
| **In ZIP** | N/A — no workers to export |
| **Post-migration note** | When implementing: use node-cron, Bull/BullMQ, or platform-level cron (Railway, Render, Heroku Scheduler) |

---

### 1F. Third-Party Hosted / External Integrations

| Service | Active? | Purpose | Action Required |
|---------|---------|---------|-----------------|
| Google Fonts CDN | ✅ Active | Inter font family | None — public CDN, no key needed |
| Unsplash CDN | ✅ Active | Placeholder images | None — public URLs, no key |
| Replit Vite plugins | ✅ Active (dev only) | Dev overlay, code nav | Remove on non-Replit hosts (see portable config) |
| Stripe | ❌ Planned | Payments | Set up account, add env vars |
| Twilio | ❌ Planned | BurnCall phone system | Set up account, buy FL number |
| OpenAI | ❌ Planned | BurnCall AI | Set up account, add API key |
| SMTP/Email | ❌ Planned | Notifications | Set up SendGrid/Postmark |
| S3/Storage | ❌ Planned | File uploads | Set up S3/R2/B2 bucket |

---

## Section 2 — Data Export Status

| Data Source | Export Method | Included | Notes |
|-------------|--------------|----------|-------|
| PostgreSQL schema | `pg_dump --schema-only` | ✅ `schema.sql` | Full DDL |
| PostgreSQL data | `pg_dump --data-only --inserts` | ✅ `seed-data.sql` | All current rows |
| Brand logos | File copy | ✅ `attached_assets/` | PNG/JPG included |
| User-uploaded images | N/A | ✅ | No user uploads yet — all placeholder URLs |
| Replit object storage | N/A | N/A | Not used by this app |
| Replit KV database | N/A | N/A | Not used by this app |
| Session data | N/A | N/A | localStorage-only (no server sessions) |

---

## Section 3 — Functionality Coverage

| Feature | Implemented | Location | Post-Migration Notes |
|---------|-------------|----------|---------------------|
| Public website — all pages | ✅ | `artifacts/buyshare/src/pages/` | Static SPA, no special config |
| Admin dashboard | ✅ | `/admin` page + `/api/admin/*` routes | Role-based via localStorage |
| User registration | ⚠️ Demo only | `SignUp.tsx` (localStorage) | **Needs real auth for production** |
| User login | ⚠️ Demo only | `SignIn.tsx` (localStorage) | **Needs real auth for production** |
| Role-based access | ⚠️ Demo only | Layout.tsx role switcher | **Needs real middleware for production** |
| Password reset | ❌ Not implemented | — | Requires email integration |
| Every API endpoint (17 route files) | ✅ | `artifacts/api-server/src/routes/` | All included |
| Database reads and writes | ✅ | All routes via Drizzle ORM | Requires `DATABASE_URL` |
| Forms and submissions | ✅ | Bookings, BurnCall, ThriftGirl, Playdate, etc. | POST to `/api/*` |
| Email sending | ❌ Not implemented | — | Wire up SMTP when ready |
| Payments / Stripe | ❌ Not implemented | PocketCash UI exists | Wire up Stripe backend |
| File uploads | ❌ Not implemented | — | Wire up S3 storage |
| Webhooks | ❌ Not implemented | — | Add when integrations are wired |
| Scheduled tasks | ❌ Not implemented | — | Add node-cron when needed |
| CORS | ✅ | `app.ts` (`cors()` middleware) | Configured globally |
| Request logging | ✅ | `pino-http` | Structured JSON logs |
| Error handling | ✅ | All routes have try/catch + 500 response | |
| Rate limiting | ❌ Not implemented | — | Add `express-rate-limit` for production |
| HTTPS / TLS | ⚠️ Platform-level | — | Handled by Nginx/Caddy/platform, not app code |
| Health check endpoint | ✅ | `GET /api/healthz` | Use for uptime monitoring |

---

## Section 4 — Items NOT Included in ZIP

The following cannot be included in the project ZIP and require separate action:

| Item | Reason | Action Required |
|------|--------|-----------------|
| `DATABASE_URL` value | Secret credential | Create new PostgreSQL database, get new connection string |
| `SESSION_SECRET` value | Secret | Generate new one: `openssl rand -hex 32` |
| Live PostgreSQL database rows | Sensitive / hosted externally | Use `seed-data.sql` to restore, or `pg_dump` from Replit before migration |
| Replit `.replit` / `replit.nix` configs | Replit-platform-specific | Not needed outside Replit |
| Replit workflow/deployment config | Replit-platform-specific | Set up your own workflow on target platform |
| Stripe account & keys | Third-party account | Create new account at stripe.com |
| Twilio account & phone number | Third-party account | Create new account at twilio.com |
| Domain DNS records | Registrar-level | Configure with your registrar after migration |

---

## Section 5 — Final Verification Report

### Can the app start from a clean environment using only the handover package?
**✅ YES** — with the following prerequisites:
1. Node.js 20+ and pnpm installed
2. A PostgreSQL database provisioned
3. `.env` file filled from `.env.example`
4. `pnpm install` run
5. `pnpm --filter @workspace/db run push` run

### All frontend pages identified and included?
✅ 27 pages documented above, all source files in ZIP

### All backend API routes identified and included?
✅ 17 route files, 50+ endpoints documented above

### All databases identified and exported?
✅ PostgreSQL — `schema.sql` (DDL) + `seed-data.sql` (data) included

### All secrets listed by name in `.env.example`?
✅ Yes — `DATABASE_URL`, `SESSION_SECRET`, `PORT`, `NODE_ENV`, `BASE_PATH`, plus all planned integration keys

### All integrations documented?
✅ Yes — `INTEGRATIONS_AND_SECRETS.md` covers all current and planned integrations

### Known limitations and risks:
| Risk | Severity | Mitigation |
|------|----------|------------|
| Authentication is demo-only (localStorage) | 🔴 High | Implement Lucia Auth, Better Auth, or Clerk before going live with real users |
| No email notifications | 🟡 Medium | Add SMTP/SendGrid when booking confirmations are needed |
| No payment processing | 🟡 Medium | Wire Stripe when real bookings need payment |
| No file uploads | 🟡 Medium | Add S3 storage for ThriftGirl images and contractor docs |
| No rate limiting | 🟡 Medium | Add `express-rate-limit` before launch |
| esbuild overrides are linux-only | 🟡 Medium | Remove overrides from `pnpm-workspace.yaml` on non-linux hosts |

### Can a new owner relaunch without depending on this Replit workspace?
**✅ YES** — following `RELAUNCH_GUIDE.md` and using the files in this package, the app is fully self-contained.

---

## Handover Package File List

```
buyshare-co-handover.zip
├── README.md                          ← Framework, setup, commands
├── .env.example                       ← All required env var names
├── INTEGRATIONS_AND_SECRETS.md        ← Every service and credential
├── RELAUNCH_GUIDE.md                  ← Step-by-step relaunch instructions
├── HANDOVER_CHECKLIST.md              ← This file — full verification report
├── schema.sql                         ← PostgreSQL DDL (all tables)
├── seed-data.sql                      ← Current database rows (INSERT statements)
├── pnpm-workspace.yaml                ← Workspace config (Replit version)
├── pnpm-workspace.portable.yaml       ← Workspace config (cross-platform)
├── package.json                       ← Root scripts
├── pnpm-lock.yaml                     ← Exact dependency versions
├── tsconfig.base.json                 ← Shared TypeScript config
├── artifacts/
│   ├── buyshare/                      ← Frontend (React/Vite)
│   │   ├── index.html                 ← HTML entry point ✅
│   │   ├── vite.config.ts             ← Vite config (Replit version)
│   │   ├── vite.config.portable.ts    ← Vite config (portable, no Replit plugins)
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── components.json            ← shadcn/ui config
│   │   └── src/
│   │       ├── App.tsx                ← Router + providers
│   │       ├── main.tsx               ← React entry point
│   │       ├── index.css              ← Tailwind + globals
│   │       ├── pages/                 ← 27 page components
│   │       ├── components/            ← Layout + 50+ shadcn/ui components
│   │       ├── hooks/                 ← use-toast, use-mobile
│   │       └── lib/                   ← utils
│   └── api-server/                    ← Backend (Express 5)
│       ├── package.json
│       ├── tsconfig.json
│       ├── build.mjs                  ← esbuild build script
│       └── src/
│           ├── index.ts               ← Server entry point
│           ├── app.ts                 ← Express app config
│           ├── lib/logger.ts          ← Pino logger
│           └── routes/                ← 17 API route files
├── lib/
│   ├── db/                            ← Drizzle ORM + schema
│   │   ├── src/schema/                ← 15 schema files
│   │   ├── drizzle.config.ts
│   │   └── package.json
│   ├── api-spec/                      ← OpenAPI spec
│   ├── api-client-react/              ← Generated React Query hooks
│   └── api-zod/                       ← Generated Zod schemas
├── scripts/
│   └── src/seed.ts                    ← Database seed script
└── attached_assets/                   ← Brand logos and images
    ├── Blue_Truck_LOGO_*.PNG
    ├── SHARE_LOGO_*.png
    └── *.png (other brand images)
```
