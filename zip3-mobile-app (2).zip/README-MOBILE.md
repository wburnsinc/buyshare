# Buyshare.co — Mobile App (SHARE Mobile)

## Stack
- Expo (React Native)
- TypeScript
- Expo Router

## Install & Run
```bash
cd artifacts/buyshare-mobile
pnpm install
pnpm run dev  # starts Expo dev server (scan QR with Expo Go)
```

## Production Build
```bash
eas build --platform ios    # iOS
eas build --platform android # Android
```

## Key Config
- Update API base URL in the app to point to production API
- Update app.json with your bundle identifier and app name
