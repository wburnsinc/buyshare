import { Feather } from "@expo/vector-icons";
import { useGetBooking } from "@workspace/api-client-react";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useRef } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";

function fmt(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

function fmtDate(d: string) {
  return new Date(d).toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export default function BookingConfirmScreen() {
  const { bookingId, status } = useLocalSearchParams<{ bookingId: string; status: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { token } = useAuth();
  const cancelledRef = useRef(false);

  const { data: booking, isLoading, isError } = useGetBooking(bookingId ?? "");

  const cancelled = status === "cancel";

  useEffect(() => {
    if (!cancelled || !bookingId || cancelledRef.current) return;
    cancelledRef.current = true;
    const baseUrl = process.env.EXPO_PUBLIC_DOMAIN
      ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
      : "";
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (token) headers["Authorization"] = `Bearer ${token}`;
    fetch(`${baseUrl}/api/bookings/${bookingId}/cancel`, { method: "POST", headers }).catch(() => {});
  }, [cancelled, bookingId, token]);

  if (isLoading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (isError || !booking) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Feather name="alert-circle" size={36} color={colors.mutedForeground} />
        <Text style={[styles.errorText, { color: colors.mutedForeground }]}>
          Booking not found.
        </Text>
        <Pressable
          onPress={() => router.replace("/(tabs)")}
          style={[styles.primaryBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
        >
          <Text style={[styles.primaryBtnText, { color: colors.primaryForeground }]}>
            Go to Home
          </Text>
        </Pressable>
      </View>
    );
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 32, paddingTop: insets.top + 24 }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.iconWrap}>
        {cancelled ? (
          <View style={[styles.iconCircle, { backgroundColor: "#ef444418" }]}>
            <Feather name="x-circle" size={40} color="#ef4444" />
          </View>
        ) : (
          <View style={[styles.iconCircle, { backgroundColor: colors.primary + "18" }]}>
            <Feather name="check-circle" size={40} color={colors.primary} />
          </View>
        )}
        <Text style={[styles.headline, { color: colors.foreground }]}>
          {cancelled ? "Payment Cancelled" : "Booking Submitted!"}
        </Text>
        <Text style={[styles.subline, { color: colors.mutedForeground }]}>
          {cancelled
            ? "Your payment was not completed. No charges were made."
            : "Your booking is pending confirmation from the owner. You'll be notified once it's approved."}
        </Text>
      </View>

      {!cancelled && (
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>
            {booking.listing?.title ?? "Listing"}
          </Text>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Feather name="calendar" size={15} color={colors.mutedForeground} />
              <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>Dates</Text>
            </View>
            <Text style={[styles.rowValue, { color: colors.foreground }]}>
              {fmtDate(booking.startDate)} – {fmtDate(booking.endDate)}
            </Text>
          </View>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Feather name="clock" size={15} color={colors.mutedForeground} />
              <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>Duration</Text>
            </View>
            <Text style={[styles.rowValue, { color: colors.foreground }]}>
              {booking.totalDays} {booking.totalDays === 1 ? "day" : "days"}
            </Text>
          </View>

          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Feather name="tag" size={15} color={colors.mutedForeground} />
              <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>Rental</Text>
            </View>
            <Text style={[styles.rowValue, { color: colors.foreground }]}>
              {fmt(booking.rentalAmountCents)}
            </Text>
          </View>

          {booking.securityDepositCents > 0 && (
            <View style={styles.row}>
              <View style={styles.rowLeft}>
                <Feather name="shield" size={15} color={colors.mutedForeground} />
                <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>Deposit</Text>
              </View>
              <Text style={[styles.rowValue, { color: colors.foreground }]}>
                {fmt(booking.securityDepositCents)}
              </Text>
            </View>
          )}

          {(booking.protectionFeeCents ?? 0) > 0 && (
            <View style={styles.row}>
              <View style={styles.rowLeft}>
                <Feather name="umbrella" size={15} color={colors.mutedForeground} />
                <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>Protection</Text>
              </View>
              <Text style={[styles.rowValue, { color: colors.foreground }]}>
                {fmt(booking.protectionFeeCents ?? 0)}
              </Text>
            </View>
          )}

          {(booking.deliveryFeeCents ?? 0) > 0 && (
            <View style={styles.row}>
              <View style={styles.rowLeft}>
                <Feather name="truck" size={15} color={colors.mutedForeground} />
                <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>Delivery</Text>
              </View>
              <Text style={[styles.rowValue, { color: colors.foreground }]}>
                {fmt(booking.deliveryFeeCents ?? 0)}
              </Text>
            </View>
          )}

          {(booking.stripeFeesCents ?? 0) > 0 && (
            <View style={styles.row}>
              <View style={styles.rowLeft}>
                <Feather name="percent" size={15} color={colors.mutedForeground} />
                <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>Processing</Text>
              </View>
              <Text style={[styles.rowValue, { color: colors.foreground }]}>
                {fmt(booking.stripeFeesCents ?? 0)}
              </Text>
            </View>
          )}

          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Text style={[styles.totalLabel, { color: colors.foreground }]}>Total charged</Text>
            </View>
            <Text style={[styles.totalValue, { color: colors.primary }]}>
              {fmt(booking.totalChargeCents)}
            </Text>
          </View>

          <View style={[styles.statusPill, { backgroundColor: "#f59e0b18" }]}>
            <Feather name="clock" size={13} color="#f59e0b" />
            <Text style={[styles.statusText, { color: "#f59e0b" }]}>
              Pending owner confirmation
            </Text>
          </View>
        </View>
      )}

      <View style={styles.actions}>
        <Pressable
          onPress={() => router.replace("/(tabs)")}
          style={[styles.primaryBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
        >
          <Text style={[styles.primaryBtnText, { color: colors.primaryForeground }]}>
            Back to Browse
          </Text>
        </Pressable>

        <Pressable
          onPress={() => router.replace("/(tabs)/profile" as any)}
          style={[styles.outlineBtn, { borderColor: colors.border, borderRadius: colors.radius }]}
        >
          <Text style={[styles.outlineBtnText, { color: colors.foreground }]}>
            View My Bookings
          </Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
    padding: 24,
  },
  scroll: {
    paddingHorizontal: 20,
    gap: 24,
  },
  iconWrap: {
    alignItems: "center",
    gap: 12,
    paddingVertical: 8,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  headline: {
    fontSize: 24,
    fontWeight: "700",
    textAlign: "center",
  },
  subline: {
    fontSize: 14,
    lineHeight: 21,
    textAlign: "center",
  },
  card: {
    borderWidth: 1,
    padding: 16,
    gap: 12,
  },
  cardTitle: {
    fontSize: 17,
    fontWeight: "700",
    marginBottom: 2,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  rowLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  rowLabel: {
    fontSize: 14,
  },
  rowValue: {
    fontSize: 14,
    fontWeight: "500",
  },
  divider: {
    height: 1,
    marginVertical: 2,
  },
  totalLabel: {
    fontSize: 15,
    fontWeight: "700",
  },
  totalValue: {
    fontSize: 18,
    fontWeight: "700",
  },
  statusPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 8,
    marginTop: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: "600",
  },
  actions: {
    gap: 12,
  },
  primaryBtn: {
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  primaryBtnText: {
    fontSize: 16,
    fontWeight: "700",
  },
  outlineBtn: {
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
  outlineBtnText: {
    fontSize: 15,
    fontWeight: "600",
  },
  errorText: {
    fontSize: 16,
    textAlign: "center",
  },
});
