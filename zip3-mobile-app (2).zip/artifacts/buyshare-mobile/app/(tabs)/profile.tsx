import { Feather } from "@expo/vector-icons";
import { useGetUserBookings } from "@workspace/api-client-react";
import { File } from "expo-file-system";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { fetch as expoFetch } from "expo/fetch";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Animated,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth, type RegisterParams } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";

function formatDate(dateStr: string) {
  try {
    return new Date(dateStr).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  } catch {
    return dateStr;
  }
}

function formatCents(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

const STATUS_COLORS: Record<string, string> = {
  pending: "#f59e0b",
  confirmed: "#0e7490",
  active: "#059669",
  completed: "#6b7280",
  cancelled: "#ef4444",
  disputed: "#dc2626",
};

function BookingCard({ booking, colors }: { booking: any; colors: any }) {
  const statusColor = STATUS_COLORS[booking.status] ?? colors.mutedForeground;
  const title = booking.listing?.title ?? `Booking #${booking.id.slice(-6)}`;

  return (
    <View
      style={[
        styles.bookingCard,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
        },
      ]}
    >
      <View style={styles.bookingHeader}>
        <Text style={[styles.bookingTitle, { color: colors.foreground }]} numberOfLines={1}>
          {title}
        </Text>
        <View style={[styles.statusBadge, { backgroundColor: statusColor + "20" }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>
            {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
          </Text>
        </View>
      </View>
      <View style={styles.bookingMeta}>
        <Feather name="calendar" size={13} color={colors.mutedForeground} />
        <Text style={[styles.bookingDates, { color: colors.mutedForeground }]}>
          {formatDate(booking.startDate)} – {formatDate(booking.endDate)}
        </Text>
      </View>
      <Text style={[styles.bookingAmount, { color: colors.foreground }]}>
        {formatCents(booking.totalChargeCents)} total · {booking.totalDays}{" "}
        {booking.totalDays === 1 ? "day" : "days"}
      </Text>
    </View>
  );
}

function BookingsSection({ userId, colors }: { userId: string; colors: any }) {
  const { data: bookings, isLoading, error } = useGetUserBookings(userId);

  if (isLoading) {
    return (
      <View style={styles.centeredState}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centeredState}>
        <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
          Could not load bookings.
        </Text>
      </View>
    );
  }

  if (!bookings || bookings.length === 0) {
    return (
      <View style={styles.centeredState}>
        <Feather name="calendar" size={36} color={colors.mutedForeground} style={{ marginBottom: 10 }} />
        <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
          No bookings yet.
        </Text>
        <Text style={[styles.emptySubText, { color: colors.mutedForeground }]}>
          When you book or rent out a listing, it will appear here.
        </Text>
      </View>
    );
  }

  const active = bookings.filter((b: any) =>
    ["pending", "confirmed", "active"].includes(b.status)
  );
  const past = bookings.filter((b: any) =>
    ["completed", "cancelled", "disputed"].includes(b.status)
  );

  return (
    <View style={{ gap: 8 }}>
      {active.length > 0 && (
        <>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ACTIVE</Text>
          {active.map((b: any) => (
            <BookingCard key={b.id} booking={b} colors={colors} />
          ))}
        </>
      )}
      {past.length > 0 && (
        <>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: active.length > 0 ? 12 : 0 }]}>PAST</Text>
          {past.map((b: any) => (
            <BookingCard key={b.id} booking={b} colors={colors} />
          ))}
        </>
      )}
    </View>
  );
}

interface ProProfile {
  id: string;
  business_name: string;
  description: string | null;
  photo_url: string | null;
  website: string | null;
  phone: string | null;
  location: string | null;
}

interface EditProModalProps {
  visible: boolean;
  pro: ProProfile;
  token: string;
  colors: any;
  insets: { bottom: number };
  onClose: () => void;
  onSaved: (updated: ProProfile) => void;
}

function EditProModal({ visible, pro, token, colors, insets, onClose, onSaved }: EditProModalProps) {
  const [bio, setBio] = useState(pro.description ?? "");
  const [photoUrl, setPhotoUrl] = useState(pro.photo_url ?? "");
  const [website, setWebsite] = useState(pro.website ?? "");
  const [phone, setPhone] = useState(pro.phone ?? "");
  const [location, setLocation] = useState(pro.location ?? "");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [localPhotoUri, setLocalPhotoUri] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const slideAnim = useRef(new Animated.Value(600)).current;

  const pickPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Please allow photo library access to upload a profile photo.");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (result.canceled || !result.assets?.[0]) return;

    const asset = result.assets[0];
    setLocalPhotoUri(asset.uri);
    setUploading(true);

    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      const base = domain ? `https://${domain}` : "";

      const metaRes = await fetch(`${base}/api/storage/uploads/request-url`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: asset.fileName ?? "profile-photo.jpg",
          size: asset.fileSize ?? 0,
          contentType: asset.mimeType ?? "image/jpeg",
        }),
      });

      if (!metaRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL, objectPath } = await metaRes.json();

      const mimeType = asset.mimeType ?? "image/jpeg";
      const file = new File(asset.uri);
      const uploadRes = await expoFetch(uploadURL, {
        method: "PUT",
        headers: { "Content-Type": mimeType },
        body: file,
      });

      if (!uploadRes.ok) {
        throw new Error(`Upload failed (${uploadRes.status})`);
      }

      const servingUrl = `${base}/api/storage${objectPath}`;
      setPhotoUrl(servingUrl);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err: any) {
      setLocalPhotoUri(null);
      Alert.alert("Upload failed", err?.message ?? "Could not upload photo. Please try again.");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setUploading(false);
    }
  };

  useEffect(() => {
    if (visible) {
      setBio(pro.description ?? "");
      setPhotoUrl(pro.photo_url ?? "");
      setWebsite(pro.website ?? "");
      setPhone(pro.phone ?? "");
      setLocation(pro.location ?? "");
      setLocalPhotoUri(null);
      setError(null);
      setSaved(false);
      Animated.spring(slideAnim, {
        toValue: 0,
        useNativeDriver: true,
        tension: 65,
        friction: 11,
      }).start();
    } else {
      slideAnim.setValue(600);
    }
  }, [visible]);

  const handleClose = () => {
    Animated.timing(slideAnim, {
      toValue: 600,
      duration: 220,
      useNativeDriver: true,
    }).start(() => onClose());
  };

  const handleSave = async () => {
    setError(null);
    setSaving(true);
    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      const base = domain ? `https://${domain}` : "";
      const res = await fetch(`${base}/api/vetted-pros/${pro.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          bio: bio.trim() || undefined,
          photo_url: photoUrl.trim() || undefined,
          website: website.trim() || undefined,
          phone: phone.trim() || undefined,
          location: location.trim() || undefined,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data?.error ?? `Save failed (${res.status})`);
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onSaved(data.pro ?? { ...pro, description: bio.trim() || pro.description, photo_url: photoUrl.trim() || pro.photo_url, website: website.trim() || pro.website, phone: phone.trim() || pro.phone, location: location.trim() || pro.location });
      setSaved(true);
    } catch (err: any) {
      setError(err?.message ?? "Something went wrong.");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setSaving(false);
    }
  };

  const inputStyle = [
    styles.input,
    {
      backgroundColor: colors.card,
      borderColor: colors.border,
      borderRadius: colors.radius,
      color: colors.foreground,
    },
  ];

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      onRequestClose={handleClose}
      statusBarTranslucent
    >
      <Pressable style={styles.modalOverlay} onPress={handleClose}>
        <Animated.View
          style={[
            styles.sheet,
            {
              backgroundColor: colors.background,
              borderTopLeftRadius: 20,
              borderTopRightRadius: 20,
              paddingBottom: Math.max(insets.bottom, 16) + 8,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <Pressable onPress={() => {}}>
            <View style={styles.sheetHandle} />
            <View style={[styles.sheetHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.sheetTitle, { color: colors.foreground }]}>
                {saved ? "Profile saved!" : "Edit my profile"}
              </Text>
              <Pressable onPress={handleClose} hitSlop={12}>
                <Feather name="x" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>

            {saved ? (
              <View style={[styles.successBody, { paddingBottom: Math.max(insets.bottom, 16) + 8 }]}>
                <View style={[styles.successIconWrap, { backgroundColor: "#059669" + "18" }]}>
                  <Feather name="check-circle" size={44} color="#059669" />
                </View>
                <Text style={[styles.successTitle, { color: colors.foreground }]}>
                  Your profile is live
                </Text>
                <Text style={[styles.successSubtitle, { color: colors.mutedForeground }]}>
                  Your changes are published and visible to everyone on the platform.
                </Text>
                <Pressable
                  onPress={async () => {
                    const domain = process.env.EXPO_PUBLIC_DOMAIN;
                    const url = domain
                      ? `https://${domain}/pro/${pro.id}`
                      : null;
                    if (!url) {
                      Alert.alert("Unavailable", "Could not determine the profile URL. Please try again later.");
                      return;
                    }
                    const canOpen = await Linking.canOpenURL(url).catch(() => false);
                    if (canOpen) {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      Linking.openURL(url);
                    } else {
                      Alert.alert("Unavailable", "Could not open the profile page. Please try again.");
                    }
                  }}
                  style={({ pressed }) => [
                    styles.viewProfileBtn,
                    {
                      backgroundColor: colors.primary,
                      borderRadius: colors.radius,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Feather name="external-link" size={16} color="#fff" />
                  <Text style={styles.viewProfileBtnText}>View my public profile</Text>
                </Pressable>
                <Pressable
                  onPress={handleClose}
                  style={({ pressed }) => [
                    styles.doneBtn,
                    {
                      borderColor: colors.border,
                      borderRadius: colors.radius,
                      opacity: pressed ? 0.7 : 1,
                    },
                  ]}
                >
                  <Text style={[styles.doneBtnText, { color: colors.mutedForeground }]}>Done</Text>
                </Pressable>
              </View>
            ) : (
            <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : undefined}
            >
              <ScrollView
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.sheetBody}
              >
                <View style={styles.fieldGroup}>
                  <Text style={[styles.label, { color: colors.mutedForeground }]}>Bio</Text>
                  <TextInput
                    style={[inputStyle, styles.bioInput]}
                    placeholder="Tell clients about your experience and services…"
                    placeholderTextColor={colors.mutedForeground + "80"}
                    value={bio}
                    onChangeText={setBio}
                    multiline
                    numberOfLines={4}
                    textAlignVertical="top"
                    editable={!saving}
                  />
                </View>

                <View style={styles.fieldGroup}>
                  <Text style={[styles.label, { color: colors.mutedForeground }]}>Profile Photo</Text>
                  <View style={styles.photoRow}>
                    <Pressable
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                        pickPhoto();
                      }}
                      disabled={uploading || saving}
                      style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}
                    >
                      <View
                        style={[
                          styles.photoThumb,
                          { borderColor: colors.border, backgroundColor: colors.card },
                        ]}
                      >
                        {localPhotoUri || photoUrl ? (
                          <Image
                            source={{ uri: localPhotoUri ?? photoUrl }}
                            style={styles.photoImage}
                          />
                        ) : (
                          <Feather name="user" size={28} color={colors.mutedForeground} />
                        )}
                        <View style={[styles.cameraChip, { backgroundColor: colors.primary }]}>
                          {uploading ? (
                            <ActivityIndicator size={11} color="#fff" />
                          ) : (
                            <Feather name="camera" size={11} color="#fff" />
                          )}
                        </View>
                      </View>
                    </Pressable>
                    <View style={{ flex: 1, gap: 4 }}>
                      <Text style={[styles.photoHint, { color: colors.foreground }]}>
                        {uploading ? "Uploading…" : "Tap photo to pick from camera roll"}
                      </Text>
                      <Text style={[styles.photoSub, { color: colors.mutedForeground }]}>
                        Or paste a URL below
                      </Text>
                    </View>
                  </View>
                  <TextInput
                    style={[inputStyle, { marginTop: 4 }]}
                    placeholder="https://example.com/photo.jpg"
                    placeholderTextColor={colors.mutedForeground + "80"}
                    value={photoUrl}
                    onChangeText={(v) => {
                      setPhotoUrl(v);
                      setLocalPhotoUri(null);
                    }}
                    autoCapitalize="none"
                    keyboardType="url"
                    autoCorrect={false}
                    editable={!saving && !uploading}
                  />
                </View>

                <View style={styles.fieldGroup}>
                  <Text style={[styles.label, { color: colors.mutedForeground }]}>Website</Text>
                  <TextInput
                    style={inputStyle}
                    placeholder="https://yourbusiness.com"
                    placeholderTextColor={colors.mutedForeground + "80"}
                    value={website}
                    onChangeText={setWebsite}
                    autoCapitalize="none"
                    keyboardType="url"
                    autoCorrect={false}
                    editable={!saving}
                  />
                </View>

                <View style={styles.fieldGroup}>
                  <Text style={[styles.label, { color: colors.mutedForeground }]}>Phone</Text>
                  <TextInput
                    style={inputStyle}
                    placeholder="(239) 555-0100"
                    placeholderTextColor={colors.mutedForeground + "80"}
                    value={phone}
                    onChangeText={setPhone}
                    keyboardType="phone-pad"
                    editable={!saving}
                  />
                </View>

                <View style={styles.fieldGroup}>
                  <Text style={[styles.label, { color: colors.mutedForeground }]}>Location</Text>
                  <TextInput
                    style={inputStyle}
                    placeholder="Naples, FL"
                    placeholderTextColor={colors.mutedForeground + "80"}
                    value={location}
                    onChangeText={setLocation}
                    autoCapitalize="words"
                    editable={!saving}
                  />
                </View>

                {error && (
                  <View style={[styles.errorBox, { backgroundColor: "#ef444415", borderColor: "#ef444430" }]}>
                    <Feather name="alert-circle" size={14} color="#ef4444" />
                    <Text style={[styles.errorText, { color: "#ef4444" }]}>{error}</Text>
                  </View>
                )}

                <Pressable
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                    handleSave();
                  }}
                  disabled={saving}
                  style={({ pressed }) => [
                    styles.saveBtn,
                    {
                      backgroundColor: colors.primary,
                      borderRadius: colors.radius,
                      opacity: pressed || saving ? 0.8 : 1,
                    },
                  ]}
                >
                  {saving ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Text style={styles.saveBtnText}>Save changes</Text>
                  )}
                </Pressable>
              </ScrollView>
            </KeyboardAvoidingView>
            )}
          </Pressable>
        </Animated.View>
      </Pressable>
    </Modal>
  );
}

function useProProfile(token: string | null) {
  const [pro, setPro] = useState<ProProfile | null>(null);
  const [loading, setLoading] = useState(false);

  const fetch_ = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      const base = domain ? `https://${domain}` : "";
      const res = await fetch(`${base}/api/pro-requests/portal/vetted-pro`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.pro) setPro(data.pro as ProProfile);
        else setPro(null);
      } else {
        setPro(null);
      }
    } catch {
      setPro(null);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetch_();
  }, [fetch_]);

  return { pro, loading, setPro };
}

function ProProfileCard({
  pro,
  colors,
  onEdit,
}: {
  pro: ProProfile;
  colors: any;
  onEdit: () => void;
}) {
  return (
    <View
      style={[
        styles.proCard,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
        },
      ]}
    >
      <View style={styles.proCardHeader}>
        <View style={[styles.proIconWrap, { backgroundColor: colors.primary + "18" }]}>
          <Feather name="award" size={20} color={colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.proCardName, { color: colors.foreground }]} numberOfLines={1}>
            {pro.business_name}
          </Text>
          {pro.location ? (
            <Text style={[styles.proCardLocation, { color: colors.mutedForeground }]} numberOfLines={1}>
              {pro.location}
            </Text>
          ) : null}
        </View>
        <View style={[styles.proBadge, { backgroundColor: colors.primary + "18" }]}>
          <Text style={[styles.proBadgeText, { color: colors.primary }]}>Vetted Pro</Text>
        </View>
      </View>
      <Pressable
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          onEdit();
        }}
        style={({ pressed }) => [
          styles.editProBtn,
          {
            backgroundColor: colors.primary,
            borderRadius: colors.radius,
            opacity: pressed ? 0.8 : 1,
          },
        ]}
      >
        <Feather name="edit-2" size={15} color="#fff" />
        <Text style={styles.editProBtnText}>Edit my profile</Text>
      </Pressable>
    </View>
  );
}

function LoggedInView({ colors, bottomInset, topInset }: { colors: any; bottomInset: number; topInset: number }) {
  const { user, logout, token } = useAuth();
  const [loggingOut, setLoggingOut] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const { pro, loading: proLoading, setPro } = useProProfile(token);
  const insets = useSafeAreaInsets();

  const handleLogout = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: async () => {
          setLoggingOut(true);
          try {
            await logout();
          } finally {
            setLoggingOut(false);
          }
        },
      },
    ]);
  };

  if (!user) return null;

  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <>
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={{ paddingBottom: bottomInset }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.profileHeader, { paddingTop: topInset + 20 }]}>
          <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          <Text style={[styles.userName, { color: colors.foreground }]}>{user.name}</Text>
          <Text style={[styles.userEmail, { color: colors.mutedForeground }]}>{user.email}</Text>
          {user.role && (
            <View style={[styles.rolePill, { backgroundColor: colors.primary + "18" }]}>
              <Text style={[styles.roleText, { color: colors.primary }]}>
                {user.role === "both" ? "Renter & Owner" : user.role.charAt(0).toUpperCase() + user.role.slice(1)}
              </Text>
            </View>
          )}
        </View>

        {proLoading ? (
          <View style={[styles.section, { paddingHorizontal: 16 }]}>
            <ActivityIndicator color={colors.primary} size="small" style={{ alignSelf: "flex-start" }} />
          </View>
        ) : pro ? (
          <View style={[styles.section, { paddingHorizontal: 16 }]}>
            <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>MY PRO PROFILE</Text>
            <ProProfileCard
              pro={pro}
              colors={colors}
              onEdit={() => setEditModalOpen(true)}
            />
          </View>
        ) : null}

        <View style={[styles.section, { paddingHorizontal: 16 }]}>
          <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>MY BOOKINGS</Text>
          <BookingsSection userId={user.id} colors={colors} />
        </View>

        <View style={[styles.section, { paddingHorizontal: 16 }]}>
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              handleLogout();
            }}
            disabled={loggingOut}
            style={({ pressed }) => [
              styles.linkRow,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                borderRadius: colors.radius,
                opacity: pressed || loggingOut ? 0.7 : 1,
              },
            ]}
          >
            <View style={[styles.linkIcon, { backgroundColor: "#ef444418" }]}>
              <Feather name="log-out" size={18} color="#ef4444" />
            </View>
            <Text style={[styles.linkLabel, { color: "#ef4444" }]}>
              {loggingOut ? "Signing out…" : "Sign Out"}
            </Text>
          </Pressable>
        </View>
      </ScrollView>

      {pro && token && (
        <EditProModal
          visible={editModalOpen}
          pro={pro}
          token={token}
          colors={colors}
          insets={insets}
          onClose={() => setEditModalOpen(false)}
          onSaved={(updated) => setPro(updated)}
        />
      )}
    </>
  );
}

function AuthForm({ colors, bottomInset, topInset }: { colors: any; bottomInset: number; topInset: number }) {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    setError(null);
    if (!email.trim() || !password.trim()) {
      setError("Email and password are required.");
      return;
    }
    if (mode === "register" && !name.trim()) {
      setError("Name is required.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    setLoading(true);
    try {
      if (mode === "login") {
        await login(email.trim(), password);
      } else {
        const params: RegisterParams = {
          name: name.trim(),
          email: email.trim(),
          password,
        };
        if (phone.trim()) params.phone = phone.trim();
        await register(params);
      }
    } catch (err: any) {
      setError(err?.message ?? "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = [
    styles.input,
    {
      backgroundColor: colors.card,
      borderColor: colors.border,
      borderRadius: colors.radius,
      color: colors.foreground,
    },
  ];

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={[styles.authScroll, { paddingTop: topInset + 20, paddingBottom: bottomInset }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.authHeader}>
          <View style={[styles.authIconWrap, { backgroundColor: colors.primary + "18" }]}>
            <Feather name="user" size={32} color={colors.primary} />
          </View>
          <Text style={[styles.authTitle, { color: colors.foreground }]}>
            {mode === "login" ? "Welcome back" : "Create account"}
          </Text>
          <Text style={[styles.authSubtitle, { color: colors.mutedForeground }]}>
            {mode === "login"
              ? "Sign in to view your bookings and manage listings."
              : "Join SHARE to book or list on Southwest Florida's rental platform."}
          </Text>
        </View>

        <View style={styles.form}>
          {mode === "register" && (
            <View style={styles.fieldGroup}>
              <Text style={[styles.label, { color: colors.mutedForeground }]}>Full Name</Text>
              <TextInput
                style={inputStyle}
                placeholder="Jane Smith"
                placeholderTextColor={colors.mutedForeground + "80"}
                value={name}
                onChangeText={setName}
                autoCapitalize="words"
                autoCorrect={false}
                editable={!loading}
              />
            </View>
          )}

          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.mutedForeground }]}>Email</Text>
            <TextInput
              style={inputStyle}
              placeholder="you@example.com"
              placeholderTextColor={colors.mutedForeground + "80"}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              autoCorrect={false}
              editable={!loading}
            />
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.label, { color: colors.mutedForeground }]}>Password</Text>
            <TextInput
              style={inputStyle}
              placeholder="Min. 6 characters"
              placeholderTextColor={colors.mutedForeground + "80"}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!loading}
            />
          </View>

          {mode === "register" && (
            <View style={styles.fieldGroup}>
              <Text style={[styles.label, { color: colors.mutedForeground }]}>Phone (optional)</Text>
              <TextInput
                style={inputStyle}
                placeholder="(239) 555-0100"
                placeholderTextColor={colors.mutedForeground + "80"}
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                editable={!loading}
              />
            </View>
          )}

          {error && (
            <View style={[styles.errorBox, { backgroundColor: "#ef444415", borderColor: "#ef444430" }]}>
              <Feather name="alert-circle" size={14} color="#ef4444" />
              <Text style={[styles.errorText, { color: "#ef4444" }]}>{error}</Text>
            </View>
          )}

          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              handleSubmit();
            }}
            disabled={loading}
            style={({ pressed }) => [
              styles.submitBtn,
              {
                backgroundColor: colors.primary,
                borderRadius: colors.radius,
                opacity: pressed || loading ? 0.8 : 1,
              },
            ]}
          >
            {loading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text style={styles.submitBtnText}>
                {mode === "login" ? "Sign In" : "Create Account"}
              </Text>
            )}
          </Pressable>

          <Pressable
            onPress={() => {
              setError(null);
              setMode(mode === "login" ? "register" : "login");
            }}
            style={styles.switchMode}
          >
            <Text style={[styles.switchModeText, { color: colors.mutedForeground }]}>
              {mode === "login" ? "Don't have an account? " : "Already have an account? "}
              <Text style={{ color: colors.primary, fontWeight: "600" }}>
                {mode === "login" ? "Sign Up" : "Sign In"}
              </Text>
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, isLoading } = useAuth();
  const isWeb = Platform.OS === "web";
  const topInset = isWeb ? 67 : insets.top;
  const bottomInset = isWeb ? 34 : insets.bottom + 80;

  if (isLoading) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  if (user) {
    return <LoggedInView colors={colors} bottomInset={bottomInset} topInset={topInset} />;
  }

  return <AuthForm colors={colors} bottomInset={bottomInset} topInset={topInset} />;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { alignItems: "center", justifyContent: "center" },

  profileHeader: {
    paddingHorizontal: 24,
    paddingBottom: 24,
    alignItems: "center",
    gap: 6,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  avatarText: { fontSize: 28, fontWeight: "700", color: "#fff" },
  userName: { fontSize: 20, fontWeight: "700" },
  userEmail: { fontSize: 14 },
  rolePill: {
    marginTop: 4,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 100,
  },
  roleText: { fontSize: 12, fontWeight: "600" },

  section: { marginBottom: 20, gap: 8 },
  sectionTitle: {
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1.2,
    marginBottom: 2,
  },
  sectionLabel: {
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1.1,
    marginBottom: 2,
  },
  linkRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderWidth: 1,
    paddingVertical: 14,
    paddingHorizontal: 14,
  },
  linkIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  linkLabel: { flex: 1, fontSize: 15, fontWeight: "500" },

  bookingCard: {
    borderWidth: 1,
    padding: 14,
    gap: 6,
  },
  bookingHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  bookingTitle: { flex: 1, fontSize: 15, fontWeight: "600" },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100 },
  statusText: { fontSize: 12, fontWeight: "600" },
  bookingMeta: { flexDirection: "row", alignItems: "center", gap: 5 },
  bookingDates: { fontSize: 13 },
  bookingAmount: { fontSize: 13, fontWeight: "500" },

  centeredState: { alignItems: "center", paddingVertical: 32, gap: 6 },
  emptyText: { fontSize: 15, fontWeight: "500" },
  emptySubText: { fontSize: 13, textAlign: "center", lineHeight: 19 },

  proCard: {
    borderWidth: 1,
    padding: 14,
    gap: 12,
  },
  proCardHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  proIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  proCardName: { fontSize: 15, fontWeight: "700" },
  proCardLocation: { fontSize: 12, marginTop: 1 },
  proBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 100,
  },
  proBadgeText: { fontSize: 11, fontWeight: "700" },
  editProBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    paddingVertical: 11,
  },
  editProBtnText: { color: "#fff", fontSize: 14, fontWeight: "700" },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    justifyContent: "flex-end",
  },
  sheet: {
    maxHeight: "90%",
  },
  sheetHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#00000020",
    alignSelf: "center",
    marginTop: 10,
    marginBottom: 4,
  },
  sheetHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  sheetTitle: { fontSize: 17, fontWeight: "700" },
  sheetBody: {
    padding: 20,
    gap: 16,
    paddingBottom: 8,
  },

  fieldGroup: { gap: 6 },
  label: { fontSize: 13, fontWeight: "600" },

  photoRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    marginBottom: 2,
  },
  photoThumb: {
    width: 72,
    height: 72,
    borderRadius: 36,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  photoImage: {
    width: 72,
    height: 72,
    borderRadius: 36,
  },
  cameraChip: {
    position: "absolute",
    bottom: 2,
    right: 2,
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  photoHint: { fontSize: 13, fontWeight: "500" },
  photoSub: { fontSize: 12 },

  input: {
    borderWidth: 1,
    paddingVertical: 12,
    paddingHorizontal: 14,
    fontSize: 15,
  },
  bioInput: {
    minHeight: 100,
    paddingTop: 12,
  },

  errorBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
  },
  errorText: { flex: 1, fontSize: 13, lineHeight: 18 },

  saveBtn: {
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
    minHeight: 50,
  },
  saveBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" },

  successBody: {
    padding: 28,
    alignItems: "center",
    gap: 12,
  },
  successIconWrap: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 6,
  },
  successTitle: {
    fontSize: 20,
    fontWeight: "700",
    textAlign: "center",
  },
  successSubtitle: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 20,
    marginBottom: 8,
  },
  viewProfileBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
    width: "100%",
    minHeight: 50,
  },
  viewProfileBtnText: { color: "#fff", fontSize: 15, fontWeight: "700" },
  doneBtn: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    paddingHorizontal: 24,
    width: "100%",
    borderWidth: 1,
    minHeight: 46,
  },
  doneBtnText: { fontSize: 15, fontWeight: "600" },

  authScroll: { flexGrow: 1, paddingHorizontal: 24 },
  authHeader: { alignItems: "center", gap: 10, marginBottom: 28 },
  authIconWrap: {
    width: 68,
    height: 68,
    borderRadius: 34,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  authTitle: { fontSize: 24, fontWeight: "700" },
  authSubtitle: { fontSize: 14, textAlign: "center", lineHeight: 20 },

  form: { gap: 16 },
  submitBtn: {
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
    minHeight: 50,
  },
  submitBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" },

  switchMode: { alignItems: "center", paddingVertical: 4 },
  switchModeText: { fontSize: 14 },
});
