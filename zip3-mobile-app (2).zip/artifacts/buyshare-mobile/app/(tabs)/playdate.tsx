import { Feather } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";

const SAFETY_STORAGE_KEY = "playdate_safety_accepted_v1";

function SafetyModal({ onAccept, colors }: { onAccept: () => void; colors: any }) {
  const [agreed, setAgreed] = useState(false);
  const insets = useSafeAreaInsets();

  return (
    <Modal visible animationType="fade" transparent presentationStyle="overFullScreen">
      <View style={safetyStyles.overlay}>
        <ScrollView
          style={safetyStyles.scroll}
          contentContainerStyle={[
            safetyStyles.container,
            { paddingTop: insets.top + 24, paddingBottom: insets.bottom + 24 },
          ]}
          showsVerticalScrollIndicator={false}
        >
          <View style={[safetyStyles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={safetyStyles.titleRow}>
              <Text style={safetyStyles.emoji}>☀️</Text>
              <Text style={[safetyStyles.title, { color: colors.foreground }]}>Welcome to PLAYDATE</Text>
              <Text style={[safetyStyles.subtitle, { color: colors.mutedForeground }]}>
                A free community for SWFL families to connect safely
              </Text>
            </View>

            <View style={[safetyStyles.section, { backgroundColor: "#fffbeb", borderColor: "#fde68a" }]}>
              <View style={safetyStyles.sectionHeader}>
                <Feather name="alert-triangle" size={14} color="#d97706" />
                <Text style={[safetyStyles.sectionTitle, { color: "#92400e" }]}>Safety & Legal Requirements</Text>
              </View>
              {[
                "All meetups must take place in public places only. No private residences for initial meetups.",
                "Any adult accompanying a minor must be 21 years of age or older.",
                "No last names. First name and last initial only for privacy.",
                "No photos of children or minors may be posted on this platform.",
                "Offensive language, references to weapons, drugs, alcohol, or sexual content are automatically blocked.",
              ].map((rule, i) => (
                <View key={i} style={safetyStyles.ruleRow}>
                  <Text style={{ color: "#16a34a", fontWeight: "700", marginTop: 1 }}>✓</Text>
                  <Text style={[safetyStyles.ruleText, { color: "#92400e" }]}>{rule}</Text>
                </View>
              ))}
            </View>

            <View style={[safetyStyles.section, { backgroundColor: "#fef2f2", borderColor: "#fecaca" }]}>
              <View style={safetyStyles.sectionHeader}>
                <Feather name="phone" size={14} color="#dc2626" />
                <Text style={[safetyStyles.sectionTitle, { color: "#991b1b" }]}>Human Trafficking Awareness</Text>
              </View>
              <Text style={[safetyStyles.bodyText, { color: "#991b1b" }]}>
                If you believe a child is in danger or suspect human trafficking, call the{" "}
                <Text style={{ fontWeight: "700" }}>National Human Trafficking Hotline: 1-888-373-7888</Text> or text
                "HELP" to 233733. For immediate danger, call <Text style={{ fontWeight: "700" }}>911</Text>. SHARE and
                PLAYDATE are committed to child safety.
              </Text>
            </View>

            <View style={[safetyStyles.section, { backgroundColor: "#eff6ff", borderColor: "#bfdbfe" }]}>
              <View style={safetyStyles.sectionHeader}>
                <Text style={{ fontSize: 13 }}>📋</Text>
                <Text style={[safetyStyles.sectionTitle, { color: "#1e40af" }]}>Terms of Use</Text>
              </View>
              <Text style={[safetyStyles.bodyTextSmall, { color: "#1e3a8a" }]}>
                By using PLAYDATE, you agree that: (1) you are 21 years of age or older; (2) you will only arrange
                meetups in publicly accessible, well-lit locations during daytime hours; (3) you accept full personal
                responsibility for your participation; (4) BlueTruck LLC, BURNS INC., and SHARE are not responsible for
                interactions between users; (5) you will not share or solicit personal identifying information beyond
                what is displayed on this platform.
              </Text>
            </View>

            <Pressable
              onPress={() => setAgreed((v) => !v)}
              style={safetyStyles.checkRow}
              accessibilityRole="checkbox"
              accessibilityState={{ checked: agreed }}
            >
              <View
                style={[
                  safetyStyles.checkbox,
                  {
                    backgroundColor: agreed ? "#f59e0b" : colors.muted,
                    borderColor: agreed ? "#f59e0b" : colors.border,
                  },
                ]}
              >
                {agreed && <Feather name="check" size={12} color="#ffffff" />}
              </View>
              <Text style={[safetyStyles.checkText, { color: colors.foreground }]}>
                <Text style={{ fontWeight: "700" }}>I confirm I am 21 or older.</Text> I have read and agree to the
                PLAYDATE Safety Rules and Terms of Use. I understand all meetups must be in public places and I am
                solely responsible for my participation.
              </Text>
            </Pressable>

            <Pressable
              onPress={onAccept}
              disabled={!agreed}
              style={({ pressed }) => [
                safetyStyles.agreeBtn,
                {
                  backgroundColor: "#f59e0b",
                  opacity: !agreed ? 0.4 : pressed ? 0.88 : 1,
                },
              ]}
            >
              <Text style={safetyStyles.agreeBtnText}>I Understand — Enter PLAYDATE Community</Text>
            </Pressable>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}

const safetyStyles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.65)",
  },
  scroll: {
    flex: 1,
  },
  container: {
    paddingHorizontal: 16,
    flexGrow: 1,
    justifyContent: "center",
  },
  card: {
    borderWidth: 1,
    borderRadius: 20,
    padding: 24,
    gap: 16,
  },
  titleRow: {
    alignItems: "center",
    gap: 6,
    marginBottom: 4,
  },
  emoji: { fontSize: 44 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center" },
  subtitle: { fontSize: 13, textAlign: "center" },
  section: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    gap: 8,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  sectionTitle: { fontSize: 13, fontWeight: "700" },
  ruleRow: {
    flexDirection: "row",
    gap: 8,
    alignItems: "flex-start",
  },
  ruleText: { fontSize: 13, lineHeight: 18, flex: 1 },
  bodyText: { fontSize: 13, lineHeight: 19 },
  bodyTextSmall: { fontSize: 12, lineHeight: 17 },
  checkRow: {
    flexDirection: "row",
    gap: 12,
    alignItems: "flex-start",
    paddingVertical: 4,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 1,
    flexShrink: 0,
  },
  checkText: { fontSize: 13, lineHeight: 19, flex: 1 },
  agreeBtn: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },
  agreeBtnText: { color: "#ffffff", fontWeight: "700", fontSize: 15 },
});

const getBaseUrl = () =>
  process.env.EXPO_PUBLIC_DOMAIN
    ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
    : "";

interface Meetup {
  id: string;
  title: string;
  location: string;
  date: string;
  time: string;
  description: string;
  host_name: string;
  category: string;
  max_attendees: number;
  rsvp_count: number;
  status: "active" | "cancelled" | "closed";
  created_at: string;
}

type ManageStep = "code" | "action" | "confirm";
type ManageAction = "cancel" | "close" | "reopen" | "delete";

interface RsvpEntry {
  id: string;
  first_name: string;
  last_initial: string;
  contact: string;
  num_children: number;
  created_at: string;
  emailed_at: string | null;
}

function formatDate(dateStr: string) {
  try {
    const d = new Date(dateStr + "T00:00:00");
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return dateStr;
  }
}

function StatusBadge({ status, colors }: { status: Meetup["status"]; colors: any }) {
  if (status === "active") return null;
  const isCancelled = status === "cancelled";
  return (
    <View
      style={[
        styles.badge,
        { backgroundColor: isCancelled ? "#fef2f2" : "#fefce8", borderColor: isCancelled ? "#fecaca" : "#fde68a" },
      ]}
    >
      <Text style={[styles.badgeText, { color: isCancelled ? "#dc2626" : "#92400e" }]}>
        {isCancelled ? "Cancelled" : "Closed"}
      </Text>
    </View>
  );
}

interface MeetupCardProps {
  meetup: Meetup;
  colors: any;
  onManage: (meetup: Meetup) => void;
}

function MeetupCard({ meetup, colors, onManage }: MeetupCardProps) {
  const spotsLeft = meetup.max_attendees - meetup.rsvp_count;
  const isCancelled = meetup.status === "cancelled";

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: isCancelled ? "#fecaca" : colors.border,
          borderRadius: colors.radius,
          opacity: isCancelled ? 0.8 : 1,
        },
      ]}
    >
      <View style={styles.cardHeader}>
        <View style={styles.cardTitleRow}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]} numberOfLines={2}>
            {meetup.title}
          </Text>
          <StatusBadge status={meetup.status} colors={colors} />
        </View>
        <Text style={[styles.cardCategory, { color: colors.mutedForeground }]}>{meetup.category}</Text>
      </View>

      <View style={styles.cardMeta}>
        <View style={styles.cardMetaRow}>
          <Feather name="calendar" size={13} color="#f59e0b" />
          <Text style={[styles.cardMetaText, { color: colors.mutedForeground }]}>
            {formatDate(meetup.date)} at {meetup.time}
          </Text>
        </View>
        <View style={styles.cardMetaRow}>
          <Feather name="map-pin" size={13} color="#f59e0b" />
          <Text style={[styles.cardMetaText, { color: colors.mutedForeground }]} numberOfLines={1}>
            {meetup.location}
          </Text>
        </View>
        <View style={styles.cardMetaRow}>
          <Feather name="users" size={13} color="#f59e0b" />
          <Text style={[styles.cardMetaText, { color: colors.mutedForeground }]}>
            {meetup.rsvp_count} / {meetup.max_attendees} families
            {meetup.status === "active" && spotsLeft <= 5 && spotsLeft > 0 && (
              <Text style={{ color: "#ea580c", fontWeight: "700" }}> · {spotsLeft} left!</Text>
            )}
          </Text>
        </View>
        <View style={styles.cardMetaRow}>
          <Feather name="user" size={13} color="#f59e0b" />
          <Text style={[styles.cardMetaText, { color: colors.mutedForeground }]}>
            Hosted by {meetup.host_name}
          </Text>
        </View>
      </View>

      {meetup.description ? (
        <Text style={[styles.cardDesc, { color: colors.mutedForeground }]} numberOfLines={2}>
          {meetup.description}
        </Text>
      ) : null}

      <Pressable
        onPress={() => onManage(meetup)}
        style={({ pressed }) => [
          styles.manageBtn,
          {
            backgroundColor: pressed ? "#d97706" : "#f59e0b",
            borderRadius: colors.radius,
            opacity: pressed ? 0.88 : 1,
          },
        ]}
      >
        <Feather name="settings" size={14} color="#ffffff" />
        <Text style={styles.manageBtnText}>Manage</Text>
      </Pressable>
    </View>
  );
}

interface ManageModalProps {
  meetup: Meetup;
  visible: boolean;
  onClose: () => void;
  onStatusChange: (id: string, status: Meetup["status"]) => void;
  onDelete: (id: string) => void;
  colors: any;
}

function ManageModal({ meetup, visible, onClose, onStatusChange, onDelete, colors }: ManageModalProps) {
  const [step, setStep] = useState<ManageStep>("code");
  const [code, setCode] = useState("");
  const [codeError, setCodeError] = useState("");
  const [codeLoading, setCodeLoading] = useState(false);
  const [pendingAction, setPendingAction] = useState<ManageAction | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [rsvps, setRsvps] = useState<RsvpEntry[]>([]);
  const insets = useSafeAreaInsets();

  useEffect(() => {
    if (!visible) {
      setStep("code");
      setCode("");
      setCodeError("");
      setPendingAction(null);
      setSubmitting(false);
      setRsvps([]);
    }
  }, [visible]);

  async function handleCodeSubmit() {
    if (code.trim().length < 4) return;
    setCodeError("");
    setCodeLoading(true);
    try {
      const r = await fetch(
        `${getBaseUrl()}/api/playdate/meetups/${meetup.id}/rsvps?host_code=${encodeURIComponent(code.trim())}`
      );
      const d = await r.json();
      if (!r.ok) {
        setCodeError(d.error || "Invalid host code.");
      } else {
        setRsvps(d.rsvps ?? []);
        setStep("action");
      }
    } catch {
      setCodeError("Could not connect. Please try again.");
    }
    setCodeLoading(false);
  }

  async function handleConfirm() {
    if (!pendingAction) return;
    setSubmitting(true);
    try {
      if (pendingAction === "delete") {
        const r = await fetch(`${getBaseUrl()}/api/playdate/meetups/${meetup.id}`, {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ host_code: code.trim() }),
        });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error);
        onDelete(meetup.id);
        onClose();
        Alert.alert("Meetup deleted", "Your meetup has been permanently removed from the board.");
      } else {
        const r = await fetch(`${getBaseUrl()}/api/playdate/meetups/${meetup.id}/status`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ host_code: code.trim(), action: pendingAction }),
        });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error);
        const newStatus: Meetup["status"] =
          pendingAction === "cancel" ? "cancelled" : pendingAction === "close" ? "closed" : "active";
        onStatusChange(meetup.id, newStatus);
        onClose();
        const notified = d.notified ?? 0;
        if (pendingAction === "cancel") {
          Alert.alert(
            "Meetup cancelled",
            notified > 0
              ? `${notified} RSVP${notified === 1 ? "" : "s"} notified by email.`
              : "Meetup removed from the board."
          );
        } else if (pendingAction === "close") {
          Alert.alert("Sign-ups closed", "No new RSVPs will be accepted.");
        } else {
          Alert.alert("Sign-ups re-opened ☀️", "Your meetup is accepting RSVPs again.");
        }
      }
    } catch (err: any) {
      Alert.alert("Error", err.message ?? "Something went wrong. Please try again.");
    }
    setSubmitting(false);
  }

  const actionLabel: Record<ManageAction, string> = {
    cancel: "Cancel Meetup",
    close: "Close Sign-ups",
    reopen: "Re-open Sign-ups",
    delete: "Delete Meetup",
  };

  const confirmMsg: Record<ManageAction, string> = {
    cancel:
      "This will mark the meetup as cancelled. Any RSVPs with email addresses will be notified. This cannot be undone.",
    close: "No new RSVPs will be accepted. Existing attendees are not affected and the meetup stays visible.",
    reopen: "Sign-ups will be re-enabled and the meetup will appear as active on the board again.",
    delete:
      "This will permanently remove the meetup and all its RSVPs from the board. This cannot be undone.",
  };

  const confirmColor: Record<ManageAction, string> = {
    cancel: "#dc2626",
    close: "#f59e0b",
    reopen: "#16a34a",
    delete: "#dc2626",
  };

  return (
    <Modal visible={visible} animationType="slide" transparent presentationStyle="overFullScreen">
      <KeyboardAvoidingView
        style={styles.modalOverlay}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.card, paddingBottom: insets.bottom + 16 },
          ]}
        >
          <View style={styles.sheetHandle} />

          <View style={styles.sheetHeader}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Manage Meetup</Text>
              <Text style={[styles.sheetSubtitle, { color: colors.mutedForeground }]} numberOfLines={1}>
                {meetup.title}
              </Text>
            </View>
            <Pressable onPress={onClose} style={styles.closeBtn} hitSlop={8}>
              <Feather name="x" size={20} color={colors.mutedForeground} />
            </Pressable>
          </View>

          {step === "code" && (
            <View style={styles.sheetBody}>
              <View style={[styles.infoBox, { backgroundColor: "#fffbeb", borderColor: "#fde68a" }]}>
                <Feather name="key" size={14} color="#d97706" style={{ marginTop: 1 }} />
                <Text style={[styles.infoText, { color: "#92400e" }]}>
                  Enter your host code to verify you posted this meetup.
                </Text>
              </View>

              <Text style={[styles.label, { color: colors.foreground }]}>Host Code</Text>
              <TextInput
                style={[
                  styles.codeInput,
                  {
                    backgroundColor: colors.muted,
                    borderColor: codeError ? "#fca5a5" : colors.border,
                    color: colors.foreground,
                    borderRadius: colors.radius,
                  },
                ]}
                placeholder="e.g., AB12CD"
                placeholderTextColor={colors.mutedForeground}
                value={code}
                onChangeText={(t) => setCode(t.toUpperCase())}
                maxLength={6}
                autoCapitalize="characters"
                autoCorrect={false}
                returnKeyType="done"
                onSubmitEditing={handleCodeSubmit}
              />

              {codeError ? (
                <View style={[styles.infoBox, { backgroundColor: "#fef2f2", borderColor: "#fecaca", marginTop: 8 }]}>
                  <Feather name="alert-triangle" size={14} color="#dc2626" style={{ marginTop: 1 }} />
                  <Text style={[styles.infoText, { color: "#dc2626" }]}>{codeError}</Text>
                </View>
              ) : null}

              <Pressable
                onPress={handleCodeSubmit}
                disabled={codeLoading || code.trim().length < 4}
                style={({ pressed }) => [
                  styles.primaryBtn,
                  {
                    backgroundColor: "#f59e0b",
                    borderRadius: colors.radius,
                    opacity: codeLoading || code.trim().length < 4 ? 0.4 : pressed ? 0.88 : 1,
                    marginTop: 12,
                  },
                ]}
              >
                <Text style={styles.primaryBtnText}>
                  {codeLoading ? "Checking…" : "Verify & Continue"}
                </Text>
              </Pressable>
            </View>
          )}

          {step === "action" && (
            <ScrollView style={styles.sheetBody} showsVerticalScrollIndicator={false}>
              {/* RSVP list */}
              <View style={[rsvpStyles.rsvpSection, { borderColor: colors.border }]}>
                <View style={rsvpStyles.rsvpHeader}>
                  <Feather name="users" size={14} color="#f59e0b" />
                  <Text style={[rsvpStyles.rsvpHeaderText, { color: colors.foreground }]}>
                    Who's Coming
                  </Text>
                  <View style={[rsvpStyles.rsvpBadge, { backgroundColor: "#fef3c7" }]}>
                    <Text style={rsvpStyles.rsvpBadgeText}>{rsvps.length} / {meetup.max_attendees}</Text>
                  </View>
                </View>

                {rsvps.length === 0 ? (
                  <View style={rsvpStyles.emptyState}>
                    <Text style={rsvpStyles.emptyEmoji}>☀️</Text>
                    <Text style={[rsvpStyles.emptyTitle, { color: colors.foreground }]}>No RSVPs yet</Text>
                    <Text style={[rsvpStyles.emptySubtitle, { color: colors.mutedForeground }]}>
                      Share your meetup so families can sign up!
                    </Text>
                  </View>
                ) : (
                  <>
                    <View style={[rsvpStyles.statRow, { borderColor: colors.border }]}>
                      <Text style={[rsvpStyles.statText, { color: colors.mutedForeground }]}>
                        {rsvps.reduce((s, r) => s + r.num_children, 0)} children total
                      </Text>
                    </View>
                    {rsvps.map((r, i) => (
                      <View
                        key={r.id}
                        style={[
                          rsvpStyles.rsvpRow,
                          { backgroundColor: colors.muted, borderColor: colors.border },
                          i < rsvps.length - 1 && { marginBottom: 8 },
                        ]}
                      >
                        <View style={rsvpStyles.rsvpAvatar}>
                          <Text style={rsvpStyles.rsvpAvatarText}>{i + 1}</Text>
                        </View>
                        <View style={rsvpStyles.rsvpInfo}>
                          <View style={rsvpStyles.rsvpNameRow}>
                            <Text style={[rsvpStyles.rsvpName, { color: colors.foreground }]}>
                              {r.first_name} {r.last_initial}.
                            </Text>
                            {r.emailed_at ? (
                              <View style={rsvpStyles.emailedBadge}>
                                <Feather name="mail" size={10} color="#0369a1" />
                                <Text style={rsvpStyles.emailedBadgeText}>Emailed</Text>
                              </View>
                            ) : null}
                          </View>
                          <Text style={[rsvpStyles.rsvpContact, { color: colors.mutedForeground }]} numberOfLines={1}>
                            {r.contact}
                          </Text>
                        </View>
                        <View style={rsvpStyles.rsvpFamily}>
                          <Feather name="users" size={11} color="#f59e0b" />
                          <Text style={[rsvpStyles.rsvpFamilyText, { color: colors.mutedForeground }]}>
                            {r.num_children} {r.num_children === 1 ? "child" : "children"}
                          </Text>
                        </View>
                      </View>
                    ))}
                  </>
                )}
              </View>

              <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: 16 }]}>
                What would you like to do?
              </Text>

              {(meetup.status === "closed" || meetup.status === "cancelled") && (
                <ActionRow
                  icon="refresh-cw"
                  iconColor="#16a34a"
                  title="Re-open Sign-ups"
                  desc="Allows new RSVPs again. The meetup goes back to active status."
                  onPress={() => { setPendingAction("reopen"); setStep("confirm"); }}
                  colors={colors}
                />
              )}

              {meetup.status === "active" && (
                <ActionRow
                  icon="lock"
                  iconColor="#d97706"
                  title="Close Sign-ups"
                  desc="Stops new RSVPs but keeps the meetup visible. Existing RSVPs unaffected."
                  onPress={() => { setPendingAction("close"); setStep("confirm"); }}
                  colors={colors}
                />
              )}

              {meetup.status !== "cancelled" && (
                <ActionRow
                  icon="x-circle"
                  iconColor="#dc2626"
                  title="Cancel Meetup"
                  desc="Marks the meetup as cancelled and emails all RSVPs to let them know."
                  onPress={() => { setPendingAction("cancel"); setStep("confirm"); }}
                  colors={colors}
                />
              )}

              <ActionRow
                icon="trash-2"
                iconColor="#7f1d1d"
                title="Delete Meetup"
                desc="Permanently removes this meetup and all RSVPs. Cannot be undone."
                onPress={() => { setPendingAction("delete"); setStep("confirm"); }}
                colors={colors}
              />

              <Pressable onPress={() => setStep("code")} style={{ marginTop: 12, alignSelf: "flex-start" }}>
                <Text style={{ color: colors.mutedForeground, fontSize: 14 }}>← Back</Text>
              </Pressable>
            </ScrollView>
          )}

          {step === "confirm" && pendingAction && (
            <View style={styles.sheetBody}>
              <View
                style={[
                  styles.infoBox,
                  {
                    backgroundColor:
                      pendingAction === "cancel" || pendingAction === "delete"
                        ? "#fef2f2"
                        : pendingAction === "reopen"
                        ? "#f0fdf4"
                        : "#fffbeb",
                    borderColor:
                      pendingAction === "cancel" || pendingAction === "delete"
                        ? "#fecaca"
                        : pendingAction === "reopen"
                        ? "#bbf7d0"
                        : "#fde68a",
                    flexDirection: "column",
                    gap: 4,
                    paddingVertical: 14,
                  },
                ]}
              >
                <Text
                  style={{
                    fontWeight: "700",
                    fontSize: 15,
                    color:
                      pendingAction === "cancel" || pendingAction === "delete"
                        ? "#991b1b"
                        : pendingAction === "reopen"
                        ? "#166534"
                        : "#92400e",
                  }}
                >
                  {pendingAction === "cancel"
                    ? "Cancel this meetup?"
                    : pendingAction === "delete"
                    ? "Permanently delete this meetup?"
                    : pendingAction === "reopen"
                    ? "Re-open sign-ups?"
                    : "Close sign-ups?"}
                </Text>
                <Text
                  style={{
                    fontSize: 13,
                    lineHeight: 18,
                    color:
                      pendingAction === "cancel" || pendingAction === "delete"
                        ? "#b91c1c"
                        : pendingAction === "reopen"
                        ? "#15803d"
                        : "#92400e",
                  }}
                >
                  {confirmMsg[pendingAction]}
                </Text>
              </View>

              <View style={styles.confirmBtns}>
                <Pressable
                  onPress={() => setStep("action")}
                  style={[styles.outlineBtn, { borderColor: colors.border, borderRadius: colors.radius }]}
                >
                  <Text style={{ color: colors.foreground, fontWeight: "600" }}>Back</Text>
                </Pressable>
                <Pressable
                  onPress={handleConfirm}
                  disabled={submitting}
                  style={({ pressed }) => [
                    styles.primaryBtn,
                    {
                      flex: 1,
                      backgroundColor: confirmColor[pendingAction],
                      borderRadius: colors.radius,
                      opacity: submitting ? 0.5 : pressed ? 0.88 : 1,
                    },
                  ]}
                >
                  <Text style={styles.primaryBtnText}>
                    {submitting
                      ? "Processing…"
                      : pendingAction === "cancel"
                      ? "Yes, Cancel Meetup"
                      : pendingAction === "delete"
                      ? "Yes, Delete Meetup"
                      : pendingAction === "reopen"
                      ? "Yes, Re-open Sign-ups"
                      : "Yes, Close Sign-ups"}
                  </Text>
                </Pressable>
              </View>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

interface ActionRowProps {
  icon: string;
  iconColor: string;
  title: string;
  desc: string;
  onPress: () => void;
  colors: any;
}

function ActionRow({ icon, iconColor, title, desc, onPress, colors }: ActionRowProps) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.actionRow,
        { borderColor: colors.border, borderRadius: colors.radius, opacity: pressed ? 0.8 : 1 },
      ]}
    >
      <Feather name={icon as any} size={20} color={iconColor} style={{ marginTop: 2, flexShrink: 0 }} />
      <View style={{ flex: 1 }}>
        <Text style={[styles.actionTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.actionDesc, { color: colors.mutedForeground }]}>{desc}</Text>
      </View>
    </Pressable>
  );
}

export default function PlaydateScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";

  const [meetups, setMeetups] = useState<Meetup[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [managingMeetup, setManagingMeetup] = useState<Meetup | null>(null);
  const [safetyAccepted, setSafetyAccepted] = useState<boolean | null>(null);

  const topInset = isWeb ? 67 : insets.top;
  const bottomInset = isWeb ? 34 : insets.bottom + 80;

  useEffect(() => {
    AsyncStorage.getItem(SAFETY_STORAGE_KEY).then((val) => {
      setSafetyAccepted(val === "1");
    });
  }, []);

  async function handleSafetyAccept() {
    await AsyncStorage.setItem(SAFETY_STORAGE_KEY, "1");
    setSafetyAccepted(true);
  }

  async function fetchMeetups() {
    try {
      const r = await fetch(`${getBaseUrl()}/api/playdate/meetups`);
      if (r.ok) {
        const d = await r.json();
        setMeetups(Array.isArray(d?.meetups) ? d.meetups : []);
      }
    } catch {
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchMeetups();
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchMeetups();
    setRefreshing(false);
  }, []);

  function handleStatusChange(id: string, status: Meetup["status"]) {
    setMeetups((prev) => prev.map((m) => (m.id === id ? { ...m, status } : m)));
  }

  function handleDelete(id: string) {
    setMeetups((prev) => prev.filter((m) => m.id !== id));
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {safetyAccepted === false && (
        <SafetyModal onAccept={handleSafetyAccept} colors={colors} />
      )}
      <View
        style={[
          styles.header,
          {
            paddingTop: topInset + 12,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <View style={styles.headerTopRow}>
          <View>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>☀️ PLAYDATE</Text>
            <Text style={[styles.headerSubtitle, { color: colors.mutedForeground }]}>
              SWFL family meetup community
            </Text>
          </View>
        </View>
        <View style={[styles.infoBox, { backgroundColor: "#fffbeb", borderColor: "#fde68a" }]}>
          <Feather name="info" size={13} color="#d97706" style={{ marginTop: 1 }} />
          <Text style={[styles.infoText, { color: "#92400e", fontSize: 12 }]}>
            Tap <Text style={{ fontWeight: "700" }}>Manage</Text> on your meetup and enter your host code to cancel, close, or delete it.
          </Text>
        </View>
      </View>

      {loading ? (
        <View style={styles.loadingBox}>
          <ActivityIndicator size="large" color="#f59e0b" />
        </View>
      ) : (
        <FlatList
          data={meetups}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <MeetupCard meetup={item} colors={colors} onManage={setManagingMeetup} />
          )}
          contentContainerStyle={[styles.listContent, { paddingBottom: bottomInset }]}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#f59e0b" />
          }
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View
              style={[
                styles.emptyBox,
                { borderColor: colors.border, borderRadius: colors.radius },
              ]}
            >
              <Text style={styles.emptyEmoji}>☀️</Text>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No meetups posted yet</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Visit the website to post the first SWFL family meetup!
              </Text>
            </View>
          }
        />
      )}

      {managingMeetup && (
        <ManageModal
          meetup={managingMeetup}
          visible={!!managingMeetup}
          onClose={() => setManagingMeetup(null)}
          onStatusChange={handleStatusChange}
          onDelete={handleDelete}
          colors={colors}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 10,
  },
  headerTopRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: "700",
  },
  headerSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 14,
    gap: 12,
  },
  loadingBox: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyBox: {
    borderWidth: 1,
    borderStyle: "dashed",
    paddingVertical: 52,
    alignItems: "center",
    gap: 8,
    marginTop: 20,
  },
  emptyEmoji: { fontSize: 36 },
  emptyTitle: { fontSize: 17, fontWeight: "600" },
  emptyText: { fontSize: 14, textAlign: "center", paddingHorizontal: 32 },
  card: {
    borderWidth: 1,
    padding: 16,
    gap: 10,
  },
  cardHeader: { gap: 3 },
  cardTitleRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "700",
    flex: 1,
    lineHeight: 22,
  },
  cardCategory: {
    fontSize: 12,
    fontWeight: "500",
  },
  cardMeta: { gap: 5 },
  cardMetaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  cardMetaText: { fontSize: 13, flex: 1 },
  cardDesc: { fontSize: 13, lineHeight: 18 },
  manageBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 10,
    marginTop: 4,
  },
  manageBtnText: { color: "#ffffff", fontWeight: "700", fontSize: 14 },
  badge: {
    borderWidth: 1,
    borderRadius: 50,
    paddingHorizontal: 8,
    paddingVertical: 3,
    flexShrink: 0,
  },
  badgeText: { fontSize: 11, fontWeight: "700" },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.45)",
  },
  sheet: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: 12,
    maxHeight: "85%",
  },
  sheetHandle: {
    width: 36,
    height: 4,
    backgroundColor: "#d1d5db",
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 16,
  },
  sheetHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    paddingHorizontal: 20,
    marginBottom: 16,
    gap: 12,
  },
  sheetTitle: { fontSize: 18, fontWeight: "700" },
  sheetSubtitle: { fontSize: 13, marginTop: 2 },
  closeBtn: { padding: 2 },
  sheetBody: { paddingHorizontal: 20, paddingBottom: 8 },
  infoBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
  },
  infoText: { fontSize: 13, lineHeight: 18, flex: 1 },
  label: { fontSize: 14, fontWeight: "600", marginBottom: 6 },
  codeInput: {
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 22,
    fontWeight: "800",
    textAlign: "center",
    letterSpacing: 6,
  },
  primaryBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 13,
    gap: 6,
  },
  primaryBtnText: { color: "#ffffff", fontWeight: "700", fontSize: 15 },
  sectionLabel: { fontSize: 14, marginBottom: 12 },
  actionRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
    borderWidth: 1,
    padding: 14,
    marginBottom: 10,
  },
  actionTitle: { fontSize: 15, fontWeight: "700", marginBottom: 2 },
  actionDesc: { fontSize: 13, lineHeight: 18 },
  confirmBtns: { flexDirection: "row", gap: 10, marginTop: 16 },
  outlineBtn: {
    borderWidth: 1,
    paddingVertical: 13,
    paddingHorizontal: 18,
    alignItems: "center",
    justifyContent: "center",
  },
});

const rsvpStyles = StyleSheet.create({
  rsvpSection: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    marginBottom: 4,
  },
  rsvpHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 12,
  },
  rsvpHeaderText: {
    fontSize: 14,
    fontWeight: "700",
    flex: 1,
  },
  rsvpBadge: {
    borderRadius: 20,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  rsvpBadgeText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#92400e",
  },
  statRow: {
    borderTopWidth: 1,
    paddingTop: 8,
    marginBottom: 10,
  },
  statText: {
    fontSize: 12,
  },
  emptyState: {
    alignItems: "center",
    paddingVertical: 16,
    gap: 4,
  },
  emptyEmoji: { fontSize: 28 },
  emptyTitle: { fontSize: 14, fontWeight: "700" },
  emptySubtitle: { fontSize: 12, textAlign: "center" },
  rsvpRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderRadius: 10,
    borderWidth: 1,
    padding: 10,
    marginBottom: 8,
  },
  rsvpAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "#fef3c7",
    borderWidth: 1,
    borderColor: "#fde68a",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  rsvpAvatarText: { fontSize: 11, fontWeight: "800", color: "#92400e" },
  rsvpInfo: { flex: 1, minWidth: 0 },
  rsvpNameRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    flexWrap: "wrap",
  },
  rsvpName: { fontSize: 13, fontWeight: "700" },
  emailedBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    backgroundColor: "#e0f2fe",
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderWidth: 1,
    borderColor: "#bae6fd",
  },
  emailedBadgeText: {
    fontSize: 10,
    fontWeight: "600",
    color: "#0369a1",
  },
  rsvpContact: { fontSize: 11, marginTop: 1 },
  rsvpFamily: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    flexShrink: 0,
  },
  rsvpFamilyText: { fontSize: 11, fontWeight: "600" },
});
