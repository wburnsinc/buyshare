import { Feather } from "@expo/vector-icons";
import { useGetListings } from "@workspace/api-client-react";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useCallback } from "react";
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ListingCard } from "@/components/ListingCard";
import { useColors } from "@/hooks/useColors";

const SHARE_LOGO = "https://bluetruck.co/assets/share-logo.png";

const CATEGORIES = [
  { slug: "poolshare", label: "PoolShare", sub: "Private pools", icon: "droplet" as const, color: "#0e7490" },
  { slug: "boatshare", label: "BoatShare", sub: "Boats & docks", icon: "anchor" as const, color: "#1d4ed8" },
  { slug: "parkshare", label: "ParkShare", sub: "Parking spots", icon: "map-pin" as const, color: "#6b7280" },
  { slug: "yardshare", label: "YardShare", sub: "Outdoor yards", icon: "feather" as const, color: "#16a34a" },
  { slug: "homeshare", label: "HomeShare", sub: "Rooms & spaces", icon: "home" as const, color: "#7c3aed" },
  { slug: "rvshare", label: "RVShare", sub: "RVs & campers", icon: "truck" as const, color: "#ea580c" },
];

function CategoryCard({ item }: { item: typeof CATEGORIES[0] }) {
  const colors = useColors();
  return (
    <Pressable
      testID={`category-${item.slug}`}
      onPress={() => router.push({ pathname: "/(tabs)/browse", params: { category: item.slug } })}
      style={({ pressed }) => [
        styles.categoryCard,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
          opacity: pressed ? 0.88 : 1,
          transform: [{ scale: pressed ? 0.97 : 1 }],
        },
      ]}
    >
      <View style={[styles.categoryIcon, { backgroundColor: item.color + "18" }]}>
        <Feather name={item.icon} size={22} color={item.color} />
      </View>
      <Text style={[styles.categoryLabel, { color: colors.foreground }]}>{item.label}</Text>
      <Text style={[styles.categorySub, { color: colors.mutedForeground }]}>{item.sub}</Text>
    </Pressable>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";

  const { data: listings, isLoading, refetch, isRefetching } = useGetListings({});

  const topInset = isWeb ? 67 : insets.top;
  const featuredListings = listings?.slice(0, 4) ?? [];

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: isWeb ? 34 : insets.bottom + 80 }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={isRefetching}
          onRefresh={onRefresh}
          tintColor={colors.primary}
        />
      }
    >
      <LinearGradient
        colors={["#0e7490", "#0891b2", "#0c4a6e"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.hero, { paddingTop: topInset + 20 }]}
      >
        <Image
          source={{ uri: SHARE_LOGO }}
          style={styles.logo}
          resizeMode="contain"
        />
        <Text style={styles.heroTagline}>Share what you have.{"\n"}Rent what you need.</Text>
        <Pressable
          testID="hero-browse-btn"
          onPress={() => router.push("/(tabs)/browse")}
          style={styles.heroCta}
        >
          <Feather name="search" size={16} color="#0e7490" />
          <Text style={styles.heroCtaText}>Browse listings</Text>
        </Pressable>
      </LinearGradient>

      <View style={[styles.section, { paddingHorizontal: 16, paddingTop: 24 }]}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Categories</Text>
        <View style={styles.categoryGrid}>
          {CATEGORIES.map((cat) => (
            <CategoryCard key={cat.slug} item={cat} />
          ))}
        </View>
      </View>

      <View style={[styles.section, { paddingHorizontal: 16, paddingTop: 8 }]}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Recent Listings</Text>
          <Pressable onPress={() => router.push("/(tabs)/browse")} testID="see-all-btn">
            <Text style={[styles.seeAll, { color: colors.primary }]}>See all</Text>
          </Pressable>
        </View>

        {isLoading ? (
          <View style={styles.loadingBox}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        ) : featuredListings.length === 0 ? (
          <View style={[styles.emptyBox, { borderColor: colors.border, borderRadius: colors.radius }]}>
            <Feather name="inbox" size={32} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No listings yet</Text>
          </View>
        ) : (
          featuredListings.map((listing) => (
            <ListingCard
              key={listing.id}
              id={listing.id}
              title={listing.title}
              category={listing.category}
              dailyRate={listing.dailyRate}
              location={listing.location}
              photos={listing.photos}
              averageRating={listing.averageRating}
              reviewCount={listing.reviewCount}
            />
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  hero: {
    paddingHorizontal: 24,
    paddingBottom: 36,
    alignItems: "flex-start",
  },
  logo: {
    width: 120,
    height: 40,
    marginBottom: 16,
  },
  heroTagline: {
    fontSize: 26,
    fontWeight: "700",
    color: "#ffffff",
    lineHeight: 34,
    marginBottom: 20,
  },
  heroCta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#ffffff",
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 50,
  },
  heroCtaText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#0e7490",
  },
  section: {
    gap: 12,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
  },
  seeAll: {
    fontSize: 14,
    fontWeight: "600",
  },
  categoryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  categoryCard: {
    width: "47.5%",
    borderWidth: 1,
    padding: 14,
    gap: 6,
  },
  categoryIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 2,
  },
  categoryLabel: {
    fontSize: 15,
    fontWeight: "700",
  },
  categorySub: {
    fontSize: 12,
    lineHeight: 16,
  },
  loadingBox: {
    paddingVertical: 48,
    alignItems: "center",
  },
  emptyBox: {
    borderWidth: 1,
    borderStyle: "dashed",
    paddingVertical: 36,
    alignItems: "center",
    gap: 10,
  },
  emptyText: {
    fontSize: 14,
  },
});
