import { Feather } from "@expo/vector-icons";
import { useGetListings } from "@workspace/api-client-react";
import { router, useLocalSearchParams } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ListingCard } from "@/components/ListingCard";
import { MapListingsView } from "@/components/MapListingsView";
import { useColors } from "@/hooks/useColors";

const FILTER_CATEGORIES = [
  { label: "All", value: "" },
  { label: "Pool", value: "poolshare" },
  { label: "Boat", value: "boatshare" },
  { label: "Parking", value: "parkshare" },
  { label: "Yard", value: "yardshare" },
  { label: "Home", value: "homeshare" },
  { label: "RV", value: "rvshare" },
];

type ViewMode = "list" | "map";

export default function BrowseScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";
  const params = useLocalSearchParams<{ category?: string }>();

  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState(params.category ?? "");
  const [viewMode, setViewMode] = useState<ViewMode>("list");

  useEffect(() => {
    if (params.category) setActiveCategory(params.category);
  }, [params.category]);

  const { data: listings, isLoading, refetch, isRefetching } = useGetListings({
    category: activeCategory || undefined,
    search: search || undefined,
  });

  const topInset = isWeb ? 67 : insets.top;
  const bottomInset = isWeb ? 34 : insets.bottom + 80;

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: topInset + 12,
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <View style={styles.titleRow}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Browse</Text>
          <View style={[styles.viewToggle, { backgroundColor: colors.muted, borderRadius: 10 }]}>
            <Pressable
              testID="view-toggle-list"
              onPress={() => setViewMode("list")}
              style={[
                styles.toggleBtn,
                viewMode === "list" && [styles.toggleBtnActive, { backgroundColor: colors.background, borderRadius: 8 }],
              ]}
            >
              <Feather
                name="list"
                size={17}
                color={viewMode === "list" ? colors.primary : colors.mutedForeground}
              />
            </Pressable>
            <Pressable
              testID="view-toggle-map"
              onPress={() => setViewMode("map")}
              style={[
                styles.toggleBtn,
                viewMode === "map" && [styles.toggleBtnActive, { backgroundColor: colors.background, borderRadius: 8 }],
              ]}
            >
              <Feather
                name="map"
                size={17}
                color={viewMode === "map" ? colors.primary : colors.mutedForeground}
              />
            </Pressable>
          </View>
        </View>

        <View style={[styles.searchBar, { backgroundColor: colors.muted, borderRadius: colors.radius }]}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            testID="search-input"
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="Search listings..."
            placeholderTextColor={colors.mutedForeground}
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
          />
          {!!search && (
            <Pressable onPress={() => setSearch("")}>
              <Feather name="x" size={16} color={colors.mutedForeground} />
            </Pressable>
          )}
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filtersRow}
        >
          {FILTER_CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat.value;
            return (
              <Pressable
                key={cat.value}
                testID={`filter-${cat.value || "all"}`}
                onPress={() => setActiveCategory(cat.value)}
                style={[
                  styles.filterChip,
                  {
                    backgroundColor: isActive ? colors.primary : colors.muted,
                    borderRadius: 50,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    { color: isActive ? colors.primaryForeground : colors.mutedForeground },
                  ]}
                >
                  {cat.label}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      {isLoading ? (
        <View style={styles.loadingBox}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : viewMode === "map" ? (
        <MapListingsView listings={listings ?? []} />
      ) : (
        <FlatList
          data={listings ?? []}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <ListingCard
              id={item.id}
              title={item.title}
              category={item.category}
              dailyRate={item.dailyRate}
              location={item.location}
              photos={item.photos}
              averageRating={item.averageRating}
              reviewCount={item.reviewCount}
            />
          )}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: bottomInset },
          ]}
          onRefresh={onRefresh}
          refreshing={isRefetching}
          scrollEnabled={!!(listings && listings.length > 0)}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={[styles.emptyBox, { borderColor: colors.border, borderRadius: colors.radius }]}>
              <Feather name="inbox" size={36} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No listings found</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                {search ? "Try a different search term" : "Check back soon for new listings"}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    borderBottomWidth: 1,
    gap: 10,
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: "700",
  },
  viewToggle: {
    flexDirection: "row",
    padding: 3,
    gap: 2,
  },
  toggleBtn: {
    padding: 6,
  },
  toggleBtnActive: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
    elevation: 2,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
  },
  filtersRow: {
    gap: 8,
    paddingRight: 16,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 7,
  },
  filterChipText: {
    fontSize: 13,
    fontWeight: "600",
  },
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 14,
  },
  loadingBox: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyBox: {
    borderWidth: 1,
    borderStyle: "dashed",
    paddingVertical: 52,
    alignItems: "center",
    gap: 10,
    marginTop: 20,
  },
  emptyTitle: {
    fontSize: 17,
    fontWeight: "600",
  },
  emptyText: {
    fontSize: 14,
    textAlign: "center",
    paddingHorizontal: 32,
  },
});
