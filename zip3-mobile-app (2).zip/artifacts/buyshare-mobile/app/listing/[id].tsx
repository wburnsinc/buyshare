import { Feather } from "@expo/vector-icons";
import { useCalculateBooking, useGetListing, useGetListingReviews } from "@workspace/api-client-react";
import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import * as WebBrowser from "expo-web-browser";
import { router, useLocalSearchParams } from "expo-router";
import React, { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";

// ─── helpers ──────────────────────────────────────────────────────────────────

function fmt(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

function fmtShort(cents: number) {
  return `$${(cents / 100).toFixed(0)}`;
}

function isoDate(d: Date) {
  return d.toISOString().split("T")[0];
}

function addDays(d: Date, n: number) {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}

function daysBetween(a: Date, b: Date) {
  return Math.round((b.getTime() - a.getTime()) / 86400000);
}

function monthName(year: number, month: number) {
  return new Date(year, month, 1).toLocaleString("en-US", { month: "long", year: "numeric" });
}

const WEEKDAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

// ─── DateRangePicker ──────────────────────────────────────────────────────────

interface DateRangePickerProps {
  startDate: Date | null;
  endDate: Date | null;
  onSelectStart: (d: Date) => void;
  onSelectEnd: (d: Date) => void;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}

function DateRangePicker({ startDate, endDate, onSelectStart, onSelectEnd, colors }: DateRangePickerProps) {
  const today = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selectingEnd, setSelectingEnd] = useState(false);

  const firstOfMonth = new Date(viewYear, viewMonth, 1);
  const startDow = firstOfMonth.getDay();
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();

  const cells: (Date | null)[] = [];
  for (let i = 0; i < startDow; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(viewYear, viewMonth, d));

  const prevMonth = () => {
    if (viewMonth === 0) { setViewYear(y => y - 1); setViewMonth(11); }
    else setViewMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewYear(y => y + 1); setViewMonth(0); }
    else setViewMonth(m => m + 1);
  };

  const handleDayPress = (day: Date) => {
    Haptics.selectionAsync();
    if (!startDate || selectingEnd === false && !endDate) {
      onSelectStart(day);
      setSelectingEnd(true);
    } else if (selectingEnd) {
      if (day < startDate!) {
        onSelectStart(day);
        setSelectingEnd(true);
      } else {
        onSelectEnd(day);
        setSelectingEnd(false);
      }
    } else {
      onSelectStart(day);
      setSelectingEnd(true);
    }
  };

  const inRange = (day: Date) => {
    if (!startDate || !endDate) return false;
    return day > startDate && day < endDate;
  };
  const isStart = (day: Date) => startDate && isoDate(day) === isoDate(startDate);
  const isEnd = (day: Date) => endDate && isoDate(day) === isoDate(endDate);
  const isPast = (day: Date) => day < today;

  return (
    <View style={{ gap: 10 }}>
      <View style={dpStyles.header}>
        <Pressable onPress={prevMonth} hitSlop={12} style={dpStyles.navBtn}>
          <Feather name="chevron-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[dpStyles.monthLabel, { color: colors.foreground }]}>
          {monthName(viewYear, viewMonth)}
        </Text>
        <Pressable onPress={nextMonth} hitSlop={12} style={dpStyles.navBtn}>
          <Feather name="chevron-right" size={20} color={colors.foreground} />
        </Pressable>
      </View>

      <View style={dpStyles.weekRow}>
        {WEEKDAYS.map(d => (
          <Text key={d} style={[dpStyles.weekDay, { color: colors.mutedForeground }]}>{d}</Text>
        ))}
      </View>

      <View style={dpStyles.grid}>
        {cells.map((day, i) => {
          if (!day) return <View key={`e-${i}`} style={dpStyles.cell} />;
          const past = isPast(day);
          const start = isStart(day);
          const end = isEnd(day);
          const range = inRange(day);

          return (
            <Pressable
              key={isoDate(day)}
              onPress={() => !past && handleDayPress(day)}
              disabled={past}
              style={[
                dpStyles.cell,
                range && { backgroundColor: colors.primary + "22" },
                (start || end) && { backgroundColor: colors.primary, borderRadius: 8 },
              ]}
            >
              <Text
                style={[
                  dpStyles.dayText,
                  past && { color: colors.mutedForeground + "50" },
                  !past && !start && !end && { color: colors.foreground },
                  (start || end) && { color: "#fff", fontWeight: "700" },
                  range && { color: colors.primary },
                ]}
              >
                {day.getDate()}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View style={dpStyles.legend}>
        <View style={dpStyles.legendItem}>
          <Feather name="circle" size={10} color={colors.primary} />
          <Text style={[dpStyles.legendText, { color: colors.mutedForeground }]}>
            {selectingEnd && startDate ? "Pick end date" : "Pick start date"}
          </Text>
        </View>
        {startDate && (
          <Text style={[dpStyles.legendText, { color: colors.foreground, fontWeight: "600" }]}>
            {isoDate(startDate)}{endDate ? ` → ${isoDate(endDate)}` : ""}
          </Text>
        )}
      </View>
    </View>
  );
}

const dpStyles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 4,
  },
  navBtn: {
    padding: 6,
  },
  monthLabel: {
    fontSize: 16,
    fontWeight: "700",
  },
  weekRow: {
    flexDirection: "row",
  },
  weekDay: {
    flex: 1,
    textAlign: "center",
    fontSize: 12,
    fontWeight: "600",
    paddingVertical: 4,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  cell: {
    width: `${100 / 7}%`,
    aspectRatio: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  dayText: {
    fontSize: 14,
    textAlign: "center",
  },
  legend: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 2,
    paddingTop: 2,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  legendText: {
    fontSize: 12,
  },
});

// ─── BookingModal ─────────────────────────────────────────────────────────────

type BookingStep = "dates" | "pricing" | "paying";

interface BookingModalProps {
  visible: boolean;
  onClose: () => void;
  listingId: string;
  listingTitle: string;
  dailyRate: number;
  securityDeposit: number;
  deliveryAvailable: boolean;
  deliveryFee?: number | null;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  renterId: string;
  authToken: string | null;
}

function BookingModal({
  visible,
  onClose,
  listingId,
  listingTitle,
  dailyRate,
  securityDeposit,
  deliveryAvailable,
  deliveryFee,
  colors,
  renterId,
  authToken,
}: BookingModalProps) {
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState<BookingStep>("dates");
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [addProtection, setAddProtection] = useState(false);
  const [wantDelivery, setWantDelivery] = useState(false);
  const [paying, setPaying] = useState(false);

  const days = startDate && endDate ? daysBetween(startDate, endDate) : 0;
  const datesValid = startDate !== null && endDate !== null && days >= 1;

  const calcMutation = useCalculateBooking();

  const handleSelectStart = (d: Date) => {
    setStartDate(d);
    setEndDate(null);
  };
  const handleSelectEnd = (d: Date) => {
    setEndDate(d);
  };

  const goToPricing = async () => {
    if (!datesValid) return;
    await calcMutation.mutateAsync({
      data: {
        listingId,
        startDate: isoDate(startDate!),
        endDate: isoDate(endDate!),
        addProtection,
        deliveryRequested: wantDelivery,
      },
    });
    setStep("pricing");
  };

  const handlePay = async () => {
    if (!datesValid || paying) return;
    setPaying(true);
    try {
      const baseUrl = process.env.EXPO_PUBLIC_DOMAIN
        ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
        : "";
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (authToken) headers["Authorization"] = `Bearer ${authToken}`;
      const res = await fetch(`${baseUrl}/api/bookings/stripe-checkout`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          listingId,
          startDate: isoDate(startDate!),
          endDate: isoDate(endDate!),
          addProtection,
          deliveryRequested: wantDelivery,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        Alert.alert("Payment Error", data.error ?? "Could not start checkout.");
        return;
      }
      onClose();
      const result = await WebBrowser.openAuthSessionAsync(
        data.checkoutUrl,
        "buyshare-mobile://",
      );
      if (result.type === "success" && result.url) {
        const url = new URL(result.url);
        const bookingId = url.searchParams.get("bookingId") ?? data.bookingId;
        const status = url.searchParams.get("status") ?? "success";
        router.push(`/booking-confirm?bookingId=${bookingId}&status=${status}`);
      } else {
        router.push(`/booking-confirm?bookingId=${data.bookingId}&status=cancel`);
      }
    } catch (err: any) {
      Alert.alert("Error", err?.message ?? "Something went wrong.");
    } finally {
      setPaying(false);
    }
  };

  const handleClose = () => {
    setStep("dates");
    setStartDate(null);
    setEndDate(null);
    setAddProtection(false);
    setWantDelivery(false);
    onClose();
  };

  const calc = calcMutation.data;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={handleClose}
    >
      <View style={[modalStyles.container, { backgroundColor: colors.background }]}>
        <View style={[modalStyles.header, { borderBottomColor: colors.border, paddingTop: insets.top + 16 }]}>
          <Pressable onPress={handleClose} hitSlop={10} style={modalStyles.closeBtn}>
            <Feather name="x" size={22} color={colors.foreground} />
          </Pressable>
          <Text style={[modalStyles.title, { color: colors.foreground }]}>
            {step === "dates" ? "Choose Dates" : step === "pricing" ? "Price Breakdown" : "Confirm & Pay"}
          </Text>
          <View style={{ width: 32 }} />
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={[modalStyles.body, { paddingBottom: insets.bottom + 80 }]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {step === "dates" && (
            <View style={{ gap: 20 }}>
              <DateRangePicker
                startDate={startDate}
                endDate={endDate}
                onSelectStart={handleSelectStart}
                onSelectEnd={handleSelectEnd}
                colors={colors}
              />

              {deliveryAvailable && (
                <View style={[modalStyles.toggleRow, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={[modalStyles.toggleLabel, { color: colors.foreground }]}>
                      Request Delivery
                    </Text>
                    {deliveryFee ? (
                      <Text style={[modalStyles.toggleSub, { color: colors.mutedForeground }]}>
                        +{fmtShort(deliveryFee)} delivery fee
                      </Text>
                    ) : (
                      <Text style={[modalStyles.toggleSub, { color: colors.mutedForeground }]}>
                        Free delivery
                      </Text>
                    )}
                  </View>
                  <Switch
                    value={wantDelivery}
                    onValueChange={setWantDelivery}
                    trackColor={{ true: colors.primary }}
                  />
                </View>
              )}

              <View style={[modalStyles.toggleRow, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={[modalStyles.toggleLabel, { color: colors.foreground }]}>
                    Add Buyshare Protection
                  </Text>
                  <Text style={[modalStyles.toggleSub, { color: colors.mutedForeground }]}>
                    +$3.99 · Damage coverage & support
                  </Text>
                </View>
                <Switch
                  value={addProtection}
                  onValueChange={setAddProtection}
                  trackColor={{ true: colors.primary }}
                />
              </View>
            </View>
          )}

          {step === "pricing" && calc && (
            <View style={{ gap: 16 }}>
              <View style={[modalStyles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
                <Text style={[modalStyles.cardTitle, { color: colors.foreground }]}>{listingTitle}</Text>
                <Text style={[modalStyles.cardSub, { color: colors.mutedForeground }]}>
                  {isoDate(startDate!)} → {isoDate(endDate!)} · {days} {days === 1 ? "day" : "days"}
                </Text>
              </View>

              <View style={[modalStyles.breakdownCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
                <LineItem label={`Rental (${fmtShort(dailyRate)}/day × ${days} ${days === 1 ? "day" : "days"})`} value={fmt(calc.rentalAmountCents)} colors={colors} />

                {calc.securityDepositCents > 0 && (
                  <LineItem label="Security deposit (refundable)" value={fmt(calc.securityDepositCents)} colors={colors} muted />
                )}
                {calc.protectionFeeCents > 0 && (
                  <LineItem label="Buyshare Protection" value={fmt(calc.protectionFeeCents)} colors={colors} />
                )}
                {calc.deliveryFeeCents > 0 && (
                  <LineItem label="Delivery fee" value={fmt(calc.deliveryFeeCents)} colors={colors} />
                )}
                {calc.stripeFeesCents > 0 && (
                  <LineItem label="Processing fee" value={fmt(calc.stripeFeesCents)} colors={colors} muted />
                )}

                <View style={[modalStyles.divider, { backgroundColor: colors.border }]} />

                <View style={modalStyles.totalRow}>
                  <Text style={[modalStyles.totalLabel, { color: colors.foreground }]}>Total due today</Text>
                  <Text style={[modalStyles.totalValue, { color: colors.primary }]}>
                    {fmt(calc.totalChargeCents)}
                  </Text>
                </View>

                {calc.securityDepositCents > 0 && (
                  <Text style={[modalStyles.depositNote, { color: colors.mutedForeground }]}>
                    Security deposit of {fmt(calc.securityDepositCents)} is held and returned after a successful rental.
                  </Text>
                )}
              </View>
            </View>
          )}
        </ScrollView>

        <View style={[modalStyles.footer, { borderTopColor: colors.border, paddingBottom: insets.bottom + 12, backgroundColor: colors.card }]}>
          {step === "dates" && (
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                goToPricing();
              }}
              disabled={!datesValid || calcMutation.isPending}
              style={[
                modalStyles.footerBtn,
                {
                  backgroundColor: datesValid ? colors.primary : colors.muted,
                  borderRadius: colors.radius,
                },
              ]}
            >
              {calcMutation.isPending ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <Text style={[modalStyles.footerBtnText, { color: datesValid ? colors.primaryForeground : colors.mutedForeground }]}>
                  {datesValid ? `Review Pricing · ${days} ${days === 1 ? "day" : "days"}` : "Select dates to continue"}
                </Text>
              )}
            </Pressable>
          )}

          {step === "pricing" && (
            <View style={{ gap: 10 }}>
              <Pressable
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                  handlePay();
                }}
                disabled={paying}
                style={[
                  modalStyles.footerBtn,
                  { backgroundColor: colors.primary, borderRadius: colors.radius },
                ]}
              >
                {paying ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                    <Feather name="lock" size={16} color={colors.primaryForeground} />
                    <Text style={[modalStyles.footerBtnText, { color: colors.primaryForeground }]}>
                      Pay {calc ? fmt(calc.totalChargeCents) : ""}
                    </Text>
                  </View>
                )}
              </Pressable>
              <Pressable
                onPress={() => setStep("dates")}
                style={[modalStyles.backBtn, { borderColor: colors.border, borderRadius: colors.radius }]}
              >
                <Text style={[modalStyles.backBtnText, { color: colors.foreground }]}>Back</Text>
              </Pressable>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

function LineItem({ label, value, colors, muted }: { label: string; value: string; colors: any; muted?: boolean }) {
  return (
    <View style={modalStyles.lineItem}>
      <Text style={[modalStyles.lineLabel, { color: muted ? colors.mutedForeground : colors.foreground }]}>{label}</Text>
      <Text style={[modalStyles.lineValue, { color: muted ? colors.mutedForeground : colors.foreground }]}>{value}</Text>
    </View>
  );
}

const modalStyles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  closeBtn: {
    width: 32,
    height: 32,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 17,
    fontWeight: "700",
  },
  body: {
    padding: 20,
  },
  toggleRow: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    padding: 14,
    gap: 12,
  },
  toggleLabel: {
    fontSize: 15,
    fontWeight: "600",
  },
  toggleSub: {
    fontSize: 13,
  },
  card: {
    borderWidth: 1,
    padding: 14,
    gap: 4,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  cardSub: {
    fontSize: 13,
  },
  breakdownCard: {
    borderWidth: 1,
    padding: 14,
    gap: 12,
  },
  lineItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  lineLabel: {
    fontSize: 14,
    flex: 1,
    paddingRight: 8,
  },
  lineValue: {
    fontSize: 14,
    fontWeight: "500",
  },
  divider: {
    height: 1,
  },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: "700",
  },
  totalValue: {
    fontSize: 20,
    fontWeight: "700",
  },
  depositNote: {
    fontSize: 12,
    lineHeight: 17,
    fontStyle: "italic",
  },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    borderTopWidth: 1,
    paddingHorizontal: 20,
    paddingTop: 14,
  },
  footerBtn: {
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    minHeight: 50,
  },
  footerBtnText: {
    fontSize: 16,
    fontWeight: "700",
  },
  backBtn: {
    paddingVertical: 12,
    alignItems: "center",
    borderWidth: 1,
  },
  backBtnText: {
    fontSize: 15,
    fontWeight: "600",
  },
});

// ─── Main listing screen ──────────────────────────────────────────────────────

export default function ListingDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, token } = useAuth();
  const isWeb = Platform.OS === "web";
  const bottomInset = isWeb ? 34 : insets.bottom;
  const topInset = isWeb ? 67 : insets.top;

  const [photoIndex, setPhotoIndex] = useState(0);
  const [bookingOpen, setBookingOpen] = useState(false);

  const { data: listing, isLoading, isError } = useGetListing(id ?? "");
  const { data: reviews } = useGetListingReviews(id ?? "");

  const handleBookNow = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (!user) {
      router.push("/(tabs)/profile");
      return;
    }
    setBookingOpen(true);
  }, [user]);

  if (isLoading) {
    return (
      <View style={[styles.loadingBox, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (isError || !listing) {
    return (
      <View style={[styles.loadingBox, { backgroundColor: colors.background }]}>
        <Feather name="alert-circle" size={36} color={colors.mutedForeground} />
        <Text style={[styles.errorText, { color: colors.mutedForeground }]}>Listing not found</Text>
        <Pressable onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}>
          <Text style={{ color: colors.primaryForeground, fontWeight: "600" }}>Go Back</Text>
        </Pressable>
      </View>
    );
  }

  const photos = listing.photos ?? [];
  const dailyRateDisplay = `$${(listing.dailyRate / 100).toFixed(0)}`;
  const catLabel = listing.category?.replace(/share$/i, "").toUpperCase();
  const avgRating = listing.averageRating;
  const reviewCount = listing.reviewCount ?? 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: bottomInset + 100 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.photoContainer}>
          {photos.length > 0 ? (
            <Image
              source={{ uri: photos[photoIndex] }}
              style={styles.photo}
              contentFit="cover"
              transition={200}
            />
          ) : (
            <View style={[styles.photoPlaceholder, { backgroundColor: colors.muted }]}>
              <Feather name="image" size={48} color={colors.mutedForeground} />
            </View>
          )}

          <Pressable
            onPress={() => router.back()}
            style={[styles.backOverlay, { top: topInset + 10, backgroundColor: "rgba(0,0,0,0.4)" }]}
          >
            <Feather name="arrow-left" size={20} color="#fff" />
          </Pressable>

          {photos.length > 1 && (
            <View style={styles.photoDots}>
              {photos.map((_, i) => (
                <Pressable key={i} onPress={() => setPhotoIndex(i)}>
                  <View
                    style={[
                      styles.dot,
                      { backgroundColor: i === photoIndex ? "#fff" : "rgba(255,255,255,0.5)" },
                    ]}
                  />
                </Pressable>
              ))}
            </View>
          )}
        </View>

        <View style={styles.content}>
          <View style={styles.titleRow}>
            <View style={[styles.catBadge, { backgroundColor: colors.primary + "18", borderRadius: 6 }]}>
              <Text style={[styles.catLabel, { color: colors.primary }]}>{catLabel}</Text>
            </View>
            {!!avgRating && (
              <View style={styles.ratingRow}>
                <Feather name="star" size={13} color="#f59e0b" />
                <Text style={[styles.ratingText, { color: colors.foreground }]}>
                  {avgRating.toFixed(1)}
                </Text>
                <Text style={[styles.reviewCount, { color: colors.mutedForeground }]}>
                  ({reviewCount})
                </Text>
              </View>
            )}
          </View>

          <Text style={[styles.title, { color: colors.foreground }]}>{listing.title}</Text>

          <View style={styles.priceRow}>
            <Text style={[styles.price, { color: colors.primary }]}>{dailyRateDisplay}</Text>
            <Text style={[styles.priceUnit, { color: colors.mutedForeground }]}>/day</Text>
          </View>

          <View style={[styles.metaCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <View style={styles.metaItem}>
              <Feather name="map-pin" size={15} color={colors.mutedForeground} />
              <Text style={[styles.metaText, { color: colors.foreground }]}>{listing.location}</Text>
            </View>
            {listing.deliveryAvailable && (
              <View style={styles.metaItem}>
                <Feather name="truck" size={15} color={colors.mutedForeground} />
                <Text style={[styles.metaText, { color: colors.foreground }]}>
                  Delivery available
                  {listing.deliveryFee ? ` · $${(listing.deliveryFee / 100).toFixed(0)} fee` : ""}
                </Text>
              </View>
            )}
            {listing.securityDeposit > 0 && (
              <View style={styles.metaItem}>
                <Feather name="shield" size={15} color={colors.mutedForeground} />
                <Text style={[styles.metaText, { color: colors.foreground }]}>
                  ${(listing.securityDeposit / 100).toFixed(0)} security deposit
                </Text>
              </View>
            )}
          </View>

          <View style={styles.descSection}>
            <Text style={[styles.descTitle, { color: colors.foreground }]}>About this listing</Text>
            <Text style={[styles.desc, { color: colors.mutedForeground }]}>{listing.description}</Text>
          </View>

          {listing.owner && (
            <View style={[styles.ownerCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
              <View style={[styles.avatarCircle, { backgroundColor: colors.primary }]}>
                <Text style={styles.avatarText}>
                  {listing.owner.name?.charAt(0).toUpperCase() ?? "?"}
                </Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.ownerName, { color: colors.foreground }]}>{listing.owner.name}</Text>
                {listing.owner.isVerified && (
                  <View style={styles.verifiedRow}>
                    <Feather name="check-circle" size={12} color={colors.primary} />
                    <Text style={[styles.verifiedText, { color: colors.primary }]}>Verified host</Text>
                  </View>
                )}
              </View>
            </View>
          )}

          {reviews && reviews.length > 0 && (
            <View style={styles.reviewsSection}>
              <Text style={[styles.descTitle, { color: colors.foreground }]}>Reviews</Text>
              {reviews.slice(0, 3).map((review) => (
                <View
                  key={review.id}
                  style={[styles.reviewCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}
                >
                  <View style={styles.reviewHeader}>
                    <View style={[styles.reviewAvatar, { backgroundColor: colors.primary + "22" }]}>
                      <Text style={[styles.reviewAvatarText, { color: colors.primary }]}>
                        {review.reviewer?.name?.charAt(0).toUpperCase() ?? "?"}
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.reviewName, { color: colors.foreground }]}>
                        {review.reviewer?.name ?? "Anonymous"}
                      </Text>
                      <View style={styles.starsRow}>
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Feather
                            key={i}
                            name="star"
                            size={12}
                            color={i < (review.rating ?? 0) ? "#f59e0b" : colors.border}
                          />
                        ))}
                      </View>
                    </View>
                  </View>
                  {review.comment && (
                    <Text style={[styles.reviewComment, { color: colors.mutedForeground }]}>
                      {review.comment}
                    </Text>
                  )}
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      <View
        style={[
          styles.bookBar,
          {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
            paddingBottom: bottomInset + 12,
          },
        ]}
      >
        <View>
          <Text style={[styles.bookPrice, { color: colors.primary }]}>
            {dailyRateDisplay}<Text style={[styles.bookPriceUnit, { color: colors.mutedForeground }]}>/day</Text>
          </Text>
          {listing.securityDeposit > 0 && (
            <Text style={[styles.depositHint, { color: colors.mutedForeground }]}>
              +{fmtShort(listing.securityDeposit)} deposit
            </Text>
          )}
        </View>
        <Pressable
          testID="book-now-btn"
          onPress={handleBookNow}
          style={({ pressed }) => [
            styles.bookBtn,
            {
              backgroundColor: colors.primary,
              borderRadius: colors.radius,
              opacity: pressed ? 0.88 : 1,
            },
          ]}
        >
          <Text style={[styles.bookBtnText, { color: colors.primaryForeground }]}>Book Now</Text>
        </Pressable>
      </View>

      {user && (
        <BookingModal
          visible={bookingOpen}
          onClose={() => setBookingOpen(false)}
          listingId={id ?? ""}
          listingTitle={listing.title}
          dailyRate={listing.dailyRate}
          securityDeposit={listing.securityDeposit}
          deliveryAvailable={listing.deliveryAvailable ?? false}
          deliveryFee={listing.deliveryFee}
          colors={colors}
          renterId={user.id}
          authToken={token}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingBox: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  errorText: {
    fontSize: 16,
  },
  backBtn: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  photoContainer: {
    height: 280,
    position: "relative",
  },
  photo: {
    width: "100%",
    height: "100%",
  },
  photoPlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  backOverlay: {
    position: "absolute",
    left: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  photoDots: {
    position: "absolute",
    bottom: 12,
    alignSelf: "center",
    flexDirection: "row",
    gap: 6,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  content: {
    padding: 20,
    gap: 16,
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  catBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  catLabel: {
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.8,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: "600",
  },
  reviewCount: {
    fontSize: 13,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    lineHeight: 30,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: 2,
  },
  price: {
    fontSize: 28,
    fontWeight: "700",
  },
  priceUnit: {
    fontSize: 16,
  },
  metaCard: {
    borderWidth: 1,
    padding: 14,
    gap: 10,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  metaText: {
    fontSize: 14,
    flex: 1,
  },
  descSection: {
    gap: 8,
  },
  descTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  desc: {
    fontSize: 14,
    lineHeight: 22,
  },
  ownerCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    borderWidth: 1,
    padding: 14,
  },
  avatarCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    fontSize: 18,
    fontWeight: "700",
    color: "#fff",
  },
  ownerName: {
    fontSize: 15,
    fontWeight: "600",
  },
  verifiedRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 2,
  },
  verifiedText: {
    fontSize: 12,
    fontWeight: "500",
  },
  reviewsSection: {
    gap: 10,
  },
  reviewCard: {
    borderWidth: 1,
    padding: 12,
    gap: 8,
  },
  reviewHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  reviewAvatar: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },
  reviewAvatarText: {
    fontSize: 14,
    fontWeight: "700",
  },
  reviewName: {
    fontSize: 14,
    fontWeight: "600",
  },
  starsRow: {
    flexDirection: "row",
    gap: 2,
    marginTop: 2,
  },
  reviewComment: {
    fontSize: 13,
    lineHeight: 19,
  },
  bookBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: 14,
    borderTopWidth: 1,
  },
  bookPrice: {
    fontSize: 22,
    fontWeight: "700",
  },
  bookPriceUnit: {
    fontSize: 14,
    fontWeight: "400",
  },
  depositHint: {
    fontSize: 12,
    marginTop: 1,
  },
  bookBtn: {
    paddingHorizontal: 28,
    paddingVertical: 14,
  },
  bookBtnText: {
    fontSize: 16,
    fontWeight: "700",
  },
});
