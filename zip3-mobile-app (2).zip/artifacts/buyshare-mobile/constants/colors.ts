const colors = {
  light: {
    text: "#0d1e2b",
    tint: "#0e7490",

    background: "#faf9f5",
    foreground: "#0d1e2b",

    card: "#ffffff",
    cardForeground: "#0d1e2b",

    primary: "#0e7490",
    primaryForeground: "#ffffff",

    secondary: "#ede8d8",
    secondaryForeground: "#0d1e2b",

    muted: "#edeae4",
    mutedForeground: "#5d7280",

    accent: "#f07540",
    accentForeground: "#ffffff",

    destructive: "#f23838",
    destructiveForeground: "#ffffff",

    border: "#dcd8cf",
    input: "#dcd8cf",
  },

  dark: {
    text: "#faf9f5",
    tint: "#12a8cc",

    background: "#0a1620",
    foreground: "#faf9f5",

    card: "#0c1c2b",
    cardForeground: "#faf9f5",

    primary: "#12a8cc",
    primaryForeground: "#0a1620",

    secondary: "#1f3348",
    secondaryForeground: "#faf9f5",

    muted: "#172535",
    mutedForeground: "#8aa0b0",

    accent: "#f38050",
    accentForeground: "#0a1620",

    destructive: "#f23838",
    destructiveForeground: "#ffffff",

    border: "#1f3348",
    input: "#1f3348",
  },

  radius: 12,
};

export default colors;
