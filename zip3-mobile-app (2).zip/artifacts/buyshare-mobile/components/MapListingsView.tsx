import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, View } from "react-native";

import { useColors } from "@/hooks/useColors";

interface MapListing {
  id: string;
  title: string;
  category: string;
  dailyRate: number;
  location: string;
  latitude?: number;
  longitude?: number;
  photos?: string[];
}

interface MapListingsViewProps {
  listings: MapListing[];
}

export function MapListingsView(_props: MapListingsViewProps) {
  const colors = useColors();
  return (
    <View style={[styles.fallback, { backgroundColor: colors.muted }]}>
      <Feather name="map" size={40} color={colors.mutedForeground} />
      <Text style={[styles.fallbackTitle, { color: colors.foreground }]}>
        Map view is available on mobile
      </Text>
      <Text style={[styles.fallbackText, { color: colors.mutedForeground }]}>
        Open the SHARE app on your phone to browse listings on the map
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  fallback: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    padding: 32,
  },
  fallbackTitle: {
    fontSize: 17,
    fontWeight: "600",
    textAlign: "center",
  },
  fallbackText: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 20,
  },
});
