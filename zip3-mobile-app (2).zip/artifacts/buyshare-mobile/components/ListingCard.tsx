import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import { router } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { useColors } from "@/hooks/useColors";

interface ListingCardProps {
  id: string;
  title: string;
  category: string;
  dailyRate: number;
  location: string;
  photos: string[];
  averageRating?: number;
  reviewCount?: number;
  deliveryAvailable?: boolean;
}

const CATEGORY_ICONS: Record<string, string> = {
  poolshare: "droplet",
  boatshare: "anchor",
  parkshare: "map-pin",
  yardshare: "feather",
  homeshare: "home",
  rvshare: "truck",
};

export function ListingCard({
  id,
  title,
  category,
  dailyRate,
  location,
  photos,
  averageRating,
  reviewCount,
}: ListingCardProps) {
  const colors = useColors();
  const iconName = CATEGORY_ICONS[category?.toLowerCase()] ?? "tag";
  const catLabel = category?.replace(/share$/i, "") ?? "";

  return (
    <Pressable
      testID={`listing-card-${id}`}
      onPress={() => router.push(`/listing/${id}`)}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
          opacity: pressed ? 0.92 : 1,
          transform: [{ scale: pressed ? 0.98 : 1 }],
        },
      ]}
    >
      <View style={[styles.photoBox, { borderRadius: colors.radius - 2, backgroundColor: colors.muted }]}>
        {photos?.[0] ? (
          <Image
            source={{ uri: photos[0] }}
            style={styles.photo}
            contentFit="cover"
            transition={200}
          />
        ) : (
          <View style={[styles.photoPlaceholder, { backgroundColor: colors.muted }]}>
            <Feather name={iconName as any} size={32} color={colors.mutedForeground} />
          </View>
        )}
        <View style={[styles.priceBadge, { backgroundColor: "rgba(255,255,255,0.95)" }]}>
          <Text style={[styles.priceText, { color: colors.foreground }]}>
            ${(dailyRate / 100).toFixed(0)}<Text style={styles.priceSuffix}>/day</Text>
          </Text>
        </View>
      </View>

      <View style={styles.info}>
        <View style={[styles.catBadge, { backgroundColor: colors.primary + "18", borderRadius: 6 }]}>
          <Text style={[styles.catLabel, { color: colors.primary }]}>
            {catLabel.toUpperCase()}
          </Text>
        </View>
        <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={2}>
          {title}
        </Text>
        <View style={styles.meta}>
          <Feather name="map-pin" size={11} color={colors.mutedForeground} />
          <Text style={[styles.metaText, { color: colors.mutedForeground }]} numberOfLines={1}>
            {location}
          </Text>
        </View>
        {!!averageRating && (
          <View style={styles.meta}>
            <Feather name="star" size={11} color="#f59e0b" />
            <Text style={[styles.metaText, { color: colors.mutedForeground }]}>
              {averageRating.toFixed(1)} ({reviewCount ?? 0})
            </Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    overflow: "hidden",
    marginBottom: 14,
  },
  photoBox: {
    height: 180,
    overflow: "hidden",
    position: "relative",
  },
  photo: {
    width: "100%",
    height: "100%",
  },
  photoPlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  priceBadge: {
    position: "absolute",
    bottom: 10,
    right: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 3,
  },
  priceText: {
    fontSize: 15,
    fontWeight: "700",
  },
  priceSuffix: {
    fontSize: 12,
    fontWeight: "400",
  },
  info: {
    padding: 12,
    gap: 5,
  },
  catBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 7,
    paddingVertical: 3,
    marginBottom: 2,
  },
  catLabel: {
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 0.8,
  },
  title: {
    fontSize: 15,
    fontWeight: "600",
    lineHeight: 20,
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    flex: 1,
  },
});
