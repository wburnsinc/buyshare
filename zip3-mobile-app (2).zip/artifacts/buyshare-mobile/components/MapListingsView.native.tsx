import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import MapView, { Callout, Marker } from "react-native-maps";

import { useColors } from "@/hooks/useColors";

const CATEGORY_COLORS: Record<string, string> = {
  poolshare: "#0ea5e9",
  boatshare: "#06b6d4",
  parkshare: "#22c55e",
  yardshare: "#84cc16",
  homeshare: "#f97316",
  rvshare: "#a855f7",
};

const CATEGORY_ICONS: Record<string, string> = {
  poolshare: "droplet",
  boatshare: "anchor",
  parkshare: "map-pin",
  yardshare: "feather",
  homeshare: "home",
  rvshare: "truck",
};

interface MapListing {
  id: string;
  title: string;
  category: string;
  dailyRate: number;
  location: string;
  latitude?: number;
  longitude?: number;
  photos?: string[];
}

interface MapListingsViewProps {
  listings: MapListing[];
}

export function MapListingsView({ listings }: MapListingsViewProps) {
  const colors = useColors();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const mappableListings = listings.filter(
    (l) => typeof l.latitude === "number" && typeof l.longitude === "number"
  );

  const initialRegion =
    mappableListings.length > 0
      ? (() => {
          const lats = mappableListings.map((l) => l.latitude as number);
          const lngs = mappableListings.map((l) => l.longitude as number);
          const minLat = Math.min(...lats);
          const maxLat = Math.max(...lats);
          const minLng = Math.min(...lngs);
          const maxLng = Math.max(...lngs);
          return {
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 1.4, 0.05),
            longitudeDelta: Math.max((maxLng - minLng) * 1.4, 0.05),
          };
        })()
      : {
          latitude: 26.142,
          longitude: -81.7948,
          latitudeDelta: 0.5,
          longitudeDelta: 0.5,
        };

  if (mappableListings.length === 0) {
    return (
      <View style={[styles.fallback, { backgroundColor: colors.muted }]}>
        <Feather name="map-pin" size={40} color={colors.mutedForeground} />
        <Text style={[styles.fallbackTitle, { color: colors.foreground }]}>
          No listings on the map yet
        </Text>
        <Text style={[styles.fallbackText, { color: colors.mutedForeground }]}>
          Listings will appear here once owners add their location
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.mapContainer}>
      <MapView
        style={StyleSheet.absoluteFill}
        initialRegion={initialRegion}
        showsUserLocation
        showsMyLocationButton={false}
      >
        {mappableListings.map((listing) => {
          const pinColor =
            CATEGORY_COLORS[listing.category?.toLowerCase()] ?? "#6366f1";
          const catLabel =
            listing.category?.replace(/share$/i, "").toUpperCase() ?? "";
          const iconName =
            CATEGORY_ICONS[listing.category?.toLowerCase()] ?? "tag";
          const isSelected = selectedId === listing.id;

          return (
            <Marker
              key={listing.id}
              coordinate={{
                latitude: listing.latitude as number,
                longitude: listing.longitude as number,
              }}
              onPress={() => setSelectedId(listing.id)}
              tracksViewChanges={false}
            >
              <View
                style={[
                  styles.pin,
                  {
                    backgroundColor: pinColor,
                    shadowColor: pinColor,
                    transform: [{ scale: isSelected ? 1.15 : 1 }],
                  },
                ]}
              >
                <Feather name={iconName as any} size={14} color="#fff" />
              </View>
              <View style={[styles.pinTail, { borderTopColor: pinColor }]} />

              <Callout
                tooltip
                onPress={() => router.push(`/listing/${listing.id}`)}
              >
                <View
                  style={[
                    styles.callout,
                    {
                      backgroundColor: colors.card,
                      borderColor: colors.border,
                      borderRadius: colors.radius,
                    },
                  ]}
                >
                  <View style={styles.calloutHeader}>
                    <View
                      style={[
                        styles.calloutCatBadge,
                        { backgroundColor: pinColor + "20" },
                      ]}
                    >
                      <Text style={[styles.calloutCat, { color: pinColor }]}>
                        {catLabel}
                      </Text>
                    </View>
                    <Text
                      style={[
                        styles.calloutPrice,
                        { color: colors.foreground },
                      ]}
                    >
                      ${(listing.dailyRate / 100).toFixed(0)}
                      <Text style={styles.calloutPriceSuffix}>/day</Text>
                    </Text>
                  </View>

                  <Text
                    style={[styles.calloutTitle, { color: colors.foreground }]}
                    numberOfLines={2}
                  >
                    {listing.title}
                  </Text>

                  <View style={styles.calloutMeta}>
                    <Feather
                      name="map-pin"
                      size={11}
                      color={colors.mutedForeground}
                    />
                    <Text
                      style={[
                        styles.calloutLocation,
                        { color: colors.mutedForeground },
                      ]}
                      numberOfLines={1}
                    >
                      {listing.location}
                    </Text>
                  </View>

                  <Pressable
                    style={[
                      styles.calloutBtn,
                      {
                        backgroundColor: pinColor,
                        borderRadius: colors.radius - 2,
                      },
                    ]}
                  >
                    <Text style={styles.calloutBtnText}>View Listing</Text>
                    <Feather name="arrow-right" size={13} color="#fff" />
                  </Pressable>
                </View>
              </Callout>
            </Marker>
          );
        })}
      </MapView>

      <View
        style={[
          styles.legend,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <Text style={[styles.legendCount, { color: colors.foreground }]}>
          {mappableListings.length} listing
          {mappableListings.length !== 1 ? "s" : ""}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mapContainer: {
    flex: 1,
  },
  fallback: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    padding: 32,
  },
  fallbackTitle: {
    fontSize: 17,
    fontWeight: "600",
    textAlign: "center",
  },
  fallbackText: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 20,
  },
  pin: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  pinTail: {
    alignSelf: "center",
    width: 0,
    height: 0,
    borderLeftWidth: 5,
    borderRightWidth: 5,
    borderTopWidth: 7,
    borderLeftColor: "transparent",
    borderRightColor: "transparent",
    marginTop: -1,
  },
  callout: {
    width: 220,
    padding: 12,
    borderWidth: 1,
    gap: 6,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 6,
  },
  calloutHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  calloutCatBadge: {
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 5,
  },
  calloutCat: {
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 0.8,
  },
  calloutPrice: {
    fontSize: 14,
    fontWeight: "700",
  },
  calloutPriceSuffix: {
    fontSize: 11,
    fontWeight: "400",
  },
  calloutTitle: {
    fontSize: 13,
    fontWeight: "600",
    lineHeight: 18,
  },
  calloutMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  calloutLocation: {
    fontSize: 11,
    flex: 1,
  },
  calloutBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
    gap: 5,
    marginTop: 2,
  },
  calloutBtnText: {
    color: "#fff",
    fontSize: 13,
    fontWeight: "600",
  },
  legend: {
    position: "absolute",
    top: 12,
    right: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  legendCount: {
    fontSize: 12,
    fontWeight: "600",
  },
});
