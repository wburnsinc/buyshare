# Deploy to Render

## Render.com Deployment

1. Create account at render.com
2. Create a PostgreSQL database — copy DATABASE_URL

### API (Web Service)
- Environment: Node
- Build Command: `pnpm install && pnpm --filter @workspace/api-server run build`
- Start Command: `node artifacts/api-server/dist/index.mjs`
- Add all env vars from .env.example

### Web Frontend (Static Site)
- Build Command: `pnpm install && pnpm --filter @workspace/buyshare run build`
- Publish Directory: `artifacts/buyshare/dist`
- Add redirect rule: `/* → /index.html` (status 200) for SPA routing

### Custom Domain
- Settings → Custom Domains → Add buyshare.co
- Update DNS: CNAME record pointing to your Render URL
