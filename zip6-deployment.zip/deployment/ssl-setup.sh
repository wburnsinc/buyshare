#!/bin/bash
# Install SSL certificate with Let's Encrypt
# Run as root on your server after pointing DNS to it

apt-get update
apt-get install -y certbot python3-certbot-nginx

# Replace with your domain
DOMAIN="buyshare.co"

certbot --nginx -d $DOMAIN -d www.$DOMAIN \
  --email admin@buyshare.co \
  --agree-tos \
  --non-interactive

# Auto-renew
systemctl enable certbot.timer
systemctl start certbot.timer

echo "SSL installed for $DOMAIN"
