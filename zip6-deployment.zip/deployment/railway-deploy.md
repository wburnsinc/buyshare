# Deploy to Railway

## Railway (Recommended for fast launch)

1. Push code to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add two services:

### API Service
- Root directory: `artifacts/api-server`
- Build command: `pnpm install && pnpm run build`
- Start command: `node dist/index.mjs`
- Port: 8080

### Web Service (Static)
- Root directory: `artifacts/buyshare`
- Build command: `pnpm install && pnpm run build`
- Output directory: `dist`

### Database
- Add Railway PostgreSQL plugin
- DATABASE_URL is auto-injected

### Environment Variables (API service)
Add all variables from `.env.example`
