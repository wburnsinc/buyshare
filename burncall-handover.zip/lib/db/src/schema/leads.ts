import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { businessesTable } from "./businesses";

export const leadsTable = pgTable("leads", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull().references(() => businessesTable.id),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  source: text("source").notNull().default("website"), // website | sms | phone | social
  channel: text("channel").notNull().default("web"), // web | sms | email | call
  message: text("message"),
  status: text("status").notNull().default("new"), // new | contacted | qualified | booked | won | lost | spam
  score: integer("score").default(0), // 0-100
  service: text("service"),
  zipCode: text("zip_code"),
  urgency: text("urgency"), // low | medium | high | emergency
  estimatedValue: integer("estimated_value"),
  aiResponseTime: integer("ai_response_time"), // seconds
  notes: text("notes"),
  tags: jsonb("tags").$type<string[]>().default([]),
  assignedTo: text("assigned_to"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  lastContactedAt: timestamp("last_contacted_at"),
});

export const insertLeadSchema = createInsertSchema(leadsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertLead = z.infer<typeof insertLeadSchema>;
export type Lead = typeof leadsTable.$inferSelect;
