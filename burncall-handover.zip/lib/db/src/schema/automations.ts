import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { businessesTable } from "./businesses";

export const automationsTable = pgTable("automations", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull().references(() => businessesTable.id),
  name: text("name").notNull(),
  type: text("type").notNull(), // instant_response | missed_call | follow_up | appointment_reminder | review_request
  triggerEvent: text("trigger_event").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  delayMinutes: integer("delay_minutes").default(0),
  channel: text("channel").notNull().default("sms"), // sms | email | both
  templateBody: text("template_body"),
  conditions: jsonb("conditions").$type<Record<string, unknown>>().default({}),
  stats: jsonb("stats").$type<{ triggered: number; sent: number; failed: number; opened: number }>().default({ triggered: 0, sent: 0, failed: 0, opened: 0 }),
  lastRunAt: timestamp("last_run_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertAutomationSchema = createInsertSchema(automationsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAutomation = z.infer<typeof insertAutomationSchema>;
export type Automation = typeof automationsTable.$inferSelect;
