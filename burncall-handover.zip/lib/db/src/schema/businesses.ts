import { pgTable, text, serial, boolean, jsonb, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const businessesTable = pgTable("businesses", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id").notNull().references(() => usersTable.id),
  name: text("name").notNull(),
  industry: text("industry").notNull().default(""),
  website: text("website"),
  phone: text("phone"),
  serviceArea: text("service_area"),
  emergencyService: boolean("emergency_service").notNull().default(false),
  replyTone: text("reply_tone").notNull().default("professional"),
  calendarLink: text("calendar_link"),
  notifyEmails: text("notify_emails"),
  plan: text("plan").notNull().default("starter"),
  trialEndsAt: timestamp("trial_ends_at"),
  services: jsonb("services").$type<Array<{ name: string; price: string; questions: string }>>().default([]),
  faqs: jsonb("faqs").$type<Array<{ q: string; a: string }>>().default([]),
  policies: jsonb("policies").$type<Record<string, unknown>>().default({}),
  monthlyLeadTarget: integer("monthly_lead_target").default(80),
  avgJobValue: integer("avg_job_value").default(1200),
  apptTarget: integer("appt_target").default(20),
  onboardingCompleted: boolean("onboarding_completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertBusinessSchema = createInsertSchema(businessesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBusiness = z.infer<typeof insertBusinessSchema>;
export type Business = typeof businessesTable.$inferSelect;
