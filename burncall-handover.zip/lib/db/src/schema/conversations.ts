import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { leadsTable } from "./leads";

export const conversationsTable = pgTable("conversations", {
  id: serial("id").primaryKey(),
  leadId: integer("lead_id").notNull().references(() => leadsTable.id),
  channel: text("channel").notNull().default("sms"), // sms | email | webchat
  status: text("status").notNull().default("open"), // open | needs_human | closed
  aiHandled: boolean("ai_handled").notNull().default(true),
  takenOverBy: text("taken_over_by"),
  takenOverAt: timestamp("taken_over_at"),
  closedAt: timestamp("closed_at"),
  messages: jsonb("messages").$type<Array<{ role: "ai" | "human" | "customer"; content: string; ts: string }>>().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertConversationSchema = createInsertSchema(conversationsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversationsTable.$inferSelect;
