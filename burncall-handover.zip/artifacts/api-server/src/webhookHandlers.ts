import { getStripeClient } from "./stripeClient";

export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        "Webhook payload must be a Buffer. Ensure webhook route is registered BEFORE express.json().",
      );
    }
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!webhookSecret) {
      // Without a webhook secret we cannot verify — log and skip silently in dev
      console.warn("STRIPE_WEBHOOK_SECRET not set — skipping webhook signature verification");
      return;
    }
    const stripe = getStripeClient();
    stripe.webhooks.constructEvent(payload, signature, webhookSecret);
    // Event is valid — extend here to persist webhook data as needed
  }
}
