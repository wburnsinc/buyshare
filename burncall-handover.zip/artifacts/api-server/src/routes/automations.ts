import { Router, type IRouter } from "express";

const router: IRouter = Router();

const MOCK_AUTOMATIONS = [
  { id: 1, businessId: 1, name: "Instant Web Lead Response", type: "instant_response", triggerEvent: "new_web_lead", enabled: true, delayMinutes: 0, channel: "sms", templateBody: "Hi {{customer_name}}! Thanks for reaching out to {{business_name}}. We received your request about {{service}}. Someone will follow up shortly — can you confirm your availability?", conditions: {}, stats: { triggered: 412, sent: 407, failed: 5, opened: 312 }, lastRunAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(), createdAt: new Date("2025-01-01").toISOString(), updatedAt: new Date().toISOString() },
  { id: 2, businessId: 1, name: "Missed-Call Text Back", type: "missed_call", triggerEvent: "missed_call", enabled: true, delayMinutes: 1, channel: "sms", templateBody: "Hi! We just missed your call at {{business_name}}. We want to help — what can we assist you with today?", conditions: {}, stats: { triggered: 156, sent: 154, failed: 2, opened: 98 }, lastRunAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), createdAt: new Date("2025-01-01").toISOString(), updatedAt: new Date().toISOString() },
  { id: 3, businessId: 1, name: "No-Response Follow-Up (1 Hour)", type: "follow_up", triggerEvent: "no_reply_1hr", enabled: true, delayMinutes: 60, channel: "sms", templateBody: "Hey {{customer_name}}, just checking in! We'd love to help with your {{service}} request. Are you still looking for assistance?", conditions: { minScore: 40 }, stats: { triggered: 287, sent: 279, failed: 8, opened: 201 }, lastRunAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(), createdAt: new Date("2025-01-01").toISOString(), updatedAt: new Date().toISOString() },
  { id: 4, businessId: 1, name: "No-Response Follow-Up (24 Hours)", type: "follow_up", triggerEvent: "no_reply_24hr", enabled: true, delayMinutes: 1440, channel: "both", templateBody: "Hi {{customer_name}}, we're still here and would love to help with your {{service}} request. Reply anytime to schedule!", conditions: { minScore: 50 }, stats: { triggered: 98, sent: 94, failed: 4, opened: 67 }, lastRunAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), createdAt: new Date("2025-01-01").toISOString(), updatedAt: new Date().toISOString() },
  { id: 5, businessId: 1, name: "Appointment Reminder (24h Before)", type: "appointment_reminder", triggerEvent: "appt_24hr_before", enabled: true, delayMinutes: 0, channel: "both", templateBody: "Hi {{customer_name}}! Reminder: Your {{service}} appointment is tomorrow at {{time}}. Reply YES to confirm or call us to reschedule.", conditions: {}, stats: { triggered: 67, sent: 67, failed: 0, opened: 61 }, lastRunAt: new Date(Date.now() - 60 * 60 * 1000).toISOString(), createdAt: new Date("2025-01-01").toISOString(), updatedAt: new Date().toISOString() },
  { id: 6, businessId: 1, name: "Review Request After Job", type: "review_request", triggerEvent: "job_completed", enabled: false, delayMinutes: 120, channel: "sms", templateBody: "Hi {{customer_name}}, thanks for choosing {{business_name}}! If you had a great experience, we'd really appreciate a quick Google review: {{review_link}}", conditions: { status: "completed" }, stats: { triggered: 0, sent: 0, failed: 0, opened: 0 }, lastRunAt: null, createdAt: new Date("2025-01-01").toISOString(), updatedAt: new Date().toISOString() },
];

// GET /api/automations
router.get("/automations", (_req, res) => {
  res.json({ automations: MOCK_AUTOMATIONS, total: MOCK_AUTOMATIONS.length });
});

// GET /api/automations/:id
router.get("/automations/:id", (req, res) => {
  const auto = MOCK_AUTOMATIONS.find(a => a.id === parseInt(req.params.id));
  if (!auto) { res.status(404).json({ error: "Automation not found" }); return; }
  res.json(auto);
});

// PATCH /api/automations/:id (toggle, update)
router.patch("/automations/:id", (req, res) => {
  const auto = MOCK_AUTOMATIONS.find(a => a.id === parseInt(req.params.id));
  if (!auto) { res.status(404).json({ error: "Automation not found" }); return; }
  const updated = { ...auto, ...req.body, updatedAt: new Date().toISOString() };
  res.json(updated);
});

// POST /api/automations
router.post("/automations", (req, res) => {
  const newAuto = {
    id: MOCK_AUTOMATIONS.length + 1,
    businessId: 1,
    enabled: false,
    stats: { triggered: 0, sent: 0, failed: 0, opened: 0 },
    lastRunAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    conditions: {},
    ...req.body,
  };
  res.status(201).json(newAuto);
});

export default router;
