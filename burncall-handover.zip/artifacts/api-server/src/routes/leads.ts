import { Router, type IRouter } from "express";

const router: IRouter = Router();

const MOCK_LEADS = [
  { id: 1, businessId: 1, name: "Sarah Mitchell", email: "sarah.m@email.com", phone: "(407) 555-0142", source: "website", channel: "web", message: "AC is blowing warm air. Can someone come today?", status: "booked", score: 92, service: "AC Repair", zipCode: "32789", urgency: "high", estimatedValue: 1250, aiResponseTime: 14, createdAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 90 * 1000).toISOString(), notes: "Confirmed appointment for 2PM today.", tags: ["hot-lead", "urgent"], assignedTo: null },
  { id: 2, businessId: 1, name: "James Thompson", email: "james.t@email.com", phone: "(407) 555-0188", source: "website", channel: "web", message: "Interested in a full HVAC system replacement. Home is 2,200 sq ft.", status: "qualified", score: 85, service: "AC Installation", zipCode: "32792", urgency: "medium", estimatedValue: 6800, aiResponseTime: 22, createdAt: new Date(Date.now() - 40 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(), notes: "Qualified — in service area. Needs quote.", tags: ["high-value"], assignedTo: "John Tech" },
  { id: 3, businessId: 1, name: "Emily Rodriguez", email: "emily.r@email.com", phone: "(407) 555-0210", source: "phone", channel: "call", message: "Missed call — no voicemail left.", status: "contacted", score: 55, service: null, zipCode: null, urgency: "low", estimatedValue: null, aiResponseTime: 8, createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 170 * 60 * 1000).toISOString(), notes: "Texted back after missed call. Awaiting reply.", tags: ["missed-call"], assignedTo: null },
  { id: 4, businessId: 1, name: "Marcus Lee", email: "marcus.l@email.com", phone: "(407) 555-0303", source: "website", channel: "web", message: "Unit is completely dead. Stopped working overnight.", status: "new", score: 78, service: "AC Repair", zipCode: "32803", urgency: "emergency", estimatedValue: 850, aiResponseTime: 11, createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 11 * 60 * 1000).toISOString(), notes: null, tags: ["emergency"], assignedTo: null },
  { id: 5, businessId: 1, name: "Diana Foster", email: "diana.f@email.com", phone: "(407) 555-0421", source: "social", channel: "sms", message: "How much is a maintenance tune-up?", status: "new", score: 42, service: "Maintenance", zipCode: "32712", urgency: "low", estimatedValue: 120, aiResponseTime: 19, createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 350 * 60 * 1000).toISOString(), notes: "Price inquiry — low urgency.", tags: [], assignedTo: null },
  { id: 6, businessId: 1, name: "Kevin Park", email: "kevin.p@email.com", phone: "(407) 555-0519", source: "website", channel: "web", message: "AC dripping water inside. Noticed a puddle under the unit.", status: "qualified", score: 71, service: "AC Repair", zipCode: "32789", urgency: "medium", estimatedValue: 450, aiResponseTime: 16, createdAt: new Date(Date.now() - 1.5 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 60 * 60 * 1000).toISOString(), notes: "Likely clogged drain line.", tags: [], assignedTo: null },
  { id: 7, businessId: 1, name: "Angela White", email: "angela.w@email.com", phone: "(407) 555-0621", source: "website", channel: "web", message: "Looking for estimates on ductless mini-split in sunroom.", status: "won", score: 88, service: "AC Installation", zipCode: "32792", urgency: "medium", estimatedValue: 2400, aiResponseTime: 18, createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), notes: "Job completed. Paid.", tags: ["closed-won"], assignedTo: "Mike Tech" },
  { id: 8, businessId: 1, name: "Robert Kim", email: "r.kim@email.com", phone: "(407) 555-0718", source: "phone", channel: "call", message: "Called to ask if we service Volusia County.", status: "lost", score: 15, service: null, zipCode: "32127", urgency: "low", estimatedValue: null, aiResponseTime: 6, createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), notes: "Outside service area. Declined.", tags: ["out-of-area"], assignedTo: null },
  { id: 9, businessId: 1, name: "Priya Patel", email: "p.patel@email.com", phone: "(407) 555-0815", source: "website", channel: "web", message: "System runs but house doesn't cool below 80 even at 68 setting.", status: "booked", score: 82, service: "AC Repair", zipCode: "32789", urgency: "high", estimatedValue: 680, aiResponseTime: 12, createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(), notes: "Appointment tomorrow 10AM.", tags: [], assignedTo: "John Tech" },
  { id: 10, businessId: 1, name: "Derek Johnson", email: "d.johnson@email.com", phone: "(407) 555-0912", source: "sms", channel: "sms", message: "Hi do you have any openings for AC tune-ups this week?", status: "contacted", score: 60, service: "Maintenance", zipCode: "32803", urgency: "low", estimatedValue: 120, aiResponseTime: 9, createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString(), lastContactedAt: new Date(Date.now() - 7.5 * 60 * 60 * 1000).toISOString(), notes: "Sent available time slots.", tags: [], assignedTo: null },
];

// GET /api/leads
router.get("/leads", (req, res) => {
  const { status, source, search, page = "1", limit = "20" } = req.query as Record<string, string>;
  let leads = [...MOCK_LEADS];

  if (status && status !== "all") leads = leads.filter(l => l.status === status);
  if (source && source !== "all") leads = leads.filter(l => l.source === source);
  if (search) {
    const q = search.toLowerCase();
    leads = leads.filter(l => l.name.toLowerCase().includes(q) || (l.email || "").toLowerCase().includes(q) || (l.phone || "").includes(q));
  }

  const pageNum = parseInt(page);
  const limitNum = parseInt(limit);
  const total = leads.length;
  const paginated = leads.slice((pageNum - 1) * limitNum, pageNum * limitNum);

  res.json({ leads: paginated, total, page: pageNum, limit: limitNum, totalPages: Math.ceil(total / limitNum) });
});

// GET /api/leads/:id
router.get("/leads/:id", (req, res) => {
  const lead = MOCK_LEADS.find(l => l.id === parseInt(req.params.id));
  if (!lead) { res.status(404).json({ error: "Lead not found" }); return; }
  res.json(lead);
});

// PATCH /api/leads/:id
router.patch("/leads/:id", (req, res) => {
  const lead = MOCK_LEADS.find(l => l.id === parseInt(req.params.id));
  if (!lead) { res.status(404).json({ error: "Lead not found" }); return; }
  const updated = { ...lead, ...req.body, updatedAt: new Date().toISOString() };
  res.json(updated);
});

// POST /api/leads
router.post("/leads", (req, res) => {
  const newLead = {
    id: MOCK_LEADS.length + 1,
    businessId: 1,
    status: "new",
    score: 50,
    aiResponseTime: Math.floor(Math.random() * 30) + 5,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lastContactedAt: null,
    notes: null,
    tags: [],
    assignedTo: null,
    ...req.body,
  };
  res.status(201).json(newLead);
});

export default router;
