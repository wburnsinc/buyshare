import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import leadsRouter from "./leads";
import dashboardRouter from "./dashboard";
import appointmentsRouter from "./appointments";
import automationsRouter from "./automations";
import inboxRouter from "./inbox";
import stripeRouter from "./stripe";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(leadsRouter);
router.use(dashboardRouter);
router.use(appointmentsRouter);
router.use(automationsRouter);
router.use(inboxRouter);
router.use(stripeRouter);

export default router;
