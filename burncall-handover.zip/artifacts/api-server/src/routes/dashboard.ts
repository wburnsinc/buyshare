import { Router, type IRouter } from "express";

const router: IRouter = Router();

const LEADS_BY_DAY = [
  { date: "Jun 18", leads: 8, qualified: 5, booked: 3 },
  { date: "Jun 19", leads: 12, qualified: 8, booked: 5 },
  { date: "Jun 20", leads: 6, qualified: 4, booked: 2 },
  { date: "Jun 21", leads: 15, qualified: 10, booked: 7 },
  { date: "Jun 22", leads: 9, qualified: 6, booked: 4 },
  { date: "Jun 23", leads: 11, qualified: 7, booked: 5 },
  { date: "Jun 24", leads: 7, qualified: 5, booked: 3 },
];

const SOURCE_BREAKDOWN = [
  { source: "Website Form", count: 34, pct: 43 },
  { source: "Missed Call", count: 18, pct: 23 },
  { source: "SMS Keyword", count: 12, pct: 15 },
  { source: "Social Media", count: 8, pct: 10 },
  { source: "Referral", count: 7, pct: 9 },
];

const REVENUE_OVER_TIME = [
  { month: "Jan", rescued: 4200 },
  { month: "Feb", rescued: 6100 },
  { month: "Mar", rescued: 8900 },
  { month: "Apr", rescued: 11200 },
  { month: "May", rescued: 14800 },
  { month: "Jun", rescued: 18640 },
];

const RECENT_LEADS = [
  { id: 1, name: "Sarah Mitchell", service: "AC Repair", status: "booked", urgency: "high", createdAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(), estimatedValue: 1250 },
  { id: 4, name: "Marcus Lee", service: "AC Repair", status: "new", urgency: "emergency", createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(), estimatedValue: 850 },
  { id: 2, name: "James Thompson", service: "AC Installation", status: "qualified", urgency: "medium", createdAt: new Date(Date.now() - 40 * 60 * 1000).toISOString(), estimatedValue: 6800 },
  { id: 9, name: "Priya Patel", service: "AC Repair", status: "booked", urgency: "high", createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), estimatedValue: 680 },
  { id: 5, name: "Diana Foster", service: "Maintenance", status: "new", urgency: "low", createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), estimatedValue: 120 },
];

const NEEDS_ATTENTION = [
  { id: 4, name: "Marcus Lee", issue: "Emergency — no response after AI contacted", type: "urgent", minutesAgo: 15 },
  { id: 3, name: "Emily Rodriguez", issue: "Missed call — no reply to text-back yet", type: "missed_call", minutesAgo: 182 },
  { id: 5, name: "Diana Foster", issue: "3rd no-response — last follow-up 6h ago", type: "stale", minutesAgo: 362 },
];

const TODAY_WINS = [
  "Sarah Mitchell booked an AC Repair appointment for 2PM today",
  "AI responded to 7 new leads in under 20 seconds",
  "3 appointments confirmed without human intervention",
  "Missed call recovered: Emily Rodriguez replied after text-back",
];

const AUTOMATION_PERFORMANCE = [
  { name: "Instant Web Lead Response", triggered: 18, success: 17, rate: 94 },
  { name: "Missed-Call Text Back", triggered: 5, success: 5, rate: 100 },
  { name: "No-Reply Follow-Up (1hr)", triggered: 8, success: 7, rate: 88 },
  { name: "Appointment Reminder", triggered: 3, success: 3, rate: 100 },
];

// GET /api/dashboard/stats
router.get("/dashboard/stats", (_req, res) => {
  res.json({
    metrics: {
      leadsReceived: 56,
      avgResponseTime: 14,
      qualifiedLeads: 38,
      appointmentsBooked: 21,
      estimatedRevenueRescued: 18640,
      needsAttentionCount: 3,
    },
    todayWins: TODAY_WINS,
    recentLeads: RECENT_LEADS,
    needsAttention: NEEDS_ATTENTION,
    automationPerformance: AUTOMATION_PERFORMANCE,
  });
});

// GET /api/dashboard/charts
router.get("/dashboard/charts", (_req, res) => {
  res.json({
    leadsByDay: LEADS_BY_DAY,
    sourceBreakdown: SOURCE_BREAKDOWN,
    funnel: [
      { stage: "Received", count: 56 },
      { stage: "Contacted", count: 51 },
      { stage: "Qualified", count: 38 },
      { stage: "Booked", count: 21 },
      { stage: "Won", count: 18 },
    ],
    revenueRescued: REVENUE_OVER_TIME,
  });
});

export default router;
