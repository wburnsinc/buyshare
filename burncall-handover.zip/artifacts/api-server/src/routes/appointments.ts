import { Router, type IRouter } from "express";

const router: IRouter = Router();

const now = new Date();
const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

const MOCK_APPOINTMENTS = [
  { id: 1, businessId: 1, leadId: 1, customerName: "Sarah Mitchell", customerPhone: "(407) 555-0142", customerEmail: "sarah.m@email.com", service: "AC Repair", scheduledAt: new Date(today.getTime() + 14 * 60 * 60 * 1000).toISOString(), duration: 90, status: "confirmed", estimatedValue: 1250, notes: "AC blowing warm air. Unit is 8 years old.", assignedTech: "John T.", address: "482 Oak Circle, Winter Park, FL 32789", createdAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString() },
  { id: 2, businessId: 1, leadId: 9, customerName: "Priya Patel", customerPhone: "(407) 555-0815", customerEmail: "p.patel@email.com", service: "AC Repair", scheduledAt: new Date(today.getTime() + 24 * 60 * 60 * 1000 + 10 * 60 * 60 * 1000).toISOString(), duration: 60, status: "scheduled", estimatedValue: 680, notes: "System runs but house won't cool below 80°.", assignedTech: "John T.", address: "1201 Lake Shore Dr, Maitland, FL 32751", createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString() },
  { id: 3, businessId: 1, leadId: 2, customerName: "James Thompson", customerPhone: "(407) 555-0188", customerEmail: "james.t@email.com", service: "AC Installation Quote", scheduledAt: new Date(today.getTime() + 3 * 24 * 60 * 60 * 1000 + 9 * 60 * 60 * 1000).toISOString(), duration: 120, status: "scheduled", estimatedValue: 6800, notes: "Full system replacement — 2,200 sq ft home.", assignedTech: "Mike S.", address: "800 Park Ave, Winter Park, FL 32792", createdAt: new Date(Date.now() - 40 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString() },
  { id: 4, businessId: 1, leadId: 7, customerName: "Angela White", customerPhone: "(407) 555-0621", customerEmail: "angela.w@email.com", service: "Mini-Split Installation", scheduledAt: new Date(today.getTime() - 24 * 60 * 60 * 1000 + 10 * 60 * 60 * 1000).toISOString(), duration: 240, status: "completed", estimatedValue: 2400, notes: "Sunroom ductless mini-split. Completed and paid.", assignedTech: "Mike S.", address: "3312 Sunshine Way, Casselberry, FL 32707", createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString() },
  { id: 5, businessId: 1, leadId: 6, customerName: "Kevin Park", customerPhone: "(407) 555-0519", customerEmail: "k.park@email.com", service: "AC Repair - Drain Line", scheduledAt: new Date(today.getTime() + 2 * 24 * 60 * 60 * 1000 + 14 * 60 * 60 * 1000).toISOString(), duration: 60, status: "scheduled", estimatedValue: 450, notes: "Likely clogged drain line causing indoor leak.", assignedTech: "John T.", address: "721 Elm St, Winter Park, FL 32789", createdAt: new Date(Date.now() - 1.5 * 60 * 60 * 1000).toISOString(), updatedAt: new Date().toISOString() },
];

// GET /api/appointments
router.get("/appointments", (req, res) => {
  const { status, date } = req.query as Record<string, string>;
  let appts = [...MOCK_APPOINTMENTS];
  if (status && status !== "all") appts = appts.filter(a => a.status === status);
  if (date) {
    const d = new Date(date);
    appts = appts.filter(a => {
      const apptDate = new Date(a.scheduledAt);
      return apptDate.toDateString() === d.toDateString();
    });
  }
  appts.sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime());
  res.json({ appointments: appts, total: appts.length });
});

// GET /api/appointments/:id
router.get("/appointments/:id", (req, res) => {
  const appt = MOCK_APPOINTMENTS.find(a => a.id === parseInt(req.params.id));
  if (!appt) { res.status(404).json({ error: "Appointment not found" }); return; }
  res.json(appt);
});

// PATCH /api/appointments/:id
router.patch("/appointments/:id", (req, res) => {
  const appt = MOCK_APPOINTMENTS.find(a => a.id === parseInt(req.params.id));
  if (!appt) { res.status(404).json({ error: "Appointment not found" }); return; }
  const updated = { ...appt, ...req.body, updatedAt: new Date().toISOString() };
  res.json(updated);
});

// POST /api/appointments
router.post("/appointments", (req, res) => {
  const newAppt = {
    id: MOCK_APPOINTMENTS.length + 1,
    businessId: 1,
    status: "scheduled",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...req.body,
  };
  res.status(201).json(newAppt);
});

export default router;
