import { Router, type IRouter } from "express";

const router: IRouter = Router();

const MOCK_CONVERSATIONS = [
  {
    id: 1,
    leadId: 1,
    leadName: "Sarah Mitchell",
    channel: "sms",
    status: "closed",
    aiHandled: true,
    takenOverBy: null,
    createdAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 90 * 1000).toISOString(),
    messages: [
      { role: "customer", content: "Hi, my AC is blowing warm air. Can someone come today?", ts: new Date(Date.now() - 2 * 60 * 1000).toISOString() },
      { role: "ai", content: "Hi Sarah — sorry you're dealing with that! We may be able to help today. Is the system completely off, or is it running but blowing warm air?", ts: new Date(Date.now() - 1.9 * 60 * 1000).toISOString() },
      { role: "customer", content: "It's running but just blowing warm air", ts: new Date(Date.now() - 1.5 * 60 * 1000).toISOString() },
      { role: "ai", content: "Got it. That could be a refrigerant issue or a dirty coil. We can have a tech out today at 2:00 PM. Would you like me to book that for you?", ts: new Date(Date.now() - 1.4 * 60 * 1000).toISOString() },
      { role: "customer", content: "Yes please, that would be great!", ts: new Date(Date.now() - 60 * 1000).toISOString() },
      { role: "ai", content: "Perfect! I've booked John T. for today at 2:00 PM at your address. You'll receive a confirmation text shortly. Is there anything else I can help with?", ts: new Date(Date.now() - 55 * 1000).toISOString() },
    ],
  },
  {
    id: 2,
    leadId: 4,
    leadName: "Marcus Lee",
    channel: "web",
    status: "needs_human",
    aiHandled: true,
    takenOverBy: null,
    createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    messages: [
      { role: "customer", content: "My AC unit is completely dead. Stopped working overnight. It's 95 degrees in my house.", ts: new Date(Date.now() - 15 * 60 * 1000).toISOString() },
      { role: "ai", content: "Hi Marcus — I'm sorry to hear that, especially in this heat! This sounds urgent. Let me check our emergency availability. Can you confirm your ZIP code?", ts: new Date(Date.now() - 14.7 * 60 * 1000).toISOString() },
      { role: "customer", content: "32803", ts: new Date(Date.now() - 14 * 60 * 1000).toISOString() },
      { role: "ai", content: "Great — you're in our service area. I'm flagging this as an emergency and routing you to our team right now. Someone will call you within 15 minutes.", ts: new Date(Date.now() - 13.5 * 60 * 1000).toISOString() },
    ],
  },
  {
    id: 3,
    leadId: 3,
    leadName: "Emily Rodriguez",
    channel: "sms",
    status: "open",
    aiHandled: true,
    takenOverBy: null,
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    messages: [
      { role: "ai", content: "Hi! We just missed your call at Burke Air Conditioning. We want to help — what can we assist you with today?", ts: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString() },
    ],
  },
  {
    id: 4,
    leadId: 2,
    leadName: "James Thompson",
    channel: "web",
    status: "open",
    aiHandled: true,
    takenOverBy: null,
    createdAt: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 20 * 60 * 1000).toISOString(),
    messages: [
      { role: "customer", content: "Hi, I'm interested in a full HVAC system replacement. My home is about 2,200 square feet.", ts: new Date(Date.now() - 40 * 60 * 1000).toISOString() },
      { role: "ai", content: "Hi James! Great timing — we specialize in system replacements. For a home your size, we'd recommend a 4-ton system. Can I ask — how old is your current unit, and are you looking for a specific efficiency rating?", ts: new Date(Date.now() - 39 * 60 * 1000).toISOString() },
      { role: "customer", content: "It's about 15 years old. I want something energy efficient.", ts: new Date(Date.now() - 35 * 60 * 1000).toISOString() },
      { role: "ai", content: "Perfect — a 15-year-old system is past its lifespan, so replacement makes sense. We carry 16-20 SEER units that could cut your cooling costs significantly. I can schedule a free quote with one of our comfort advisors. What days work best for you?", ts: new Date(Date.now() - 34 * 60 * 1000).toISOString() },
    ],
  },
];

// GET /api/inbox
router.get("/inbox", (req, res) => {
  const { status } = req.query as { status?: string };
  let convs = [...MOCK_CONVERSATIONS];
  if (status && status !== "all") convs = convs.filter(c => c.status === status);
  convs.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  res.json({ conversations: convs, total: convs.length });
});

// GET /api/inbox/:id
router.get("/inbox/:id", (req, res) => {
  const conv = MOCK_CONVERSATIONS.find(c => c.id === parseInt(req.params.id));
  if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }
  res.json(conv);
});

// POST /api/inbox/:id/takeover
router.post("/inbox/:id/takeover", (req, res) => {
  const conv = MOCK_CONVERSATIONS.find(c => c.id === parseInt(req.params.id));
  if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }
  res.json({ ...conv, status: "open", takenOverBy: req.body.agentName || "Team Member", takenOverAt: new Date().toISOString(), aiHandled: false });
});

// POST /api/inbox/:id/reply
router.post("/inbox/:id/reply", (req, res) => {
  const conv = MOCK_CONVERSATIONS.find(c => c.id === parseInt(req.params.id));
  if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }
  const message = { role: "human" as const, content: req.body.content, ts: new Date().toISOString() };
  res.json({ ...conv, messages: [...conv.messages, message], updatedAt: new Date().toISOString() });
});

export default router;
