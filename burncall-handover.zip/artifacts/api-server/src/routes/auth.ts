import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();

// In a real implementation, these would use DB + bcrypt + JWT/sessions
// Using mock authentication for demo purposes

// POST /api/auth/signup
router.post("/auth/signup", (req: Request, res: Response) => {
  const { email, name, businessName, industry, phone } = req.body;

  if (!email || !name) {
    res.status(400).json({ error: "Email and name are required" });
    return;
  }

  // Mock successful signup
  res.status(201).json({
    user: {
      id: 101,
      email,
      name,
      role: "owner",
      isEmailVerified: false,
      createdAt: new Date().toISOString(),
    },
    business: {
      id: 1,
      name: businessName || "",
      industry: industry || "",
      phone: phone || "",
      plan: "starter",
      onboardingCompleted: false,
    },
    token: "mock-jwt-token-" + Date.now(),
    redirectTo: "/onboarding",
  });
});

// POST /api/auth/login
router.post("/auth/login", (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({ error: "Email and password are required" });
    return;
  }

  // Mock auth — accept any valid-looking credentials
  if (!email.includes("@")) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  res.json({
    user: {
      id: 1,
      email,
      name: "Jason Burke",
      role: "owner",
      isEmailVerified: true,
      createdAt: "2025-03-01T00:00:00.000Z",
    },
    business: {
      id: 1,
      name: "Burke Air Conditioning",
      industry: "HVAC",
      plan: "growth",
      onboardingCompleted: true,
    },
    token: "mock-jwt-token-" + Date.now(),
    redirectTo: "/dashboard",
  });
});

// POST /api/auth/logout
router.post("/auth/logout", (_req: Request, res: Response) => {
  res.json({ success: true });
});

// POST /api/auth/reset-password
router.post("/auth/reset-password", (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) { res.status(400).json({ error: "Email is required" }); return; }
  res.json({ success: true, message: "If that email exists, a reset link has been sent." });
});

// POST /api/auth/magic-link
router.post("/auth/magic-link", (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) { res.status(400).json({ error: "Email is required" }); return; }
  res.json({ success: true, message: "Magic link sent to " + email });
});

// GET /api/auth/me
router.get("/auth/me", (_req: Request, res: Response) => {
  // In production, validate JWT from Authorization header
  res.json({
    user: {
      id: 1,
      email: "jason@burkeac.com",
      name: "Jason Burke",
      role: "owner",
      isEmailVerified: true,
      createdAt: "2025-03-01T00:00:00.000Z",
    },
    business: {
      id: 1,
      name: "Burke Air Conditioning",
      industry: "HVAC",
      plan: "growth",
      onboardingCompleted: true,
    },
  });
});

export default router;
