import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Phone, ChevronLeft, ChevronRight, CheckCircle2, X } from "lucide-react";

const APPTS = [
  { id: 1, name: "Sarah Mitchell", service: "AC Repair", date: "Tue May 20", time: "8:00 AM – 10:00 AM", tech: "Mike T.", value: "$1,250", status: "Confirmed" },
  { id: 2, name: "James Torres", service: "Plumbing Leak", date: "Tue May 20", time: "10:00 AM – 12:00 PM", tech: "Dave R.", value: "$650", status: "Confirmed" },
  { id: 3, name: "Linda Zhao", service: "Roof Inspection", date: "Tue May 20", time: "1:00 PM – 3:00 PM", tech: "Unassigned", value: "$4,500", status: "Pending" },
  { id: 4, name: "Emily Rodriguez", service: "AC Installation", date: "Wed May 21", time: "8:00 AM – 4:00 PM", tech: "Mike T.", value: "$3,800", status: "Confirmed" },
  { id: 5, name: "Mike Davidson", service: "Electrical Panel", date: "Wed May 21", time: "9:00 AM – 11:00 AM", tech: "Dave R.", value: "$2,100", status: "Confirmed" },
  { id: 6, name: "Robert Kim", service: "Pest Control", date: "Wed May 21", time: "2:00 PM – 4:00 PM", tech: "Unassigned", value: "$280", status: "Cancelled" },
  { id: 7, name: "Amanda Foster", service: "Garage Door Repair", date: "Thu May 22", time: "10:00 AM – 12:00 PM", tech: "Mike T.", value: "$450", status: "Confirmed" },
  { id: 8, name: "Chris Patterson", service: "HVAC Maintenance", date: "Fri May 23", time: "9:00 AM – 11:00 AM", tech: "Dave R.", value: "$189", status: "Pending" },
];

const STATUS_COLOR: Record<string, string> = {
  Confirmed: "bg-green-500/20 text-green-400 border-green-500/30",
  Pending: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  Cancelled: "bg-red-500/20 text-red-400 border-red-500/30",
};

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const WEEK_DAYS = ["Tue May 20", "Wed May 21", "Thu May 22", "Fri May 23", "Sat May 24"];
const HOURS = ["8 AM", "9 AM", "10 AM", "11 AM", "12 PM", "1 PM", "2 PM", "3 PM", "4 PM", "5 PM"];

const APPT_COLORS: Record<string, string> = {
  Confirmed: "bg-[#FF6B2B]/90 text-white",
  Pending: "bg-yellow-500/80 text-white",
  Cancelled: "bg-slate-700 text-slate-400 line-through",
};

export default function Appointments() {
  const [view, setView] = useState<"list" | "calendar">("list");
  const [filter, setFilter] = useState("All");

  const filters = ["All", "Confirmed", "Pending", "Cancelled"];
  const filtered = APPTS.filter(a => filter === "All" || a.status === filter);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Appointments</h1>
          <p className="text-slate-400 text-sm mt-0.5">{APPTS.filter(a => a.status === "Confirmed").length} confirmed this week</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-lg p-1">
            <button onClick={() => setView("list")} className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${view === "list" ? "bg-white/10 text-white" : "text-slate-400"}`}>List</button>
            <button onClick={() => setView("calendar")} className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${view === "calendar" ? "bg-white/10 text-white" : "text-slate-400"}`}>Calendar</button>
          </div>
        </div>
      </div>

      <div className="flex gap-2 mb-5">
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${filter === f ? "bg-[#FF6B2B] text-white border-[#FF6B2B]" : "bg-white/5 text-slate-400 border-white/10 hover:text-white"}`}>{f}</button>
        ))}
      </div>

      {view === "list" ? (
        <div className="space-y-3">
          {["Tue May 20", "Wed May 21", "Thu May 22", "Fri May 23"].map(day => {
            const dayAppts = filtered.filter(a => a.date === day);
            if (!dayAppts.length) return null;
            const total = dayAppts.reduce((sum, a) => sum + parseInt(a.value.replace(/[^0-9]/g, "")), 0);
            return (
              <div key={day}>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-white font-semibold text-sm">{day}</p>
                  <span className="text-green-400 text-xs font-medium">${total.toLocaleString()} potential</span>
                </div>
                <div className="space-y-2">
                  {dayAppts.map(appt => (
                    <div key={appt.id} className="flex items-center gap-4 bg-[#0A0F1E] border border-white/10 rounded-xl p-4 hover:border-white/20 transition-colors">
                      <div className="h-10 w-10 rounded-xl bg-[#FF6B2B]/10 flex items-center justify-center shrink-0">
                        <Calendar className="h-5 w-5 text-[#FF6B2B]" />
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-medium text-sm">{appt.name}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <Clock className="h-3 w-3 text-slate-500" />
                          <span className="text-slate-400 text-xs">{appt.time}</span>
                          <span className="text-slate-600">·</span>
                          <span className="text-slate-400 text-xs">{appt.service}</span>
                        </div>
                      </div>
                      <div className="hidden md:block text-center">
                        <p className="text-slate-400 text-xs">Technician</p>
                        <p className="text-white text-xs font-medium mt-0.5">{appt.tech}</p>
                      </div>
                      <div className="text-center hidden sm:block">
                        <p className="text-slate-400 text-xs">Est. Value</p>
                        <p className="text-green-400 text-sm font-semibold mt-0.5">{appt.value}</p>
                      </div>
                      <Badge className={`border text-xs ${STATUS_COLOR[appt.status]}`}>{appt.status}</Badge>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" className="border-white/20 text-slate-400 h-7 w-7 p-0" data-testid={`confirm-appt-${appt.id}`}>
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        </Button>
                        <Button size="sm" variant="outline" className="border-white/20 text-slate-400 h-7 w-7 p-0">
                          <X className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-white/10">
            <button className="text-slate-400 hover:text-white p-1"><ChevronLeft className="h-5 w-5" /></button>
            <p className="text-white font-semibold">Week of May 20 – 24, 2025</p>
            <button className="text-slate-400 hover:text-white p-1"><ChevronRight className="h-5 w-5" /></button>
          </div>
          <div className="overflow-x-auto">
            <div className="grid min-w-[700px]" style={{ gridTemplateColumns: "60px repeat(5, 1fr)" }}>
              <div className="border-b border-white/10 p-2" />
              {WEEK_DAYS.map(day => (
                <div key={day} className="border-b border-l border-white/10 p-3 text-center">
                  <p className="text-white text-xs font-semibold">{day.split(" ")[0]}</p>
                  <p className="text-slate-500 text-xs">{day.split(" ").slice(1).join(" ")}</p>
                </div>
              ))}
              {HOURS.map(hour => (
                <React.Fragment key={hour}>
                  <div className="border-b border-white/5 p-2 text-right">
                    <span className="text-slate-600 text-xs">{hour}</span>
                  </div>
                  {WEEK_DAYS.map(day => {
                    const dayAppts = APPTS.filter(a => a.date === day && a.time.startsWith(hour.replace(" AM", " AM").replace(" PM", " PM")));
                    return (
                      <div key={day} className="border-b border-l border-white/5 p-1 min-h-[44px] relative">
                        {dayAppts.map(appt => (
                          <div key={appt.id} className={`rounded px-1.5 py-1 text-xs ${APPT_COLORS[appt.status]}`}>
                            <p className="font-medium truncate">{appt.name}</p>
                            <p className="opacity-75 truncate">{appt.service}</p>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
