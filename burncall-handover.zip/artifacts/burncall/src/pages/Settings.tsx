import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Globe, Clock, Bell, MessageSquare, Phone } from "lucide-react";

const TABS = ["Business", "Business Hours", "AI Behavior", "Notifications", "Phone & SMS"];

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export default function Settings() {
  const [tab, setTab] = useState("Business");
  const [saved, setSaved] = useState(false);
  const [hours, setHours] = useState(
    DAYS.map((day, i) => ({ day, open: i < 5, from: "08:00", to: "17:00" }))
  );
  const [aiTone, setAiTone] = useState("professional");
  const [notifications, setNotifications] = useState({
    newLead: true, qualifiedLead: true, appointmentBooked: true, emergency: true,
    emailDigest: true, smsAlerts: false, pushAlerts: true,
  });

  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
          <p className="text-slate-400 text-sm mt-0.5">Configure your BurnCall account</p>
        </div>
        <Button onClick={save} className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white" data-testid="save-settings">
          {saved ? <><CheckCircle2 className="h-4 w-4 mr-2" /> Saved</> : "Save Changes"}
        </Button>
      </div>

      <div className="flex gap-2 mb-6 border-b border-white/10 pb-4 overflow-x-auto">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${tab === t ? "bg-[#FF6B2B]/20 text-[#FF6B2B]" : "text-slate-400 hover:text-white"}`}>{t}</button>
        ))}
      </div>

      {tab === "Business" && (
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 space-y-4">
            <p className="text-white font-semibold flex items-center gap-2"><Globe className="h-4 w-4 text-[#FF6B2B]" /> Business Information</p>
            {[
              { label: "Business Name", value: "Burke Air Conditioning", placeholder: "Your business name" },
              { label: "Industry", value: "HVAC", placeholder: "e.g. HVAC, Plumbing" },
              { label: "Website URL", value: "https://burkeac.com", placeholder: "https://yoursite.com" },
              { label: "Primary Email", value: "jason@burkeac.com", placeholder: "your@email.com" },
            ].map(field => (
              <div key={field.label}>
                <label className="text-xs text-slate-400 mb-1.5 block">{field.label}</label>
                <Input defaultValue={field.value} placeholder={field.placeholder} className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 text-sm" />
              </div>
            ))}
          </div>
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 space-y-4">
            <p className="text-white font-semibold">Location</p>
            {[
              { label: "Street Address", value: "123 Business Blvd", placeholder: "" },
              { label: "City", value: "Orlando", placeholder: "" },
              { label: "State", value: "FL", placeholder: "" },
              { label: "ZIP Code", value: "32789", placeholder: "" },
            ].map(field => (
              <div key={field.label}>
                <label className="text-xs text-slate-400 mb-1.5 block">{field.label}</label>
                <Input defaultValue={field.value} placeholder={field.placeholder} className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 text-sm" />
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "Business Hours" && (
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-5">
            <Clock className="h-4 w-4 text-[#FF6B2B]" />
            <p className="text-white font-semibold">Business Hours</p>
          </div>
          <p className="text-slate-400 text-xs mb-5">BurnCall's AI will indicate availability and after-hours status based on these settings.</p>
          <div className="space-y-3">
            {hours.map((h, i) => (
              <div key={h.day} className="flex items-center gap-4">
                <div className="w-28">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={h.open} onChange={e => setHours(hrs => hrs.map((x, j) => j === i ? { ...x, open: e.target.checked } : x))} className="rounded border-white/20" />
                    <span className="text-sm text-white">{h.day}</span>
                  </label>
                </div>
                {h.open ? (
                  <div className="flex items-center gap-2">
                    <input type="time" value={h.from} onChange={e => setHours(hrs => hrs.map((x, j) => j === i ? { ...x, from: e.target.value } : x))} className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none" />
                    <span className="text-slate-500 text-xs">to</span>
                    <input type="time" value={h.to} onChange={e => setHours(hrs => hrs.map((x, j) => j === i ? { ...x, to: e.target.value } : x))} className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none" />
                  </div>
                ) : (
                  <span className="text-slate-600 text-sm">Closed</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "AI Behavior" && (
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 space-y-5">
            <p className="text-white font-semibold">AI Tone</p>
            {["professional", "friendly", "formal"].map(tone => (
              <label key={tone} className="flex items-center gap-3 cursor-pointer">
                <input type="radio" name="tone" value={tone} checked={aiTone === tone} onChange={() => setAiTone(tone)} className="border-white/20" />
                <div>
                  <p className="text-white text-sm capitalize">{tone}</p>
                  <p className="text-slate-400 text-xs">{{ professional: "Confident and helpful without being overly casual", friendly: "Warm and conversational — great for residential services", formal: "Strict business language — ideal for commercial clients" }[tone]}</p>
                </div>
              </label>
            ))}
          </div>
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 space-y-4">
            <p className="text-white font-semibold">AI Rules</p>
            {[
              { label: "Auto-respond to all leads", desc: "AI responds to every new lead automatically" },
              { label: "Confirm service area before promising availability", desc: "Always check ZIP before offering slots" },
              { label: "Never quote prices in chat", desc: "Defer to on-site or a call for pricing" },
              { label: "Escalate emergency keywords immediately", desc: "Alert the owner for 'flooding', 'no heat', 'no AC'" },
              { label: "Send booking link when score ≥ 70", desc: "Only high-intent leads get the booking link" },
            ].map(rule => (
              <label key={rule.label} className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" defaultChecked className="mt-0.5 rounded border-white/20" />
                <div>
                  <p className="text-white text-sm">{rule.label}</p>
                  <p className="text-slate-500 text-xs">{rule.desc}</p>
                </div>
              </label>
            ))}
          </div>
        </div>
      )}

      {tab === "Notifications" && (
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 space-y-5">
          <div className="flex items-center gap-2 mb-2">
            <Bell className="h-4 w-4 text-[#FF6B2B]" />
            <p className="text-white font-semibold">Notification Preferences</p>
          </div>
          {[
            { key: "newLead", label: "New lead arrives", desc: "Notify when any new lead comes in" },
            { key: "qualifiedLead", label: "Lead qualified (score ≥ 80)", desc: "Notify when a hot lead is identified" },
            { key: "appointmentBooked", label: "Appointment booked", desc: "Notify when a customer books a slot" },
            { key: "emergency", label: "Emergency lead detected", desc: "Always alert immediately for emergencies" },
            { key: "emailDigest", label: "Daily email digest", desc: "Summary of leads and performance each morning" },
            { key: "smsAlerts", label: "SMS alerts (owner phone)", desc: "Text alerts for critical events" },
            { key: "pushAlerts", label: "Push notifications", desc: "Browser and mobile push notifications" },
          ].map(n => (
            <div key={n.key} className="flex items-center justify-between">
              <div>
                <p className="text-white text-sm">{n.label}</p>
                <p className="text-slate-400 text-xs">{n.desc}</p>
              </div>
              <button
                onClick={() => setNotifications(prev => ({ ...prev, [n.key]: !prev[n.key as keyof typeof notifications] }))}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${notifications[n.key as keyof typeof notifications] ? "bg-[#FF6B2B]" : "bg-white/20"}`}
                data-testid={`toggle-notif-${n.key}`}
              >
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${notifications[n.key as keyof typeof notifications] ? "translate-x-6" : "translate-x-1"}`} />
              </button>
            </div>
          ))}
        </div>
      )}

      {tab === "Phone & SMS" && (
        <div className="space-y-5">
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Phone className="h-4 w-4 text-[#FF6B2B]" />
              <p className="text-white font-semibold">BurnCall Phone Number</p>
            </div>
            <div className="flex items-center gap-3 p-4 bg-white/5 rounded-xl border border-white/10 mb-4">
              <span className="text-2xl font-bold text-white">(407) 555-7729</span>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Active</Badge>
            </div>
            <p className="text-slate-400 text-xs">Missed calls to this number trigger the AI text-back sequence. Forward your business number to this number to enable missed-call text back.</p>
          </div>
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="h-4 w-4 text-[#FF6B2B]" />
              <p className="text-white font-semibold">SMS Settings</p>
            </div>
            {[
              { label: "Opt-out message", value: "Reply STOP to unsubscribe from messages from Burke AC. Message & data rates may apply." },
              { label: "Business name in messages", value: "Burke Air Conditioning" },
            ].map(f => (
              <div key={f.label}>
                <label className="text-xs text-slate-400 mb-1.5 block">{f.label}</label>
                <Input defaultValue={f.value} className="bg-white/5 border-white/10 text-white text-sm" />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
