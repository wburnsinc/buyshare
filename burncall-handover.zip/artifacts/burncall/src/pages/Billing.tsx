import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, CreditCard, Download, AlertCircle, Loader2, ExternalLink } from "lucide-react";

const INVOICES = [
  { date: "Jun 1, 2025", desc: "BurnCall Growth · Monthly", amount: "$299.00", status: "Paid" },
  { date: "May 1, 2025", desc: "BurnCall Growth · Monthly", amount: "$299.00", status: "Paid" },
  { date: "Apr 1, 2025", desc: "BurnCall Growth · Monthly", amount: "$299.00", status: "Paid" },
  { date: "Mar 1, 2025", desc: "BurnCall Starter · Monthly", amount: "$149.00", status: "Paid" },
  { date: "Feb 1, 2025", desc: "BurnCall Starter · Monthly", amount: "$149.00", status: "Paid" },
];

// Fallback plan definitions shown while Stripe products load
const FALLBACK_PLANS = [
  {
    name: "Starter", monthly: 149, annual: 119,
    features: ["1 location", "Up to 100 leads/month", "AI lead response", "Email notifications", "Basic reporting"],
  },
  {
    name: "Growth", monthly: 299, annual: 239,
    features: ["Up to 500 leads/month", "SMS automation", "Missed-call text back", "Calendar booking", "Team inbox", "3 team members"],
  },
  {
    name: "Pro", monthly: 499, annual: 399,
    features: ["Multiple locations", "Up to 2,000 leads/month", "Custom AI playbooks", "CRM integrations", "Unlimited team members", "Priority support"],
  },
];

interface StripePlan {
  productId: string;
  name: string;
  description: string;
  monthlyPriceId: string | null;
  monthlyAmount: number | null;
  annualPriceId: string | null;
  annualAmount: number | null;
}

function parsePlanName(name: string): string {
  return name.replace("BurnCall ", "");
}

export default function Billing() {
  const [annual, setAnnual] = useState(false);
  const [currentPlan] = useState("Growth");
  const [stripePlans, setStripePlans] = useState<StripePlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState("");
  const [error, setError] = useState("");

  // Check for Stripe redirect result
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("status") === "success") {
      setSuccessMessage("Your subscription has been activated! Welcome to BurnCall.");
      window.history.replaceState({}, "", "/billing");
    } else if (params.get("status") === "cancelled") {
      setError("Checkout was cancelled. No charge was made.");
      window.history.replaceState({}, "", "/billing");
    }
  }, []);

  // Fetch Stripe products
  useEffect(() => {
    async function fetchProducts() {
      try {
        const res = await fetch("/api/stripe/products");
        if (!res.ok) throw new Error(`API error ${res.status}`);
        const data = await res.json() as { products: Array<{id: string; name: string; description: string; prices: Array<{id: string; unit_amount: number; interval: string | null}>}> };

        const plans: StripePlan[] = data.products
          .filter((p) => p.name.startsWith("BurnCall"))
          .map((p) => {
            const monthly = p.prices.find((pr) => pr.interval === "month") ?? null;
            const annual = p.prices.find((pr) => pr.interval === "year") ?? null;
            return {
              productId: p.id,
              name: parsePlanName(p.name),
              description: p.description ?? "",
              monthlyPriceId: monthly?.id ?? null,
              monthlyAmount: monthly?.unit_amount ?? null,
              annualPriceId: annual?.id ?? null,
              annualAmount: annual?.unit_amount ?? null,
            };
          })
          .sort((a, b) => (a.monthlyAmount ?? 0) - (b.monthlyAmount ?? 0));

        if (plans.length > 0) setStripePlans(plans);
      } catch {
        // Silently fall back to static plans
      } finally {
        setLoading(false);
      }
    }
    fetchProducts();
  }, []);

  const handleCheckout = async (priceId: string | null, planName: string) => {
    if (!priceId) { setError("Price not available — please try again shortly."); return; }
    setCheckoutLoading(planName);
    setError("");
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ priceId, customerEmail: "user@example.com" }),
      });
      const data = await res.json() as { url?: string; error?: string };
      if (!res.ok || !data.url) throw new Error(data.error ?? "Checkout failed");
      window.location.href = data.url;
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Checkout failed");
      setCheckoutLoading(null);
    }
  };

  // Use Stripe plans if loaded, otherwise fall back to static
  const displayPlans = stripePlans.length > 0
    ? stripePlans
    : FALLBACK_PLANS.map((p) => ({
        productId: "",
        name: p.name,
        description: "",
        monthlyPriceId: null as string | null,
        monthlyAmount: p.monthly * 100,
        annualPriceId: null as string | null,
        annualAmount: p.annual * 100,
      }));

  return (
    <div>
      <h1 className="text-2xl font-bold text-white mb-6">Billing</h1>

      {successMessage && (
        <div className="mb-5 p-4 bg-green-500/10 border border-green-500/30 rounded-xl flex items-center gap-3">
          <CheckCircle2 className="h-5 w-5 text-green-400 shrink-0" />
          <p className="text-green-300 text-sm">{successMessage}</p>
        </div>
      )}
      {error && (
        <div className="mb-5 p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-3">
          <AlertCircle className="h-4 w-4 text-red-400 shrink-0" />
          <p className="text-red-300 text-sm">{error}</p>
        </div>
      )}

      {/* Current plan summary */}
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Current Plan</p>
          <p className="text-xl font-bold text-white">{currentPlan}</p>
          <Badge className="mt-1 bg-green-500/20 text-green-400 border-green-500/30 text-xs">Active</Badge>
          <p className="text-slate-400 text-xs mt-2">Renews July 1, 2025</p>
        </div>
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Next Invoice</p>
          <p className="text-xl font-bold text-white">$299.00</p>
          <p className="text-slate-400 text-xs mt-2">July 1, 2025</p>
        </div>
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Leads This Month</p>
          <p className="text-xl font-bold text-white">156 / 500</p>
          <div className="mt-2 w-full bg-white/10 rounded-full h-1.5">
            <div className="bg-[#FF6B2B] h-1.5 rounded-full" style={{ width: "31%" }} />
          </div>
          <p className="text-slate-500 text-xs mt-1">31% of monthly limit</p>
        </div>
      </div>

      {/* Payment method */}
      <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <p className="text-white font-semibold">Payment Method</p>
          <Button size="sm" variant="outline" className="border-white/20 text-white text-xs h-7" data-testid="update-card">
            Manage via Stripe <ExternalLink className="h-3 w-3 ml-1" />
          </Button>
        </div>
        <div className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-xl">
          <div className="h-10 w-14 rounded-lg bg-slate-700 flex items-center justify-center">
            <CreditCard className="h-5 w-5 text-slate-300" />
          </div>
          <div>
            <p className="text-white text-sm font-medium">Visa ending in 4242</p>
            <p className="text-slate-400 text-xs">Expires 09/2027</p>
          </div>
          <Badge className="ml-auto bg-green-500/20 text-green-400 border-green-500/30 text-xs">Default</Badge>
        </div>
      </div>

      {/* Plan chooser */}
      <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 mb-6">
        <div className="flex items-center justify-between mb-5">
          <p className="text-white font-semibold">
            {loading ? "Loading Plans..." : stripePlans.length > 0 ? "Change Plan" : "Plans"}
          </p>
          <div className="flex items-center gap-2">
            <span className={`text-xs ${!annual ? "text-white" : "text-slate-500"}`}>Monthly</span>
            <button
              onClick={() => setAnnual(!annual)}
              className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${annual ? "bg-[#FF6B2B]" : "bg-white/20"}`}
            >
              <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${annual ? "translate-x-[18px]" : "translate-x-0.5"}`} />
            </button>
            <span className={`text-xs ${annual ? "text-white" : "text-slate-500"}`}>
              Annual <span className="text-green-400">(Save 20%)</span>
            </span>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-8 gap-2 text-slate-400">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span className="text-sm">Loading plans from Stripe...</span>
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-4">
            {displayPlans.map((plan) => {
              const priceId = annual ? plan.annualPriceId : plan.monthlyPriceId;
              const amount = annual ? plan.annualAmount : plan.monthlyAmount;
              const displayPrice = amount != null
                ? annual
                  ? Math.round(amount / 100 / 12)  // show per-month equivalent for annual
                  : amount / 100
                : null;
              const isCurrent = currentPlan === plan.name;
              const isLoadingThis = checkoutLoading === plan.name;

              return (
                <div
                  key={plan.name}
                  className={`rounded-xl border p-4 ${isCurrent ? "border-[#FF6B2B] bg-[#FF6B2B]/5" : "border-white/10"}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-white font-semibold text-sm">{plan.name}</p>
                    {isCurrent && (
                      <Badge className="bg-[#FF6B2B]/20 text-[#FF6B2B] border-[#FF6B2B]/30 text-xs">Current</Badge>
                    )}
                  </div>
                  <p className="text-2xl font-bold text-white mb-0.5">
                    {displayPrice != null ? `$${displayPrice}` : "—"}
                    <span className="text-sm font-normal text-slate-400">/mo</span>
                  </p>
                  {annual && amount != null && (
                    <p className="text-xs text-slate-500 mb-2">billed ${Math.round(amount / 100)}/yr</p>
                  )}
                  <p className="text-xs text-slate-500 mb-3">14-day free trial</p>
                  <Button
                    size="sm"
                    disabled={isCurrent || isLoadingThis || !priceId}
                    onClick={() => handleCheckout(priceId, plan.name)}
                    className={`w-full text-xs h-8 ${isCurrent ? "bg-white/5 text-slate-500 cursor-not-allowed" : "bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white"}`}
                    data-testid={`select-plan-${plan.name.toLowerCase()}`}
                  >
                    {isLoadingThis ? (
                      <><Loader2 className="h-3 w-3 animate-spin mr-1" />Redirecting...</>
                    ) : isCurrent ? "Current Plan"
                      : !priceId ? "Coming Soon"
                      : "Subscribe via Stripe"}
                  </Button>
                </div>
              );
            })}
          </div>
        )}
        <p className="text-xs text-slate-600 text-center mt-4">Secure checkout powered by Stripe · 14-day free trial · Cancel anytime</p>
      </div>

      {/* Invoice history */}
      <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6 mb-6">
        <p className="text-white font-semibold mb-4">Invoice History</p>
        <div className="space-y-2">
          {INVOICES.map((inv, i) => (
            <div key={i} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
              <div>
                <p className="text-white text-sm">{inv.desc}</p>
                <p className="text-slate-500 text-xs">{inv.date}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-white font-medium text-sm">{inv.amount}</span>
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">{inv.status}</Badge>
                <Button size="sm" variant="outline" className="border-white/20 text-slate-400 text-xs h-7 px-2">
                  <Download className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Danger zone */}
      <div className="bg-red-500/5 border border-red-500/20 rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-2">
          <AlertCircle className="h-4 w-4 text-red-400" />
          <p className="text-white font-semibold text-sm">Danger Zone</p>
        </div>
        <p className="text-slate-400 text-xs mb-4">
          Cancelling your subscription will stop all AI lead response at the end of your billing period.
          Your data will be retained for 90 days.
        </p>
        <Button
          variant="outline"
          className="border-red-500/30 text-red-400 hover:bg-red-500/10 text-sm"
          data-testid="cancel-subscription"
        >
          Cancel Subscription
        </Button>
      </div>
    </div>
  );
}
