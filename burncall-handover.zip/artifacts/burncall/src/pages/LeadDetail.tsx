import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Phone, Mail, MessageSquare, Star, ArrowLeft, CheckCircle2, Clock, Bot, User, Calendar, DollarSign, Tag, Send } from "lucide-react";

const timeline = [
  { time: "2:14 PM", event: "Lead submitted via website form", icon: "web", color: "text-blue-400" },
  { time: "2:14 PM", event: "AI responded in 14 seconds", icon: "bot", color: "text-[#FF6B2B]" },
  { time: "2:17 PM", event: "Lead qualified — Score: 92", icon: "star", color: "text-green-400" },
  { time: "2:19 PM", event: "Booking link sent via SMS", icon: "sms", color: "text-purple-400" },
  { time: "2:22 PM", event: "Appointment booked — Tue May 20 @ 2:00 PM", icon: "calendar", color: "text-green-400" },
  { time: "2:22 PM", event: "Owner notified via push + SMS", icon: "phone", color: "text-slate-400" },
];

const conversation = [
  { from: "Sarah", text: "Hi, my AC is blowing warm air. Can someone come today? It's really hot in here.", time: "2:14 PM", ai: false },
  { from: "BurnCall AI", text: "Hi Sarah — sorry you're dealing with that! We can definitely help. Is the system completely off, or is it running but blowing warm air?", time: "2:14 PM", ai: true },
  { from: "Sarah", text: "It's running but blowing warm air.", time: "2:15 PM", ai: false },
  { from: "BurnCall AI", text: "Got it. What's your ZIP code so I can confirm we serve your area?", time: "2:15 PM", ai: true },
  { from: "Sarah", text: "32789", time: "2:15 PM", ai: false },
  { from: "BurnCall AI", text: "We cover your area! Are you the homeowner or a tenant?", time: "2:15 PM", ai: true },
  { from: "Sarah", text: "Homeowner.", time: "2:16 PM", ai: false },
  { from: "BurnCall AI", text: "Perfect. Would this afternoon between 1–5 PM work for a technician to come take a look?", time: "2:16 PM", ai: true },
  { from: "Sarah", text: "Yes that works!", time: "2:17 PM", ai: false },
  { from: "BurnCall AI", text: "Great! I'm sending you a booking link now. Pick the time that works best for you and you'll get a confirmation right away.", time: "2:17 PM", ai: true },
  { from: "Sarah", text: "Booked for 2:00 PM, thank you!", time: "2:22 PM", ai: false },
  { from: "BurnCall AI", text: "Excellent! You're all set for Tuesday May 20 at 2:00 PM. You'll receive a reminder the morning of your appointment. See you then!", time: "2:22 PM", ai: true },
];

export default function LeadDetail() {
  const [note, setNote] = useState("");
  const [message, setMessage] = useState("");
  const [humanMode, setHumanMode] = useState(false);

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <Link href="/leads">
          <button className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors text-sm">
            <ArrowLeft className="h-4 w-4" /> Back to Leads
          </button>
        </Link>
      </div>

      <div className="grid lg:grid-cols-[320px_1fr] gap-6">
        {/* Left Column */}
        <div className="space-y-4">
          {/* Lead Profile */}
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-gradient-to-br from-[#FF6B2B] to-orange-600 flex items-center justify-center text-white font-bold text-lg">S</div>
                <div>
                  <h2 className="text-white font-bold">Sarah Mitchell</h2>
                  <p className="text-slate-400 text-xs">Lead #1042 • Website Form</p>
                </div>
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">Qualified</Badge>
            </div>
            <div className="space-y-2.5 text-sm">
              <div className="flex items-center gap-2.5 text-slate-300">
                <Phone className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                <span>(407) 555-0192</span>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <Mail className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                <span>sarah.m@gmail.com</span>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <Tag className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                <span>HVAC Repair · Emergency</span>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <DollarSign className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                <span className="text-green-400 font-semibold">$1,250 est. value</span>
              </div>
            </div>
          </div>

          {/* AI Score */}
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm font-semibold text-white">AI Lead Score</p>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">HOT</Badge>
            </div>
            <div className="flex items-center gap-4 mb-4">
              <div className="h-16 w-16 rounded-full border-4 border-green-400 flex items-center justify-center">
                <span className="text-xl font-bold text-white">92</span>
              </div>
              <div className="flex-1">
                <div className="w-full bg-white/10 rounded-full h-2 mb-1">
                  <div className="bg-green-400 h-2 rounded-full" style={{ width: "92%" }} />
                </div>
                <p className="text-xs text-slate-400">Score out of 100</p>
              </div>
            </div>
            <p className="text-xs text-slate-400 bg-white/5 rounded-lg p-3 leading-relaxed">
              High score: customer is in service area, requested emergency service, confirmed homeowner, wants same-day availability, and contact info is complete.
            </p>
          </div>

          {/* Appointment */}
          <div className="bg-[#0A0F1E] border border-[#FF6B2B]/30 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-4 w-4 text-[#FF6B2B]" />
              <p className="text-sm font-semibold text-white">Appointment Booked</p>
            </div>
            <p className="text-white font-medium text-sm">Tuesday, May 20, 2025</p>
            <p className="text-slate-400 text-xs">2:00 PM – 4:00 PM</p>
            <div className="mt-3 pt-3 border-t border-white/5">
              <p className="text-xs text-slate-500">Confirmation sent via SMS + email</p>
            </div>
          </div>

          {/* Notes */}
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
            <p className="text-sm font-semibold text-white mb-3">Internal Notes</p>
            <Textarea
              placeholder="Add a note..."
              value={note}
              onChange={e => setNote(e.target.value)}
              className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 text-sm min-h-[80px] resize-none"
              data-testid="lead-notes"
            />
            <Button size="sm" className="mt-2 bg-white/10 hover:bg-white/20 text-white text-xs">Save Note</Button>
          </div>

          {/* Actions */}
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5 space-y-2">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-3">Actions</p>
            <Button className="w-full bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white text-sm h-9" data-testid="mark-won">Mark as Won</Button>
            <Button variant="outline" className="w-full border-white/20 text-white text-sm h-9" data-testid="take-over">Take Over Conversation</Button>
            <Button variant="outline" className="w-full border-white/20 text-white text-sm h-9">
              <Phone className="h-3.5 w-3.5 mr-2" /> Call Lead
            </Button>
            <Button variant="outline" className="w-full border-red-500/30 text-red-400 text-sm h-9">Mark as Lost</Button>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-4">
          {/* Conversation */}
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-slate-400" />
                <p className="text-sm font-semibold text-white">Conversation</p>
                <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">SMS</Badge>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">AI Mode</span>
                <button
                  onClick={() => setHumanMode(!humanMode)}
                  className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${humanMode ? "bg-[#FF6B2B]" : "bg-white/20"}`}
                  data-testid="human-takeover"
                >
                  <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${humanMode ? "translate-x-[18px]" : "translate-x-0.5"}`} />
                </button>
                <span className="text-xs text-slate-400">Human</span>
              </div>
            </div>
            <div className="p-4 space-y-3 max-h-[400px] overflow-y-auto">
              {conversation.map((msg, i) => (
                <div key={i} className={`flex gap-2.5 ${msg.ai ? "justify-end" : ""}`}>
                  {!msg.ai && (
                    <div className="h-7 w-7 rounded-full bg-slate-600 flex items-center justify-center text-white text-xs font-bold shrink-0 mt-1">S</div>
                  )}
                  <div className={`max-w-[70%] rounded-2xl p-3 ${msg.ai ? "bg-[#FF6B2B] text-white rounded-tr-sm" : "bg-white/5 text-slate-200 rounded-tl-sm"}`}>
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                    <p className={`text-xs mt-1.5 ${msg.ai ? "text-orange-200" : "text-slate-500"}`}>{msg.time}</p>
                  </div>
                  {msg.ai && (
                    <div className="h-7 w-7 rounded-full bg-[#FF6B2B]/30 flex items-center justify-center shrink-0 mt-1">
                      <Bot className="h-3.5 w-3.5 text-[#FF6B2B]" />
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-white/10">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder={humanMode ? "Type a message..." : "AI is handling this conversation"}
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  disabled={!humanMode}
                  className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm text-white placeholder:text-slate-600 disabled:opacity-50 focus:outline-none focus:border-[#FF6B2B]/50"
                  data-testid="message-input"
                />
                <Button size="sm" disabled={!humanMode} className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white px-4 rounded-xl">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
            <p className="text-sm font-semibold text-white mb-4">Timeline</p>
            <div className="space-y-3">
              {timeline.map((item, i) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`h-2 w-2 rounded-full mt-1.5 ${item.color.replace("text-", "bg-")}`} />
                    {i < timeline.length - 1 && <div className="w-px flex-1 bg-white/10 my-1" />}
                  </div>
                  <div className="pb-3">
                    <p className="text-slate-200 text-sm">{item.event}</p>
                    <p className="text-slate-500 text-xs mt-0.5">{item.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
