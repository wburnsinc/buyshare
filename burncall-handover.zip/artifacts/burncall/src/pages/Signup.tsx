import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, ArrowRight } from "lucide-react";
import logoPath from "@assets/bestlogo_1782311057091.png";

const STEPS = ["Account", "Business", "Plan"];

const PLANS_SIGNUP = [
  { name: "Starter", price: 149, desc: "Solo operators" },
  { name: "Growth", price: 299, desc: "Growing teams", popular: true },
  { name: "Pro", price: 499, desc: "Multi-location" },
];

const BENEFITS = [
  "14-day free trial — no credit card required",
  "Instant web lead AI response in < 60 seconds",
  "Missed-call text back enabled immediately",
  "Setup takes under 10 minutes",
];

export default function Signup() {
  const [step, setStep] = useState(0);
  const [plan, setPlan] = useState("Growth");
  const [form, setForm] = useState({ name: "", email: "", password: "", business: "", industry: "", phone: "" });
  const [agreed, setAgreed] = useState(false);
  const [done, setDone] = useState(false);

  const handleField = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  if (done) {
    return (
      <div className="min-h-screen bg-[#050812] flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="h-16 w-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">You're all set!</h2>
          <p className="text-slate-400 mb-6">Your BurnCall account is ready. Let's get your AI working for you.</p>
          <Link href="/dashboard">
            <Button className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white px-8 h-12">
              Go to Dashboard <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050812] flex">
      {/* Left Panel */}
      <div className="hidden lg:flex flex-col w-[420px] bg-[#0A0F1E] border-r border-white/10 p-10 shrink-0">
        <Link href="/">
          <img src={logoPath} alt="BurnCall" className="h-8 mb-12" />
        </Link>
        <h2 className="text-2xl font-bold text-white mb-3">Start capturing every lead today.</h2>
        <p className="text-slate-400 text-sm mb-8">Join 1,400+ home service businesses using BurnCall to respond faster, qualify better, and book more jobs.</p>
        <ul className="space-y-4">
          {BENEFITS.map(b => (
            <li key={b} className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-green-400 shrink-0 mt-0.5" />
              <span className="text-slate-300 text-sm">{b}</span>
            </li>
          ))}
        </ul>
        <div className="mt-auto pt-8 border-t border-white/10">
          <blockquote className="text-slate-300 text-sm italic leading-relaxed mb-3">
            "BurnCall paid for itself in the first week. We booked 3 jobs from leads we would have never followed up on."
          </blockquote>
          <p className="text-slate-500 text-xs">— Jason B., HVAC contractor, Orlando FL</p>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* Steps */}
          <div className="flex items-center gap-2 mb-8">
            {STEPS.map((s, i) => (
              <React.Fragment key={s}>
                <div className={`flex items-center gap-1.5 text-sm font-medium ${i <= step ? "text-white" : "text-slate-600"}`}>
                  <div className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold ${i < step ? "bg-green-500 text-white" : i === step ? "bg-[#FF6B2B] text-white" : "bg-white/10 text-slate-500"}`}>
                    {i < step ? <CheckCircle2 className="h-3.5 w-3.5" /> : i + 1}
                  </div>
                  {s}
                </div>
                {i < STEPS.length - 1 && <div className={`flex-1 h-px ${i < step ? "bg-green-500/50" : "bg-white/10"}`} />}
              </React.Fragment>
            ))}
          </div>

          {step === 0 && (
            <div className="space-y-4">
              <div>
                <h1 className="text-2xl font-bold text-white">Create your account</h1>
                <p className="text-slate-400 text-sm mt-1">No credit card required. 14-day free trial.</p>
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Full Name</label>
                <Input value={form.name} onChange={e => handleField("name", e.target.value)} placeholder="Jason Burke" className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 h-11" data-testid="signup-name" />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Email Address</label>
                <Input type="email" value={form.email} onChange={e => handleField("email", e.target.value)} placeholder="jason@burkeac.com" className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 h-11" data-testid="signup-email" />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Password</label>
                <Input type="password" value={form.password} onChange={e => handleField("password", e.target.value)} placeholder="At least 8 characters" className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 h-11" data-testid="signup-password" />
              </div>
              <label className="flex items-start gap-2 cursor-pointer">
                <input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} className="mt-1 rounded border-white/20" />
                <span className="text-slate-400 text-xs">I agree to the <Link href="/terms" className="text-[#FF6B2B] hover:underline">Terms of Service</Link> and <Link href="/privacy" className="text-[#FF6B2B] hover:underline">Privacy Policy</Link></span>
              </label>
              <Button onClick={() => setStep(1)} disabled={!form.name || !form.email || !form.password || !agreed} className="w-full bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white h-11" data-testid="signup-next-1">
                Continue <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
              <p className="text-center text-slate-500 text-xs">Already have an account? <Link href="/dashboard" className="text-[#FF6B2B] hover:underline">Sign in</Link></p>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h1 className="text-2xl font-bold text-white">Tell us about your business</h1>
                <p className="text-slate-400 text-sm mt-1">We'll use this to personalize your AI setup.</p>
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Business Name</label>
                <Input value={form.business} onChange={e => handleField("business", e.target.value)} placeholder="Burke Air Conditioning" className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 h-11" data-testid="signup-business" />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Industry</label>
                <select value={form.industry} onChange={e => handleField("industry", e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-[#FF6B2B]/50 h-11" data-testid="signup-industry">
                  <option value="">Select your industry</option>
                  {["HVAC", "Plumbing", "Electrical", "Roofing", "Cleaning", "Landscaping", "Pest Control", "Restoration", "Garage Door", "Other"].map(i => <option key={i}>{i}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Business Phone</label>
                <Input value={form.phone} onChange={e => handleField("phone", e.target.value)} placeholder="(407) 555-0001" className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 h-11" />
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" onClick={() => setStep(0)} className="flex-1 border-white/20 text-white h-11">Back</Button>
                <Button onClick={() => setStep(2)} disabled={!form.business || !form.industry} className="flex-1 bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white h-11" data-testid="signup-next-2">
                  Continue <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h1 className="text-2xl font-bold text-white">Choose your plan</h1>
                <p className="text-slate-400 text-sm mt-1">All plans include a 14-day free trial.</p>
              </div>
              {PLANS_SIGNUP.map(p => (
                <button
                  key={p.name}
                  data-testid={`signup-plan-${p.name.toLowerCase()}`}
                  onClick={() => setPlan(p.name)}
                  className={`w-full flex items-center justify-between p-4 rounded-xl border text-left transition-all ${plan === p.name ? "border-[#FF6B2B] bg-[#FF6B2B]/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-semibold">{p.name}</span>
                      {p.popular && <Badge className="bg-[#FF6B2B]/20 text-[#FF6B2B] border-[#FF6B2B]/30 text-xs">Most Popular</Badge>}
                    </div>
                    <span className="text-slate-400 text-xs">{p.desc}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-white font-bold">${p.price}<span className="text-slate-400 text-xs font-normal">/mo</span></span>
                    <div className={`h-5 w-5 rounded-full border-2 flex items-center justify-center ${plan === p.name ? "border-[#FF6B2B] bg-[#FF6B2B]" : "border-white/20"}`}>
                      {plan === p.name && <div className="h-2 w-2 rounded-full bg-white" />}
                    </div>
                  </div>
                </button>
              ))}
              <div className="flex gap-3 pt-2">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1 border-white/20 text-white h-11">Back</Button>
                <Button onClick={() => setDone(true)} className="flex-1 bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white h-11 font-semibold" data-testid="signup-finish">
                  Start Free Trial
                </Button>
              </div>
              <p className="text-center text-slate-600 text-xs">No credit card required. Cancel anytime.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
