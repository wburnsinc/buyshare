import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MessageSquare, Phone, Mail, Bot, Send, RefreshCw, User } from "lucide-react";

const conversations = [
  { id: 1, name: "Sarah Mitchell", preview: "Booked for 2:00 PM, thank you!", time: "2m ago", channel: "sms", unread: 0, status: "Booked", score: 92 },
  { id: 2, name: "Emily Rodriguez", preview: "What's your hourly rate for AC installation?", time: "8m ago", channel: "chat", unread: 2, status: "New", score: 78 },
  { id: 3, name: "James Torres", preview: "The leak is getting worse, is this an emergency?", time: "15m ago", channel: "sms", unread: 1, status: "Needs Review", score: 85 },
  { id: 4, name: "Mike Davidson", preview: "I need someone today if possible", time: "22m ago", channel: "phone", unread: 0, status: "Contacted", score: 91 },
  { id: 5, name: "Linda Zhao", preview: "Can you send me a quote for a full roof inspection?", time: "1h ago", channel: "email", unread: 0, status: "Qualified", score: 88 },
  { id: 6, name: "Robert Kim", preview: "Thanks! See you Friday.", time: "2h ago", channel: "sms", unread: 0, status: "Won", score: 67 },
];

const aiSuggestedReplies = [
  "Hi James — yes, a worsening leak is definitely something we can treat as urgent. Can you tell me where the leak is located and how fast the water is coming in?",
  "We can have a plumber out to you today. What's your address and are you the homeowner?",
];

const msgs = [
  { from: "James", text: "Hi, I have a pipe leaking under my kitchen sink. It started small but it's getting worse.", time: "3:15 PM", ai: false },
  { from: "BurnCall AI", text: "Hi James — sorry to hear that! A leaking pipe under the sink can definitely escalate. Is the water dripping slowly or is it more of a steady stream?", time: "3:15 PM", ai: true },
  { from: "James", text: "It's a steady drip, maybe a cup every 5 minutes", time: "3:17 PM", ai: false },
  { from: "BurnCall AI", text: "Got it. That's manageable for now but you'll want it fixed soon. What's your ZIP code?", time: "3:17 PM", ai: true },
  { from: "James", text: "32792", time: "3:18 PM", ai: false },
  { from: "BurnCall AI", text: "We cover your area! Are you the homeowner?", time: "3:18 PM", ai: true },
  { from: "James", text: "The leak is getting worse, is this an emergency?", time: "3:20 PM", ai: false },
];

const CHANNEL_ICON = { sms: MessageSquare, phone: Phone, email: Mail, chat: MessageSquare };
const CHANNEL_COLOR: Record<string, string> = { sms: "text-green-400", phone: "text-blue-400", email: "text-purple-400", chat: "text-orange-400" };

export default function Inbox() {
  const [selected, setSelected] = useState(2);
  const [humanMode, setHumanMode] = useState(false);
  const [reply, setReply] = useState("");
  const [tone, setTone] = useState<string | null>(null);

  const convo = conversations.find(c => c.id === selected)!;

  return (
    <div className="h-[calc(100vh-120px)] flex gap-4 -mx-2">
      {/* Conversation list */}
      <div className="w-72 shrink-0 bg-[#0A0F1E] border border-white/10 rounded-2xl overflow-hidden flex flex-col">
        <div className="p-4 border-b border-white/10">
          <h2 className="text-white font-semibold">Inbox</h2>
          <div className="flex gap-2 mt-3">
            {["All", "SMS", "Email"].map(f => (
              <button key={f} className="text-xs px-2.5 py-1 rounded-lg bg-white/5 text-slate-400 hover:text-white border border-white/10 transition-colors">{f}</button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {conversations.map(convo => {
            const Icon = CHANNEL_ICON[convo.channel as keyof typeof CHANNEL_ICON] || MessageSquare;
            return (
              <button
                key={convo.id}
                onClick={() => setSelected(convo.id)}
                data-testid={`convo-${convo.id}`}
                className={`w-full flex items-start gap-3 p-4 border-b border-white/5 text-left hover:bg-white/[0.02] transition-colors ${selected === convo.id ? "bg-[#FF6B2B]/10 border-l-2 border-l-[#FF6B2B]" : ""}`}
              >
                <div className="h-9 w-9 rounded-full bg-slate-700 flex items-center justify-center text-white text-sm font-bold shrink-0">{convo.name[0]}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <p className="text-white text-sm font-medium truncate">{convo.name}</p>
                    <span className="text-slate-500 text-xs shrink-0 ml-2">{convo.time}</span>
                  </div>
                  <p className="text-slate-400 text-xs truncate">{convo.preview}</p>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Icon className={`h-3 w-3 ${CHANNEL_COLOR[convo.channel]}`} />
                    <span className="text-slate-600 text-xs">{convo.channel.toUpperCase()}</span>
                    {convo.unread > 0 && <span className="ml-auto h-4 w-4 rounded-full bg-[#FF6B2B] text-white text-xs flex items-center justify-center">{convo.unread}</span>}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main conversation */}
      <div className="flex-1 bg-[#0A0F1E] border border-white/10 rounded-2xl flex flex-col overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-slate-700 flex items-center justify-center text-white font-bold">{convo?.name[0]}</div>
            <div>
              <p className="text-white font-semibold text-sm">{convo?.name}</p>
              <div className="flex items-center gap-2">
                <Badge className={`text-xs ${convo?.status === "Needs Review" ? "bg-red-500/20 text-red-400 border-red-500/30" : "bg-white/10 text-slate-400 border-white/10"}`}>{convo?.status}</Badge>
                <span className="text-slate-500 text-xs">Score: {convo?.score}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400">AI Mode</span>
            <button onClick={() => setHumanMode(!humanMode)} className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${humanMode ? "bg-[#FF6B2B]" : "bg-white/20"}`} data-testid="inbox-human-toggle">
              <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${humanMode ? "translate-x-[18px]" : "translate-x-0.5"}`} />
            </button>
            <span className="text-xs text-slate-400">Human</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {msgs.map((msg, i) => (
            <div key={i} className={`flex gap-2.5 ${msg.ai ? "justify-end" : ""}`}>
              {!msg.ai && <div className="h-7 w-7 rounded-full bg-slate-600 flex items-center justify-center text-white text-xs font-bold shrink-0 mt-1">J</div>}
              <div className={`max-w-[60%] rounded-2xl p-3 ${msg.ai ? "bg-[#FF6B2B] text-white rounded-tr-sm" : "bg-white/5 text-slate-200 rounded-tl-sm"}`}>
                <p className="text-sm">{msg.text}</p>
                <p className={`text-xs mt-1 ${msg.ai ? "text-orange-200" : "text-slate-500"}`}>{msg.time}</p>
              </div>
              {msg.ai && <div className="h-7 w-7 rounded-full bg-[#FF6B2B]/30 flex items-center justify-center shrink-0 mt-1"><Bot className="h-3.5 w-3.5 text-[#FF6B2B]" /></div>}
            </div>
          ))}
        </div>

        {/* AI suggested reply */}
        <div className="p-4 border-t border-white/10 bg-white/[0.01]">
          <div className="bg-white/5 border border-[#FF6B2B]/20 rounded-xl p-3 mb-3">
            <div className="flex items-center gap-2 mb-2">
              <Bot className="h-4 w-4 text-[#FF6B2B]" />
              <span className="text-xs text-[#FF6B2B] font-semibold">AI Suggested Reply</span>
            </div>
            <p className="text-slate-200 text-sm">{aiSuggestedReplies[0]}</p>
            <div className="flex items-center gap-2 mt-3 flex-wrap">
              <span className="text-xs text-slate-500">Rewrite as:</span>
              {["Shorter", "Friendlier", "More Professional", "More Urgent"].map(t => (
                <button key={t} onClick={() => setTone(tone === t ? null : t)} className={`text-xs px-2.5 py-1 rounded-lg border transition-colors ${tone === t ? "bg-[#FF6B2B]/20 border-[#FF6B2B]/40 text-[#FF6B2B]" : "border-white/10 text-slate-400 hover:text-white"}`}>{t}</button>
              ))}
              <Button size="sm" className="ml-auto bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white text-xs h-7 px-3">Send with AI</Button>
            </div>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder={humanMode ? "Type your message..." : "Switch to Human mode to reply manually"}
              value={reply}
              onChange={e => setReply(e.target.value)}
              disabled={!humanMode}
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm text-white placeholder:text-slate-600 disabled:opacity-40 focus:outline-none focus:border-[#FF6B2B]/50"
              data-testid="inbox-reply-input"
            />
            <Button disabled={!humanMode} className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white px-4 rounded-xl">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div className="w-64 shrink-0 space-y-4">
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-4">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-3">Conversation Summary</p>
          <p className="text-slate-300 text-xs leading-relaxed">James has a steady leak under his kitchen sink in ZIP 32792. Urgency is escalating — customer asking if it's an emergency. Recommend prioritizing same-day dispatch.</p>
        </div>
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-4">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-3">Suggested Next Action</p>
          <div className="bg-[#FF6B2B]/10 border border-[#FF6B2B]/20 rounded-lg p-3 text-xs text-orange-300">
            Send booking link for same-day emergency slot — lead score is 85 and urgency is high.
          </div>
          <Button className="w-full mt-3 bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white text-xs h-8">Send Booking Link</Button>
        </div>
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-4">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-3">Assign To</p>
          <select className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none">
            <option>Unassigned</option>
            <option>Mike T.</option>
            <option>Dave R.</option>
          </select>
        </div>
      </div>
    </div>
  );
}
