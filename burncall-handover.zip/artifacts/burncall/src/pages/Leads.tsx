import React, { useState } from "react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Download, LayoutGrid, List, ChevronDown, Phone, Mail, MessageSquare, Star } from "lucide-react";

const LEADS = [
  { id: 1, name: "Sarah Mitchell", contact: "(407) 555-0192", method: "sms", service: "AC Repair", source: "Website", score: 92, status: "Qualified", time: "2 min ago", value: "$1,250", assigned: "Unassigned" },
  { id: 2, name: "Emily Rodriguez", contact: "(321) 555-0847", method: "phone", service: "AC Installation", source: "Google", score: 78, status: "Contacted", time: "5 min ago", value: "$3,800", assigned: "Mike T." },
  { id: 3, name: "James Torres", contact: "(407) 555-0231", method: "email", service: "Plumbing Leak", source: "Facebook", score: 85, status: "Appointment Booked", time: "11 min ago", value: "$650", assigned: "Dave R." },
  { id: 4, name: "Mike Davidson", contact: "(321) 555-0573", method: "sms", service: "Electrical Panel", source: "Referral", score: 91, status: "New", time: "18 min ago", value: "$2,100", assigned: "Unassigned" },
  { id: 5, name: "Chris Patterson", contact: "(407) 555-0915", method: "phone", service: "HVAC Maintenance", source: "Google", score: 54, status: "Contacted", time: "34 min ago", value: "$189", assigned: "Mike T." },
  { id: 6, name: "Linda Zhao", contact: "(321) 555-0682", method: "email", service: "Roof Inspection", source: "Website", score: 88, status: "Qualified", time: "1 hr ago", value: "$4,500", assigned: "Unassigned" },
  { id: 7, name: "Robert Kim", contact: "(407) 555-0347", method: "sms", service: "Pest Control", source: "Yelp", score: 67, status: "Won", time: "2 hrs ago", value: "$280", assigned: "Dave R." },
  { id: 8, name: "Amanda Foster", contact: "(321) 555-0918", method: "phone", service: "Garage Door Repair", source: "Google", score: 80, status: "New", time: "3 hrs ago", value: "$450", assigned: "Unassigned" },
  { id: 9, name: "David Washington", contact: "(407) 555-0256", method: "email", service: "Landscaping", source: "Referral", score: 43, status: "Lost", time: "4 hrs ago", value: "$800", assigned: "Mike T." },
  { id: 10, name: "Jessica Lee", contact: "(321) 555-0731", method: "sms", service: "AC Repair", source: "Google", score: 95, status: "Appointment Booked", time: "5 hrs ago", value: "$1,100", assigned: "Dave R." },
  { id: 11, name: "Tyler Brooks", contact: "(407) 555-0482", method: "phone", service: "Water Heater", source: "Website", score: 72, status: "Contacted", time: "6 hrs ago", value: "$1,900", assigned: "Unassigned" },
  { id: 12, name: "Maria Santos", contact: "(321) 555-0264", method: "email", service: "Cleaning Service", source: "Facebook", score: 21, status: "Spam", time: "7 hrs ago", value: "$0", assigned: "Unassigned" },
];

const STATUS_COLORS: Record<string, string> = {
  "New": "bg-blue-500/20 text-blue-400 border-blue-500/30",
  "Contacted": "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  "Qualified": "bg-orange-500/20 text-orange-400 border-orange-500/30",
  "Appointment Booked": "bg-purple-500/20 text-purple-400 border-purple-500/30",
  "Won": "bg-green-500/20 text-green-400 border-green-500/30",
  "Lost": "bg-slate-500/20 text-slate-400 border-slate-500/30",
  "Spam": "bg-red-500/20 text-red-400 border-red-500/30",
};

const SCORE_COLOR = (s: number) => s >= 80 ? "text-green-400" : s >= 50 ? "text-yellow-400" : "text-red-400";
const SCORE_LABEL = (s: number) => s >= 80 ? "Hot" : s >= 50 ? "Warm" : "Low";

export default function Leads() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [view, setView] = useState<"table" | "kanban">("table");
  const [selected, setSelected] = useState<number[]>([]);

  const statuses = ["All", "New", "Contacted", "Qualified", "Appointment Booked", "Won", "Lost", "Spam"];
  const filtered = LEADS.filter(l =>
    (statusFilter === "All" || l.status === statusFilter) &&
    (l.name.toLowerCase().includes(search.toLowerCase()) || l.service.toLowerCase().includes(search.toLowerCase()))
  );

  const toggleSelect = (id: number) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Leads</h1>
          <p className="text-slate-400 text-sm mt-0.5">{LEADS.length} total leads this month</p>
        </div>
        <Button className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white" data-testid="export-csv">
          <Download className="h-4 w-4 mr-2" /> Export CSV
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-5">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search leads..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-slate-500"
            data-testid="search-leads"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {statuses.map(s => (
            <button
              key={s}
              data-testid={`filter-${s.toLowerCase().replace(/\s+/g, "-")}`}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${statusFilter === s ? "bg-[#FF6B2B] text-white" : "bg-white/5 text-slate-400 hover:text-white border border-white/10"}`}
            >
              {s}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-lg p-1 ml-auto">
          <button onClick={() => setView("table")} className={`p-1.5 rounded ${view === "table" ? "bg-white/10 text-white" : "text-slate-400"}`} data-testid="view-table"><List className="h-4 w-4" /></button>
          <button onClick={() => setView("kanban")} className={`p-1.5 rounded ${view === "kanban" ? "bg-white/10 text-white" : "text-slate-400"}`} data-testid="view-kanban"><LayoutGrid className="h-4 w-4" /></button>
        </div>
      </div>

      {selected.length > 0 && (
        <div className="mb-4 flex items-center gap-3 p-3 bg-[#FF6B2B]/10 border border-[#FF6B2B]/20 rounded-xl">
          <span className="text-sm text-orange-400 font-medium">{selected.length} selected</span>
          <Button size="sm" variant="outline" className="border-white/20 text-white text-xs h-7">Mark Won</Button>
          <Button size="sm" variant="outline" className="border-white/20 text-white text-xs h-7">Assign</Button>
          <Button size="sm" variant="outline" className="border-red-500/30 text-red-400 text-xs h-7">Mark Spam</Button>
          <button className="ml-auto text-slate-400 text-xs" onClick={() => setSelected([])}>Clear</button>
        </div>
      )}

      {view === "table" ? (
        <div className="bg-[#0A0F1E] border border-white/10 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 text-xs uppercase tracking-wider">
                <th className="p-4 text-left w-8"><input type="checkbox" className="rounded border-white/20 bg-white/5" onChange={e => setSelected(e.target.checked ? filtered.map(l => l.id) : [])} /></th>
                <th className="p-4 text-left">Name</th>
                <th className="p-4 text-left hidden md:table-cell">Service</th>
                <th className="p-4 text-left hidden lg:table-cell">Source</th>
                <th className="p-4 text-left">Score</th>
                <th className="p-4 text-left">Status</th>
                <th className="p-4 text-left hidden md:table-cell">Est. Value</th>
                <th className="p-4 text-left hidden lg:table-cell">Time</th>
                <th className="p-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((lead) => (
                <tr key={lead.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                  <td className="p-4"><input type="checkbox" checked={selected.includes(lead.id)} onChange={() => toggleSelect(lead.id)} className="rounded border-white/20 bg-white/5" /></td>
                  <td className="p-4">
                    <div>
                      <Link href="/leads/detail" className="font-medium text-white hover:text-[#FF6B2B] transition-colors">{lead.name}</Link>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {lead.method === "sms" && <MessageSquare className="h-3 w-3 text-slate-500" />}
                        {lead.method === "phone" && <Phone className="h-3 w-3 text-slate-500" />}
                        {lead.method === "email" && <Mail className="h-3 w-3 text-slate-500" />}
                        <span className="text-xs text-slate-500">{lead.contact}</span>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 hidden md:table-cell text-slate-300">{lead.service}</td>
                  <td className="p-4 hidden lg:table-cell text-slate-400 text-xs">{lead.source}</td>
                  <td className="p-4">
                    <div className="flex items-center gap-1.5">
                      <Star className={`h-3 w-3 ${SCORE_COLOR(lead.score)}`} />
                      <span className={`font-semibold ${SCORE_COLOR(lead.score)}`}>{lead.score}</span>
                      <span className="text-slate-600 text-xs">{SCORE_LABEL(lead.score)}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <Badge className={`text-xs border ${STATUS_COLORS[lead.status]}`}>{lead.status}</Badge>
                  </td>
                  <td className="p-4 hidden md:table-cell text-green-400 font-medium">{lead.value}</td>
                  <td className="p-4 hidden lg:table-cell text-slate-500 text-xs">{lead.time}</td>
                  <td className="p-4">
                    <Link href="/leads/detail">
                      <Button size="sm" variant="outline" className="border-white/20 text-white text-xs h-7 hover:bg-white/10">View</Button>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-16 text-slate-500">
              <Search className="h-8 w-8 mx-auto mb-3 opacity-40" />
              <p>No leads match your search</p>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 overflow-x-auto">
          {["New", "Contacted", "Qualified", "Appointment Booked", "Won", "Lost", "Spam"].map(status => (
            <div key={status} className="min-w-[180px]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{status}</span>
                <span className="text-xs text-slate-600">{LEADS.filter(l => l.status === status).length}</span>
              </div>
              <div className="space-y-2">
                {LEADS.filter(l => l.status === status).map(lead => (
                  <Link key={lead.id} href="/leads/detail">
                    <div className="bg-[#0A0F1E] border border-white/10 rounded-xl p-3 hover:border-[#FF6B2B]/40 transition-colors cursor-pointer">
                      <p className="text-white text-xs font-semibold mb-0.5">{lead.name}</p>
                      <p className="text-slate-400 text-xs mb-2">{lead.service}</p>
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-bold ${SCORE_COLOR(lead.score)}`}>{lead.score}</span>
                        <span className="text-green-400 text-xs">{lead.value}</span>
                      </div>
                      <p className="text-slate-600 text-xs mt-1">{lead.time}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
