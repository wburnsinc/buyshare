import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Zap, Edit2, Play, Pause, ChevronRight, ArrowRight } from "lucide-react";

const AUTOMATIONS = [
  {
    id: 1,
    name: "Instant Web Lead Response",
    description: "Responds to every new website form submission within 30 seconds via SMS.",
    trigger: "New website lead",
    actions: ["Send AI SMS in 30s", "Ask qualification questions", "Send booking link if score ≥70"],
    stopOn: "Appointment booked or human takes over",
    active: true,
    triggered: 156,
    completed: 131,
    category: "Lead Response",
  },
  {
    id: 2,
    name: "Missed-Call Text Back",
    description: "Automatically texts back any missed call within 60 seconds, keeping the lead warm.",
    trigger: "Missed inbound call",
    actions: ["Text: 'Hi, I missed your call...'", "Start qualification if they reply"],
    stopOn: "Call returned or lead replies and books",
    active: true,
    triggered: 43,
    completed: 41,
    category: "Lead Response",
  },
  {
    id: 3,
    name: "No-Response Follow-Up Sequence",
    description: "Sends a 3-step follow-up sequence to leads who haven't replied in 24 hours.",
    trigger: "Lead has no reply for 24 hours",
    actions: ["Day 1: Follow-up SMS", "Day 3: Follow-up email", "Day 7: Final outreach"],
    stopOn: "Lead replies or books appointment",
    active: true,
    triggered: 28,
    completed: 19,
    category: "Follow-Up",
  },
  {
    id: 4,
    name: "Appointment Reminder",
    description: "Sends SMS and email reminders before every booked appointment to reduce no-shows.",
    trigger: "24 hours before appointment",
    actions: ["SMS reminder 24hrs prior", "Email reminder 24hrs prior", "SMS reminder 2hrs prior"],
    stopOn: "Appointment completed or cancelled",
    active: true,
    triggered: 21,
    completed: 21,
    category: "Appointments",
  },
  {
    id: 5,
    name: "Review Request After Completed Job",
    description: "Asks happy customers to leave a Google review 24 hours after the job is marked complete.",
    trigger: "Job marked as Won/Complete",
    actions: ["Wait 24 hours", "Send review request SMS", "Send Google review link"],
    stopOn: "Review submitted or 7 days elapsed",
    active: false,
    triggered: 0,
    completed: 0,
    category: "Reviews",
  },
  {
    id: 6,
    name: "Reactivate Old Leads",
    description: "Re-engages leads that have gone cold for 30+ days with a personalized outreach.",
    trigger: "Lead inactive for 30 days",
    actions: ["Send reactivation SMS", "Offer special promotion if no reply"],
    stopOn: "Lead books or unsubscribes",
    active: false,
    triggered: 0,
    completed: 0,
    category: "Re-engagement",
  },
  {
    id: 7,
    name: "Emergency Lead Escalation",
    description: "Immediately escalates leads who mention 'emergency', 'flooding', 'no heat', or 'no AC' to the owner.",
    trigger: "AI detects emergency keyword",
    actions: ["Send urgent owner SMS", "Send push notification", "Set lead priority: Critical"],
    stopOn: "Owner acknowledges or takes over",
    active: true,
    triggered: 8,
    completed: 8,
    category: "Escalation",
  },
  {
    id: 8,
    name: "After-Hours Response",
    description: "Handles leads that come in outside business hours with a custom message and next-day booking.",
    trigger: "Lead arrives outside business hours",
    actions: ["Send after-hours AI response", "Offer next-day earliest appointment"],
    stopOn: "Appointment booked",
    active: true,
    triggered: 34,
    completed: 29,
    category: "Lead Response",
  },
];

const CATEGORIES = ["All", "Lead Response", "Follow-Up", "Appointments", "Reviews", "Re-engagement", "Escalation"];

export default function Automations() {
  const [toggles, setToggles] = useState<Record<number, boolean>>(
    Object.fromEntries(AUTOMATIONS.map(a => [a.id, a.active]))
  );
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [expanded, setExpanded] = useState<number | null>(null);

  const filtered = AUTOMATIONS.filter(a => categoryFilter === "All" || a.category === categoryFilter);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Automations</h1>
          <p className="text-slate-400 text-sm mt-0.5">{AUTOMATIONS.filter(a => toggles[a.id]).length} active automations</p>
        </div>
        <Button className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white">
          <Zap className="h-4 w-4 mr-2" /> Create Automation
        </Button>
      </div>

      <div className="flex gap-2 flex-wrap mb-5">
        {CATEGORIES.map(c => (
          <button
            key={c}
            onClick={() => setCategoryFilter(c)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border ${categoryFilter === c ? "bg-[#FF6B2B] text-white border-[#FF6B2B]" : "bg-white/5 text-slate-400 hover:text-white border-white/10"}`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.map((auto) => {
          const isExpanded = expanded === auto.id;
          const isActive = toggles[auto.id];
          const completionRate = auto.triggered > 0 ? Math.round((auto.completed / auto.triggered) * 100) : 0;

          return (
            <div
              key={auto.id}
              className={`bg-[#0A0F1E] border rounded-2xl overflow-hidden transition-all ${isActive ? "border-white/10" : "border-white/5 opacity-70"}`}
            >
              <div className="flex items-center gap-4 p-5">
                <div className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${isActive ? "bg-[#FF6B2B]/20" : "bg-white/5"}`}>
                  <Zap className={`h-5 w-5 ${isActive ? "text-[#FF6B2B]" : "text-slate-500"}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="text-white font-semibold text-sm">{auto.name}</p>
                    <Badge className="text-xs bg-white/10 text-slate-400 border-white/10">{auto.category}</Badge>
                    {isActive && <Badge className="text-xs bg-green-500/20 text-green-400 border-green-500/30">Active</Badge>}
                  </div>
                  <p className="text-slate-400 text-xs truncate">{auto.description}</p>
                </div>
                <div className="flex items-center gap-6 shrink-0">
                  {auto.triggered > 0 && (
                    <div className="text-center hidden md:block">
                      <p className="text-white font-semibold">{auto.triggered}</p>
                      <p className="text-slate-500 text-xs">triggered</p>
                    </div>
                  )}
                  {auto.triggered > 0 && (
                    <div className="text-center hidden md:block">
                      <p className="text-green-400 font-semibold">{completionRate}%</p>
                      <p className="text-slate-500 text-xs">completed</p>
                    </div>
                  )}
                  <button
                    data-testid={`toggle-automation-${auto.id}`}
                    onClick={() => setToggles(t => ({ ...t, [auto.id]: !t[auto.id] }))}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${isActive ? "bg-[#FF6B2B]" : "bg-white/20"}`}
                  >
                    <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isActive ? "translate-x-6" : "translate-x-1"}`} />
                  </button>
                  <Button size="sm" variant="outline" className="border-white/20 text-white h-8 w-8 p-0">
                    <Edit2 className="h-3.5 w-3.5" />
                  </Button>
                  <button
                    onClick={() => setExpanded(isExpanded ? null : auto.id)}
                    className="text-slate-400 hover:text-white transition-colors"
                    data-testid={`expand-automation-${auto.id}`}
                  >
                    <ChevronRight className={`h-4 w-4 transition-transform ${isExpanded ? "rotate-90" : ""}`} />
                  </button>
                </div>
              </div>

              {isExpanded && (
                <div className="border-t border-white/10 p-5 bg-white/[0.01]">
                  <div className="grid md:grid-cols-3 gap-6 text-sm">
                    <div>
                      <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Trigger</p>
                      <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
                        <div className="flex items-center gap-2">
                          <Play className="h-3.5 w-3.5 text-blue-400" />
                          <span className="text-blue-300 text-xs">{auto.trigger}</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Actions</p>
                      <div className="space-y-2">
                        {auto.actions.map((action, i) => (
                          <div key={i} className="flex items-start gap-2">
                            <div className="h-5 w-5 rounded-full bg-[#FF6B2B]/20 flex items-center justify-center text-xs text-[#FF6B2B] font-bold shrink-0 mt-0.5">{i + 1}</div>
                            <span className="text-slate-300 text-xs">{action}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Stop Condition</p>
                      <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                        <div className="flex items-center gap-2">
                          <Pause className="h-3.5 w-3.5 text-red-400" />
                          <span className="text-red-300 text-xs">{auto.stopOn}</span>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="mt-3 w-full border-white/20 text-white text-xs h-7">
                        Test Automation
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
