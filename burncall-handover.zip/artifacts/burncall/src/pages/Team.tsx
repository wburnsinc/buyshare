import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Plus, Trash2, Shield, Mail } from "lucide-react";

const MEMBERS = [
  { id: 1, name: "Jason Burke", email: "jason@burkeac.com", role: "Owner", lastActive: "Active now", avatar: "JB", notifications: true },
  { id: 2, name: "Mike Torres", email: "mike@burkeac.com", role: "Dispatcher", lastActive: "2 hours ago", avatar: "MT", notifications: true },
  { id: 3, name: "Dave Ramirez", email: "dave@burkeac.com", role: "Technician", lastActive: "Yesterday", avatar: "DR", notifications: false },
];

const ROLE_COLORS: Record<string, string> = {
  Owner: "bg-[#FF6B2B]/20 text-[#FF6B2B] border-[#FF6B2B]/30",
  Dispatcher: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  Technician: "bg-green-500/20 text-green-400 border-green-500/30",
  Admin: "bg-purple-500/20 text-purple-400 border-purple-500/30",
};

export default function Team() {
  const [members, setMembers] = useState(MEMBERS);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("Technician");
  const [inviting, setInviting] = useState(false);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Team</h1>
          <p className="text-slate-400 text-sm mt-0.5">{members.length} team members on your account</p>
        </div>
        <Button className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white" onClick={() => setInviting(true)} data-testid="invite-member">
          <Plus className="h-4 w-4 mr-2" /> Invite Member
        </Button>
      </div>

      {inviting && (
        <div className="bg-[#0A0F1E] border border-[#FF6B2B]/30 rounded-2xl p-5 mb-5">
          <p className="text-white font-semibold mb-4">Invite a team member</p>
          <div className="flex gap-3 flex-wrap">
            <Input placeholder="Email address" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 flex-1 min-w-[200px]" data-testid="invite-email" />
            <select value={inviteRole} onChange={e => setInviteRole(e.target.value)} className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none" data-testid="invite-role">
              <option>Admin</option>
              <option>Dispatcher</option>
              <option>Technician</option>
            </select>
            <Button className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white text-sm" onClick={() => {
              if (inviteEmail) {
                const name = inviteEmail.split("@")[0];
                setMembers(m => [...m, { id: Date.now(), name, email: inviteEmail, role: inviteRole, lastActive: "Invite pending", avatar: name.slice(0, 2).toUpperCase(), notifications: true }]);
                setInviteEmail("");
                setInviting(false);
              }
            }}>Send Invite</Button>
            <Button variant="outline" className="border-white/20 text-white text-sm" onClick={() => setInviting(false)}>Cancel</Button>
          </div>
        </div>
      )}

      <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl overflow-hidden mb-8">
        <div className="p-4 border-b border-white/10">
          <p className="text-xs text-slate-500 uppercase tracking-wider">Members</p>
        </div>
        {members.map((member, i) => (
          <div key={member.id} className={`flex items-center gap-4 p-5 ${i < members.length - 1 ? "border-b border-white/5" : ""}`}>
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#FF6B2B]/60 to-orange-700/60 flex items-center justify-center text-white font-bold text-sm shrink-0">{member.avatar}</div>
            <div className="flex-1">
              <p className="text-white font-medium text-sm">{member.name}</p>
              <p className="text-slate-400 text-xs flex items-center gap-1.5 mt-0.5">
                <Mail className="h-3 w-3" /> {member.email}
              </p>
            </div>
            <div className="hidden md:flex items-center gap-3">
              <div className={`h-1.5 w-1.5 rounded-full ${member.lastActive === "Active now" ? "bg-green-400" : "bg-slate-600"}`} />
              <span className="text-slate-500 text-xs">{member.lastActive}</span>
            </div>
            <Badge className={`${ROLE_COLORS[member.role]} text-xs border`}>{member.role}</Badge>
            <div className="flex items-center gap-2">
              {member.role !== "Owner" && (
                <button onClick={() => setMembers(m => m.filter(x => x.id !== member.id))} className="text-slate-600 hover:text-red-400 transition-colors p-1" data-testid={`remove-member-${member.id}`}>
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <Shield className="h-5 w-5 text-[#FF6B2B]" />
          <p className="text-white font-semibold">Role Permissions</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-slate-500 text-xs uppercase tracking-wider">
                <th className="text-left pb-3">Permission</th>
                <th className="text-center pb-3">Owner</th>
                <th className="text-center pb-3">Admin</th>
                <th className="text-center pb-3">Dispatcher</th>
                <th className="text-center pb-3">Technician</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {[
                ["View & manage all leads", true, true, true, false],
                ["Take over conversations", true, true, true, true],
                ["Manage automations", true, true, false, false],
                ["View revenue dashboard", true, true, false, false],
                ["Manage team members", true, true, false, false],
                ["Billing & subscription", true, false, false, false],
                ["Knowledge base editing", true, true, true, false],
              ].map(([perm, ...roles]) => (
                <tr key={String(perm)}>
                  <td className="py-3 text-slate-300">{perm}</td>
                  {roles.map((allowed, j) => (
                    <td key={j} className="text-center py-3">
                      <span className={allowed ? "text-green-400" : "text-slate-700"}>{allowed ? "✓" : "–"}</span>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
