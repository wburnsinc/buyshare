import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownRight, PhoneMissed, DollarSign, CalendarCheck, Users } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from "recharts";

const data = [
  { name: 'Mon', leads: 4, booked: 2 },
  { name: 'Tue', leads: 7, booked: 3 },
  { name: 'Wed', leads: 5, booked: 2 },
  { name: 'Thu', leads: 9, booked: 4 },
  { name: 'Fri', leads: 6, booked: 3 },
  { name: 'Sat', leads: 12, booked: 6 },
  { name: 'Sun', leads: 8, booked: 4 },
];

export default function Dashboard() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-2">
        <div>
          <h1 className="text-2xl font-bold text-white">Command Center</h1>
          <p className="text-sm text-slate-400">Here's what's happening with your business today.</p>
        </div>
        
        <div className="bg-[#10B981]/10 border border-[#10B981]/20 rounded-lg px-4 py-2 flex items-center gap-3">
          <div className="h-2 w-2 rounded-full bg-[#10B981] animate-pulse" />
          <p className="text-sm font-medium text-[#10B981]">
            Today's Wins: 4 appointments booked • $5,600 revenue rescued
          </p>
        </div>
      </div>

      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard 
          title="New Leads" 
          value="56" 
          trend="+24%" 
          isPositive={true} 
          icon={Users} 
          color="text-[#3B82F6]" 
          bg="bg-[#3B82F6]/10" 
        />
        <MetricCard 
          title="Jobs Booked" 
          value="21" 
          trend="+31%" 
          isPositive={true} 
          icon={CalendarCheck} 
          color="text-[#10B981]" 
          bg="bg-[#10B981]/10" 
        />
        <MetricCard 
          title="Revenue Rescued" 
          value="$18,640" 
          trend="+28%" 
          isPositive={true} 
          icon={DollarSign} 
          color="text-[#FF6B2B]" 
          bg="bg-[#FF6B2B]/10" 
        />
        <MetricCard 
          title="Missed Calls" 
          value="3" 
          trend="-42%" 
          isPositive={true} 
          icon={PhoneMissed} 
          color="text-slate-400" 
          bg="bg-white/5" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <Card className="col-span-1 lg:col-span-2 bg-[#0A0F1E] border-white/10 shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold text-white">Lead Volume & Conversions (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorBooked" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#FF6B2B" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#FF6B2B" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="name" stroke="#64748B" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748B" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0A0F1E', borderColor: 'rgba(255,255,255,0.1)', color: '#fff' }}
                    itemStyle={{ color: '#fff' }}
                  />
                  <Area type="monotone" dataKey="leads" name="Total Leads" stroke="#3B82F6" strokeWidth={2} fillOpacity={1} fill="url(#colorLeads)" />
                  <Area type="monotone" dataKey="booked" name="Booked Jobs" stroke="#FF6B2B" strokeWidth={2} fillOpacity={1} fill="url(#colorBooked)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Activity Feed */}
        <Card className="bg-[#0A0F1E] border-white/10 shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold text-white">Live AI Activity</CardTitle>
          </CardHeader>
          <CardContent className="px-0">
            <div className="flex flex-col">
              {[
                { time: "2 min ago", text: "Texted Emily R. after missed call.", tag: "SMS Sent" },
                { time: "5 min ago", text: "Qualified James T. for AC Installation.", tag: "Lead Qual" },
                { time: "12 min ago", text: "Booked Sarah M. for Tomorrow 2PM.", tag: "Booked", highlight: true },
                { time: "18 min ago", text: "Answered Website Form from Mike D.", tag: "Web Lead" },
                { time: "34 min ago", text: "Followed up with Chris P. on estimate.", tag: "Follow Up" },
              ].map((activity, i) => (
                <div key={i} className="flex flex-col gap-1 px-6 py-3 hover:bg-white/[0.02] border-b border-white/5 last:border-0 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">{activity.time}</span>
                    <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${activity.highlight ? 'bg-[#FF6B2B]/20 text-[#FF6B2B] border-none' : 'bg-white/5 text-slate-300 border-white/10'}`}>
                      {activity.tag}
                    </Badge>
                  </div>
                  <p className={`text-sm ${activity.highlight ? 'text-white font-medium' : 'text-slate-300'}`}>
                    {activity.text}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pipeline Kanban Preview */}
      <Card className="bg-[#0A0F1E] border-white/10 shadow-xl mt-2">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-base font-semibold text-white">Active Pipeline</CardTitle>
          <Badge className="bg-[#3B82F6]/20 text-[#3B82F6] hover:bg-[#3B82F6]/30 border-none">View All Leads</Badge>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <KanbanCol title="New Leads" count={3} color="bg-blue-500">
              <LeadCard name="John Smith" service="Plumbing" time="10m ago" score="HOT" />
              <LeadCard name="Alice W." service="HVAC Repair" time="1h ago" score="WARM" />
            </KanbanCol>
            <KanbanCol title="Contacted (AI)" count={12} color="bg-orange-500">
              <LeadCard name="Robert K." service="Electrical" time="Active" score="HOT" />
              <LeadCard name="Dave M." service="Landscaping" time="Active" score="WARM" />
              <LeadCard name="Emma R." service="Roofing" time="Waiting" score="COLD" />
            </KanbanCol>
            <KanbanCol title="Qualified" count={5} color="bg-purple-500">
              <LeadCard name="Mike T." service="Pest Control" time="Needs Appt" score="HOT" />
              <LeadCard name="Susan J." service="HVAC Install" time="Needs Appt" score="HOT" />
            </KanbanCol>
            <KanbanCol title="Booked" count={8} color="bg-green-500">
              <LeadCard name="Sarah M." service="AC Repair" time="Tomorrow 2PM" score="WON" highlight />
              <LeadCard name="James T." service="Installation" time="Friday 9AM" score="WON" highlight />
            </KanbanCol>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function MetricCard({ title, value, trend, isPositive, icon: Icon, color, bg }: any) {
  return (
    <Card className="bg-[#0A0F1E] border-white/10 shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-xl ${bg}`}>
            <Icon className={`h-5 w-5 ${color}`} />
          </div>
          <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${isPositive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
            {isPositive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {trend}
          </div>
        </div>
        <p className="text-sm font-medium text-slate-400 mb-1">{title}</p>
        <h3 className="text-3xl font-bold text-white">{value}</h3>
      </CardContent>
    </Card>
  );
}

function KanbanCol({ title, count, color, children }: any) {
  return (
    <div className="bg-white/[0.02] rounded-xl p-3 border border-white/5 h-full">
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${color}`} />
          <h4 className="text-sm font-semibold text-white">{title}</h4>
        </div>
        <span className="text-xs font-medium text-slate-400 bg-white/10 px-2 py-0.5 rounded-full">{count}</span>
      </div>
      <div className="space-y-2">
        {children}
      </div>
    </div>
  );
}

function LeadCard({ name, service, time, score, highlight }: any) {
  const isHot = score === 'HOT' || score === 'WON';
  return (
    <div className={`bg-[#0A0F1E] p-3 rounded-lg border ${highlight ? 'border-[#10B981]/30 shadow-[0_0_15px_rgba(16,185,129,0.1)]' : 'border-white/10'} hover:border-[#FF6B2B]/50 transition-colors cursor-pointer`}>
      <div className="flex justify-between items-start mb-2">
        <span className="text-sm font-medium text-white">{name}</span>
        <Badge className={`text-[9px] px-1 py-0 h-4 border-none ${isHot ? 'bg-[#FF6B2B]/20 text-[#FF6B2B]' : 'bg-white/10 text-slate-300'}`}>
          {score}
        </Badge>
      </div>
      <div className="flex justify-between items-center text-xs">
        <span className="text-slate-400">{service}</span>
        <span className="text-slate-500 font-medium">{time}</span>
      </div>
    </div>
  );
}
