import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { BookOpen, Plus, Trash2, Upload, Bot, ChevronDown, ChevronUp } from "lucide-react";

const FAQS = [
  { q: "Do you offer emergency service?", a: "Yes! We provide 24/7 emergency service for heating, cooling, and plumbing issues. Emergency rates may apply after hours." },
  { q: "What areas do you serve?", a: "We serve Orange, Seminole, Osceola, and Brevard counties in Central Florida. Call us to confirm coverage for your ZIP code." },
  { q: "Do you offer financing?", a: "Yes, we offer 0% financing for 12 months on systems over $2,000 through our partner GreenSky. Apply in minutes." },
  { q: "How long does an AC repair take?", a: "Most repairs take 1–3 hours. Full system replacements typically take 4–8 hours depending on complexity." },
  { q: "Are your technicians licensed?", a: "All technicians are NATE-certified, EPA-licensed, and background-checked. We carry full liability insurance." },
];

const SERVICES = [
  { name: "AC Repair", price: "From $89 diagnostic", qualify: "Age of system, model number, what's happening" },
  { name: "AC Installation", price: "From $3,800 installed", qualify: "Square footage, current system type, budget range" },
  { name: "Heating Repair", price: "From $89 diagnostic", qualify: "Type of heating system, issue description" },
  { name: "Duct Cleaning", price: "$299 for up to 10 vents", qualify: "Number of vents, when last cleaned" },
  { name: "Plumbing Repair", price: "From $150/hr", qualify: "Location of issue, urgency level" },
];

const TABS = ["FAQs", "Services", "Service Areas", "Documents", "AI Instructions"];

export default function KnowledgeBase() {
  const [tab, setTab] = useState("FAQs");
  const [faqs, setFaqs] = useState(FAQS);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [addingFaq, setAddingFaq] = useState(false);
  const [newQ, setNewQ] = useState("");
  const [newA, setNewA] = useState("");
  const [aiInstruction, setAiInstruction] = useState("Always be friendly and empathetic. Never quote prices on the spot — say 'we'll give you an exact quote on-site'. Do not mention competitors. Always confirm the customer's ZIP code before promising service. For plumbing emergencies, always ask if water is actively flowing before dispatching. Prioritize same-day bookings for HVAC issues in summer.");
  const [testQ, setTestQ] = useState("");
  const [testAnswer, setTestAnswer] = useState<string | null>(null);

  const testAI = () => {
    const q = testQ.toLowerCase();
    if (q.includes("emergency")) setTestAnswer("Yes, we offer 24/7 emergency service! Emergency rates may apply after hours. What type of emergency are you experiencing — heating, cooling, or plumbing?");
    else if (q.includes("area") || q.includes("zip") || q.includes("serve")) setTestAnswer("We serve Orange, Seminole, Osceola, and Brevard counties in Central Florida. What's your ZIP code so I can confirm we cover your area?");
    else if (q.includes("financ") || q.includes("pay")) setTestAnswer("Yes, we offer 0% financing for 12 months on systems over $2,000! We partner with GreenSky — you can apply in minutes with no impact on your credit.");
    else if (q.includes("price") || q.includes("cost") || q.includes("how much")) setTestAnswer("Great question! We'll give you an exact quote on-site — no guessing. Can I get your ZIP code and a description of the issue so I can connect you with the right technician?");
    else setTestAnswer("Thanks for reaching out! I'd be happy to help. Could you tell me more about what you need, and I'll make sure we get the right person to you quickly?");
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Knowledge Base</h1>
          <p className="text-slate-400 text-sm mt-0.5">Train your AI with your business information</p>
        </div>
      </div>

      <div className="flex gap-2 mb-6 border-b border-white/10 pb-4">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${tab === t ? "bg-[#FF6B2B]/20 text-[#FF6B2B]" : "text-slate-400 hover:text-white"}`} data-testid={`kb-tab-${t.toLowerCase().replace(/\s+/g, "-")}`}>{t}</button>
        ))}
      </div>

      {tab === "FAQs" && (
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="bg-[#0A0F1E] border border-white/10 rounded-xl overflow-hidden">
              <button className="w-full flex items-center justify-between p-4 text-left" onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}>
                <span className="text-white font-medium text-sm">{faq.q}</span>
                <div className="flex items-center gap-2">
                  <button onClick={e => { e.stopPropagation(); setFaqs(f => f.filter((_, j) => j !== i)); }} className="text-slate-600 hover:text-red-400 transition-colors p-1"><Trash2 className="h-3.5 w-3.5" /></button>
                  {expandedFaq === i ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
                </div>
              </button>
              {expandedFaq === i && (
                <div className="border-t border-white/5 px-4 pb-4 pt-3">
                  <Textarea defaultValue={faq.a} className="bg-white/5 border-white/10 text-slate-300 text-sm resize-none" rows={2} />
                  <Button size="sm" className="mt-2 bg-white/10 hover:bg-white/20 text-white text-xs h-7">Save</Button>
                </div>
              )}
            </div>
          ))}
          {addingFaq ? (
            <div className="bg-[#0A0F1E] border border-[#FF6B2B]/30 rounded-xl p-4 space-y-3">
              <Input placeholder="Question" value={newQ} onChange={e => setNewQ(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 text-sm" />
              <Textarea placeholder="Answer" value={newA} onChange={e => setNewA(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 text-sm resize-none" rows={2} />
              <div className="flex gap-2">
                <Button size="sm" className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white text-xs h-8" onClick={() => { if (newQ && newA) { setFaqs(f => [...f, { q: newQ, a: newA }]); setNewQ(""); setNewA(""); setAddingFaq(false); } }}>Add FAQ</Button>
                <Button size="sm" variant="outline" className="border-white/20 text-white text-xs h-8" onClick={() => setAddingFaq(false)}>Cancel</Button>
              </div>
            </div>
          ) : (
            <button onClick={() => setAddingFaq(true)} className="w-full flex items-center justify-center gap-2 p-4 border border-dashed border-white/20 rounded-xl text-slate-400 hover:text-white hover:border-white/40 transition-colors text-sm" data-testid="add-faq">
              <Plus className="h-4 w-4" /> Add FAQ
            </button>
          )}
        </div>
      )}

      {tab === "Services" && (
        <div className="space-y-3">
          {SERVICES.map((svc, i) => (
            <div key={i} className="bg-[#0A0F1E] border border-white/10 rounded-xl p-5">
              <div className="flex items-start justify-between mb-2">
                <p className="text-white font-semibold">{svc.name}</p>
                <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">{svc.price}</Badge>
              </div>
              <p className="text-slate-400 text-xs">Qualifying questions: {svc.qualify}</p>
            </div>
          ))}
          <button className="w-full flex items-center justify-center gap-2 p-4 border border-dashed border-white/20 rounded-xl text-slate-400 hover:text-white transition-colors text-sm">
            <Plus className="h-4 w-4" /> Add Service
          </button>
        </div>
      )}

      {tab === "Service Areas" && (
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6">
          <p className="text-sm font-semibold text-white mb-4">Service ZIP Codes</p>
          <div className="flex flex-wrap gap-2 mb-4">
            {["32789", "32792", "32801", "32803", "32804", "32806", "32807", "32808", "32809", "32810"].map(zip => (
              <span key={zip} className="bg-white/5 border border-white/10 rounded-lg px-3 py-1 text-sm text-slate-300 flex items-center gap-1.5">
                {zip} <button className="text-slate-600 hover:text-red-400"><Trash2 className="h-3 w-3" /></button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <Input placeholder="Add ZIP code..." className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 text-sm max-w-xs" />
            <Button size="sm" className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white text-xs">Add</Button>
          </div>
        </div>
      )}

      {tab === "Documents" && (
        <div className="space-y-4">
          <div className="bg-[#0A0F1E] border-2 border-dashed border-white/20 rounded-2xl p-10 text-center hover:border-[#FF6B2B]/40 transition-colors cursor-pointer">
            <Upload className="h-8 w-8 text-slate-400 mx-auto mb-3" />
            <p className="text-white font-medium mb-1">Upload documents</p>
            <p className="text-slate-500 text-sm">PDF, DOCX, TXT — up to 10MB each</p>
            <p className="text-slate-600 text-xs mt-2">AI will use these to answer customer questions</p>
          </div>
          <div className="space-y-2">
            {["Service Agreement Template.pdf", "Warranty Policy.pdf", "Financing Options.docx"].map(doc => (
              <div key={doc} className="flex items-center gap-3 bg-[#0A0F1E] border border-white/10 rounded-xl p-4">
                <BookOpen className="h-4 w-4 text-blue-400 shrink-0" />
                <span className="text-slate-300 text-sm flex-1">{doc}</span>
                <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">Indexed</Badge>
                <button className="text-slate-600 hover:text-red-400"><Trash2 className="h-4 w-4" /></button>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "AI Instructions" && (
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <p className="text-sm font-semibold text-white mb-3">Custom AI Behavior Instructions</p>
            <Textarea
              value={aiInstruction}
              onChange={e => setAiInstruction(e.target.value)}
              className="bg-[#0A0F1E] border-white/10 text-slate-300 text-sm resize-none min-h-[240px]"
              placeholder="Tell the AI how to behave..."
              data-testid="ai-instructions"
            />
            <Button className="mt-3 bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white text-sm">Save Instructions</Button>
          </div>
          <div>
            <p className="text-sm font-semibold text-white mb-3">Test AI Response</p>
            <Input
              placeholder="Ask a question a customer might send..."
              value={testQ}
              onChange={e => setTestQ(e.target.value)}
              className="bg-[#0A0F1E] border-white/10 text-white placeholder:text-slate-600 text-sm mb-3"
              data-testid="test-ai-input"
            />
            <Button onClick={testAI} className="w-full bg-white/10 hover:bg-white/20 text-white text-sm mb-4" disabled={!testQ}>
              <Bot className="h-4 w-4 mr-2" /> Test AI Response
            </Button>
            {testAnswer && (
              <div className="bg-[#FF6B2B]/10 border border-[#FF6B2B]/20 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Bot className="h-4 w-4 text-[#FF6B2B]" />
                  <span className="text-xs text-[#FF6B2B] font-semibold">AI Response</span>
                </div>
                <p className="text-slate-200 text-sm leading-relaxed">{testAnswer}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
