import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Copy, ExternalLink, Plug } from "lucide-react";

const INTEGRATIONS = [
  { id: "gcal", name: "Google Calendar", desc: "Sync appointments directly to your Google Calendar.", category: "Calendar", connected: true, logo: "GC" },
  { id: "twilio", name: "Twilio", desc: "Power SMS lead response and missed-call text back.", category: "SMS", connected: true, logo: "TW" },
  { id: "website", name: "Website Forms", desc: "Capture leads from any web form via embed or webhook.", category: "Lead Capture", connected: true, logo: "WF" },
  { id: "calendly", name: "Calendly", desc: "Let leads self-schedule using your Calendly booking page.", category: "Calendar", connected: false, logo: "CL" },
  { id: "gmail", name: "Gmail", desc: "Monitor your Gmail inbox for inbound email leads.", category: "Email", connected: false, logo: "GM" },
  { id: "outlook", name: "Outlook", desc: "Connect your Outlook inbox to capture email leads.", category: "Email", connected: false, logo: "OL" },
  { id: "hubspot", name: "HubSpot", desc: "Sync leads and contacts with your HubSpot CRM.", category: "CRM", connected: false, logo: "HS" },
  { id: "jobber", name: "Jobber", desc: "Push booked jobs directly into Jobber for dispatch.", category: "Field Service", connected: false, logo: "JB" },
  { id: "servicetitan", name: "ServiceTitan", desc: "Integrate with ServiceTitan for full job management.", category: "Field Service", connected: false, logo: "ST" },
  { id: "housecall", name: "Housecall Pro", desc: "Connect with Housecall Pro for scheduling and dispatch.", category: "Field Service", connected: false, logo: "HP" },
  { id: "zapier", name: "Zapier", desc: "Connect BurnCall to 6,000+ apps via Zapier.", category: "Automation", connected: false, logo: "ZP" },
  { id: "webhooks", name: "Webhooks", desc: "Build custom integrations with raw webhook events.", category: "Developer", connected: false, logo: "WH" },
];

const CATEGORIES = ["All", "Calendar", "SMS", "Lead Capture", "Email", "CRM", "Field Service", "Automation", "Developer"];

const LOGO_COLORS: Record<string, string> = {
  GC: "bg-red-500/20 text-red-400", TW: "bg-red-600/20 text-red-400", WF: "bg-blue-500/20 text-blue-400",
  CL: "bg-cyan-500/20 text-cyan-400", GM: "bg-red-500/20 text-red-400", OL: "bg-blue-600/20 text-blue-400",
  HS: "bg-orange-500/20 text-orange-400", JB: "bg-green-600/20 text-green-400", ST: "bg-yellow-500/20 text-yellow-400",
  HP: "bg-green-500/20 text-green-400", ZP: "bg-orange-500/20 text-orange-400", WH: "bg-purple-500/20 text-purple-400",
};

export default function Integrations() {
  const [connected, setConnected] = useState<Record<string, boolean>>(
    Object.fromEntries(INTEGRATIONS.map(i => [i.id, i.connected]))
  );
  const [category, setCategory] = useState("All");
  const [showWebhook, setShowWebhook] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const filtered = INTEGRATIONS.filter(i => category === "All" || i.category === category);

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Integrations</h1>
          <p className="text-slate-400 text-sm mt-0.5">{Object.values(connected).filter(Boolean).length} connected</p>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap mb-6">
        {CATEGORIES.map(c => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${category === c ? "bg-[#FF6B2B] text-white border-[#FF6B2B]" : "bg-white/5 text-slate-400 hover:text-white border-white/10"}`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
        {filtered.map((intg) => {
          const isConnected = connected[intg.id];
          return (
            <div
              key={intg.id}
              className={`bg-[#0A0F1E] border rounded-2xl p-5 flex flex-col gap-4 ${isConnected ? "border-white/10" : "border-white/5"}`}
              data-testid={`integration-${intg.id}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`h-10 w-10 rounded-xl flex items-center justify-center text-sm font-bold ${LOGO_COLORS[intg.logo]}`}>
                    {intg.logo}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{intg.name}</p>
                    <Badge className="text-xs bg-white/5 text-slate-500 border-white/10 mt-0.5">{intg.category}</Badge>
                  </div>
                </div>
                {isConnected && <CheckCircle2 className="h-5 w-5 text-green-400 shrink-0" />}
              </div>
              <p className="text-slate-400 text-xs leading-relaxed flex-1">{intg.desc}</p>
              <Button
                size="sm"
                data-testid={`connect-${intg.id}`}
                onClick={() => {
                  if (intg.id === "webhooks") { setShowWebhook(true); return; }
                  setConnected(c => ({ ...c, [intg.id]: !c[intg.id] }));
                }}
                className={`w-full text-xs h-9 font-medium ${isConnected ? "bg-white/5 hover:bg-white/10 text-white border border-white/10" : "bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white"}`}
              >
                {isConnected ? "Disconnect" : intg.id === "webhooks" ? "Configure" : "Connect"}
              </Button>
            </div>
          );
        })}
      </div>

      {/* Webhook section */}
      {showWebhook && (
        <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Plug className="h-5 w-5 text-[#FF6B2B]" />
              <h2 className="text-white font-semibold">Webhook Configuration</h2>
            </div>
            <button onClick={() => setShowWebhook(false)} className="text-slate-400 hover:text-white text-sm">Close</button>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Your Webhook URL</p>
                <div className="flex gap-2">
                  <code className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-green-400 font-mono overflow-hidden text-ellipsis">
                    https://api.burncall.co/webhooks/abc123xyz
                  </code>
                  <Button size="sm" variant="outline" className="border-white/20 text-white shrink-0" onClick={() => copyText("https://api.burncall.co/webhooks/abc123xyz", "url")}>
                    {copied === "url" ? <CheckCircle2 className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
                  </Button>
                </div>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">API Key</p>
                <div className="flex gap-2">
                  <code className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-300 font-mono">bc_live_sk_••••••••••••••••</code>
                  <Button size="sm" variant="outline" className="border-white/20 text-white shrink-0" onClick={() => copyText("bc_live_sk_real_key_here", "key")}>
                    {copied === "key" ? <CheckCircle2 className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
                  </Button>
                </div>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Event Types</p>
                <div className="space-y-1.5">
                  {["lead.created", "lead.qualified", "lead.booked", "lead.won", "lead.lost", "appointment.confirmed", "appointment.cancelled"].map(e => (
                    <div key={e} className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded border-white/20" />
                      <code className="text-xs text-slate-300 font-mono">{e}</code>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Example Payload</p>
              <div className="relative">
                <pre className="bg-[#050812] border border-white/10 rounded-xl p-4 text-xs text-green-400 font-mono overflow-auto max-h-64">
{`{
  "event": "lead.qualified",
  "timestamp": "2025-05-20T14:17:32Z",
  "data": {
    "lead_id": "lead_abc123",
    "name": "Sarah Mitchell",
    "phone": "+14075550192",
    "service": "AC Repair",
    "score": 92,
    "status": "Qualified",
    "source": "website",
    "est_value": 1250,
    "appointment": {
      "date": "2025-05-20",
      "time": "14:00"
    }
  }
}`}
                </pre>
                <Button size="sm" variant="outline" className="absolute top-2 right-2 border-white/20 text-white text-xs h-7" onClick={() => copyText("payload", "payload")}>
                  {copied === "payload" ? "Copied!" : <Copy className="h-3 w-3" />}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
