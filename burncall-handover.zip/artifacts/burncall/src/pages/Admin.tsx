import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, TrendingUp, Bot, AlertCircle, Search, Shield, CheckCircle2, X, MoreHorizontal } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

const ACCOUNTS = [
  { id: 1, name: "Burke Air Conditioning", email: "jason@burkeac.com", plan: "Growth", status: "Active", leads: 156, mrr: 299, joined: "Mar 1, 2025", industry: "HVAC" },
  { id: 2, name: "Premier Plumbing", email: "mike@premierplumbing.com", plan: "Pro", status: "Active", leads: 412, mrr: 499, joined: "Jan 15, 2025", industry: "Plumbing" },
  { id: 3, name: "Sunshine Roofing", email: "dave@sunshineroofing.com", plan: "Starter", status: "Active", leads: 67, mrr: 149, joined: "Apr 10, 2025", industry: "Roofing" },
  { id: 4, name: "Elite Electrical", email: "sarah@eliteelectric.com", plan: "Growth", status: "Trial", leads: 23, mrr: 0, joined: "Jun 15, 2025", industry: "Electrical" },
  { id: 5, name: "Green Lawn Care", email: "tom@greenlawn.com", plan: "Starter", status: "Churned", leads: 0, mrr: 0, joined: "Feb 1, 2025", industry: "Landscaping" },
  { id: 6, name: "Pest Shield Pro", email: "amy@pestshield.com", plan: "Growth", status: "Active", leads: 89, mrr: 299, joined: "Feb 20, 2025", industry: "Pest Control" },
  { id: 7, name: "QuickClean Services", email: "jen@quickclean.com", plan: "Pro", status: "Active", leads: 234, mrr: 499, joined: "Nov 1, 2024", industry: "Cleaning" },
  { id: 8, name: "Apex Restoration", email: "kyle@apexrestore.com", plan: "Pro", status: "Active", leads: 178, mrr: 499, joined: "Dec 5, 2024", industry: "Restoration" },
];

const AUTOMATION_HEALTH = [
  { name: "Instant Web Lead Response", triggers: 1240, success: 1196, failures: 44, rate: 96.4 },
  { name: "Missed-Call Text Back", triggers: 387, success: 381, failures: 6, rate: 98.5 },
  { name: "No-Response Follow-Up", triggers: 215, success: 198, failures: 17, rate: 92.1 },
  { name: "Appointment Reminder", triggers: 156, success: 156, failures: 0, rate: 100 },
  { name: "Emergency Escalation", triggers: 43, success: 42, failures: 1, rate: 97.7 },
];

const AI_USAGE = [
  { day: "Mon", tokens: 14200, calls: 89 },
  { day: "Tue", tokens: 18900, calls: 124 },
  { day: "Wed", tokens: 21300, calls: 147 },
  { day: "Thu", tokens: 16800, calls: 108 },
  { day: "Fri", tokens: 23100, calls: 159 },
  { day: "Sat", tokens: 8900, calls: 61 },
  { day: "Sun", tokens: 6200, calls: 43 },
];

const MRR_TREND = [
  { month: "Jan", mrr: 5820 }, { month: "Feb", mrr: 7140 }, { month: "Mar", mrr: 9430 },
  { month: "Apr", mrr: 11200 }, { month: "May", mrr: 13890 }, { month: "Jun", mrr: 16340 },
];

const STATUS_COLORS: Record<string, string> = {
  Active: "bg-green-500/20 text-green-400 border-green-500/30",
  Trial: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  Churned: "bg-red-500/20 text-red-400 border-red-500/30",
};

const TABS = ["Overview", "Accounts", "Automations", "AI Usage"];

export default function Admin() {
  const [tab, setTab] = useState("Overview");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const totalMRR = ACCOUNTS.filter(a => a.status === "Active").reduce((s, a) => s + a.mrr, 0);
  const activeAccounts = ACCOUNTS.filter(a => a.status === "Active").length;
  const trialAccounts = ACCOUNTS.filter(a => a.status === "Trial").length;
  const totalLeads = ACCOUNTS.reduce((s, a) => s + a.leads, 0);

  const filteredAccounts = ACCOUNTS.filter(a =>
    (statusFilter === "All" || a.status === statusFilter) &&
    (a.name.toLowerCase().includes(search.toLowerCase()) || a.email.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-[#050812] text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-[#FF6B2B]/20 flex items-center justify-center">
              <Shield className="h-5 w-5 text-[#FF6B2B]" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Platform Admin</h1>
              <p className="text-slate-400 text-xs">BurnCall Operations Dashboard</p>
            </div>
          </div>
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">Admin Only</Badge>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-white/10 pb-4">
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${tab === t ? "bg-[#FF6B2B]/20 text-[#FF6B2B]" : "text-slate-400 hover:text-white"}`}>{t}</button>
          ))}
        </div>

        {/* Overview */}
        {tab === "Overview" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Monthly Recurring Revenue", value: `$${totalMRR.toLocaleString()}`, sub: "+$2,450 vs last month", color: "text-green-400" },
                { label: "Active Accounts", value: activeAccounts, sub: `${trialAccounts} in trial`, color: "text-white" },
                { label: "Leads Processed", value: totalLeads.toLocaleString(), sub: "All accounts, all time", color: "text-blue-400" },
                { label: "AI API Calls (7d)", value: "731", sub: "~104/day average", color: "text-[#FF6B2B]" },
              ].map(m => (
                <div key={m.label} className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
                  <p className="text-xs text-slate-500 mb-1">{m.label}</p>
                  <p className={`text-2xl font-bold ${m.color}`}>{m.value}</p>
                  <p className="text-slate-500 text-xs mt-1">{m.sub}</p>
                </div>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
                <p className="text-sm font-semibold text-white mb-4">MRR Growth</p>
                <ResponsiveContainer width="100%" height={180}>
                  <LineChart data={MRR_TREND}>
                    <XAxis dataKey="month" stroke="#475569" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#475569" tick={{ fontSize: 11 }} tickFormatter={v => `$${v}`} />
                    <Tooltip contentStyle={{ backgroundColor: "#0A0F1E", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }} formatter={(v: number) => [`$${v.toLocaleString()}`, "MRR"]} />
                    <Line type="monotone" dataKey="mrr" stroke="#FF6B2B" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
                <p className="text-sm font-semibold text-white mb-4">AI Usage (7 days)</p>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={AI_USAGE}>
                    <XAxis dataKey="day" stroke="#475569" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#475569" tick={{ fontSize: 11 }} />
                    <Tooltip contentStyle={{ backgroundColor: "#0A0F1E", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }} />
                    <Bar dataKey="calls" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
              <p className="text-sm font-semibold text-white mb-4">Recent Account Activity</p>
              <div className="space-y-3">
                {[
                  { action: "Elite Electrical started free trial", time: "2 hours ago", type: "trial" },
                  { action: "Burke Air Conditioning upgraded Starter → Growth", time: "3 days ago", type: "upgrade" },
                  { action: "Green Lawn Care subscription cancelled", time: "5 days ago", type: "churn" },
                  { action: "Apex Restoration first lead processed", time: "1 week ago", type: "activity" },
                ].map((a, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm">
                    <div className={`h-2 w-2 rounded-full shrink-0 ${a.type === "upgrade" ? "bg-green-400" : a.type === "churn" ? "bg-red-400" : a.type === "trial" ? "bg-blue-400" : "bg-slate-500"}`} />
                    <span className="text-slate-300 flex-1">{a.action}</span>
                    <span className="text-slate-600 text-xs">{a.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Accounts */}
        {tab === "Accounts" && (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input placeholder="Search accounts..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-slate-500" />
              </div>
              {["All", "Active", "Trial", "Churned"].map(s => (
                <button key={s} onClick={() => setStatusFilter(s)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${statusFilter === s ? "bg-[#FF6B2B] text-white border-[#FF6B2B]" : "bg-white/5 text-slate-400 border-white/10 hover:text-white"}`}>{s}</button>
              ))}
            </div>
            <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-slate-400 text-xs uppercase tracking-wider">
                    <th className="p-4 text-left">Account</th>
                    <th className="p-4 text-left hidden md:table-cell">Industry</th>
                    <th className="p-4 text-left">Plan</th>
                    <th className="p-4 text-left">Status</th>
                    <th className="p-4 text-left hidden lg:table-cell">Leads</th>
                    <th className="p-4 text-left hidden lg:table-cell">MRR</th>
                    <th className="p-4 text-left hidden xl:table-cell">Joined</th>
                    <th className="p-4 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAccounts.map(acc => (
                    <tr key={acc.id} className="border-b border-white/5 hover:bg-white/[0.02]">
                      <td className="p-4">
                        <p className="text-white font-medium">{acc.name}</p>
                        <p className="text-slate-500 text-xs">{acc.email}</p>
                      </td>
                      <td className="p-4 hidden md:table-cell text-slate-400">{acc.industry}</td>
                      <td className="p-4">
                        <Badge className="text-xs bg-white/10 text-slate-300 border-white/10">{acc.plan}</Badge>
                      </td>
                      <td className="p-4">
                        <Badge className={`text-xs border ${STATUS_COLORS[acc.status]}`}>{acc.status}</Badge>
                      </td>
                      <td className="p-4 hidden lg:table-cell text-slate-300">{acc.leads}</td>
                      <td className="p-4 hidden lg:table-cell text-green-400 font-medium">{acc.mrr > 0 ? `$${acc.mrr}` : "—"}</td>
                      <td className="p-4 hidden xl:table-cell text-slate-500 text-xs">{acc.joined}</td>
                      <td className="p-4">
                        <Button size="sm" variant="outline" className="border-white/20 text-white text-xs h-7">View</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Automations */}
        {tab === "Automations" && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 mb-2">
              {[
                { label: "Total Triggers (30d)", value: "2,041" },
                { label: "Successful Completions", value: "1,973" },
                { label: "Failure Rate", value: "3.3%", color: "text-yellow-400" },
              ].map(m => (
                <div key={m.label} className="bg-[#0A0F1E] border border-white/10 rounded-xl p-4">
                  <p className="text-xs text-slate-500 mb-1">{m.label}</p>
                  <p className={`text-xl font-bold ${m.color || "text-white"}`}>{m.value}</p>
                </div>
              ))}
            </div>
            <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-slate-400 text-xs uppercase tracking-wider">
                    <th className="p-4 text-left">Automation</th>
                    <th className="p-4 text-left">Triggers</th>
                    <th className="p-4 text-left">Success</th>
                    <th className="p-4 text-left">Failures</th>
                    <th className="p-4 text-left">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {AUTOMATION_HEALTH.map((a, i) => (
                    <tr key={i} className="border-b border-white/5 hover:bg-white/[0.02]">
                      <td className="p-4 text-white">{a.name}</td>
                      <td className="p-4 text-slate-400">{a.triggers}</td>
                      <td className="p-4 text-green-400">{a.success}</td>
                      <td className="p-4">
                        {a.failures > 0 ? (
                          <span className="text-red-400 flex items-center gap-1"><AlertCircle className="h-3 w-3" />{a.failures}</span>
                        ) : <span className="text-slate-600">0</span>}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-white/10 rounded-full h-1.5 w-20">
                            <div className="bg-green-400 h-1.5 rounded-full" style={{ width: `${a.rate}%` }} />
                          </div>
                          <span className={`text-xs font-medium ${a.rate >= 98 ? "text-green-400" : a.rate >= 95 ? "text-yellow-400" : "text-red-400"}`}>{a.rate}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* AI Usage */}
        {tab === "AI Usage" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "API Calls (7d)", value: "731" },
                { label: "Tokens Used (7d)", value: "109.4K" },
                { label: "Avg Cost/Lead", value: "$0.04" },
                { label: "Monthly AI Spend", value: "$187" },
              ].map(m => (
                <div key={m.label} className="bg-[#0A0F1E] border border-white/10 rounded-xl p-4">
                  <p className="text-xs text-slate-500 mb-1">{m.label}</p>
                  <p className="text-xl font-bold text-white">{m.value}</p>
                </div>
              ))}
            </div>
            <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
              <p className="text-sm font-semibold text-white mb-4">Daily AI API Calls</p>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={AI_USAGE}>
                  <XAxis dataKey="day" stroke="#475569" tick={{ fontSize: 11 }} />
                  <YAxis stroke="#475569" tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ backgroundColor: "#0A0F1E", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }} />
                  <Bar dataKey="calls" fill="#FF6B2B" radius={[4, 4, 0, 0]} name="API Calls" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="bg-[#0A0F1E] border border-white/10 rounded-2xl p-5">
              <p className="text-sm font-semibold text-white mb-4">Token Usage by Day</p>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={AI_USAGE}>
                  <XAxis dataKey="day" stroke="#475569" tick={{ fontSize: 11 }} />
                  <YAxis stroke="#475569" tick={{ fontSize: 11 }} tickFormatter={v => `${(v / 1000).toFixed(0)}K`} />
                  <Tooltip contentStyle={{ backgroundColor: "#0A0F1E", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }} formatter={(v: number) => [`${v.toLocaleString()}`, "Tokens"]} />
                  <Bar dataKey="tokens" fill="#3B82F6" radius={[4, 4, 0, 0]} name="Tokens" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
